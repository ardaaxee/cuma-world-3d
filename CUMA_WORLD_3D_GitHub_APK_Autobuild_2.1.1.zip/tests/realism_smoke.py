from pathlib import Path
from PIL import Image
import re, sys

root = Path(__file__).resolve().parents[1]
errors=[]
required=[
    'scripts/world/realism_builder.gd',
    'scripts/world/npc_walker.gd',
    'scripts/world/traffic_car.gd',
    'scripts/world/living_world.gd',
    'assets/materials/plaster.png',
    'assets/materials/oak_floor.png',
    'assets/materials/asphalt.png',
    'assets/materials/concrete.png',
    'assets/materials/fabric.png',
    'assets/materials/stone.png',
]
for rel in required:
    if not (root/rel).is_file(): errors.append(f'missing realism asset: {rel}')
for rel in required:
    p=root/rel
    if p.suffix.lower()=='.png' and p.exists():
        try:
            with Image.open(p) as im:
                if im.size[0] < 256 or im.size[1] < 256: errors.append(f'texture too small: {rel}')
                im.verify()
        except Exception as exc:
            errors.append(f'invalid texture {rel}: {exc}')
main=(root/'scripts/main.gd').read_text(encoding='utf-8')
real=(root/'scripts/world/realism_builder.gd').read_text(encoding='utf-8')
player=(root/'scripts/player_controller.gd').read_text(encoding='utf-8')
remote=(root/'scripts/together/remote_avatar.gd').read_text(encoding='utf-8')
checks={
    'main realism call':'_build_realism_overhaul()' in main,
    'realism preload':'realism_builder.gd' in main,
    'organic local character':'procedural_humanoid.gd' in player,
    'organic remote character':'procedural_humanoid.gd' in remote,
    'walking residents':'NPCWalker' in real and real.count('Vector3(') > 80,
    'moving traffic':'TrafficCar' in real and 'quality_traffic' in real,
    'night lighting':'street_night_light' in real,
    'crowd performance':'quality_crowd' in real,
    'old placeholder removed':not (root/'assets/characters/cuma_placeholder.glb').exists(),
}
for name,ok in checks.items():
    if not ok: errors.append(f'failed check: {name}')
# Prototype interaction slabs should not be authored anymore.
for marker in ['_add_visual_box_to(terminal', '_add_visual_box_to(pickup', '_add_visual_box_to(market', '_add_visual_box_to(cinema']:
    if marker in main: errors.append(f'prototype marker still visible: {marker}')
if errors:
    print('REALISM SMOKE: FAIL')
    for e in errors: print('-',e)
    sys.exit(1)
print('REALISM SMOKE: PASS')
print('Material textures: 6')
print('Living residents: 8')
print('Moving traffic cars: 2')
print('Old block character asset: removed')
