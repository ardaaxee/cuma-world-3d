from pathlib import Path
import re
ROOT=Path(__file__).resolve().parents[1]
def read(p): return (ROOT/p).read_text(encoding='utf-8')

for f in [
    'server/dedicated_server.gd','server/dedicated_server.tscn','server/README.md',
    'scripts/city/online_relay_builder.gd','scripts/city/social_citizen.gd',
    'scripts/character/expression_driver.gd','docs/SECURITY_REVIEW_1.1.md'
]:
    assert (ROOT/f).exists(), f

project=read('project.godot')
assert 'NetworkManager=' in project and 'config/name="CUMA WORLD 3D' in project
main=read('scripts/main.gd')
assert 'OnlineRelayBuilderScript' in main and '_build_online_relay_11()' in main
assert 'is_dedicated_server' in main
net=read('scripts/network_manager.gd')
for token in ['WebSocketMultiplayerPeer.new()','host_dedicated_ws','join_relay','RELAY_PORT := 7008','MAX_RELAY_CLIENTS := 2','state_owner_peer_id','known_authorized_peers']:
    assert token in net, token
assert 'clean_url.begins_with("ws://")' in net and 'clean_url.begins_with("wss://")' in net
assert '_request_snapshot_upload' in net and '_submit_shared_snapshot' in net
# Every any_peer RPC except the auth entrypoint must authorize sender.
blocks=re.split(r'(?=@rpc\("any_peer")',net)[1:]
for block in blocks:
    head='\n'.join(block.splitlines()[:14])
    if 'func _submit_session_code' in head:
        continue
    assert '_peer_authorized' in head, 'Ungated any_peer RPC:\n'+head
ui=read('scripts/mobile_controls.gd')
assert 'relay_url_input' in ui and '_on_relay_join' in ui and 'net.join_relay' in ui
builder=read('scripts/city/online_relay_builder.gd')
ids=re.findall(r'_pair\("([^"]+)"',builder)
assert len(ids)==len(set(ids))==4, ids
assert builder.count('npc.name="SocialCitizen_') == 1
social=read('scripts/city/social_citizen.gd')
for token in ['_try_social_pause','social_citizen','play_emote("wave")']:
    assert token in social
hum=read('scripts/character/procedural_humanoid.gd')
for token in ['BrowL','BrowR','set_mood','_update_expression','smile_weight']:
    assert token in hum
server=read('server/dedicated_server.gd')
assert 'host_dedicated_ws' in server and 'res://scenes/main.tscn' in server
print('ONLINE RELAY 1.1 SMOKE: PASS')
