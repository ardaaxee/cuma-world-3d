from pathlib import Path
import re

ROOT = Path(__file__).resolve().parents[1]
violations = []
for path in ROOT.rglob("*.gd"):
    text = path.read_text(encoding="utf-8")
    material_vars = set(re.findall(r"\bvar\s+([A-Za-z_][A-Za-z0-9_]*)\s*=\s*_mat\s*\(", text))
    for name in material_vars:
        if re.search(rf"\b{re.escape(name)}\s*\.\s*(?:darkened|lightened)\s*\(", text):
            violations.append(f"{path.relative_to(ROOT)}: Color method called on material variable '{name}'")
if violations:
    raise SystemExit("MATERIAL API REGRESSION FAIL\n" + "\n".join(violations))
print("MATERIAL API REGRESSION 2.1.1: PASS")
