from pathlib import Path
import re

root = Path(__file__).resolve().parents[1]
builder = (root / "scripts/city/living_city_builder.gd").read_text(encoding="utf-8")
player = (root / "scripts/player_controller.gd").read_text(encoding="utf-8")
elevator = (root / "scripts/city/elevator.gd").read_text(encoding="utf-8")
traffic = (root / "scripts/world/traffic_car.gd").read_text(encoding="utf-8")
car = (root / "scripts/city/driveable_car.gd").read_text(encoding="utf-8")
main = (root / "scripts/main.gd").read_text(encoding="utf-8")

required = [
    "_build_market", "_build_cafe", "_build_cinema", "_build_arcade",
    "_build_apartment_and_elevator", "_build_city_park", "_build_traffic_signals",
    "_build_driveable_car", "_build_citizens", "_build_city_blocks"
]
for token in required:
    assert token in builder, token

activities = re.findall(r'_pair_activity\("([^"]+)"', builder)
assert len(activities) >= 7, activities
assert len(activities) == len(set(activities)), "duplicate city activity id"
assert "LivingCityBuilderScript" in main and "_build_living_city_08()" in main
assert "enter_vehicle" in player and "get_drive_input" in player and "update_vehicle_anchor" in player
assert "net.is_online()" in car and "request_vehicle_seat" in car and "publish_vehicle_state" in car
assert "register_world_interactable" in elevator and "request_world_action" in elevator
assert "_intersection_red" in traffic
assert (root / "assets/audio/city_ambience.wav").exists()
assert (root / "assets/audio/city_ambience.wav").stat().st_size > 100_000

print("LIVING CITY SMOKE: PASS")
print("New city duo activities:", len(activities))
print("District systems: interiors, elevator, traffic signals, driveable car, park, citizens, ambience")
