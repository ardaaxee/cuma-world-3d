from pathlib import Path
import re
ROOT = Path(__file__).resolve().parents[1]
project = (ROOT/'project.godot').read_text()
main = (ROOT/'scripts/main.gd').read_text()
gs = (ROOT/'scripts/game_state.gd').read_text()
builder = (ROOT/'scripts/city/social_life_builder.gd').read_text()
npc = (ROOT/'scripts/social/relationship_citizen.gd').read_text()
ui = (ROOT/'scripts/ui/social_interaction_ui.gd').read_text()
phone = (ROOT/'scripts/ui/phone_ui.gd').read_text()
director = (ROOT/'scripts/social/social_world_director.gd').read_text()

assert 'config/name="CUMA WORLD 3D' in project
assert 'SocialLifeBuilderScript' in main and '_build_social_life_12()' in main
assert 'SocialInteractionUIScript' in main and '_build_social_ui_12()' in main
for token in ['social_relationships', 'social_memories', 'social_feed', 'npc_bonds', 'perform_social_action', 'register_npc_bond', 'advance_npc_bond']:
    assert token in gs, token
for action in ['"greet"', '"chat"', '"compliment"', '"coffee"', '"walk"', '"gift"', '"date"', '"relationship"', '"apologize"']:
    assert action in gs, action
assert 'romance_available' in gs and 'romance_available":false' in builder
assert 'friendship < 48.0' in gs and 'affection < 40.0' in gs
assert 'friendship >= 70.0' in gs and 'affection >= 68.0' in gs
ids = re.findall(r'"id":"([a-z_]+)"', builder)
assert len(ids) >= 8 and len(ids) == len(set(ids)), ids
for name in ['Ece','Deniz','Selin','Mert','İpek','Kerem','Elif','Baran']:
    assert f'"name":"{name}"' in builder
assert 'register_npc_bond("elif", "baran", 92.0, true)' in builder
assert 'register_npc_bond("ipek", "deniz", 70.0, true)' in builder
assert 'relationship_npc' in npc and 'get_current_activity' in npc and 'react_to_social_result' in npc
assert 'open_contacts' in ui and 'open_for_npc' in ui
assert 'SOSYAL • KOMŞULAR / ARKADAŞLAR' in phone
assert '_simulate_hour' in director and 'advance_npc_bond' in director
# Player-specific NPC relationships must not be included in shared multiplayer snapshot.
snapshot = gs.split('func get_shared_snapshot() -> Dictionary:',1)[1].split('func apply_shared_snapshot',1)[0]
assert 'social_relationships' not in snapshot and 'npc_bonds' not in snapshot
# New co-op neighborhood activities.
new_pair_ids = re.findall(r'_pair\("([a-z0-9_]+)"', builder)
assert len(new_pair_ids) >= 6 and len(new_pair_ids) == len(set(new_pair_ids))
print('SOCIAL LIFE 1.2 SMOKE: PASS')
print('Named neighbors:', len(ids))
print('New neighborhood duo activities:', len(new_pair_ids))
