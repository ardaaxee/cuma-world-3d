from pathlib import Path
import re, sys, wave
root=Path(__file__).resolve().parents[1]
errors=[]
required=[
 'scripts/character/procedural_humanoid.gd',
 'scripts/imported_character_bridge.gd',
 'assets/audio/footstep_a.wav',
 'assets/audio/footstep_b.wav',
]
for rel in required:
    if not (root/rel).is_file(): errors.append(f'missing animation asset: {rel}')
rig=(root/'scripts/character/procedural_humanoid.gd').read_text(encoding='utf-8')
player=(root/'scripts/player_controller.gd').read_text(encoding='utf-8')
remote=(root/'scripts/together/remote_avatar.gd').read_text(encoding='utf-8')
npc=(root/'scripts/world/npc_walker.gd').read_text(encoding='utf-8')
bridge=(root/'scripts/imported_character_bridge.gd').read_text(encoding='utf-8')
checks={
 'separate elbow joints': 'side + "Elbow"' in rig and 'left_elbow' in rig and 'right_elbow' in rig,
 'separate knee joints': 'side + "Knee"' in rig and 'left_knee' in rig and 'right_knee' in rig,
 'blink system':'_update_blink' in rig,
 'breathing':('breath :=' in rig or 'breath =' in rig),
 'jump/fall pose':'_pose_air' in rig,
 'sit pose':'_pose_sit' in rig,
 'emotes':'play_emote' in rig,
 'local player rig':'CumaOrganicRig' in player,
 'partner rig':'PartnerOrganicRig' in remote,
 'npc pauses':'pause_until' in npc,
 'glb animation aliases': all(x in bridge for x in ['"Idle"','"Walk"','"Run"','"Jump"','"Sit"']),
 'partner glb slot':'assets/characters/partner.glb' in remote,
}
for name,ok in checks.items():
    if not ok: errors.append(f'failed check: {name}')
for rel in ['assets/audio/footstep_a.wav','assets/audio/footstep_b.wav']:
    try:
        with wave.open(str(root/rel),'rb') as w:
            if w.getnchannels()!=1 or w.getframerate()<16000 or w.getnframes()<1000:
                errors.append(f'invalid footstep wav: {rel}')
    except Exception as e:
        errors.append(f'bad wav {rel}: {e}')
if errors:
    print('ANIMATION SMOKE: FAIL')
    for e in errors: print('-',e)
    sys.exit(1)
print('ANIMATION SMOKE: PASS')
print('Rig features: articulated elbows/knees, idle breathing, blink, jump/fall, sit, emotes')
print('Character slots: cuma.glb + partner.glb')
print('Ambient residents: 8')
