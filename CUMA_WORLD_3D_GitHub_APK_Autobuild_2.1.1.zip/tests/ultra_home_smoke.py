from pathlib import Path
from PIL import Image
import re, sys
root=Path(__file__).resolve().parents[1]
errors=[]
required=[
 'scripts/world/ultra_home_builder.gd',
 'scripts/world/curtain_controller.gd',
 'scripts/world/cabinet_door.gd',
 'scripts/world/home_ambience.gd',
 'assets/materials/porcelain_tile.png',
 'assets/materials/walnut.png',
 'assets/materials/linen.png',
 'assets/materials/marble.png',
 'assets/materials/backsplash.png',
]
for rel in required:
    if not (root/rel).is_file(): errors.append(f'missing ultra-home asset: {rel}')
for rel in required:
    p=root/rel
    if p.suffix=='.png' and p.exists():
        try:
            with Image.open(p) as im:
                if min(im.size)<512: errors.append(f'texture under 512: {rel}')
                im.verify()
        except Exception as e: errors.append(f'bad texture {rel}: {e}')
main=(root/'scripts/main.gd').read_text(encoding='utf-8')
ultra=(root/'scripts/world/ultra_home_builder.gd').read_text(encoding='utf-8')
door=(root/'scripts/door.gd').read_text(encoding='utf-8')
cab=(root/'scripts/world/cabinet_door.gd').read_text(encoding='utf-8')
cur=(root/'scripts/world/curtain_controller.gd').read_text(encoding='utf-8')
checks={
 'main ultra call':'_build_ultra_home_07()' in main and 'ultra_home_builder.gd' in main,
 'interactive kitchen cabinets': ultra.count('_add_cabinet(')>=3 and 'register_world_interactable' in cab,
 'interactive curtains': ultra.count('_make_interactive_curtain(')>=4 and 'register_world_interactable' in cur,
 'bath wet zone':'Frameless shower screen' in ultra,
 'balcony deck':'Narrow deck boards' in ultra,
 'entry life':'Shoe rack' in ultra and 'Coat rack' in ultra,
 'door joinery':'recessed panels' in door and 'lever handle' in door,
 'home ambience':'home_soft_motion' in ultra and 'home_clock_hand' in ultra,
 'quality-scaled practical lights': ultra.count('quality_extra_light') >= 2,
 'no prototype visible markers':'_add_visual_box_to' not in ultra,
}
for k,v in checks.items():
    if not v: errors.append(f'failed check: {k}')
if errors:
    print('ULTRA HOME SMOKE: FAIL')
    for e in errors: print('-',e)
    sys.exit(1)
print('ULTRA HOME SMOKE: PASS')
print('New material textures: 5')
print('Functional cabinet families: upper + lower')
print('Interactive curtain zones: 3')
