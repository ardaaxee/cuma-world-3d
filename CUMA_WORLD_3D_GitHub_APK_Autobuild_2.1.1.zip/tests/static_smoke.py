from pathlib import Path
import re, sys
root=Path(__file__).resolve().parents[1]
errors=[]
optional={'assets/characters/cuma.glb','assets/characters/partner.glb'}
# project basics
for rel in ['project.godot','scenes/main.tscn','scripts/main.gd','scripts/game_state.gd','scripts/network_manager.gd']:
    if not (root/rel).is_file(): errors.append(f'missing required file: {rel}')
# res refs
for p in root.rglob('*.gd'):
    text=p.read_text(encoding='utf-8')
    if not text.lstrip().startswith('extends '): errors.append(f'{p}: missing extends')
    funcs=re.findall(r'^func\s+([A-Za-z0-9_]+)',text,re.M)
    for f in set(funcs):
        if funcs.count(f)>1: errors.append(f'{p}: duplicate func {f}')
    for m in re.finditer(r'res://([^"\']+)',text):
        rel=m.group(1)
        if rel not in optional and not (root/rel).exists(): errors.append(f'{p}: missing res://{rel}')
# delimiter balance (approx, strings/comments stripped)
def stripped(text):
    out=[]
    for line in text.splitlines():
        line=line.split('#',1)[0]
        line=re.sub(r'"(?:\\.|[^"\\])*"', '""', line)
        out.append(line)
    return '\n'.join(out)
for p in root.rglob('*.gd'):
    t=stripped(p.read_text(encoding='utf-8'))
    for a,b in [('(',')'),('[',']'),('{','}')]:
        if t.count(a)!=t.count(b): errors.append(f'{p}: unbalanced {a}{b}: {t.count(a)} vs {t.count(b)}')
# security checks
alltext='\n'.join(p.read_text(encoding='utf-8',errors='ignore') for p in root.rglob('*') if p.is_file() and p.suffix in {'.gd','.godot','.md','.tscn'})
patterns=[r'sk-[A-Za-z0-9_-]{20,}',r'AIza[0-9A-Za-z_-]{20,}',r'BEGIN PRIVATE KEY',r'REPLICATE_API_TOKEN\s*=\s*[^\s]']
for pat in patterns:
    if re.search(pat,alltext): errors.append(f'possible embedded secret matching {pat}')
# together feature expectations
main=(root/'scripts/main.gd').read_text(encoding='utf-8')
activities=re.findall(r'_add_pair_activity\("([^"]+)"',main)
if len(set(activities))<15: errors.append(f'expected >=15 duo activities, found {len(set(activities))}')
network=(root/'scripts/network_manager.gd').read_text(encoding='utf-8')
for required in ['MAX_CLIENTS := 1','PAIR_DISTANCE','_server_pair_ready','_server_world_action','_sanitize_chat','_receive_shared_snapshot']:
    if required not in network: errors.append(f'network missing {required}')
if errors:
    print('STATIC SMOKE: FAIL')
    for e in errors: print('-',e)
    sys.exit(1)
print('STATIC SMOKE: PASS')
print('GDScript files:',len(list(root.rglob('*.gd'))))
print('Duo activities:',len(set(activities)))
print('Unique activity ids:',', '.join(sorted(set(activities))))
