from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]

def strip_strings_comments(s):
    out=[]; quote=None; esc=False
    for line in s.splitlines():
        row=[]; quote=None; esc=False
        for ch in line:
            if quote:
                if esc: esc=False
                elif ch=='\\': esc=True
                elif ch==quote: quote=None
                row.append(' ')
            else:
                if ch in ('"',"'"): quote=ch; row.append(' ')
                elif ch=='#': break
                else: row.append(ch)
        out.append(''.join(row))
    return '\n'.join(out)

pairs={')':'(',']':'[','}':'{'}
for p in ROOT.rglob('*.gd'):
    text=strip_strings_comments(p.read_text(encoding='utf-8'))
    stack=[]
    for i,ch in enumerate(text):
        if ch in '([{': stack.append(ch)
        elif ch in ')]}':
            if not stack or stack[-1]!=pairs[ch]: raise SystemExit(f'Bracket mismatch {p}:{i}')
            stack.pop()
    if stack: raise SystemExit(f'Unclosed bracket {p}: {stack[-10:]}')
    for line_no,line in enumerate(text.splitlines(),1):
        if line.strip().startswith('func ') and not line.rstrip().endswith(':'):
            raise SystemExit(f'Function header missing colon {p}:{line_no}')
print('GDSCRIPT SANITY: PASS')
