from pathlib import Path
import re
from collections import Counter

ROOT = Path(__file__).resolve().parents[1]
func_re = re.compile(r'^func\s+([A-Za-z_][A-Za-z0-9_]*)\s*\(', re.M)
pair_re = re.compile(r'\b(?:_pair|_add_pair_activity)\(\s*"([A-Za-z0-9_\-]+)"')

all_pairs=[]
for p in ROOT.rglob('*.gd'):
    text=p.read_text(encoding='utf-8')
    names=func_re.findall(text)
    dup=[n for n,c in Counter(names).items() if c>1]
    assert not dup, f'duplicate funcs {p.relative_to(ROOT)}: {dup}'
    assert ' is not ' not in text, f'unsupported/suspicious is not syntax: {p.relative_to(ROOT)}'
    for lineno,line in enumerate(text.splitlines(),1):
        assert '; if ' not in line and '; elif ' not in line and '; for ' not in line, f'suspicious compound statement {p.relative_to(ROOT)}:{lineno}'
    all_pairs += pair_re.findall(text)

counts=Counter(all_pairs)
dups={k:v for k,v in counts.items() if v>1}
assert not dups, f'duplicate pair ids: {dups}'
assert len(all_pairs) >= 64, len(all_pairs)

# Scan source/config only; docs may intentionally mention example secret terms.
secret_patterns = [
    re.compile(r'-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----'),
    re.compile(r'\bsk-[A-Za-z0-9_-]{20,}\b'),
    re.compile(r'\bghp_[A-Za-z0-9]{20,}\b'),
    re.compile(r'\bAKIA[0-9A-Z]{16}\b'),
]
for p in list((ROOT/'scripts').rglob('*')) + [ROOT/'project.godot']:
    if not p.is_file():
        continue
    text=p.read_text(encoding='utf-8', errors='ignore')
    for pat in secret_patterns:
        assert not pat.search(text), f'possible embedded secret: {p.relative_to(ROOT)}'

print('SOURCE INTEGRITY 1.8: PASS')
print('Pair activity IDs:', len(all_pairs), 'unique')
