from pathlib import Path
root=Path(__file__).resolve().parents[1]
required=[
    'scripts/city/human_behavior_builder.gd',
    'scripts/social/human_behavior_director.gd',
]
for rel in required:
    assert (root/rel).exists(), rel
main=(root/'scripts/main.gd').read_text()
cit=(root/'scripts/social/relationship_citizen.gd').read_text()
builder=(root/'scripts/city/human_behavior_builder.gd').read_text()
director=(root/'scripts/social/human_behavior_director.gd').read_text()
ui=(root/'scripts/ui/social_interaction_ui.gd').read_text()
gs=(root/'scripts/game_state.gd').read_text()
scheduled=(root/'scripts/city/scheduled_citizen.gd').read_text()
assert '_build_human_behavior_15()' in main
assert main.index('_build_physical_ai_14()') < main.index('_build_human_behavior_15()') < main.index('_build_social_life_12()')
assert 'checkout_queue' in builder and 'cafe_wait' in builder and 'restaurant_wait' in builder
assert 'guest_door' in builder and 'group_seat' in builder and 'phone_stop' in builder
assert 'ShoppingBasket' in cit and 'PhoneProp' in cit
assert '_reserve_nearest_spot("checkout_queue"' in cit
assert 'Kasada sırasını bekliyor' in cit
assert 'Masa boşalmasını bekliyor' in cit
assert 'start_phone_break' in cit and 'set_group_table_plan' in cit
assert 'home_visit' in cit and 'Kapıda seni bekliyor' in cit
assert 'EVE UĞRAMAYA DAVET ET' in ui and 'home_visit' in gs
assert 'ambient_city_citizen' in scheduled and 'set_crowd_factor' in scheduled
assert all(x in director for x in ['_maybe_phone_break','_maybe_friend_visit','_maybe_spontaneous_message','_maybe_group_table','_update_crowd_rhythm'])
assert '@rpc' not in builder and '@rpc' not in director
print('HUMAN BEHAVIOR 1.5 SMOKE: PASS')
print('Behavior: phone breaks + shopping basket + checkout/venue queues + home visits')
print('City rhythm: rush-hour crowd scaling + spontaneous messages + group tables')
