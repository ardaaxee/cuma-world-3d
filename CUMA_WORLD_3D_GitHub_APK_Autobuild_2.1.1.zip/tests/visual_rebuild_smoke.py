from pathlib import Path
root=Path(__file__).resolve().parents[1]
main=(root/'scripts/main.gd').read_text()
realism=(root/'scripts/world/realism_builder.gd').read_text()
player=(root/'scripts/player_controller.gd').read_text()
ui=(root/'scripts/mobile_controls.gd').read_text()
hum=(root/'scripts/character/procedural_humanoid.gd').read_text()
assert 'long rods sticking out of corridor walls' in realism
assert 'toggle_camera_mode' in player
assert 'first_person = true' in player
assert 'camera_spring.spring_length = 4.85' in player
assert 'CUMA WORLD' in ui
assert 'var signal =' not in '\n'.join(p.read_text(errors='ignore') for p in root.rglob('*.gd'))
assert 'ProductionHomeBuilderScript' in main
assert 'Vector3(0.175, 0.225, 0.17)' in hum
print('VISUAL REBUILD / PRODUCTION COMPAT: PASS')
