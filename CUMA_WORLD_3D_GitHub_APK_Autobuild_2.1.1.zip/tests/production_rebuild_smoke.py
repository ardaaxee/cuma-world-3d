from pathlib import Path
import re
ROOT=Path(__file__).resolve().parents[1]
project=(ROOT/'project.godot').read_text(encoding='utf-8')
main=(ROOT/'scripts/main.gd').read_text(encoding='utf-8')
player=(ROOT/'scripts/player_controller.gd').read_text(encoding='utf-8')
ui=(ROOT/'scripts/mobile_controls.gd').read_text(encoding='utf-8')
pair=(ROOT/'scripts/together/pair_activity.gd').read_text(encoding='utf-8')
home=(ROOT/'scripts/world/production_home_builder.gd').read_text(encoding='utf-8')
city=(ROOT/'scripts/world/production_city_polish.gd').read_text(encoding='utf-8')
assert 'PRODUCTION REBUILD 2.1' in project
assert 'ProductionHomeBuilderScript' in main and '_build_production_home_21()' in main
assert 'ProductionCityPolishScript' in main and '_build_production_city_polish_21()' in main
assert 'first_person = true' in player
assert 'camera.fov = 72.0' in player
assert 'interaction_ray.target_position = Vector3(0.0, 0.0, -3.4)' in player
assert 'CUMA WORLD' in ui and 'VISUAL REBUILD 2.0' not in ui
assert 'child.visible = false' in pair
assert 'ProductionHome21' in home and '_hide_legacy_visuals' in home
assert 'ProductionCityPolish21' in city and '_reskin_legacy_shops' in city
tex_dir=ROOT/'assets/materials/production'
textures=sorted(tex_dir.glob('*.png'))
assert len(textures)==10, len(textures)
for name in ['plaster','oak','fabric','stone','tile']:
    assert (tex_dir/f'{name}_albedo.png').exists()
    assert (tex_dir/f'{name}_normal.png').exists()
print('PRODUCTION REBUILD 2.1: PASS')
print('Production textures:', len(textures))
