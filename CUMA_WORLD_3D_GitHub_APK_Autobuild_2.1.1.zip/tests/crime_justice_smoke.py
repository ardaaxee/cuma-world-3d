from pathlib import Path
import re

ROOT = Path(__file__).resolve().parents[1]
main = (ROOT/'scripts/main.gd').read_text(encoding='utf-8')
gs = (ROOT/'scripts/game_state.gd').read_text(encoding='utf-8')
builder = (ROOT/'scripts/city/crime_justice_builder.gd').read_text(encoding='utf-8')
cyber = (ROOT/'scripts/crime/cyber_puzzle_ui.gd').read_text(encoding='utf-8')
steal = (ROOT/'scripts/crime/stealable_item.gd').read_text(encoding='utf-8')
officer = (ROOT/'scripts/crime/law_officer.gd').read_text(encoding='utf-8')
director = (ROOT/'scripts/crime/law_director.gd').read_text(encoding='utf-8')
phone = (ROOT/'scripts/ui/phone_ui.gd').read_text(encoding='utf-8')
nav = (ROOT/'scripts/navigation/physical_navigation_world.gd').read_text(encoding='utf-8')

required = [
    'scripts/city/crime_justice_builder.gd',
    'scripts/crime/security_camera.gd',
    'scripts/crime/stealable_item.gd',
    'scripts/crime/cyber_terminal.gd',
    'scripts/crime/cyber_puzzle_ui.gd',
    'scripts/crime/police_desk.gd',
    'scripts/crime/law_director.gd',
    'scripts/crime/law_officer.gd',
    'scripts/crime/patrol_vehicle.gd',
    'scripts/crime/law_hud.gd',
]
for rel in required:
    assert (ROOT/rel).is_file(), rel

assert 'CrimeJusticeBuilderScript' in main and '_build_crime_justice_19()' in main
assert 'CyberPuzzleUIScript' in main and '_build_cyber_ui_19()' in main
assert 'LawHUDScript' in main and '_build_law_hud_19()' in main

for token in ['law_heat', 'outstanding_fine', 'crime_record', 'stolen_goods', 'cyber_xp',
              'commit_game_crime', 'resolve_arrest', 'complete_cyber_puzzle',
              'get_law_summary', 'get_cyber_summary']:
    assert token in gs, token

assert 'SAVE_PATH := "user://cuma_world_save_v19.cfg"' in gs
assert 'cuma_world_save_v18.cfg' in gs

# Local law/cyber progression must never enter the shared multiplayer state.
snapshot = gs.split('func get_shared_snapshot() -> Dictionary:',1)[1].split('func apply_shared_snapshot',1)[0]
for forbidden in ['law_heat', 'crime_record', 'stolen_goods', 'cyber_xp', 'outstanding_fine']:
    assert forbidden not in snapshot, forbidden

# The "hacking" game is explicitly an abstract node puzzle, not real networking/exploit logic.
for forbidden in ['socket', 'port scan', 'sql injection', 'credential', 'password dump', 'nmap', 'metasploit', 'ssh ', 'http://', 'https://']:
    assert forbidden not in cyber.lower(), forbidden
assert 'Gerçek ağ/komut yok' in cyber
assert 'NODE' in cyber and 'sequence' in cyber
assert 'shadow_grid' in cyber and 'commit_game_crime' in cyber

# Theft is abstract risk/detection with consequences, not lock/alarm bypass instructions.
assert 'security_camera' in steal and 'witness_bonus' in steal and 'commit_game_crime' in steal
for forbidden in ['lockpick', 'bypass alarm', 'disable camera', 'pick lock']:
    assert forbidden not in steal.lower(), forbidden

# Police/FIB response is non-violent detention; no weapon/combat implementation in the new subsystem.
assert ('threshold := 4 if federal else 2' in officer) or ('threshold = 4 if federal else 2' in officer)
assert 'detain_player' in officer and 'resolve_arrest' in director
crime_source = '\n'.join(p.read_text(encoding='utf-8') for p in (ROOT/'scripts/crime').glob('*.gd')).lower()
for forbidden in ['gun', 'rifle', 'bullet', 'shoot(', 'weapon']:
    assert forbidden not in crime_source, forbidden

# World content and navigation integration.
for label in ['CUMA POLICE', 'FEDERAL INVESTIGATION BUREAU', 'CITY COURT', 'CUMA CYBER LAB', 'CUMA BANK']:
    assert label in builder, label
assert 'HomeCyberComputer' in builder
assert '_child_box(desk' in builder, 'police desk visual must not occlude its interactable collider'
assert 'Both street-facing sides have a real doorway' in builder
assert ('door_width := 2.2' in builder) or ('door_width = 2.2' in builder)
assert builder.count('_stealable(') >= 4
assert builder.count('_officer(') >= 4
assert 'PolicePatrolCar' in builder
assert 'JusticeDistrict' in nav and 'JusticeConnector' in nav
assert 'Yasa:' in phone and 'Cyber:' in phone

pair_ids = re.findall(r'_pair\("([a-z0-9_]+)"', builder)
assert len(pair_ids) >= 4 and len(pair_ids) == len(set(pair_ids))

# New local systems must not widen network RPC surface.
for rel in required:
    text = (ROOT/rel).read_text(encoding='utf-8')
    assert '@rpc(' not in text, f'new crime system widened RPC surface: {rel}'

print('CRIME & JUSTICE 1.9 SMOKE: PASS')
print('New civic duo activities:', len(pair_ids))
print('Systems: police + fictional federal bureau + wanted heat + cameras + abstract theft + fictional cyber puzzle')
