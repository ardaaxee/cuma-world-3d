from pathlib import Path
import re
ROOT=Path(__file__).resolve().parents[1]
missing=[]
for p in ROOT.rglob('*'):
    if not p.is_file() or p.suffix not in {'.gd','.tscn','.cfg'}: continue
    text=p.read_text(encoding='utf-8',errors='ignore')
    for ref in re.findall(r'res://[A-Za-z0-9_./-]+',text):
        rel=ref[6:]
        # generated/import sidecars are not referenced by source in this project.
        if not (ROOT/rel).exists() and rel not in {'assets/characters/cuma.glb','assets/characters/partner.glb'}: missing.append((str(p.relative_to(ROOT)),ref))
if missing:
    for item in missing: print('MISSING',item)
    raise SystemExit(1)
print('RESOURCE REFERENCES: PASS')
