from pathlib import Path
root=Path(__file__).resolve().parents[1]
required=[
 'scripts/social/daily_life_director.gd',
 'scripts/city/daily_life_builder.gd',
]
for rel in required:
    assert (root/rel).exists(), rel
main=(root/'scripts/main.gd').read_text(encoding='utf-8')
cit=(root/'scripts/social/relationship_citizen.gd').read_text(encoding='utf-8')
director=(root/'scripts/social/daily_life_director.gd').read_text(encoding='utf-8')
builder=(root/'scripts/city/daily_life_builder.gd').read_text(encoding='utf-8')
gs=(root/'scripts/game_state.gd').read_text(encoding='utf-8')
phone=(root/'scripts/ui/phone_ui.gd').read_text(encoding='utf-8')
project=(root/'project.godot').read_text(encoding='utf-8')
assert 'CUMA WORLD 3D •' in project
assert 'DailyLifeBuilderScript' in main and '_build_daily_life_16()' in main
assert main.index('_build_npc_intelligence_13()') < main.index('_build_daily_life_16()')
for token in ['HOME_TARGETS','BIRTHDAY_DAY','_maybe_home_routine','_maybe_phone_call','_maybe_weekend_plan','_maybe_birthday','get_daily_summary']:
    assert token in director, token
for token in ['KOMŞU EVLERİ','home_life','meal_order','weekend_meet','_build_open_apartment','weekend_brunch','weekly_grocery','neighbor_celebration','cook_for_guests']:
    assert token in builder, token
for token in ['ShoppingBag','MealTray','start_phone_call','set_home_life_plan','set_weekend_plan','set_celebration_plan','get_daily_life_state','Siparişini aldı; yemek yiyor']:
    assert token in cit, token
for token in ['daily_life_events','add_daily_life_event','get_daily_life_summary','get_weekday_name']:
    assert token in gs, token
snapshot=gs.split('func get_shared_snapshot() -> Dictionary:',1)[1].split('func apply_shared_snapshot',1)[0]
assert 'daily_life_events' not in snapshot
assert 'daily_life_director' in phone and 'Günlük yaşam:' in phone
assert '@rpc' not in director and '@rpc' not in builder
print('DAILY LIFE 1.6 SMOKE: PASS')
print('Daily behavior: homes + weekends + birthdays + calls + visible shopping/meal props')
print('Privacy: daily-life diary remains local and outside shared multiplayer snapshot')
