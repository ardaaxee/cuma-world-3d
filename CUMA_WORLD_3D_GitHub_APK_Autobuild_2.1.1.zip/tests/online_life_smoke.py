from pathlib import Path
import re
root = Path(__file__).resolve().parents[1]
main = (root/'scripts/main.gd').read_text(encoding='utf-8')
net = (root/'scripts/network_manager.gd').read_text(encoding='utf-8')
car = (root/'scripts/city/driveable_car.gd').read_text(encoding='utf-8')
weather = (root/'scripts/world/weather_manager.gd').read_text(encoding='utf-8')
phone = (root/'scripts/ui/phone_ui.gd').read_text(encoding='utf-8')
builder = (root/'scripts/city/online_life_builder.gd').read_text(encoding='utf-8')
gs = (root/'scripts/game_state.gd').read_text(encoding='utf-8')

for token in ['_build_online_life_09()', '_build_weather_09()', '_build_phone_09()', 'OnlineLifeBuilderScript', 'WeatherManagerScript', 'PhoneUIScript']:
    assert token in main, token
for token in ['register_vehicle', 'request_vehicle_seat', 'request_vehicle_leave', 'submit_vehicle_input', 'publish_vehicle_state', '@rpc("authority"', 'VEHICLE_DISTANCE']:
    assert token in net, token
for token in ['driver_peer_id', 'passenger_peer_id', '_physics_networked', 'interpolate_with', 'submit_vehicle_input']:
    assert token in car, token
for token in ['CLEAR', 'CLOUDY', 'RAIN', 'request_weather', 'weather_mode_received']:
    assert token in weather or token in net, token
assert 'weather_mode' in gs and 'get_shared_snapshot' in gs and 'cfg.set_value("world", "weather_mode"' in gs
for token in ['CUMA PHONE', 'HAVAYI DEĞİŞTİR', 'PARTNERE: BURAYA GEL', 'OYUNU KAYDET']:
    assert token in phone, token
for token in ['_build_restaurant', '_build_clothing_store', '_build_bookshop', '_build_riverside_walk', '_build_scheduled_citizens']:
    assert token in builder, token
activities = re.findall(r'_pair\("([^"]+)"', builder)
assert len(activities) >= 7 and len(activities) == len(set(activities)), activities
assert builder.count('ScheduledCitizen_') >= 1 and 'for i in range(sets.size())' in builder
print('ONLINE LIFE 0.9 SMOKE: PASS')
print('New 0.9 duo activities:', len(activities))
print('Systems: host-authoritative 2-seat car, shared weather, phone, scheduled citizens, new interiors')
