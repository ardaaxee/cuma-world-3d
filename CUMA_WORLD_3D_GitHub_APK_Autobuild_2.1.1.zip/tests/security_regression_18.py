from pathlib import Path
import re

ROOT = Path(__file__).resolve().parents[1]
net = (ROOT/'scripts/network_manager.gd').read_text()
gs = (ROOT/'scripts/game_state.gd').read_text()
relationship = (ROOT/'scripts/social/relationship_citizen.gd').read_text()
transport = (ROOT/'scripts/city/public_transport_vehicle.gd').read_text()
new_local = [
    ROOT/'scripts/city/dynamic_city_builder.gd', ROOT/'scripts/city/professional_citizen.gd',
    ROOT/'scripts/city/event_guest.gd', ROOT/'scripts/social/dynamic_city_director.gd',
    ROOT/'scripts/economy/career_terminal.gd', ROOT/'scripts/character/hair_salon_station.gd',
    ROOT/'scripts/city/activity_station.gd'
]

assert 'ALLOW_DEDICATED_CLIENT_SNAPSHOT_BOOTSTRAP := false' in net
assert 'AUTH_FAILURE_WINDOW_MS' in net and 'MAX_AUTH_FAILURES_PER_WINDOW' in net
assert 'Wrong-code peers are disconnected immediately' in net
assert 'value.basis.determinant()' in net and 'axis.is_finite()' in net
m = re.search(r'SAVE_PATH := "user://cuma_world_save_v(\d+)\.cfg"', gs)
assert m and int(m.group(1)) >= 18, 'save version regressed below v18' 
assert '_sanitize_inventory' in gs and '_sanitize_world_states' in gs and '_safe_world_position' in gs
assert 'quality_crowd' not in relationship, 'named social NPCs must remain gameplay-visible in LOW'
assert 'quality_traffic' not in transport, 'public transit is gameplay, not ambient traffic'
for p in new_local:
    assert '@rpc(' not in p.read_text(), f'new local system widened RPC surface: {p.name}'

# Sensitive/personal progression must not enter the shared multiplayer snapshot.
start = gs.index('func get_shared_snapshot()')
end = gs.index('func apply_shared_snapshot', start)
snapshot = gs[start:end]
for forbidden in ['social_relationships', 'social_memories', 'npc_bonds', 'daily_life_events', 'career_xp', 'hair_style', 'money', 'inventory', 'law_heat', 'crime_record', 'stolen_goods', 'cyber_xp']:
    assert forbidden not in snapshot, forbidden

# Every gameplay any_peer RPC after session auth must include authorization before mutation.
lines = net.splitlines()
for i, line in enumerate(lines):
    if '@rpc("any_peer"' not in line:
        continue
    block = '\n'.join(lines[i:i+18])
    if '_submit_session_code' in block:
        continue
    assert '_peer_authorized' in block, f'RPC at line {i+1} lacks peer authorization nearby'

print('SECURITY REGRESSION 1.8: PASS')
