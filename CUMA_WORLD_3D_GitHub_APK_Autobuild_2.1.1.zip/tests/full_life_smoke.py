from pathlib import Path
import re, sys
ROOT=Path(__file__).resolve().parents[1]

def read(rel): return (ROOT/rel).read_text(encoding='utf-8')

required=[
 'scripts/story/story_manager.gd','scripts/economy/shop_terminal.gd','scripts/economy/work_shift.gd',
 'scripts/character/customization_station.gd','scripts/city/full_life_builder.gd'
]
for f in required:
    assert (ROOT/f).exists(), f'Missing {f}'
project=read('project.godot')
assert 'StoryManager=' in project and 'CUMA WORLD 3D' in project
main=read('scripts/main.gd')
assert '_build_full_life_10()' in main and 'FullLifeBuilderScript' in main
gs=read('scripts/game_state.gd')
for token in ['story_chapter','story_flags','owned_outfits','selected_outfit','character_style','get_character_palette','unlock_outfit']:
    assert token in gs, token
story=read('scripts/story/story_manager.gd')
assert story.count('"title":"Bölüm') == 5
builder=read('scripts/city/full_life_builder.gd')
for token in ['OutfitRose','CafeShift','CharacterStudioMirror','night_drive','home_plan']:
    assert token in builder, token
# Pair ids added by 1.0 must remain unique.
ids=re.findall(r'_pair\("([^"]+)"',builder)
assert len(ids)==len(set(ids))==8, ids
# Network authentication must gate every gameplay any_peer RPC except the code submitter itself.
net=read('scripts/network_manager.gd')
assert 'SESSION_CODE_LENGTH := 6' in net
assert 'authorized_peers' in net and '_peer_authorized' in net
assert 'request_upnp_mapping' in net and 'UPNP.new()' in net
blocks=re.split(r'(?=@rpc\("any_peer")',net)[1:]
for b in blocks:
    head='\n'.join(b.splitlines()[:12])
    if 'func _submit_session_code' in head:
        continue
    assert '_peer_authorized' in head, 'Ungated any_peer RPC:\n'+head
# No hard-coded obvious secrets/private keys.
secret_patterns=[r'sk-[A-Za-z0-9_-]{16,}',r'BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY',r'(?i)api[_-]?key\s*=\s*["\'][^"\']+["\']']
blob='\n'.join(p.read_text(errors='ignore') for p in ROOT.rglob('*') if p.is_file() and p.suffix in {'.gd','.cfg','.md','.tscn'})
for pat in secret_patterns:
    assert not re.search(pat,blob), pat
print('FULL LIFE 1.0 SMOKE: PASS')
