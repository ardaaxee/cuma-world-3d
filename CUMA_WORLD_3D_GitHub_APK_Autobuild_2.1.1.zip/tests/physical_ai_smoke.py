from pathlib import Path
root=Path(__file__).resolve().parents[1]
required=[
 'scripts/navigation/physical_navigation_world.gd',
 'scripts/navigation/smart_spot.gd',
 'scripts/navigation/local_npc_door.gd',
 'scripts/city/physical_ai_builder.gd',
]
for rel in required:
    assert (root/rel).exists(), rel
cit=(root/'scripts/social/relationship_citizen.gd').read_text()
main=(root/'scripts/main.gd').read_text()
dirtext=(root/'scripts/social/npc_intelligence_director.gd').read_text()
builder=(root/'scripts/city/physical_ai_builder.gd').read_text()
nav=(root/'scripts/navigation/physical_navigation_world.gd').read_text()
assert 'NavigationAgent3D.new()' in cit
assert 'avoidance_enabled = true' in cit
assert 'get_next_path_position()' in cit
assert 'velocity_computed.connect' in cit
assert '_reserve_nearest_spot("market_shelf"' in cit
assert '_reserve_nearest_spot("checkout"' in cit
assert 'cafe_seat' in cit and 'park_seat' in cit
assert '_venue_entry_for_intent' in cit
assert 'request_npc_pass' in cit
assert 'set_group_walk' in cit
assert 'rig.position.y' in cit
assert '_build_physical_ai_14()' in main
assert main.index('_build_physical_ai_14()') < main.index('_build_social_life_12()')
assert 'NavigationRegion3D.new()' in nav and 'NavigationObstacle3D.new()' in nav
assert all(x in builder for x in ['market_shelf_', 'market_checkout_a', 'cafe_seat_', 'restaurant_seat_', 'neighbor_social_', 'garden_bench_', 'home_entry_'])
assert 'NeighborHomeDoor_' in builder
assert '_plan_spontaneous_group_walk' in dirtext
assert '@rpc' not in '\n'.join((root/'scripts/navigation'/f).read_text() for f in ['physical_navigation_world.gd','smart_spot.gd','local_npc_door.gd'])
print('PHYSICAL AI 1.4 SMOKE: PASS')
print('Navigation: procedural regions + NavigationAgent3D + RVO avoidance')
print('Venue behavior: entrance -> shelf/table -> checkout/sit')
print('Social motion: group formation + face-to-face + local NPC doors')
