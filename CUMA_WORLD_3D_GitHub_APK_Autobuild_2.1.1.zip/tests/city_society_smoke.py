from pathlib import Path
root=Path(__file__).resolve().parents[1]
checks={
 'builder': root/'scripts/city/city_society_builder.gd',
 'director': root/'scripts/social/city_society_director.gd',
 'terminal': root/'scripts/city/society_terminal.gd',
}
for k,p in checks.items():
    assert p.exists(), f'missing {k}'
main=(root/'scripts/main.gd').read_text()
assert 'CitySocietyBuilderScript' in main and '_build_city_society_17()' in main
b=checks['builder'].read_text()
for token in ['CUMA FIT','STUDIO HAIR','ECZANE','ATÖLYE 17','TAXI','bus_home','duo_gym','duo_city_event','duo_home_gathering']:
    assert token in b, token
assert b.count('npc.add_to_group("society_crowd")') == 1
assert 'for i in range(10)' in b
d=checks['director'].read_text()
for token in ['Hafta sonu açık hava pazarı','Komşu evinde küçük ev buluşması','Cuma akşamı şehir etkinliği','add_to_group("city_society_director")']:
    assert token in d
# new local society scripts must not expose network RPCs
for p in checks.values():
    assert '@rpc' not in p.read_text(), f'unexpected rpc: {p}'
phone=(root/'scripts/ui/phone_ui.gd').read_text()
assert 'Şehir etkinliği:' in phone and 'city_society_director' in phone
print('CITY SOCIETY 1.7: PASS')
