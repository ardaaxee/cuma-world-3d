from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
phone=(ROOT/'scripts/ui/phone_ui.gd').read_text()
gfx=(ROOT/'scripts/graphics_manager.gd').read_text()
server=(ROOT/'server/dedicated_server.gd').read_text()
nav=(ROOT/'scripts/navigation/physical_navigation_world.gd').read_text()

assert 'REFRESH_INTERVAL := 0.25' in phone
assert 'refresh_accum' in phone
assert 'set_simulation_enabled' in gfx
for rel in ['scripts/city/scheduled_citizen.gd','scripts/city/social_citizen.gd','scripts/city/professional_citizen.gd','scripts/world/traffic_car.gd']:
    assert 'func set_simulation_enabled' in (ROOT/rel).read_text(), rel
assert 'AUTOSAVE_SECONDS := 60.0' in server
assert '_save_server_state()' in server
for region in ['SocietyBoulevard','DynamicMainAvenue','DynamicPlaza']:
    assert region in nav, region
print('PERFORMANCE / SERVER REGRESSION 1.8: PASS')
