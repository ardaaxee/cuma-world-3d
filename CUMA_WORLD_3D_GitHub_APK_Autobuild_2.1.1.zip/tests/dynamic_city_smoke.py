from pathlib import Path
import re

ROOT = Path(__file__).resolve().parents[1]

def read(rel):
    return (ROOT / rel).read_text(encoding='utf-8')

required = [
    'scripts/city/dynamic_city_builder.gd',
    'scripts/city/public_transport_vehicle.gd',
    'scripts/city/professional_citizen.gd',
    'scripts/city/event_guest.gd',
    'scripts/social/dynamic_city_director.gd',
    'scripts/economy/career_terminal.gd',
    'scripts/character/hair_salon_station.gd',
    'scripts/city/activity_station.gd',
]
for rel in required:
    assert (ROOT / rel).exists(), rel

project = read('project.godot')
main = read('scripts/main.gd')
builder = read('scripts/city/dynamic_city_builder.gd')
transport = read('scripts/city/public_transport_vehicle.gd')
gs = read('scripts/game_state.gd')
player = read('scripts/player_controller.gd')

assert 'config/name="CUMA WORLD 3D' in project
assert 'DynamicCityBuilderScript' in main and '_build_dynamic_city_18()' in main
assert 'extends AnimatableBody3D' in transport
assert 'register_vehicle' in transport and 'publish_vehicle_state' in transport
assert 'quality_traffic' not in transport, 'interactive public transport must not disappear in LOW'
assert 'transit_left' in player and 'transit_right' in player
assert 'career_last_shift_day' in gs and 'can_work_career' in gs
assert 'hair_style' in gs and 'cycle_hair_style' in gs
assert 'begin_pose_activity' in player

ids = re.findall(r'_pair\("([^"]+)"', builder)
expected = {
    'duo_career_day', 'duo_bus_ride_18', 'duo_gym_plus',
    'duo_hair_day_18', 'duo_house_party_18', 'duo_city_center_18'
}
assert expected.issubset(set(ids)), (expected - set(ids))
assert len(ids) == len(set(ids))
assert 'CityBus18' in builder and 'CityTaxi18' in builder
assert 'Professional_' in builder and 'PartyGuest_' in builder
print('DYNAMIC CITY 1.8 SMOKE: PASS')
print('New duo activities:', len(ids))
print('Systems: career + moving transit + physical party + gym pose + hair customization + expanded center')
