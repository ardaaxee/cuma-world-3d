from pathlib import Path
import re
from collections import Counter
ROOT=Path(__file__).resolve().parents[1]
reserved={
    'and','as','assert','await','break','breakpoint','class','class_name','const','continue','elif','else','enum',
    'extends','for','func','if','in','is','match','namespace','not','or','pass','preload','return','self','signal',
    'static','super','trait','var','when','while','yield'
}
func_re=re.compile(r'^func\s+([A-Za-z_][A-Za-z0-9_]*)\s*\(',re.M)
var_re=re.compile(r'^\s*var\s+([A-Za-z_][A-Za-z0-9_]*)\b',re.M)
param_re=re.compile(r'^\s*func\s+[A-Za-z_][A-Za-z0-9_]*\s*\((.*?)\)\s*(?:->[^:]+)?\s*:',re.M|re.S)
for p in ROOT.rglob('*.gd'):
    text=p.read_text(encoding='utf-8',errors='strict')
    assert not re.search(r'^\s*var\s+[^\n]*:=',text,re.M), f'risky local type inference: {p.relative_to(ROOT)}'
    names=func_re.findall(text)
    dup=[n for n,c in Counter(names).items() if c>1]
    assert not dup, f'duplicate functions {p.relative_to(ROOT)}: {dup}'
    for name in var_re.findall(text):
        assert name not in reserved, f'reserved variable name {name}: {p.relative_to(ROOT)}'
    # Parameters: strip types/defaults and only inspect identifier at each comma boundary.
    for match in param_re.finditer(text):
        raw=match.group(1)
        depth=0; token=''; parts=[]
        for ch in raw:
            if ch in '([{': depth+=1
            elif ch in ')]}': depth=max(0,depth-1)
            if ch==',' and depth==0:
                parts.append(token); token=''
            else: token+=ch
        if token.strip(): parts.append(token)
        for part in parts:
            m=re.match(r'\s*([A-Za-z_][A-Za-z0-9_]*)',part)
            if m:
                assert m.group(1) not in reserved, f'reserved parameter {m.group(1)}: {p.relative_to(ROOT)}'
print('PARSER COMPAT 2.1: PASS')
