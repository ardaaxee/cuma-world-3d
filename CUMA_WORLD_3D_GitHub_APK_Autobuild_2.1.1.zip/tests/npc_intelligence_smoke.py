from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
read=lambda p:(ROOT/p).read_text(encoding='utf-8')
for f in ['scripts/social/npc_intelligence_director.gd','scripts/social/relationship_citizen.gd','scripts/game_state.gd','scripts/main.gd']:
    assert (ROOT/f).exists(), f
main=read('scripts/main.gd')
assert 'NPCIntelligenceDirectorScript' in main and '_build_npc_intelligence_13()' in main
brain=read('scripts/social/npc_intelligence_director.gd')
for token in ['THINK_INTERVAL_GAME_MINUTES','_plan_friend_meetups','_plan_player_invites','_plan_neighborhood_event','queue_social_invitation','schedule_neighborhood_event']:
    assert token in brain, token
npc=read('scripts/social/relationship_citizen.gd')
for token in ['needs','current_intent','intelligence_tick','set_ai_plan','is_available_for_invite','friend_meetup','shopping','resting']:
    assert token in npc, token
gs=read('scripts/game_state.gd')
for token in ['social_invitations','neighborhood_events','queue_social_invitation','respond_social_invitation','schedule_neighborhood_event','get_social_calendar_summary']:
    assert token in gs, token
# Social intelligence stays local and must not enter shared multiplayer snapshot.
snapshot=gs.split('func get_shared_snapshot() -> Dictionary:',1)[1].split('func apply_shared_snapshot',1)[0]
for token in ['social_invitations','neighborhood_events','social_relationships','npc_bonds']:
    assert token not in snapshot, token
print('NPC INTELLIGENCE 1.3 SMOKE: PASS')
