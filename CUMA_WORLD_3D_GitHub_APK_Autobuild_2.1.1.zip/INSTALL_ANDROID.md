# Android / Godot Setup — 1.9

1. ZIP'i çıkar.
2. Godot 4.x Android Editor veya masaüstü Godot ile `project.godot` dosyasını aç.
3. İlk çalıştırmada **MEDIUM** veya daha zayıf telefonlarda **LOW** grafik profilini kullan.
4. Multiplayer için Android exportunda `INTERNET` iznini etkin tut.
5. Cyber sistemi için ek uygulama, terminal komutu veya gerçek ağ erişimi gerekmez; mini oyun tamamen proje içinde çalışır.
6. Mevcut v18 kayıt dosyası v19 tarafından legacy olarak yüklenebilir.

## İlk testte kontrol et
- CUMA Police bölgesine giriş
- polis bankosu etkileşimi
- evdeki CUMA PC / Cyber Arena
- Cyber Lab node bulmacası
- riskli vitrin etkileşimi ve wanted HUD
- 2 yıldız polis takibi / 4 yıldız FIB takibi
- yakalanma sonrası karakol çıkışı
- LOW/MEDIUM/HIGH performansı
