# CUMA WORLD 3D 1.1 Dedicated WebSocket Server

Bu klasör, iki telefonun aynı yerel ağda olmasını gerektirmeyen **tek-oda / iki-oyuncu** dedicated sunucuyu içerir.

## Çalıştırma

Godot 4.7.x Linux/headless kurulmuş bir sunucuda proje kökünden:

```bash
godot --headless --path . res://server/dedicated_server.tscn -- --room=ABC234 --port=7008
```

- `--room=`: 6 karakter. Boş/geçersiz bırakılırsa sunucu kriptografik rastgele kod üretir.
- `--port=`: varsayılan `7008`.
- Sunucu **tek oda** içindir ve en fazla iki doğrulanmış oyuncu kabul eder.
- İstemcide Together panelindeki `RELAY` alanına `ws://SUNUCU_IP:7008` girilir.

## Public internet / WSS

Gerçek internet yayını için sunucuya açık TCP portu gerekir. Üretimde çıplak `ws://` yerine TLS sonlandıran bir reverse proxy üzerinden `wss://` kullanılması önerilir. Godot `WebSocketMultiplayerPeer` istemcisi `wss://` bağlantılarında TLS sertifikasını hostname'e göre doğrular.

Bu paket sertifika/private key içermez. Secret'lar repoya yazılmamalıdır.

## Güvenlik modeli

- Oda kodu doğrulanmadan gameplay RPC kabul edilmez.
- En fazla iki doğrulanmış oyuncu.
- Transform, araç girdisi, chat ve etkinliklerde mevcut rate/size/mesafe kontrolleri korunur.
- Araç fiziği dedicated sunucu authority'sinde hesaplanır.
- İlk doğrulanan oyuncu ortak save snapshot'ının başlangıç sahibi olur; sunucu snapshot'ı boyut/kapsam sınırlarıyla uygular.
- Dedicated sunucu normal dünyayı **headless** yükler; böylece araç, aktivite ve world-interactable registry'leri istemciden güvenilmeyen koordinat olarak alınmaz.
