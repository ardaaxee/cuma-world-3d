extends Node

const DEFAULT_PORT = 7008
const AUTOSAVE_SECONDS := 60.0

var autosave_accum = 0.0

func _ready() -> void:
	var port = DEFAULT_PORT
	var room_code = ""
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--port="):
			port = clamp(int(arg.trim_prefix("--port=")), 1024, 65535)
		elif arg.begins_with("--room="):
			room_code = arg.trim_prefix("--room=")
	var net = get_node_or_null("/root/NetworkManager")
	if net == null:
		push_error("NetworkManager autoload missing")
		get_tree().quit(2)
		return
	var err = int(net.host_dedicated_ws(room_code, port))
	if err != OK:
		push_error("Dedicated server failed with code: %d" % err)
		get_tree().quit(3)
		return
	# Load the normal world headlessly so interaction/vehicle/activity registries are
	# built from the same source as clients. main.gd skips player/UI in dedicated mode.
	var world_scene = load("res://scenes/main.tscn")
	if world_scene is PackedScene:
		var world = world_scene.instantiate()
		world.name = "AuthorityWorld"
		add_child(world)
	print("CUMA WORLD 1.8 DEDICATED READY • PORT %d • ROOM %s" % [port, net.session_code])

func _process(delta: float) -> void:
	# The autoload NetworkManager owns the authoritative simulation/RPC boundary.
	autosave_accum += delta
	if autosave_accum >= AUTOSAVE_SECONDS:
		autosave_accum = 0.0
		_save_server_state()

func _exit_tree() -> void:
	_save_server_state()

func _save_server_state() -> void:
	var gs = get_node_or_null("/root/GameState")
	if gs != null and gs.has_method("save_game"):
		gs.save_game(gs.checkpoint_position)
