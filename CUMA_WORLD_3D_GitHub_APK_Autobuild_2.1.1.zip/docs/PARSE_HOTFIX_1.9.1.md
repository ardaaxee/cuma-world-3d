# Parse Hotfix 1.9.1

This hotfix addresses Godot script load failures reported for:

- `scripts/player_controller.gd`
- `scripts/mobile_controls.gd`
- `scripts/world/living_world.gd`
- `scripts/world/weather_manager.gd`
- `server/dedicated_server.gd`

## Changes

- Removed risky local-variable type inference (`var ... :=`) project-wide while keeping constant inference intact.
- Rewrote the five reported scripts with more conservative Godot 4 GDScript syntax.
- Replaced dynamic return-value inference in UI/player/server paths with normal assignment.
- Replaced fragile group-node type narrowing in `living_world.gd` with explicit casts.
- Replaced membership checks in critical weather/player paths with `Array.has(...)`.
- Removed the `match` expression from the weather label path to reduce parser-version sensitivity.
- Removed explicit `int` assignment from a dynamically dispatched dedicated-server call and normalized the result with `int(...)`.
- Kept save format at v19; existing 1.9 saves remain compatible.

## Validation

All bundled Python regression/smoke tests pass after the changes. Static checks also confirm there are no remaining local `var ... :=` declarations in project GDScript.

A native Godot binary is not available in this execution container, so the final engine-side import/parse must still be confirmed by opening this hotfix in Godot on the target device.
