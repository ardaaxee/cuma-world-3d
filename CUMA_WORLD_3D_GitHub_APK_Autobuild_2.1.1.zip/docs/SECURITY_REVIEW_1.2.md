# Security Review — Social Life 1.2

## New surfaces
- Local player-to-NPC relationship state in `GameState`.
- NPC social-memory/feed data stored in local ConfigFile saves.
- `SocialInteractionUI` actions call local GameState methods only.
- Relationship NPC interaction bodies expose only local `interact()` / label methods.

## Trust boundary decisions
- Personal NPC relationship state is intentionally **not** part of `get_shared_snapshot()` and cannot be overwritten by the other multiplayer peer through the shared-state snapshot path.
- Social UI does not send network RPCs for friendship, trust, affection, dating or NPC-to-NPC bond scores.
- NPC-to-NPC social simulation is local ambient simulation and accepts no remote network input.
- Existing network authorization, room-code authentication, world-action allowlists, vehicle authority and pair-activity checks remain unchanged.

## Input bounds
- NPC IDs, profile strings, feed entries and memories are length-bounded.
- Loaded social dictionaries have collection-size limits.
- Social action names use a fixed allowlist.
- Daily interaction count prevents unbounded same-day interaction spam in normal gameplay.
- Gift actions can consume only known inventory items selected by the local GameState.

## Known limitations
- Local save files are user-controlled and are not competitive/remote authorization data.
- NPC social AI is a lightweight deterministic/probabilistic life-sim, not a general-purpose language model.
- NPC movement still uses lightweight waypoint motion rather than a full navmesh crowd solver.
