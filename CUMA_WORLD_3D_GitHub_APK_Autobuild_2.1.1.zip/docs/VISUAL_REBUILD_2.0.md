# Visual Rebuild 2.0

Bu sürüm, kullanıcının gerçek cihaz ekran görüntüsündeki görsel sorunlara göre hazırlanmıştır.

## Ekran görüntüsünde tespit edilen sorunlar

- Koridor kapılarından çıkan uzun silindir/çubuk geometriler.
- Prosedürel karakterin fazla iri kafa, omuz ve uzuv oranları.
- Karakterin kamerayı kaplayacak kadar yakın olması.
- İç duvarların gerçekçilik katmanındaki sıva dokusunu almaması.
- Düz/çok aydınlık ortam ışığı nedeniyle plastik görünüm.
- Mobil HUD'ın ekranın üst bölümünü fazla kaplaması.
- Kapı kollarının uzaktan gereğinden büyük okunması.

## Düzeltmeler

- Hatalı silindir kapı pervazları kaldırıldı; dikdörtgen gerçek pervaz parçaları kullanıldı.
- Kapı kolu daha küçük kutu/levere dönüştürüldü.
- Girişteki uzun coat-rail silindiri ince duvar rayına dönüştürüldü.
- Karakter fallback oranları inceltildi; kafa ve omuzlar küçültüldü.
- Gerçek animasyonlu GLB yoksa oyun birinci şahıs başlar; CAM ile 1P/3P değiştirilebilir.
- 3P kamera uzaklaştırıldı ve FOV düşürüldü.
- Koridora runner halı, duvar tabloları, süpürgelik ve gömme sıcak ışık eklendi.
- İç koridor/separator duvarlarına plaster dokusu uygulandı.
- Kapılara walnut dokusu eklendi.
- Ambient/fog azaltıldı, kontrast artırıldı, düşük enerjili kamera dolgu ışığı eklendi.
- HUD ve joystick küçültüldü, yarı saydam/yuvarlatılmış butonlara geçirildi.

## Bilinen sınır

Gerçekçi insan kalitesi için lisanslı/izinli rig'li ve animasyonlu GLB karakter asset'i hâlâ gereklidir. Bu sürüm, bu asset bulunmadığında oyuncak fallback karakterin ekranı domine etmesini engeller.
