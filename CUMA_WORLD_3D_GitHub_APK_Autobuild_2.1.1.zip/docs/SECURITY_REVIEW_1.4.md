# Security Review — Physical AI 1.4

## Boundary
Physical AI is local ambient simulation. It must not become an authority path for shared vehicle, world-action, duo-activity or human-player relationship state.

## Checks
- New navigation scripts define no `@rpc` entrypoints.
- Smart-spot reservations are local process memory only.
- NPC-only automatic doors are separate decorative nodes and do not call `NetworkManager.request_world_action()`.
- Relationship/need/AI-plan state remains excluded from the shared multiplayer snapshot established in Social Life 1.2/Intelligence 1.3.
- Navigation velocity is bounded to the configured NPC speed; non-finite safe velocity is discarded.
- Smart spot IDs/kinds are fixed local strings and not accepted from remote peers.
- The 1.4 builder does not load remote content, URLs, secrets or executable assets.

## Known limitation
This navigation layer prioritizes Android performance over full geometric path fidelity. It uses simple navigation regions and avoidance rather than a detailed runtime-baked city mesh. This is a gameplay/visual limitation, not a remote trust-boundary change.
