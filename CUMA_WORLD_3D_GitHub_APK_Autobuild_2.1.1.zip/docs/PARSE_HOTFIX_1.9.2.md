# Parse Hotfix 1.9.2

Godot reported a parse failure while loading `res://scripts/city/living_city_builder.gd`.

Root cause found in `_build_traffic_signals()`:

```gdscript
var signal = Node3D.new()
```

`signal` is a reserved GDScript keyword. It was renamed to `traffic_light` and all references in that block were updated.

A repository-wide declaration scan found no remaining local variables, constants, loop iterators, function names, or simple function parameters using the checked GDScript reserved keywords.
