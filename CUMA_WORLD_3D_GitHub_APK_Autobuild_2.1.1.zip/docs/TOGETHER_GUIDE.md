# Together Guide

## Connection
- Host: TOGETHER → HOST
- Joiner: TOGETHER → host LAN IP → JOIN
- Ready state: HUD shows 2/2

## Shared activity rule
Both players must be close to the same `BİRLİKTE` marker. Player A presses USE, then Player B presses USE within the ready window. The host checks both last accepted positions before granting the activity.

## Communication
- Preset quick messages for fast coordination
- Session-only text chat, max 120 characters per message
- Wave, cheer and high-five emotes

## Shared progression
Completing activities increases DUO points, records memories, unlocks achievements and advances the common activity goal. The joining player receives the host shared-session snapshot on connection.

## Photos
PHOTO captures the current viewport. Completing the photo booth activity also triggers a screenshot on each participating device. Images are written to the Godot `user://photos` folder for that device.

## Important limitation
This build is designed for two devices on the same trusted LAN. A true internet room-code system needs a deployed signaling/relay/backend service and should not place backend secrets in the game client.
