# Security Review — Online Relay 1.1

## Yeni trust boundary

1. LAN/UPnP modu korunur.
2. `WebSocketMultiplayerPeer` kullanan dedicated server modu eklendi.
3. Dedicated server oyuncu değildir; yalnız authority ve world registry sahibidir.
4. Her remote peer, gameplay RPC'lerinden önce 6 karakter oda kodu ile authorize olur.
5. Dedicated fizik/world registry istemciden kayıt edilmez; headless aynı dünya sahnesinden oluşturulur.

## Kontroller

- Relay URL yalnız `ws://` veya `wss://`, en fazla 512 karakter.
- Dedicated server en fazla 2 client connection/authorization kabul eder.
- Tüm `@rpc("any_peer")` gameplay yolları `_peer_authorized(sender)` kontrolü taşır.
- Transform ve araç input limitleri 1.0'dan korunur.
- Araç input stale timeout 250 ms'dir.
- Chat 120 karaktere sanitize edilir ve cooldown uygulanır.
- Ortak activity/world action mesafe doğrulaması authority'de yapılır.
- İlk client snapshot upload'ı yalnız `state_owner_peer_id` için kabul edilir; `GameState.apply_shared_snapshot` dictionary/array boyutlarını sınırlar.
- Repo içinde TLS private key, API token veya hard-coded credential yoktur.

## Bilinen sınırlar

- Bu 1.1 server **tek oda / iki oyuncu** modelidir; çok-odalı matchmaking servisi değildir.
- Public deployment, firewall/hosting/TLS yapılandırması gerektirir.
- DDoS/WAF/managed rate limiting uygulama dışındaki altyapı sorumluluğudur.
- Dedicated server henüz kalıcı server-side database kullanmaz; ortak snapshot ilk client'tan bootstrap edilir.
