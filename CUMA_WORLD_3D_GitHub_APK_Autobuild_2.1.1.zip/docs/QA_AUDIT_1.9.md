# QA Audit — 1.9 Crime & Justice

## Scope
Full regression from existing 0.x/1.x systems plus the new Crime & Justice layer.

## Manual issues found and fixed
1. Civic buildings initially had full front/back collision walls and could become inaccessible.
   - Fixed by splitting both street-facing walls around a 2.2 m doorway and adding headers.
2. Police desk initially used a separate colliding visual body that could intercept the interaction ray.
   - Fixed: visual is now a non-colliding child of the interactable desk; the desk owns its collider.
3. 1.8 security regression test hard-coded the v18 save filename.
   - Fixed to accept version >=18 while still asserting save sanitization and shared-state privacy.
4. Stolen targets could be repeated after a same-day reload because only node-local state was checked.
   - Fixed: persistent `stolen_goods` also blocks repeated pickup until consequences clear it.

## Automated coverage
- crime_justice_smoke.py
- all pre-existing regression smoke tests
- resource_refs.py
- gdscript_sanity.py
- source_integrity_18.py
- security_regression_18.py

## Runtime gap
Godot native binary is not available in this execution environment, so actual Godot parser/render/physics and
Android FPS still require device-side verification.

## Final automated result
- 21/21 Python regression test files PASS
- 91 GDScript files
- 68 unique co-op activity IDs
- resource references PASS
- source integrity PASS
- network/security regression PASS
