# Security Review — 1.9 Crime & Justice

## New surfaces
No new network RPCs are added by 1.9.

## Local/private state
The following remain local and are excluded from `get_shared_snapshot()`:
- `law_heat`
- `outstanding_fine`
- `crime_record`
- `stolen_goods`
- `cyber_xp`
- `cyber_cases_completed`

## Cyber boundary
Cyber gameplay is an abstract NODE sequence puzzle. The source intentionally contains no real-target URL,
port scanner, credential handling, exploit or malware capability.

## Crime boundary
Theft is represented by a single game interaction with probabilistic detection from abstract risk, nearby in-game
cameras and witnesses. There are no real lock-picking, alarm-disabling or surveillance-evasion instructions.

## Consequences
Detected crimes increase wanted heat and fines. Police/FIB agents use non-violent detention. Detention clears heat,
seizes stolen game items and advances game time.

## Remaining limitation
Law agents are local simulation in multiplayer; they are not authoritative replicated NPCs.
