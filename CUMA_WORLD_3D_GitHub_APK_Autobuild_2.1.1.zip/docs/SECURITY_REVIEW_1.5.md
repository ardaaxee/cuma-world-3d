# Security Review — Human Behavior 1.5

## Boundary
Human Behavior 1.5 is local NPC ambience. It must not become an authority path for shared vehicle transforms, shared world actions, duo activity completion, room authorization or another human player's relationship data.

## Checks
- `human_behavior_builder.gd` and `human_behavior_director.gd` add no `@rpc` entrypoints.
- Phone use, shopping baskets, queue reservations, guest visits, group seating and crowd rhythm are locally constructed state.
- Queue/seat/guest spot IDs are fixed project strings, not remote inputs.
- The explicit “home visit” action modifies only the local player's NPC relationship data and local NPC AI plan.
- Social relationships, social memories, NPC bonds and Human Behavior state remain absent from `GameState.get_shared_snapshot()`.
- LOW-profile crowd suppression is visual/performance behavior only and does not change multiplayer authority.
- No URLs, secrets, private keys, executable downloads or remote model calls were introduced by 1.5.

## Known limitation
Named-neighbor physical/social simulation is still client-local. Two multiplayer clients can see slightly different ambient NPC decisions. Shared player actions, vehicles, weather and registered world interactions continue to use the existing host/dedicated-server authority path.
