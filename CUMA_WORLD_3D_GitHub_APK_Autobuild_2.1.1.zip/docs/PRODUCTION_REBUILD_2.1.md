# Production Rebuild 2.1 — QA Notes

## Problems targeted from the Android screenshot
1. Procedural local character occupied too much of the frame.
2. Corridor felt narrow and synthetic.
3. Primitive door-frame geometry read as rods/sticks.
4. Flat colors made walls and furniture look plastic.
5. Large HUD controls covered too much of the scene.
6. Colored co-op cubes and labels made the world read like a prototype.

## Fixes
- First-person default; 3P remains optional.
- New production home visual overlay with preserved collision/interactions.
- 1024px local albedo/normal material set.
- Smaller HUD and action controls.
- Invisible pair-activity interaction zones.
- New storefront presentation for legacy outdoor slice.
- Parser keyword/type-inference regression checks retained and expanded.

## Static QA result
- 95 GDScript files.
- 172 project files before packaging.
- 10 production material textures.
- 68 unique co-op activity IDs.
- All Python regression/sanity/resource/security tests pass.

## Remaining runtime verification
- Godot import/parse on the target device.
- Android GPU frame time on LOW/MEDIUM/HIGH.
- Visual check of corridor, living room, city storefronts and partner avatar.
- Real rigged character asset integration for high-quality third-person presentation.
