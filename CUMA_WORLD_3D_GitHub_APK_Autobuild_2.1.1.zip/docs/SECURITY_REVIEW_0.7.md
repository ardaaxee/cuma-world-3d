# 0.7 Security Change Review

The new remotely shareable objects are kitchen cabinet doors and curtains. They reuse the existing `NetworkManager.register_world_interactable()` / `request_world_action()` flow.

Checks performed for this update:

- Interaction IDs are fixed project-authored strings and remain below the registry length bound.
- The only remote cabinet/curtain action is `toggle`.
- A joining client cannot call the authority broadcast RPC to set shared state directly.
- The host verifies that an ID is registered, the action is allowlisted, a recent accepted transform exists, and the peer is within the configured interaction distance before emitting/broadcasting the action.
- Cabinet/curtain persistent state is a boolean only; no arbitrary serialized object or file path is accepted from network input.
- No new credentials, API keys, URLs, account tokens, public matchmaking or cloud services were added in 0.7.

The 0.7 visual/home-detail builder itself is local scene construction and adds no network parsing surface beyond those registered toggle actions.
