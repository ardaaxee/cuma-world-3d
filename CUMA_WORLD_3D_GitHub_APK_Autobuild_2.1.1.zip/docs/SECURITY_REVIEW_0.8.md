# Security Review — Living City 0.8

Scope: newly added city scripts plus integration changes to the player and main scene.

## Boundary decisions

- Shared elevator: routed through the existing host-validated world-action registry; client requests only `toggle`.
- New duo activities: routed through the existing pair-activity registry and host distance/readiness checks.
- Driveable car: local/offline only. It refuses entry while NetworkManager reports an active multiplayer session, avoiding divergent shared vehicle state.
- Traffic signals, citizens and ambience: local visual simulation only, with no RPC entry points.

## Remaining limitation

A future shared driveable vehicle must not simply relay client transforms. It needs host/server ownership, bounded input commands and authoritative simulation before multiplayer driving is enabled.
