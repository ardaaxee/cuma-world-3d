# Security Review 1.3 — NPC Intelligence

## Boundary

NPC intelligence, player-to-NPC relationships, invitations, social memories, neighborhood events and NPC-to-NPC bonds are local simulation state. They are not trusted multiplayer authority and are intentionally excluded from `GameState.get_shared_snapshot()`.

## Controls

- NPC invitation IDs, action kinds and event kinds are allowlisted/bounded before being stored.
- Invitation and event collections are capped to avoid unbounded save growth.
- User-visible NPC/profile strings are length-bounded by the existing profile registration path.
- Social AI does not call arbitrary methods from network input and exposes no new `@rpc("any_peer")` endpoint.
- Vehicle, world action, pair activity and relay authorization continue to use the pre-existing host/dedicated-server authority checks.
- NPC intelligence cannot award shared DUO points, mutate another human player's relationship save, or alter multiplayer authorization.

## Known limitations

This is a game simulation, not an LLM-backed conversational agent. NPC decisions are utility/routine driven and intentionally bounded for mobile performance and deterministic-ish gameplay. Dedicated server and client still require real device/runtime validation with Godot.
