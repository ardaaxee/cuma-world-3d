# CUMA WORLD 3D — Security Review 0.9

## Scope
Online Life 0.9 network changes: shared two-seat vehicle, vehicle control input, shared weather, existing pair activities and shared-world actions.

## Trust boundary
The joining Android client is untrusted. The LAN host remains authoritative for vehicle seat ownership, vehicle simulation, shared-world mutation and pair-activity completion.

## Controls added
- Vehicle IDs must be registered locally before a request is accepted.
- Seat requests accept only `driver` or `passenger` and are checked against the requesting peer's last server-known position.
- One peer cannot occupy both seats and occupied seats cannot be overwritten.
- Joining clients never publish vehicle transforms. They send bounded steering/throttle input only; the host simulates and publishes the resulting transform.
- Vehicle input is finite/bounded, rate-limited, and expires after 250 ms so stale throttle cannot remain active.
- Host-published vehicle transforms pass the existing finite/world-bounds transform validation before clients apply them.
- Peer disconnect removes vehicle input and releases any occupied seat.
- Weather accepts an allowlist only (`CLEAR`, `CLOUDY`, `RAIN`) and changes are rate-limited by the host.
- Existing chat length/rate limits, world-action allowlists, distance checks and host-authoritative pair activity completion remain in place.

## Known limitations
- ENet LAN traffic is not an internet-grade authenticated identity system. Use only with people trusted on the same LAN for this prototype.
- No cloud account, relay service, matchmaking or internet room-code system is included in 0.9.
- Anti-cheat is designed for a private two-player session, not hostile public servers.
- Vehicle collision and motion are gameplay-authoritative on the host, but there is no rollback/prediction system yet; latency may be visible to the joining driver.

## Review result
No client-authoritative money, inventory, DUO reward, world-state or vehicle-transform mutation was introduced by the 0.9 feature set.
