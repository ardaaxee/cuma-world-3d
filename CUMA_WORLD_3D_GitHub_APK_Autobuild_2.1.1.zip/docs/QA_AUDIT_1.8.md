# QA Audit — Dynamic City 1.8

## Audit performed
- Ran all legacy smoke/regression tests from animation through City Society.
- Added Dynamic City 1.8 feature smoke test.
- Added network/security regression test.
- Added performance/server regression test.
- Validated every `res://` reference through the existing resource test.
- Checked all GDScript files for bracket/function-header sanity.
- Checked pair-activity IDs globally for duplicates: 64 IDs, 64 unique.
- Scanned source for embedded secret/private-key patterns.

## Bugs/quality issues fixed during audit
- Stale project description/version.
- Dedicated client shared-snapshot injection.
- Weak Transform3D basis validation.
- Wrong room-code peer could remain connected and consume a relay slot.
- Per-frame phone UI refresh.
- Hidden ambient crowds continuing to consume process time.
- Important social NPC/public transport incorrectly eligible for LOW culling.
- Society citizens cutting through solid storefronts.
- Missing navigation coverage for new districts.
- Career shift economy farming.
- Duplicate party diary logging.
- Public transit converted to moving-body semantics (`AnimatableBody3D`).
- Dedicated shared state autosave.
- Save data bounds/migration.

## Runtime checks still required on device
1. Godot native parse/import of all scripts/scenes.
2. Android Compatibility-renderer visual inspection and FPS/memory profiling.
3. Real two-device LAN session.
4. Public relay test using a deployed `wss://` dedicated server.
5. Collision/path inspection around the new City Center and Society Boulevard.
6. Save migration from a real pre-1.8 device save.
