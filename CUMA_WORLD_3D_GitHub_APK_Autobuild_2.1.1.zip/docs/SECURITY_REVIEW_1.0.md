# Security Review • Full Life 1.0

## Network trust boundary
The host remains authoritative for shared world actions, pair completion, weather changes and multiplayer vehicle physics. Client packets are treated as requests, not state truth.

## Session authentication
1.0 generates a six-character room code using Godot `Crypto.generate_random_bytes` and validates it server-side after ENet connection establishment. Until validation succeeds, gameplay `any_peer` RPC handlers reject the remote peer. Failed codes are rejected and the peer is disconnected.

The room code is an invitation gate, not transport encryption. Direct ENet chat/game traffic is not described as confidential on untrusted networks.

## UPnP
UPnP is opt-in only. No port is opened automatically. The mapping code includes a network-generation guard: if the host session ends while discovery is running, a stale successful result is removed instead of keeping a port open for a dead session.

## Economy and progression
Money, inventory, story progress and cosmetic ownership are local save-state. Remote clients do not receive RPCs that directly set wallet balance, inventory contents, owned outfits or story flags.

## Input limits retained
- maximum 2 peers
- transform rate and movement-distance bounds
- vehicle input finite-number validation and timeout
- pair activity distance checks
- registered world-action allowlists
- chat length/rate limits
- bounded shared snapshots

## Known production limitations
- no relay/matchmaking service
- no account identity layer
- no end-to-end encrypted chat
- local save files are not anti-cheat protected
- optional GLB models are external production assets and should be license/security reviewed before shipping
