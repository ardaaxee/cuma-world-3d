# Security Review — Dynamic City 1.8

## Scope
Reviewed the networking, dedicated relay, shared snapshot, world actions, vehicles, pair activities, save loading, new Dynamic City scripts and graphics-culling boundary.

## Findings fixed
1. **Dedicated client snapshot injection — fixed.** The first authenticated client could previously seed dedicated shared state. Bootstrap is now disabled by default; dedicated authority sends its own snapshot.
2. **Transform basis validation gap — fixed.** Network transforms now reject non-finite/scaled/non-orthogonal Basis values as well as invalid positions.
3. **Wrong-code relay slot retention / brute-force pressure — fixed.** Authentication now has a failed-attempt window budget, per-peer timing check and immediate disconnect on a wrong room code.
4. **Gameplay objects incorrectly tied to graphics culling — fixed.** Named relationship NPCs and public transport no longer belong to ambient culling groups.
5. **Corrupt save robustness — improved.** Save collections/numeric values/world positions are bounded and legacy saves migrate into the v18 path.

## Verified invariants
- Every gameplay `any_peer` RPC except the initial room-code submission has a nearby server-side authorization check.
- Shared snapshot excludes money, inventory, career, hair style, social relationships, NPC bonds and daily-life diary state.
- New 1.8 local content scripts expose no RPC entrypoint.
- Bus/taxi authority stays on host/dedicated server via the existing vehicle state channel.
- No API keys, private keys, relay credentials or TLS secrets are stored in source.

## Coverage limitation
Native Godot 4.7.2 was not available in this execution environment, so engine-level parser/runtime, rendering, physics and Android-device network tests remain to be performed on a real Godot runtime.
