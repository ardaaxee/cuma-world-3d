# CUMA WORLD 3D — Production Rebuild 2.1.1

Android-first two-player 3D living-world/life-sim built for Godot 4.x Compatibility renderer.

## What this build changes

Production Rebuild 2.1.1 is a visual and architecture cleanup pass over the existing game systems. It keeps the home, city, social NPCs, relationships, vehicles, weather, economy, police/FIB-style fictional justice systems, abstract in-game cyber puzzles, co-op activities, save system and relay/LAN multiplayer while replacing the most obvious prototype presentation.

### Production visual layer
- New local 1024px albedo + normal material set: plaster, oak, fabric, stone and tile.
- Legacy block furniture visuals are hidden while their collision/interactions are preserved.
- New living room, bedrooms, kitchen, bathroom, entry and balcony presentation layers.
- Door trims, baseboards, runner, wall art and recessed lighting for the corridor.
- Old kiosk-like exterior shells are re-skinned as recognizable storefronts.
- Pair/co-op activity cubes and floating marker labels are hidden; real props/places are the visual cue.

### Camera and controls
- First-person is the production default so the procedural fallback character does not dominate the screen.
- Third-person remains available with CAM.
- Walking/running/jump values were reduced to more natural speeds.
- Camera FOV, near plane and interaction range were retuned.
- Mobile joystick/action buttons and top HUD controls are smaller and less opaque.
- HUD refresh is throttled instead of rebuilding text every frame.

### Character path
`res://assets/characters/cuma.glb` and `partner.glb` remain the production slots for rigged animated characters. If a valid animated GLB is present, the imported-character bridge uses it. Otherwise the built-in fallback remains available, but local play starts in first person.

## Controls
- Mobile: left joystick, right-side look, KOŞ, ZIPLA, KULLAN, CAM.
- Keyboard: WASD, Shift, Space, E.

## Testing
Run all checks from the project root:

```bash
for t in tests/*.py; do python "$t"; done
```

The 2.1 package includes parser-compatibility, resource-reference, source-integrity and production-visual smoke tests in addition to previous regression tests.

## Important runtime note
This build was statically validated in the build environment, but the final Godot render/FPS check still needs to happen on the target Android device. Real photorealistic humans require proper rigged character assets; the code path for them is already present.
