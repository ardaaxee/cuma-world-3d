# CUMA WORLD 3D — Feature Set

## Core
- 4+1 home + balcony
- First/third-person mobile controls
- Day/night + weather
- Save/load + economy + inventory + story progression
- Graphics profiles

## Together
- Two-player LAN / relay-ready networking
- Partner avatar and shared world interactions
- Shared activities, messages, emotes and memories
- 68 unique co-op activity IDs across the complete project

## Living world
- City districts, market, cafe, cinema, arcade, restaurants, apartments and civic areas
- Vehicles, traffic signals, public transport and ambient traffic
- Named neighbors, social relationships, schedules, group events and physical navigation
- Daily/weekly routines, jobs, shopping, venues and city events

## Justice / cyber fiction
- Fictional police/FIB-style civic systems and wanted-state gameplay
- Non-violent arrest/fine loop
- Abstract fictional cyber puzzle system only; no real-world intrusion tooling

## Production Rebuild 2.1
- Production PBR-like local materials
- Rebuilt home presentation
- Re-skinned legacy street slice
- Hidden prototype activity markers
- Cleaner HUD and camera defaults
- Parser compatibility regression tests
