extends Node

signal network_status_changed(text: String)
signal peer_joined(peer_id: int)
signal peer_left(peer_id: int)
signal remote_transform_received(peer_id: int, transform: Transform3D)
signal pair_waiting(activity_id: String, ready_count: int)
signal pair_activity_completed(activity_id: String, title: String)
signal quick_message_received(peer_id: int, message: String)
signal text_message_received(peer_id: int, message: String)
signal emote_received(peer_id: int, emote: String)
signal world_action_received(persistent_id: String, action: String)
signal vehicle_seat_changed(vehicle_id: String, driver_peer_id: int, passenger_peer_id: int)
signal vehicle_state_received(vehicle_id: String, value: Transform3D, speed: float, driver_peer_id: int, passenger_peer_id: int)
signal weather_mode_received(mode: String)
signal session_code_changed(code: String)
signal session_auth_result(ok: bool, message: String)
signal upnp_status_changed(text: String)

const PORT := 7007
const RELAY_PORT := 7008
const MAX_CLIENTS := 1
const MAX_RELAY_CLIENTS := 2
const MAX_MOVEMENT_STEP := 3.0
const MIN_TRANSFORM_INTERVAL_MS := 35
const SERVER_SPEED_LIMIT := 11.0
const ACTIVITY_COOLDOWN_MS := 4500
const PAIR_DISTANCE := 4.5
const PAIR_READY_WINDOW_MS := 30000
const MESSAGE_COOLDOWN_MS := 650
const VEHICLE_DISTANCE := 5.5
const VEHICLE_INPUT_INTERVAL_MS := 35
const ALLOWED_WEATHER := ["CLEAR", "CLOUDY", "RAIN"]
const SESSION_CODE_ALPHABET := "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"
const SESSION_CODE_LENGTH := 6
const AUTH_ATTEMPT_INTERVAL_MS := 600
const MAX_AUTH_FAILURES := 5
const AUTH_FAILURE_WINDOW_MS := 60000
const MAX_AUTH_FAILURES_PER_WINDOW := 20
const ALLOW_DEDICATED_CLIENT_SNAPSHOT_BOOTSTRAP := false

const ALLOWED_MESSAGES := [
	"Buraya gel",
	"Hazırım",
	"Market?",
	"Film?",
	"Fotoğraf?",
	"Balkona gel"
]
const ALLOWED_EMOTES := ["wave", "cheer", "highfive"]

var status = "OFFLINE"
var activity_registry: Dictionary = {}
var world_registry: Dictionary = {}
var ready_by_activity: Dictionary = {}
var last_transform_by_peer: Dictionary = {}
var last_transform_at_by_peer: Dictionary = {}
var last_activity_complete_at: Dictionary = {}
var last_message_at_by_peer: Dictionary = {}
var vehicle_registry: Dictionary = {}
var vehicle_inputs: Dictionary = {}
var last_vehicle_input_at: Dictionary = {}
var last_weather_change_ms = 0
var session_code = ""
var pending_session_code = ""
var authorized_peers: Dictionary = {}
var upnp_thread: Thread
var upnp_gateway: UPNP
var public_address = ""
var network_generation = 0
var network_mode = "offline"
var state_owner_peer_id = 0
var known_authorized_peers: Dictionary = {}
var auth_failures_by_peer: Dictionary = {}
var last_auth_attempt_by_peer: Dictionary = {}
var auth_window_started_ms = 0
var auth_failures_in_window = 0

func _ready() -> void:
	multiplayer.peer_connected.connect(_on_peer_connected)
	multiplayer.peer_disconnected.connect(_on_peer_disconnected)
	multiplayer.connected_to_server.connect(_on_connected_to_server)
	multiplayer.connection_failed.connect(_on_connection_failed)
	multiplayer.server_disconnected.connect(_on_server_disconnected)

func host_lan(invite_code: String = "") -> int:
	stop()
	network_mode = "lan_host"
	session_code = _sanitize_session_code(invite_code)
	if session_code.length() != SESSION_CODE_LENGTH:
		session_code = _generate_session_code()
	pending_session_code = session_code
	var peer = ENetMultiplayerPeer.new()
	var err = peer.create_server(PORT, MAX_CLIENTS)
	if err != OK:
		_set_status("HOST ERROR")
		return err
	multiplayer.multiplayer_peer = peer
	authorized_peers = {1: true}
	last_transform_by_peer.clear()
	last_transform_at_by_peer.clear()
	ready_by_activity.clear()
	session_code_changed.emit(session_code)
	_set_status("LAN HOST • KOD " + session_code)
	return OK

func join_lan(address: String, invite_code: String = "") -> int:
	var clean = address.strip_edges()
	if clean.is_empty() or clean.length() > 255:
		return ERR_INVALID_PARAMETER
	pending_session_code = _sanitize_session_code(invite_code)
	if pending_session_code.length() != SESSION_CODE_LENGTH:
		_set_status("6 HANELİ KOD GEREKLİ")
		return ERR_INVALID_PARAMETER
	stop(false)
	network_mode = "lan_client"
	var peer = ENetMultiplayerPeer.new()
	var err = peer.create_client(clean, PORT)
	if err != OK:
		_set_status("JOIN ERROR")
		return err
	multiplayer.multiplayer_peer = peer
	last_transform_by_peer.clear()
	last_transform_at_by_peer.clear()
	ready_by_activity.clear()
	_set_status("CONNECTING • CODE VERIFY")
	return OK


func host_dedicated_ws(invite_code: String = "", port: int = RELAY_PORT) -> int:
	stop()
	network_mode = "dedicated_server"
	session_code = _sanitize_session_code(invite_code)
	if session_code.length() != SESSION_CODE_LENGTH:
		session_code = _generate_session_code()
	pending_session_code = session_code
	var peer = WebSocketMultiplayerPeer.new()
	var err = peer.create_server(clamp(port, 1024, 65535), "*")
	if err != OK:
		network_mode = "offline"
		_set_status("RELAY SERVER ERROR")
		return err
	multiplayer.multiplayer_peer = peer
	authorized_peers.clear()
	state_owner_peer_id = 0
	last_transform_by_peer.clear()
	last_transform_at_by_peer.clear()
	ready_by_activity.clear()
	session_code_changed.emit(session_code)
	_set_status("DEDICATED RELAY • KOD " + session_code)
	return OK

func join_relay(url: String, invite_code: String = "") -> int:
	var clean_url = url.strip_edges()
	if clean_url.length() > 512 or not (clean_url.begins_with("ws://") or clean_url.begins_with("wss://")):
		_set_status("RELAY URL GEÇERSİZ")
		return ERR_INVALID_PARAMETER
	pending_session_code = _sanitize_session_code(invite_code)
	if pending_session_code.length() != SESSION_CODE_LENGTH:
		_set_status("6 HANELİ KOD GEREKLİ")
		return ERR_INVALID_PARAMETER
	stop(false)
	network_mode = "relay_client"
	var peer = WebSocketMultiplayerPeer.new()
	var err = peer.create_client(clean_url)
	if err != OK:
		network_mode = "offline"
		_set_status("RELAY JOIN ERROR")
		return err
	multiplayer.multiplayer_peer = peer
	last_transform_by_peer.clear()
	last_transform_at_by_peer.clear()
	ready_by_activity.clear()
	_set_status("RELAY CONNECTING • CODE VERIFY")
	return OK

func is_dedicated_server() -> bool:
	return network_mode == "dedicated_server"

func is_relay_client() -> bool:
	return network_mode == "relay_client"

func stop(clear_pending: bool = true) -> void:
	network_generation += 1
	if upnp_gateway != null:
		upnp_gateway.delete_port_mapping(PORT, "UDP")
		upnp_gateway = null
	public_address = ""
	if multiplayer.multiplayer_peer != null:
		multiplayer.multiplayer_peer = OfflineMultiplayerPeer.new()
	last_transform_by_peer.clear()
	last_transform_at_by_peer.clear()
	ready_by_activity.clear()
	authorized_peers.clear()
	known_authorized_peers.clear()
	auth_failures_by_peer.clear()
	last_auth_attempt_by_peer.clear()
	auth_window_started_ms = 0
	auth_failures_in_window = 0
	state_owner_peer_id = 0
	if clear_pending:
		pending_session_code = ""
		session_code = ""
	vehicle_inputs.clear()
	last_vehicle_input_at.clear()
	for vehicle_id in vehicle_registry.keys():
		var meta: Dictionary = vehicle_registry[vehicle_id]
		meta["driver"] = 0
		meta["passenger"] = 0
		vehicle_registry[vehicle_id] = meta
		vehicle_seat_changed.emit(str(vehicle_id),0,0)
	network_mode = "offline"
	_set_status("OFFLINE")

func request_upnp_mapping() -> void:
	if not is_online() or not multiplayer.is_server():
		upnp_status_changed.emit("Önce HOST başlat")
		return
	if upnp_thread != null and upnp_thread.is_started():
		upnp_status_changed.emit("UPnP zaten deneniyor")
		return
	upnp_status_changed.emit("UPnP aranıyor...")
	var generation = network_generation
	upnp_thread = Thread.new()
	upnp_thread.start(_upnp_worker.bind(generation))

func _upnp_worker(generation: int) -> void:
	var upnp = UPNP.new()
	var err = upnp.discover(1800, 2, "InternetGatewayDevice")
	var external = ""
	if err == UPNP.UPNP_RESULT_SUCCESS:
		var gateway = upnp.get_gateway()
		if gateway != null and gateway.is_valid_gateway():
			err = upnp.add_port_mapping(PORT, PORT, "CUMA WORLD 3D", "UDP")
			if err == UPNP.UPNP_RESULT_SUCCESS:
				external = gateway.query_external_address()
	call_deferred("_finish_upnp", generation, err, external, upnp)

func _finish_upnp(generation: int, err: int, external: String, discovered_upnp: UPNP) -> void:
	if upnp_thread != null and upnp_thread.is_started():
		upnp_thread.wait_to_finish()
	if generation != network_generation or not is_online() or not multiplayer.is_server():
		if err == UPNP.UPNP_RESULT_SUCCESS:
			discovered_upnp.delete_port_mapping(PORT, "UDP")
		return
	if err == UPNP.UPNP_RESULT_SUCCESS:
		upnp_gateway = discovered_upnp
	public_address = external.strip_edges().left(64)
	if err == UPNP.UPNP_RESULT_SUCCESS and not public_address.is_empty():
		upnp_status_changed.emit("PORT AÇIK • " + public_address + ":%d" % PORT)
	else:
		upnp_status_changed.emit("UPnP kullanılamadı • LAN devam ediyor")

func is_online() -> bool:
	var peer = multiplayer.multiplayer_peer
	return peer != null and not (peer is OfflineMultiplayerPeer)

func get_peer_count() -> int:
	if not is_online():
		return 1
	if network_mode == "dedicated_server":
		return authorized_peers.size()
	if network_mode == "relay_client":
		return 1 + known_authorized_peers.size()
	return multiplayer.get_peers().size() + 1

func get_local_peer_id() -> int:
	return multiplayer.get_unique_id() if is_online() else 1

func get_connected_peer_ids() -> PackedInt32Array:
	return multiplayer.get_peers() if is_online() else PackedInt32Array()

func get_lan_address_hint() -> String:
	for address in IP.get_local_addresses():
		if ":" in address:
			continue
		if address.begins_with("192.168.") or address.begins_with("10.") or address.begins_with("172."):
			return address
	return ""


func _sanitize_session_code(value: String) -> String:
	var clean = value.to_upper().strip_edges().replace("-", "").replace(" ", "")
	var out = ""
	for i in range(clean.length()):
		var ch = clean.substr(i, 1)
		if SESSION_CODE_ALPHABET.contains(ch):
			out += ch
	return out.left(SESSION_CODE_LENGTH)

func _generate_session_code() -> String:
	var crypto = Crypto.new()
	var bytes = crypto.generate_random_bytes(SESSION_CODE_LENGTH)
	var result = ""
	for i in range(SESSION_CODE_LENGTH):
		var index = int(bytes[i]) % SESSION_CODE_ALPHABET.length()
		result += SESSION_CODE_ALPHABET.substr(index, 1)
	return result

func _peer_authorized(peer_id: int) -> bool:
	return peer_id == 1 or bool(authorized_peers.get(peer_id, false))

@rpc("any_peer", "call_remote", "reliable")
func _submit_session_code(value: String) -> void:
	if not multiplayer.is_server():
		return
	var sender = multiplayer.get_remote_sender_id()
	var now = Time.get_ticks_msec()
	if not _auth_budget_available(now):
		_session_auth_reply.rpc_id(sender, false, "Çok fazla hatalı deneme")
		_disconnect_peer(sender)
		return
	if now - int(last_auth_attempt_by_peer.get(sender, 0)) < AUTH_ATTEMPT_INTERVAL_MS:
		return
	last_auth_attempt_by_peer[sender] = now
	if int(auth_failures_by_peer.get(sender, 0)) >= MAX_AUTH_FAILURES:
		_disconnect_peer(sender)
		return
	var clean = _sanitize_session_code(value)
	if clean == session_code and clean.length() == SESSION_CODE_LENGTH:
		if network_mode == "dedicated_server" and authorized_peers.size() >= MAX_RELAY_CLIENTS:
			_session_auth_reply.rpc_id(sender, false, "Oda dolu")
			var full_peer = multiplayer.multiplayer_peer
			if full_peer != null and full_peer.has_method("disconnect_peer"):
				full_peer.disconnect_peer(sender)
			return
		authorized_peers[sender] = true
		auth_failures_by_peer.erase(sender)
		last_auth_attempt_by_peer.erase(sender)
		_session_auth_reply.rpc_id(sender, true, "Oturum doğrulandı")
		peer_joined.emit(sender)
		if network_mode == "dedicated_server":
			for other in authorized_peers.keys():
				var other_id = int(other)
				if other_id == sender:
					continue
				_announce_authorized_peer.rpc_id(sender, other_id)
				_announce_authorized_peer.rpc_id(other_id, sender)
			# Dedicated servers own shared world progression. Client save bootstrap is
			# disabled by default so a joining client cannot inject forged DUO/world state.
			if state_owner_peer_id == 0:
				state_owner_peer_id = sender
			if ALLOW_DEDICATED_CLIENT_SNAPSHOT_BOOTSTRAP and authorized_peers.size() == 1:
				_request_snapshot_upload.rpc_id(sender)
			else:
				_send_shared_snapshot.call_deferred(sender)
			_set_status("DEDICATED RELAY • %d/2 • KOD %s" % [authorized_peers.size(), session_code])
		else:
			_set_status("LAN HOST • 2/2 • KOD " + session_code)
			_send_shared_snapshot.call_deferred(sender)
	else:
		var failures = int(auth_failures_by_peer.get(sender, 0)) + 1
		auth_failures_by_peer[sender] = failures
		auth_failures_in_window += 1
		_session_auth_reply.rpc_id(sender, false, "Oda kodu yanlış")
		# Wrong-code peers are disconnected immediately so they cannot occupy a relay slot.
		_disconnect_peer(sender)

func _auth_budget_available(now_ms: int) -> bool:
	if auth_window_started_ms <= 0 or now_ms - auth_window_started_ms >= AUTH_FAILURE_WINDOW_MS:
		auth_window_started_ms = now_ms
		auth_failures_in_window = 0
	return auth_failures_in_window < MAX_AUTH_FAILURES_PER_WINDOW

func _disconnect_peer(peer_id: int) -> void:
	var peer = multiplayer.multiplayer_peer
	if peer != null and peer.has_method("disconnect_peer"):
		peer.disconnect_peer(peer_id)

@rpc("authority", "call_remote", "reliable")
func _session_auth_reply(ok: bool, message: String) -> void:
	session_auth_result.emit(ok, message.left(64))
	if ok:
		_set_status("CONNECTED • VERIFIED" if network_mode != "relay_client" else "RELAY • VERIFIED")
		if network_mode == "lan_client":
			peer_joined.emit(1)
	else:
		_set_status("JOIN REJECTED")

@rpc("authority", "call_remote", "reliable")
func _announce_authorized_peer(peer_id: int) -> void:
	if peer_id > 1 and peer_id != multiplayer.get_unique_id():
		known_authorized_peers[peer_id] = true
		peer_joined.emit(peer_id)

@rpc("authority", "call_remote", "reliable")
func _announce_peer_left(peer_id: int) -> void:
	known_authorized_peers.erase(peer_id)
	if peer_id > 1 and peer_id != multiplayer.get_unique_id():
		peer_left.emit(peer_id)

@rpc("authority", "call_remote", "reliable")
func _request_snapshot_upload() -> void:
	if network_mode != "relay_client":
		return
	var gs = get_node_or_null("/root/GameState")
	if gs != null and gs.has_method("get_shared_snapshot"):
		_submit_shared_snapshot.rpc_id(1, gs.get_shared_snapshot())

@rpc("any_peer", "call_remote", "reliable")
func _submit_shared_snapshot(snapshot: Dictionary) -> void:
	if not multiplayer.is_server() or network_mode != "dedicated_server" or not ALLOW_DEDICATED_CLIENT_SNAPSHOT_BOOTSTRAP:
		return
	var sender = multiplayer.get_remote_sender_id()
	if not _peer_authorized(sender) or sender != state_owner_peer_id or snapshot.size() > 16:
		return
	var gs = get_node_or_null("/root/GameState")
	if gs != null and gs.has_method("apply_shared_snapshot"):
		gs.apply_shared_snapshot(snapshot)

func request_weather(mode: String) -> void:
	var clean = mode.to_upper()
	if clean not in ALLOWED_WEATHER:
		return
	if not is_online():
		weather_mode_received.emit(clean)
		return
	if multiplayer.is_server():
		_server_weather_request(multiplayer.get_unique_id(), clean)
	else:
		_request_weather.rpc_id(1, clean)

@rpc("any_peer", "call_remote", "reliable")
func _request_weather(mode: String) -> void:
	if not multiplayer.is_server():
		return
	var sender = multiplayer.get_remote_sender_id()
	if not _peer_authorized(sender):
		return
	_server_weather_request(sender, mode.to_upper())

func _server_weather_request(_peer_id: int, mode: String) -> void:
	if not multiplayer.is_server() or mode not in ALLOWED_WEATHER:
		return
	var now = Time.get_ticks_msec()
	if now - last_weather_change_ms < 1200:
		return
	last_weather_change_ms = now
	weather_mode_received.emit(mode)
	_broadcast_weather.rpc(mode)

@rpc("authority", "call_remote", "reliable")
func _broadcast_weather(mode: String) -> void:
	if mode in ALLOWED_WEATHER:
		weather_mode_received.emit(mode)

func register_vehicle(vehicle_id: String, world_position: Vector3) -> void:
	var clean = vehicle_id.strip_edges().left(48)
	if clean.is_empty():
		return
	var previous: Dictionary = vehicle_registry.get(clean, {})
	vehicle_registry[clean] = {
		"position": world_position,
		"driver": int(previous.get("driver", 0)),
		"passenger": int(previous.get("passenger", 0))
	}

func request_vehicle_seat(vehicle_id: String, seat: String) -> void:
	if not is_online() or not vehicle_registry.has(vehicle_id) or seat not in ["driver", "passenger"]:
		return
	if multiplayer.is_server():
		_server_vehicle_seat(multiplayer.get_unique_id(), vehicle_id, seat)
	else:
		_request_vehicle_seat.rpc_id(1, vehicle_id, seat)

@rpc("any_peer", "call_remote", "reliable")
func _request_vehicle_seat(vehicle_id: String, seat: String) -> void:
	if not multiplayer.is_server() or vehicle_id.length() > 48 or seat not in ["driver", "passenger"]:
		return
	var sender = multiplayer.get_remote_sender_id()
	if not _peer_authorized(sender):
		return
	_server_vehicle_seat(sender, vehicle_id, seat)

func _server_vehicle_seat(peer_id: int, vehicle_id: String, seat: String) -> void:
	if not multiplayer.is_server() or not vehicle_registry.has(vehicle_id):
		return
	var meta: Dictionary = vehicle_registry[vehicle_id]
	var peer_pos = _peer_position(peer_id)
	if peer_pos == null:
		return
	var checked_pos: Vector3 = peer_pos
	if checked_pos.distance_to(meta["position"]) > VEHICLE_DISTANCE:
		return
	var driver = int(meta.get("driver", 0))
	var passenger = int(meta.get("passenger", 0))
	if peer_id == driver or peer_id == passenger:
		return
	if seat == "driver" and driver == 0:
		driver = peer_id
	elif seat == "passenger" and passenger == 0:
		passenger = peer_id
	else:
		return
	meta["driver"] = driver
	meta["passenger"] = passenger
	vehicle_registry[vehicle_id] = meta
	vehicle_seat_changed.emit(vehicle_id, driver, passenger)
	_broadcast_vehicle_seats.rpc(vehicle_id, driver, passenger)

func request_vehicle_leave(vehicle_id: String) -> void:
	if not is_online() or not vehicle_registry.has(vehicle_id):
		return
	if multiplayer.is_server():
		_server_vehicle_leave(multiplayer.get_unique_id(), vehicle_id)
	else:
		_request_vehicle_leave.rpc_id(1, vehicle_id)

@rpc("any_peer", "call_remote", "reliable")
func _request_vehicle_leave(vehicle_id: String) -> void:
	if not multiplayer.is_server() or vehicle_id.length() > 48:
		return
	var sender = multiplayer.get_remote_sender_id()
	if not _peer_authorized(sender):
		return
	_server_vehicle_leave(sender, vehicle_id)

func _server_vehicle_leave(peer_id: int, vehicle_id: String) -> void:
	if not multiplayer.is_server() or not vehicle_registry.has(vehicle_id):
		return
	var meta: Dictionary = vehicle_registry[vehicle_id]
	var changed = false
	if int(meta.get("driver",0)) == peer_id:
		meta["driver"] = 0
		changed = true
	if int(meta.get("passenger",0)) == peer_id:
		meta["passenger"] = 0
		changed = true
	if not changed:
		return
	vehicle_registry[vehicle_id] = meta
	vehicle_inputs.erase(peer_id)
	vehicle_seat_changed.emit(vehicle_id, int(meta["driver"]), int(meta["passenger"]))
	_broadcast_vehicle_seats.rpc(vehicle_id, int(meta["driver"]), int(meta["passenger"]))

@rpc("authority", "call_remote", "reliable")
func _broadcast_vehicle_seats(vehicle_id: String, driver_peer_id: int, passenger_peer_id: int) -> void:
	if not vehicle_registry.has(vehicle_id):
		return
	var meta: Dictionary = vehicle_registry[vehicle_id]
	meta["driver"] = driver_peer_id
	meta["passenger"] = passenger_peer_id
	vehicle_registry[vehicle_id] = meta
	vehicle_seat_changed.emit(vehicle_id, driver_peer_id, passenger_peer_id)

func submit_vehicle_input(vehicle_id: String, value: Vector2) -> void:
	if not is_online() or not vehicle_registry.has(vehicle_id) or not _valid_vehicle_input(value):
		return
	var clean = value.limit_length(1.0)
	if multiplayer.is_server():
		_server_vehicle_input(multiplayer.get_unique_id(), vehicle_id, clean)
	else:
		_submit_vehicle_input.rpc_id(1, vehicle_id, clean)

@rpc("any_peer", "call_remote", "unreliable")
func _submit_vehicle_input(vehicle_id: String, value: Vector2) -> void:
	if not multiplayer.is_server() or vehicle_id.length() > 48:
		return
	var sender = multiplayer.get_remote_sender_id()
	if not _peer_authorized(sender):
		return
	_server_vehicle_input(sender, vehicle_id, value.limit_length(1.0))

func _server_vehicle_input(peer_id: int, vehicle_id: String, value: Vector2) -> void:
	if not multiplayer.is_server() or not vehicle_registry.has(vehicle_id) or not _valid_vehicle_input(value):
		return
	var meta: Dictionary = vehicle_registry[vehicle_id]
	if int(meta.get("driver",0)) != peer_id:
		return
	var now = Time.get_ticks_msec()
	if now - int(last_vehicle_input_at.get(peer_id,0)) < VEHICLE_INPUT_INTERVAL_MS:
		return
	last_vehicle_input_at[peer_id] = now
	vehicle_inputs[peer_id] = value.limit_length(1.0)

func get_vehicle_input(peer_id: int) -> Vector2:
	if Time.get_ticks_msec() - int(last_vehicle_input_at.get(peer_id,0)) > 250:
		return Vector2.ZERO
	return vehicle_inputs.get(peer_id, Vector2.ZERO)

func _valid_vehicle_input(value: Vector2) -> bool:
	return is_finite(value.x) and is_finite(value.y) and abs(value.x) <= 1.25 and abs(value.y) <= 1.25

func publish_vehicle_state(vehicle_id: String, value: Transform3D, speed: float) -> void:
	if not multiplayer.is_server() or not vehicle_registry.has(vehicle_id) or not _valid_transform(value):
		return
	var meta: Dictionary = vehicle_registry[vehicle_id]
	meta["position"] = value.origin
	vehicle_registry[vehicle_id] = meta
	_receive_vehicle_state.rpc(vehicle_id, value, clamp(speed,-40.0,40.0), int(meta.get("driver",0)), int(meta.get("passenger",0)))

@rpc("authority", "call_remote", "unreliable")
func _receive_vehicle_state(vehicle_id: String, value: Transform3D, speed: float, driver_peer_id: int, passenger_peer_id: int) -> void:
	if not vehicle_registry.has(vehicle_id) or not _valid_transform(value):
		return
	var meta: Dictionary = vehicle_registry[vehicle_id]
	meta["position"] = value.origin
	meta["driver"] = driver_peer_id
	meta["passenger"] = passenger_peer_id
	vehicle_registry[vehicle_id] = meta
	vehicle_state_received.emit(vehicle_id, value, clamp(speed,-40.0,40.0), driver_peer_id, passenger_peer_id)

func _peer_position(peer_id: int) -> Variant:
	if multiplayer.is_server() and peer_id == multiplayer.get_unique_id():
		var player = get_tree().get_first_node_in_group("player")
		if player is Node3D:
			return player.global_position
	if last_transform_by_peer.has(peer_id):
		var last_value: Transform3D = last_transform_by_peer[peer_id]
		return last_value.origin
	return null

func register_pair_activity(activity_id: String, world_position: Vector3, title: String, points: int, time_cost: float) -> void:
	if activity_id.is_empty():
		return
	activity_registry[activity_id] = {
		"position": world_position,
		"title": title.left(64),
		"points": clamp(points, 0, 100),
		"time_cost": clamp(time_cost, 0.0, 8.0)
	}

func register_world_interactable(persistent_id: String, world_position: Vector3, allowed_actions: Array) -> void:
	if persistent_id.is_empty() or allowed_actions.is_empty():
		return
	var sanitized: Array[String] = []
	for action in allowed_actions:
		var clean = action.strip_edges().left(24)
		if not clean.is_empty() and clean not in sanitized:
			sanitized.append(clean)
	world_registry[persistent_id.left(64)] = {
		"position": world_position,
		"actions": sanitized
	}

func request_world_action(persistent_id: String, action: String) -> void:
	if persistent_id.length() > 64 or action.length() > 24 or not world_registry.has(persistent_id):
		return
	if not is_online():
		world_action_received.emit(persistent_id, action)
		return
	if multiplayer.is_server():
		_server_world_action(multiplayer.get_unique_id(), persistent_id, action)
	else:
		_request_world_action.rpc_id(1, persistent_id, action)

@rpc("any_peer", "call_remote", "reliable")
func _request_world_action(persistent_id: String, action: String) -> void:
	if not multiplayer.is_server() or persistent_id.length() > 64 or action.length() > 24:
		return
	var sender = multiplayer.get_remote_sender_id()
	if not _peer_authorized(sender):
		return
	_server_world_action(sender, persistent_id, action)

func _server_world_action(peer_id: int, persistent_id: String, action: String) -> void:
	if not multiplayer.is_server() or not world_registry.has(persistent_id):
		return
	var meta: Dictionary = world_registry[persistent_id]
	var actions: Array = meta.get("actions", [])
	if action not in actions or not last_transform_by_peer.has(peer_id):
		return
	var peer_transform: Transform3D = last_transform_by_peer[peer_id]
	var world_position: Vector3 = meta["position"]
	if peer_transform.origin.distance_to(world_position) > PAIR_DISTANCE:
		return
	world_action_received.emit(persistent_id, action)
	_broadcast_world_action.rpc(persistent_id, action)

@rpc("authority", "call_remote", "reliable")
func _broadcast_world_action(persistent_id: String, action: String) -> void:
	if not world_registry.has(persistent_id):
		return
	var meta: Dictionary = world_registry[persistent_id]
	var actions: Array = meta.get("actions", [])
	if action not in actions:
		return
	world_action_received.emit(persistent_id, action)

func send_local_transform(value: Transform3D) -> void:
	if not is_online():
		return
	var local_id = multiplayer.get_unique_id()
	if multiplayer.is_server():
		_accept_transform(local_id, value)
	else:
		_submit_transform.rpc_id(1, value)

@rpc("any_peer", "call_remote", "unreliable")
func _submit_transform(value: Transform3D) -> void:
	if not multiplayer.is_server():
		return
	var sender = multiplayer.get_remote_sender_id()
	if not _peer_authorized(sender):
		return
	_accept_transform(sender, value)

func _accept_transform(peer_id: int, value: Transform3D) -> void:
	if not _valid_transform(value):
		return
	var now = Time.get_ticks_msec()
	if last_transform_by_peer.has(peer_id):
		var previous: Transform3D = last_transform_by_peer[peer_id]
		var previous_at = int(last_transform_at_by_peer.get(peer_id, now - 75))
		var elapsed_ms = now - previous_at
		if peer_id != 1 and elapsed_ms < MIN_TRANSFORM_INTERVAL_MS:
			return
		var elapsed = clamp(float(elapsed_ms) / 1000.0, 0.035, 0.5)
		var allowed_distance = min(MAX_MOVEMENT_STEP, SERVER_SPEED_LIMIT * elapsed + 0.35)
		if previous.origin.distance_to(value.origin) > allowed_distance:
			return
	last_transform_by_peer[peer_id] = value
	last_transform_at_by_peer[peer_id] = now
	if peer_id != multiplayer.get_unique_id():
		remote_transform_received.emit(peer_id, value)
	_broadcast_transform.rpc(peer_id, value)

@rpc("authority", "call_remote", "unreliable")
func _broadcast_transform(peer_id: int, value: Transform3D) -> void:
	if peer_id == multiplayer.get_unique_id():
		return
	last_transform_by_peer[peer_id] = value
	remote_transform_received.emit(peer_id, value)

func _valid_transform(value: Transform3D) -> bool:
	var p = value.origin
	if not (is_finite(p.x) and is_finite(p.y) and is_finite(p.z)):
		return false
	if abs(p.x) >= 500.0 or abs(p.y) >= 100.0 or abs(p.z) >= 500.0:
		return false
	# Reject malformed/NaN/scaled bases before they reach remote avatars or vehicles.
	var axes = [value.basis.x, value.basis.y, value.basis.z]
	for axis in axes:
		if not axis.is_finite():
			return false
		var length = axis.length()
		if length < 0.92 or length > 1.08:
			return false
	if abs(value.basis.x.dot(value.basis.y)) > 0.08 or abs(value.basis.x.dot(value.basis.z)) > 0.08 or abs(value.basis.y.dot(value.basis.z)) > 0.08:
		return false
	var determinant = value.basis.determinant()
	return is_finite(determinant) and determinant > 0.82 and determinant < 1.18

func request_pair_activity(activity_id: String) -> void:
	if activity_id.length() > 64 or not activity_registry.has(activity_id):
		return
	if not is_online():
		pair_waiting.emit(activity_id, 1)
		return
	if multiplayer.is_server():
		_server_pair_ready(multiplayer.get_unique_id(), activity_id)
	else:
		_request_pair_ready.rpc_id(1, activity_id)

@rpc("any_peer", "call_remote", "reliable")
func _request_pair_ready(activity_id: String) -> void:
	if not multiplayer.is_server() or activity_id.length() > 64:
		return
	var sender = multiplayer.get_remote_sender_id()
	if not _peer_authorized(sender):
		return
	_server_pair_ready(sender, activity_id)

func _server_pair_ready(peer_id: int, activity_id: String) -> void:
	if not multiplayer.is_server() or not activity_registry.has(activity_id):
		return
	var now = Time.get_ticks_msec()
	if now - int(last_activity_complete_at.get(activity_id, 0)) < ACTIVITY_COOLDOWN_MS:
		return
	if not last_transform_by_peer.has(peer_id):
		return
	var meta: Dictionary = activity_registry[activity_id]
	var activity_position: Vector3 = meta["position"]
	var peer_transform: Transform3D = last_transform_by_peer[peer_id]
	var player_position = peer_transform.origin
	if player_position.distance_to(activity_position) > PAIR_DISTANCE:
		return

	var ready: Dictionary = ready_by_activity.get(activity_id, {})
	for old_peer in ready.keys():
		if now - int(ready[old_peer]) > PAIR_READY_WINDOW_MS:
			ready.erase(old_peer)
	ready[peer_id] = now
	ready_by_activity[activity_id] = ready
	_emit_pair_waiting.rpc(activity_id, ready.size())
	pair_waiting.emit(activity_id, ready.size())

	if ready.size() >= 2:
		ready_by_activity.erase(activity_id)
		last_activity_complete_at[activity_id] = now
		_complete_pair_activity_local(activity_id)
		_complete_pair_activity_remote.rpc(activity_id)

@rpc("authority", "call_remote", "reliable")
func _emit_pair_waiting(activity_id: String, ready_count: int) -> void:
	pair_waiting.emit(activity_id, ready_count)

@rpc("authority", "call_remote", "reliable")
func _complete_pair_activity_remote(activity_id: String) -> void:
	_complete_pair_activity_local(activity_id)

func _complete_pair_activity_local(activity_id: String) -> void:
	if not activity_registry.has(activity_id):
		return
	var meta: Dictionary = activity_registry[activity_id]
	var gs = get_node_or_null("/root/GameState")
	if gs != null and gs.has_method("complete_duo_activity"):
		gs.complete_duo_activity(activity_id, str(meta["title"]), int(meta["points"]), float(meta["time_cost"]))
	pair_activity_completed.emit(activity_id, str(meta["title"]))

func send_quick_message(message: String) -> void:
	if message not in ALLOWED_MESSAGES or not is_online():
		return
	if multiplayer.is_server():
		_server_quick_message(multiplayer.get_unique_id(), message)
	else:
		_request_quick_message.rpc_id(1, message)

@rpc("any_peer", "call_remote", "reliable")
func _request_quick_message(message: String) -> void:
	if not multiplayer.is_server():
		return
	var sender = multiplayer.get_remote_sender_id()
	if not _peer_authorized(sender):
		return
	_server_quick_message(sender, message)

func _server_quick_message(peer_id: int, message: String) -> void:
	if message not in ALLOWED_MESSAGES:
		return
	var now = Time.get_ticks_msec()
	if now - int(last_message_at_by_peer.get(peer_id, 0)) < MESSAGE_COOLDOWN_MS:
		return
	last_message_at_by_peer[peer_id] = now
	quick_message_received.emit(peer_id, message)
	_broadcast_quick_message.rpc(peer_id, message)

@rpc("authority", "call_remote", "reliable")
func _broadcast_quick_message(peer_id: int, message: String) -> void:
	quick_message_received.emit(peer_id, message)

func send_text_message(message: String) -> void:
	if not is_online():
		return
	var clean = _sanitize_chat(message)
	if clean.is_empty():
		return
	if multiplayer.is_server():
		_server_text_message(multiplayer.get_unique_id(), clean)
	else:
		_request_text_message.rpc_id(1, clean)

@rpc("any_peer", "call_remote", "reliable")
func _request_text_message(message: String) -> void:
	if not multiplayer.is_server() or message.length() > 512:
		return
	var sender = multiplayer.get_remote_sender_id()
	if not _peer_authorized(sender):
		return
	_server_text_message(sender, _sanitize_chat(message))

func _server_text_message(peer_id: int, message: String) -> void:
	var clean = _sanitize_chat(message)
	if clean.is_empty():
		return
	var now = Time.get_ticks_msec()
	if now - int(last_message_at_by_peer.get(peer_id, 0)) < MESSAGE_COOLDOWN_MS:
		return
	last_message_at_by_peer[peer_id] = now
	text_message_received.emit(peer_id, clean)
	_broadcast_text_message.rpc(peer_id, clean)

@rpc("authority", "call_remote", "reliable")
func _broadcast_text_message(peer_id: int, message: String) -> void:
	var clean = _sanitize_chat(message)
	if clean.is_empty():
		return
	text_message_received.emit(peer_id, clean)

func _sanitize_chat(message: String) -> String:
	var clean = message.replace("\n", " ").replace("\r", " ").replace("\t", " ").strip_edges()
	return clean.left(120)

func send_emote(emote: String) -> void:
	if emote not in ALLOWED_EMOTES or not is_online():
		return
	if multiplayer.is_server():
		_server_emote(multiplayer.get_unique_id(), emote)
	else:
		_request_emote.rpc_id(1, emote)

@rpc("any_peer", "call_remote", "reliable")
func _request_emote(emote: String) -> void:
	if not multiplayer.is_server():
		return
	var sender = multiplayer.get_remote_sender_id()
	if not _peer_authorized(sender):
		return
	_server_emote(sender, emote)

func _server_emote(peer_id: int, emote: String) -> void:
	if emote not in ALLOWED_EMOTES:
		return
	emote_received.emit(peer_id, emote)
	_broadcast_emote.rpc(peer_id, emote)

@rpc("authority", "call_remote", "reliable")
func _broadcast_emote(peer_id: int, emote: String) -> void:
	emote_received.emit(peer_id, emote)

func _send_shared_snapshot(peer_id: int) -> void:
	if not multiplayer.is_server() or peer_id <= 1:
		return
	var gs = get_node_or_null("/root/GameState")
	if gs == null or not gs.has_method("get_shared_snapshot"):
		return
	var snapshot: Dictionary = gs.get_shared_snapshot()
	_receive_shared_snapshot.rpc_id(peer_id, snapshot)

@rpc("authority", "call_remote", "reliable")
func _receive_shared_snapshot(snapshot: Dictionary) -> void:
	var gs = get_node_or_null("/root/GameState")
	if gs != null and gs.has_method("apply_shared_snapshot"):
		gs.apply_shared_snapshot(snapshot)

func _on_peer_connected(peer_id: int) -> void:
	if multiplayer.is_server():
		if network_mode == "dedicated_server":
			if multiplayer.get_peers().size() > MAX_RELAY_CLIENTS:
				var p = multiplayer.multiplayer_peer
				if p != null and p.has_method("disconnect_peer"):
					p.disconnect_peer(peer_id)
				return
			_set_status("DEDICATED RELAY • VERIFYING")
		else:
			_set_status("LAN HOST • VERIFYING PEER")
	else:
		# Client waits for the explicit session-code reply before exposing the peer to gameplay.
		pass

func _on_peer_disconnected(peer_id: int) -> void:
	authorized_peers.erase(peer_id)
	known_authorized_peers.erase(peer_id)
	auth_failures_by_peer.erase(peer_id)
	last_auth_attempt_by_peer.erase(peer_id)
	last_transform_by_peer.erase(peer_id)
	last_transform_at_by_peer.erase(peer_id)
	vehicle_inputs.erase(peer_id)
	last_vehicle_input_at.erase(peer_id)
	if multiplayer.is_server():
		for vehicle_id in vehicle_registry.keys():
			var meta: Dictionary = vehicle_registry[vehicle_id]
			var changed = false
			if int(meta.get("driver",0)) == peer_id:
				meta["driver"] = 0; changed = true
			if int(meta.get("passenger",0)) == peer_id:
				meta["passenger"] = 0; changed = true
			if changed:
				vehicle_registry[vehicle_id] = meta
				vehicle_seat_changed.emit(str(vehicle_id), int(meta["driver"]), int(meta["passenger"]))
				_broadcast_vehicle_seats.rpc(str(vehicle_id), int(meta["driver"]), int(meta["passenger"]))
	for activity_id in ready_by_activity.keys():
		var ready: Dictionary = ready_by_activity[activity_id]
		ready.erase(peer_id)
		ready_by_activity[activity_id] = ready
	peer_left.emit(peer_id)
	if multiplayer.is_server():
		if network_mode == "dedicated_server":
			_announce_peer_left.rpc(peer_id)
			if peer_id == state_owner_peer_id:
				state_owner_peer_id = 0
				for candidate in authorized_peers.keys():
					state_owner_peer_id = int(candidate)
					break
			_set_status("DEDICATED RELAY • %d/2 • KOD %s" % [authorized_peers.size(), session_code])
		else:
			_set_status("LAN HOST • 1/2")

func _on_connected_to_server() -> void:
	_set_status("RELAY • VERIFYING CODE" if network_mode == "relay_client" else "CONNECTED • VERIFYING CODE")
	_submit_session_code.rpc_id(1, pending_session_code)

func _on_connection_failed() -> void:
	stop()
	_set_status("JOIN FAILED")

func _on_server_disconnected() -> void:
	stop()
	_set_status("SERVER LEFT")

func _set_status(text: String) -> void:
	status = text
	network_status_changed.emit(status)
