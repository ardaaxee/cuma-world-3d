extends StaticBody3D

var action_id = "society"
var title = "Şehir hizmeti"
var cost = 0
var time_cost = 0.25
var reward_item = ""
var teleport_target = Vector3.ZERO
var does_teleport = false

func setup(id_value:String, display_title:String, price:int=0, hours:float=0.25, item_id:String="", target:Vector3=Vector3.ZERO, teleport:bool=false) -> void:
	action_id=id_value; title=display_title; cost=price; time_cost=hours; reward_item=item_id; teleport_target=target; does_teleport=teleport

func get_interaction_label() -> String:
	return "%s%s" % [title, " • %d" % cost if cost > 0 else ""]

func interact(player:Node) -> void:
	var gs=get_node_or_null("/root/GameState")
	if gs == null: return
	if cost > 0 and not gs.spend_money(cost):
		if player != null and player.has_method("show_status"): player.show_status("Yeterli paran yok",2.0)
		return
	if reward_item != "" and gs.has_method("add_item"): gs.add_item(reward_item,1)
	if time_cost > 0.0 and gs.has_method("advance_time"): gs.advance_time(time_cost)
	if does_teleport and player is Node3D:
		(player as Node3D).global_position = teleport_target
	if player != null and player.has_method("show_status"): player.show_status("%s tamamlandı" % title,2.2)
	if gs.has_method("add_social_feed"): gs.add_social_feed("Şehir: %s" % title)
