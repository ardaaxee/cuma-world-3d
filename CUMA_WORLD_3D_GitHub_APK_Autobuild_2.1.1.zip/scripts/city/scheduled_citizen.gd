extends Node3D

const ProceduralHumanoid = preload("res://scripts/character/procedural_humanoid.gd")

var rig: Node3D
var home = Vector3.ZERO
var work = Vector3.ZERO
var leisure = Vector3.ZERO
var target = Vector3.ZERO
var travel_route: Array[Vector3] = []
var travel_index = 0
var corridor_x = INF
var speed = 1.25
var wait_left = 0.0
var phase_offset = 0.0
var density_rank = 0.5

func setup(home_pos: Vector3, work_pos: Vector3, leisure_pos: Vector3, color: Color, offset: float, walk_corridor_x: float = INF) -> void:
	home = home_pos
	work = work_pos
	leisure = leisure_pos
	phase_offset = offset
	corridor_x = walk_corridor_x
	density_rank = 0.18 + fmod(abs(offset * 0.371 + home_pos.x * 0.013 + home_pos.z * 0.007), 0.78)
	global_position = home
	rig = Node3D.new()
	rig.set_script(ProceduralHumanoid)
	add_child(rig)
	rig.setup({"skin":Color("c99875"),"top":color,"pants":Color("313742"),"hair":Color("211d1b"),"shoes":Color("17191d"),"height_scale":randf_range(0.94,1.06),"shoulder_scale":randf_range(0.92,1.05)})
	_set_destination(work)
	add_to_group("quality_crowd")
	add_to_group("ambient_city_citizen")

func set_crowd_factor(value: float) -> void:
	var gs = get_node_or_null("/root/GameState")
	if gs != null and str(gs.quality_profile) == "LOW":
		visible = false
		return
	visible = clamp(value, 0.0, 1.0) >= density_rank

func set_simulation_enabled(enabled: bool) -> void:
	visible = enabled
	set_process(enabled)

func _process(delta: float) -> void:
	var gs = get_node_or_null("/root/GameState")
	var hour = fposmod((gs.time_of_day if gs != null else 12.0) + phase_offset, 24.0)
	var desired = home
	if hour >= 7.5 and hour < 16.5:
		desired = work
	elif hour >= 16.5 and hour < 22.5:
		desired = leisure
	if target.distance_to(desired) > 0.5:
		_set_destination(desired)
		wait_left = 0.0
	if wait_left > 0.0:
		wait_left -= delta
		_update_rig(delta, 0.0)
		return
	if travel_route.is_empty():
		_update_rig(delta, 0.0)
		return
	var step_target = travel_route[travel_index]
	var flat = step_target - global_position
	flat.y = 0.0
	if flat.length() < 0.55:
		if travel_index < travel_route.size() - 1:
			travel_index += 1
			return
		wait_left = randf_range(2.5, 7.0)
		_update_rig(delta, 0.0)
		return
	var dir = flat.normalized()
	global_position += dir * speed * delta
	rotation.y = lerp_angle(rotation.y, atan2(-dir.x, -dir.z), min(1.0, delta * 5.0))
	_update_rig(delta, speed)

func _set_destination(desired: Vector3) -> void:
	target = desired
	travel_route.clear()
	travel_index = 0
	if is_finite(corridor_x):
		var y = max(global_position.y, 0.05)
		var first = Vector3(corridor_x, y, global_position.z)
		var second = Vector3(corridor_x, max(desired.y, 0.05), desired.z)
		if global_position.distance_to(first) > 0.8:
			travel_route.append(first)
		if first.distance_to(second) > 0.8:
			travel_route.append(second)
	travel_route.append(desired)

func _update_rig(delta: float, move_speed: float) -> void:
	if rig != null and rig.has_method("update_pose"):
		rig.update_pose(delta, move_speed, false, 0.0, true, false, 0.0)
