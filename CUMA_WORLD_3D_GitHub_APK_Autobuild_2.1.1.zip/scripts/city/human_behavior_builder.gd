extends Node

# Human Behavior 1.5
# Adds physical anchors used by the local NPC simulation. These are not multiplayer-authoritative objects.

const SmartSpot = preload("res://scripts/navigation/smart_spot.gd")
const HumanBehaviorDirector = preload("res://scripts/social/human_behavior_director.gd")
const ScheduledCitizen = preload("res://scripts/city/scheduled_citizen.gd")

var root: Node3D

func setup(world: Node3D) -> void:
	root = Node3D.new()
	root.name = "HumanBehavior15"
	world.add_child(root)
	_build_checkout_queues()
	_build_venue_waiting_lines()
	_build_phone_spots()
	_build_guest_spots()
	_build_group_table_spots()
	_spawn_extra_city_flow()
	var director = Node.new()
	director.name = "HumanBehaviorDirector"
	director.set_script(HumanBehaviorDirector)
	world.add_child(director)
	director.setup()

func _spot(id_value: String, kind: String, pos: Vector3, face: Vector3 = Vector3.FORWARD) -> void:
	var node = Node3D.new()
	node.name = "BehaviorSpot_" + id_value
	node.set_script(SmartSpot)
	root.add_child(node)
	node.setup(id_value, kind, pos, face)

func _spawn_extra_city_flow() -> void:
	# Extra commuters appear mostly during daytime/rush hour; the director thins them at night.
	var sets = [
		[Vector3(-26,0.05,72), Vector3(15,0.05,38), Vector3(67,0.05,129), Color("68778a"), 2.7],
		[Vector3(58,0.05,105), Vector3(39,0.05,66), Vector3(38,0.05,82), Color("8d7167"), 3.2],
		[Vector3(14,0.05,105), Vector3(-15,0.05,38), Vector3(80,0.05,138), Color("5b7465"), 3.7],
		[Vector3(62,0.05,118), Vector3(47,0.05,47), Vector3(84,0.05,129), Color("765d83"), 4.1],
		[Vector3(-31,0.05,58), Vector3(31,0.05,47), Vector3(37,0.05,82), Color("806c50"), 4.8],
		[Vector3(54,0.05,96), Vector3(15,0.05,38), Vector3(72,0.05,130), Color("52717a"), 5.4]
	]
	for i in range(sets.size()):
		var d: Array = sets[i]
		var npc = Node3D.new()
		npc.name = "HumanFlowCitizen_%02d" % i
		npc.set_script(ScheduledCitizen)
		root.add_child(npc)
		npc.setup(d[0], d[1], d[2], d[3], d[4])

func _build_checkout_queues() -> void:
	# Fresh Market queue. NPCs reserve one position, then advance to a free checkout.
	for i in range(5):
		_spot("market_queue_%02d" % i, "checkout_queue", Vector3(13.1, 0.05, 37.0 + float(i) * 0.92), Vector3(0,0,-1))

func _build_venue_waiting_lines() -> void:
	for i in range(3):
		_spot("cafe_wait_%02d" % i, "cafe_wait", Vector3(-15.0 + float(i) * 0.65,0.05,34.1), Vector3(0,0,1))
		_spot("restaurant_wait_%02d" % i, "restaurant_wait", Vector3(31.0 + float(i) * 0.72,0.05,41.6), Vector3(0,0,1))

func _build_phone_spots() -> void:
	# Places where an idle NPC may naturally stop and check their phone.
	var spots = [
		Vector3(67.0,0.05,132.4), Vector3(83.5,0.05,132.0),
		Vector3(38.0,0.05,81.0), Vector3(29.0,0.05,82.0),
		Vector3(-12.5,0.05,37.0), Vector3(45.0,0.05,83.0)
	]
	for i in range(spots.size()):
		_spot("phone_%02d" % i, "phone_stop", spots[i], Vector3(0,0,1))

func _build_guest_spots() -> void:
	# The porch/doorbell is inside the existing navigation corridor. Visitors wait here instead of clipping through the house.
	_spot("player_doorbell_a", "guest_door", Vector3(0.0,0.05,10.55), Vector3(0,0,-1))
	_spot("player_porch_wait", "guest_wait", Vector3(-2.0,0.05,11.15), Vector3(0,0,-1))

func _build_group_table_spots() -> void:
	# Seats grouped by table so friends can sit together instead of randomly scattering.
	var cafe_centers = [Vector3(64.5,0.05,129.2), Vector3(67.0,0.05,129.2), Vector3(69.5,0.05,129.2)]
	var idx = 0
	for center in cafe_centers:
		for off in [Vector3(-0.72,0,0), Vector3(0.72,0,0)]:
			_spot("group_cafe_%02d" % idx, "group_seat", center + off, -off.normalized())
			idx += 1
	var dinner_centers = [Vector3(27.5,0.05,45.3), Vector3(31.0,0.05,45.3), Vector3(34.5,0.05,45.3)]
	for center in dinner_centers:
		for off in [Vector3(-0.88,0,0), Vector3(0.88,0,0)]:
			_spot("group_dinner_%02d" % idx, "group_seat", center + off, -off.normalized())
			idx += 1
