extends Node3D

const ProceduralHumanoid = preload("res://scripts/character/procedural_humanoid.gd")

var rig: Node3D
var home = Vector3.ZERO
var work_route: Array[Vector3] = []
var leisure_route: Array[Vector3] = []
var active_route: Array[Vector3] = []
var route_index = 0
var phase = "home"
var role = "office"
var speed = 1.18
var work_start = 8.5
var work_end = 17.0
var phase_offset = 0.0
var wait_left = 0.0

func setup(home_pos: Vector3, work_points: Array[Vector3], leisure_points: Array[Vector3], role_id: String, color: Color, offset: float) -> void:
	home = home_pos
	work_route = work_points.duplicate()
	leisure_route = leisure_points.duplicate()
	role = role_id.left(24)
	phase_offset = offset
	global_position = home
	rig = Node3D.new(); rig.set_script(ProceduralHumanoid); add_child(rig)
	rig.setup({"skin":Color("c99875"),"top":color,"pants":Color("303842"),"hair":Color("29221e"),"shoes":Color("17191d"),"height_scale":randf_range(0.95,1.05),"shoulder_scale":randf_range(0.94,1.05)})
	add_to_group("quality_crowd")
	add_to_group("dynamic_professional")
	_select_phase(true)

func _process(delta: float) -> void:
	_select_phase(false)
	if rig == null:
		return
	if wait_left > 0.0:
		wait_left -= delta
		if rig.has_method("set_activity_pose"): rig.set_activity_pose("exercise" if role == "fitness" and phase == "work" else "work" if phase == "work" else "")
		rig.update_pose(delta, 0.0, false, 0.0, true, false, 0.0)
		return
	if active_route.is_empty():
		return
	var target = active_route[route_index]
	var flat = target - global_position; flat.y = 0.0
	if flat.length() < 0.42:
		if route_index < active_route.size() - 1:
			route_index += 1
		else:
			wait_left = randf_range(4.0, 9.0)
		return
	var dir = flat.normalized()
	global_position += dir * speed * delta
	rotation.y = lerp_angle(rotation.y, atan2(-dir.x, -dir.z), min(1.0, delta * 5.0))
	if rig.has_method("set_activity_pose"): rig.set_activity_pose("")
	rig.update_pose(delta, speed, false, 0.0, true, false, 0.0)

func _select_phase(force: bool) -> void:
	var gs = get_node_or_null("/root/GameState")
	var hour = fposmod((float(gs.time_of_day) if gs != null else 12.0) + phase_offset, 24.0)
	var weekend = gs != null and int(gs.world_day) % 7 in [0, 6]
	var desired = "home"
	if not weekend and hour >= work_start and hour < work_end:
		desired = "work"
	elif hour >= 17.0 and hour < 22.5:
		desired = "leisure"
	if not force and desired == phase:
		return
	phase = desired
	route_index = 0
	wait_left = 0.0
	if phase == "work" and not work_route.is_empty():
		active_route = work_route.duplicate()
	elif phase == "leisure" and not leisure_route.is_empty():
		active_route = leisure_route.duplicate()
	else:
		active_route = [Vector3(169.0, max(home.y, 0.05), 136.0), Vector3(home.x, max(home.y, 0.05), 134.0), home]

func set_simulation_enabled(enabled: bool) -> void:
	visible = enabled
	set_process(enabled)
