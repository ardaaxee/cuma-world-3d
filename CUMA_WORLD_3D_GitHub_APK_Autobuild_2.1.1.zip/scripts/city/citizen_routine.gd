extends Node3D

const ProceduralHumanoidScript = preload("res://scripts/character/procedural_humanoid.gd")

var route: Array[Vector3] = []
var target_index = 0
var speed = 1.2
var pause_until = 0
var rig: Node3D
var schedule_seed = 0.0
var activity_time = 0.0

func setup(points: Array[Vector3], top_color: Color, seed_value: float = 0.0) -> void:
	route = points
	schedule_seed = seed_value
	speed = 0.95 + fmod(seed_value * 0.37,0.75)
	rig = Node3D.new()
	rig.set_script(ProceduralHumanoidScript)
	add_child(rig)
	rig.setup({
		"skin": Color("c99b78").lightened(fmod(seed_value,0.08)),
		"top": top_color,
		"pants": top_color.darkened(0.38),
		"hair": Color("24211f").lightened(fmod(seed_value*0.23,0.12)),
		"shoes": Color("16181a"),
		"height_scale": 0.94 + fmod(seed_value*0.07,0.11),
		"shoulder_scale": 0.94 + fmod(seed_value*0.05,0.09)
	})
	if not route.is_empty():
		global_position = route[0]
		target_index = 1 % route.size()

func _process(delta: float) -> void:
	if route.size() < 2 or rig == null:
		return
	activity_time += delta
	if Time.get_ticks_msec() < pause_until:
		rig.update_pose(delta,0.0,false,0.0,true,false,0.0)
		if fmod(activity_time + schedule_seed,9.0) < 0.03:
			rig.play_emote("wave")
		return
	var target = route[target_index]
	var flat = target - global_position
	flat.y = 0.0
	if flat.length() < 0.36:
		target_index = (target_index + 1) % route.size()
		var pause_chance = 0.28 + fmod(schedule_seed*0.11,0.22)
		if randf() < pause_chance:
			pause_until = Time.get_ticks_msec() + randi_range(700,3600)
		return
	var dir = flat.normalized()
	global_position += dir * speed * delta
	rotation.y = lerp_angle(rotation.y,atan2(-dir.x,-dir.z),min(1.0,delta*5.2))
	rig.update_pose(delta,speed,false,0.0,true,false,0.0)
