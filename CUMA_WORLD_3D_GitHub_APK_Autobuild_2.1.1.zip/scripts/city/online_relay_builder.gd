extends Node

const PairActivity = preload("res://scripts/together/pair_activity.gd")
const SocialCitizen = preload("res://scripts/city/social_citizen.gd")
var root: Node3D

func setup(world: Node3D) -> void:
	root = Node3D.new()
	root.name = "OnlineRelay11"
	world.add_child(root)
	_build_neighborhood_extension()
	_build_social_crowd()
	_build_pair_activities()

func _build_neighborhood_extension() -> void:
	# A quieter residential extension north of the 0.9 promenade.
	_box(Vector3(52,0.14,34),Vector3(38,-0.05,112),Color("777a70"),true)
	_box(Vector3(10,0.10,34),Vector3(38,0.01,112),Color("34383b"),true)
	for z in range(98,128,6):
		_box(Vector3(0.12,0.02,2.8),Vector3(38,0.08,float(z)),Color("e5dfc9"),false)
	for i in range(4):
		var x = 20.0 + float(i)*12.0
		_build_townhouse(Vector3(x,0,106),i)
	for p in [Vector3(18,0,123),Vector3(29,0,124),Vector3(49,0,123),Vector3(59,0,124)]:
		_tree(p)
	# Small plaza for social NPCs and co-op activities.
	_box(Vector3(22,0.10,12),Vector3(38,0.04,130),Color("a29d92"),true)
	for p in [Vector3(30,0,130),Vector3(46,0,130)]:
		_bench(p)
	_fountain(Vector3(38,0,130))

func _build_townhouse(c: Vector3, index: int) -> void:
	var facade = [Color("b7a58f"),Color("a6adb0"),Color("c1b1a1"),Color("a9b5a2")][index%4]
	_box(Vector3(9.2,7.2,9.5),c+Vector3(0,3.6,0),facade,true)
	_box(Vector3(9.5,0.22,9.8),c+Vector3(0,7.3,0),Color("4b4e51"),false)
	for floor in range(3):
		for col in [-2.7,0.0,2.7]:
			_window(c+Vector3(col,1.7+floor*2.0,-4.78))
	var label=Label3D.new(); label.text="RESIDENCE %02d"%(index+1); label.position=c+Vector3(0,1.2,-4.92); label.font_size=22; label.outline_size=5; root.add_child(label)

func _build_social_crowd() -> void:
	var paths: Array = [
		[Vector3(20,0.05,121),Vector3(30,0.05,130),Vector3(38,0.05,121)],
		[Vector3(56,0.05,121),Vector3(46,0.05,130),Vector3(38,0.05,121)],
		[Vector3(28,0.05,101),Vector3(30,0.05,130),Vector3(48,0.05,102)],
		[Vector3(48,0.05,101),Vector3(46,0.05,130),Vector3(28,0.05,102)],
		[Vector3(23,0.05,116),Vector3(38,0.05,130),Vector3(53,0.05,116)],
		[Vector3(53,0.05,116),Vector3(38,0.05,130),Vector3(23,0.05,116)]
	]
	var colors = [Color("536f86"),Color("8d6570"),Color("5c795f"),Color("8a7557"),Color("665b84"),Color("4e7477")]
	for i in range(paths.size()):
		var npc=Node3D.new(); npc.name="SocialCitizen_%02d"%i; npc.set_script(SocialCitizen); root.add_child(npc)
		var typed: Array[Vector3] = []
		for point in paths[i]:
			typed.append(point)
		npc.setup(typed,colors[i],float(i)*0.37)

func _build_pair_activities() -> void:
	_pair("neighborhood_walk","Yeni mahalleyi birlikte keşfet",Vector3(38,0.9,121),22,0.75)
	_pair("plaza_break","Meydanda birlikte mola ver",Vector3(38,0.9,130),18,0.5)
	_pair("future_home","Birlikte gelecekteki evi seçin",Vector3(44,0.9,106),30,1.0)
	_pair("evening_plaza","Akşam meydan ışıklarında yürüyün",Vector3(31,0.9,130),24,0.75)

func _pair(id:String,title:String,pos:Vector3,points:int,hours:float)->void:
	var body=StaticBody3D.new(); body.name="RelayDuo_"+id; body.position=pos; body.set_script(PairActivity); root.add_child(body)
	var c=CollisionShape3D.new(); var s=BoxShape3D.new(); s.size=Vector3(1.4,1.5,1.4); c.shape=s; body.add_child(c); body.setup(id,title,points,hours)

func _box(size:Vector3,pos:Vector3,color:Color,collision:bool)->void:
	var parent:Node3D
	if collision:
		var b=StaticBody3D.new(); b.position=pos; root.add_child(b); parent=b
		var c=CollisionShape3D.new(); var s=BoxShape3D.new(); s.size=size; c.shape=s; b.add_child(c)
	else:
		parent=root
	var mi=MeshInstance3D.new(); var mesh=BoxMesh.new(); mesh.size=size; mi.mesh=mesh
	if not collision: mi.position=pos
	var mat=StandardMaterial3D.new(); mat.albedo_color=color; mat.roughness=0.88; mi.material_override=mat; parent.add_child(mi)

func _window(pos:Vector3)->void:
	var mi=MeshInstance3D.new(); var mesh=BoxMesh.new(); mesh.size=Vector3(1.35,1.15,0.08); mi.mesh=mesh; mi.position=pos
	var mat=StandardMaterial3D.new(); mat.albedo_color=Color("86a1ad"); mat.roughness=0.15; mat.metallic=0.18; mi.material_override=mat; root.add_child(mi)

func _tree(pos:Vector3)->void:
	var trunk=MeshInstance3D.new(); var cm=CylinderMesh.new(); cm.top_radius=.14; cm.bottom_radius=.18; cm.height=2.5; trunk.mesh=cm; trunk.position=pos+Vector3(0,1.25,0); var tm=StandardMaterial3D.new(); tm.albedo_color=Color("654936"); tm.roughness=.96; trunk.material_override=tm; root.add_child(trunk)
	for off in [Vector3(0,2.8,0),Vector3(-.55,2.55,.1),Vector3(.55,2.5,-.1)]:
		var n=MeshInstance3D.new(); var sm=SphereMesh.new(); sm.radius=.55; sm.height=1.1; n.mesh=sm; n.position=pos+off; n.scale=Vector3(1.2,.9,1.2); var m=StandardMaterial3D.new(); m.albedo_color=Color("4a6a4c"); m.roughness=.99; n.material_override=m; root.add_child(n)

func _bench(pos:Vector3)->void:
	_box(Vector3(2.0,.14,.55),pos+Vector3(0,.5,0),Color("77573f"),false)
	_box(Vector3(2.0,.65,.12),pos+Vector3(0,.85,.28),Color("77573f"),false)

func _fountain(pos:Vector3)->void:
	var base=MeshInstance3D.new(); var cm=CylinderMesh.new(); cm.top_radius=1.5; cm.bottom_radius=1.6; cm.height=.45; cm.radial_segments=28; base.mesh=cm; base.position=pos+Vector3(0,.22,0); var m=StandardMaterial3D.new(); m.albedo_color=Color("8b8b86"); m.roughness=.8; base.material_override=m; root.add_child(base)
