extends Node

# Daily Life 1.6 - visible home interiors and anchors for local NPC routines.
const SmartSpot = preload("res://scripts/navigation/smart_spot.gd")
const DailyLifeDirector = preload("res://scripts/social/daily_life_director.gd")
const PairActivity = preload("res://scripts/together/pair_activity.gd")

var root: Node3D

func setup(world: Node3D) -> void:
	root = Node3D.new()
	root.name = "DailyLife16"
	world.add_child(root)
	_build_neighbor_apartments()
	_build_daily_spots()
	_build_pair_activities()
	var director = Node.new()
	director.name = "DailyLifeDirector"
	director.set_script(DailyLifeDirector)
	world.add_child(director)
	director.setup()

func _build_neighbor_apartments() -> void:
	var centers = [Vector3(20.2,0,145.0), Vector3(31.4,0,145.0), Vector3(42.6,0,145.0), Vector3(53.8,0,145.0)]
	var accents = [Color("b88776"),Color("6f8790"),Color("81728d"),Color("71806b")]
	for i in range(centers.size()):
		_build_open_apartment(centers[i], i, accents[i])
	var label = Label3D.new()
	label.text = "KOMŞU EVLERİ • GÜNLÜK YAŞAM"
	label.position = Vector3(37.0,3.4,140.9)
	label.font_size = 27
	label.outline_size = 6
	root.add_child(label)

func _build_open_apartment(c: Vector3, index: int, accent: Color) -> void:
	# Open south-facing room: floor + back/side walls; avoids closed placeholder boxes.
	_box(Vector3(9.4,0.10,6.0), c + Vector3(0,0.05,0), Color("b58b65"), true)
	_box(Vector3(9.4,3.0,0.14), c + Vector3(0,1.5,2.95), Color("ddd8cf"), true)
	_box(Vector3(0.14,3.0,6.0), c + Vector3(-4.63,1.5,0), Color("dedbd4"), true)
	_box(Vector3(0.14,3.0,6.0), c + Vector3(4.63,1.5,0), Color("dedbd4"), true)
	# Sofa silhouette.
	_round_box(Vector3(2.5,0.42,0.88), c+Vector3(-2.4,0.36,1.45), accent)
	_round_box(Vector3(2.5,0.84,0.22), c+Vector3(-2.4,0.74,1.82), accent.darkened(0.08))
	# Bed with headboard.
	_round_box(Vector3(2.2,0.36,1.55), c+Vector3(2.6,0.32,1.35), Color("d6d2cc"))
	_box(Vector3(2.25,1.05,0.16), c+Vector3(2.6,0.78,2.14), accent.darkened(0.16), false)
	# Kitchen counter and breakfast stool.
	_box(Vector3(3.0,0.90,0.62), c+Vector3(-2.5,0.45,-1.9), Color("745a45"), false)
	_box(Vector3(3.05,0.08,0.68), c+Vector3(-2.5,0.94,-1.9), Color("d1c8bb"), false)
	_cylinder(c+Vector3(-0.2,0.38,-1.55),0.26,0.72,Color("51463d"))
	# Small work desk / personal objects.
	_box(Vector3(1.7,0.10,0.72), c+Vector3(2.75,0.74,-1.85), Color("765d49"), false)
	_box(Vector3(0.65,0.50,0.06), c+Vector3(2.75,1.10,-2.05), Color("22272b"), false)
	for k in range(3):
		_box(Vector3(0.18,0.30+0.08*k,0.18), c+Vector3(3.55-float(k)*0.25,0.25,-1.55), [Color("8b6657"),Color("607a61"),Color("6f6885")][k], false)
	var label = Label3D.new()
	label.text = "DAİRE %s" % ["A","B","C","D"][index]
	label.position = c + Vector3(0,2.55,-2.78)
	label.font_size = 20
	label.outline_size = 5
	root.add_child(label)

func _build_daily_spots() -> void:
	var home_points = [
		["ece",Vector3(18.5,0.05,144.0)], ["selin",Vector3(22.0,0.05,144.0)],
		["deniz",Vector3(29.5,0.05,144.0)], ["mert",Vector3(33.0,0.05,144.0)],
		["ipek",Vector3(40.5,0.05,144.0)], ["kerem",Vector3(44.0,0.05,144.0)],
		["elif",Vector3(51.5,0.05,144.0)], ["baran",Vector3(55.0,0.05,144.0)]
	]
	for item in home_points:
		_spot("home_"+str(item[0]), "home_life", item[1], Vector3(0,0,-1))
	# Meal/order anchors: NPC sits first, then the meal prop appears in their hands/table space.
	for i in range(4):
		_spot("dinner_order_%02d"%i, "meal_order", Vector3(28.7+float(i)*1.55,0.05,45.8), Vector3(0,0,-1))
	# Weekend meeting points.
	for i in range(4):
		_spot("weekend_%02d"%i, "weekend_meet", Vector3(65.4+float(i)*1.1,0.05,129.3+float(i%2)*0.7), Vector3(0,0,-1))

func _build_pair_activities() -> void:
	_pair("weekend_brunch", "Hafta sonu birlikte brunch yapın", Vector3(67.0,0.9,129.2), 24, 0.65)
	_pair("weekly_grocery", "Haftalık market alışverişini birlikte yapın", Vector3(15.0,0.9,38.0), 20, 0.55)
	_pair("neighbor_celebration", "Komşu kutlamasına birlikte katılın", Vector3(84.0,0.9,129.0), 30, 0.85)
	_pair("cook_for_guests", "Misafirler için birlikte yemek hazırlayın", Vector3(6.4,0.9,4.5), 28, 0.75)

func _pair(id:String,title:String,pos:Vector3,points:int,hours:float)->void:
	var body=StaticBody3D.new(); body.name="DailyDuo_"+id; body.position=pos; body.set_script(PairActivity); root.add_child(body)
	var collision=CollisionShape3D.new(); var shape=BoxShape3D.new(); shape.size=Vector3(1.3,1.5,1.3); collision.shape=shape; body.add_child(collision)
	body.setup(id,title,points,hours)

func _spot(id_value:String, kind:String, pos:Vector3, face:Vector3) -> void:
	var spot=Node3D.new()
	spot.name="DailySpot_"+id_value
	spot.set_script(SmartSpot)
	root.add_child(spot)
	spot.setup(id_value,kind,pos,face)

func _round_box(size:Vector3,pos:Vector3,color:Color)->void:
	# Softened silhouette: central box plus round end cushions.
	_box(size,pos,color,false)
	for x in [-size.x*0.48,size.x*0.48]:
		var end=MeshInstance3D.new(); var sm=SphereMesh.new(); sm.radius=min(size.y,size.z)*0.48; sm.height=min(size.y,size.z)*0.96; end.mesh=sm
		end.position=pos+Vector3(x,0,0); end.scale=Vector3(0.72,1.0,1.0)
		var mat=StandardMaterial3D.new(); mat.albedo_color=color; mat.roughness=0.92; end.material_override=mat; root.add_child(end)

func _cylinder(pos:Vector3,radius:float,height:float,color:Color)->void:
	var mi=MeshInstance3D.new(); var cm=CylinderMesh.new(); cm.top_radius=radius; cm.bottom_radius=radius*1.05; cm.height=height; cm.radial_segments=18; mi.mesh=cm; mi.position=pos
	var mat=StandardMaterial3D.new(); mat.albedo_color=color; mat.roughness=0.88; mi.material_override=mat; root.add_child(mi)

func _box(size:Vector3,pos:Vector3,color:Color,collision:bool)->void:
	var parent:Node3D
	if collision:
		var body=StaticBody3D.new(); body.position=pos; root.add_child(body); parent=body
		var shape=CollisionShape3D.new(); var box=BoxShape3D.new(); box.size=size; shape.shape=box; body.add_child(shape)
	else:
		parent=root
	var mesh_instance=MeshInstance3D.new(); var mesh=BoxMesh.new(); mesh.size=size; mesh_instance.mesh=mesh
	if not collision: mesh_instance.position=pos
	var mat=StandardMaterial3D.new(); mat.albedo_color=color; mat.roughness=0.90; mesh_instance.material_override=mat; parent.add_child(mesh_instance)
