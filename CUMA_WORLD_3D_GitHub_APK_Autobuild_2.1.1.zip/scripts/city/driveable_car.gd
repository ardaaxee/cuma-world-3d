extends CharacterBody3D

var driver: Node = null
var current_speed = 0.0
var max_speed = 15.0
var reverse_speed = 6.0
var acceleration = 9.0
var brake_force = 15.0
var drag = 4.0
var steer_rate = 1.65
var spawn_transform = Transform3D.IDENTITY
var body_material: StandardMaterial3D
var wheel_nodes: Array[Node3D] = []
var vehicle_id = "city_car_01"
var driver_peer_id = 0
var passenger_peer_id = 0
var network_accum = 0.0
var input_accum = 0.0
var target_transform = Transform3D.IDENTITY
var has_network_target = false
var driver_occupant_visual: Node3D
var passenger_occupant_visual: Node3D

func setup(color: Color = Color("395a79"), id_value: String = "city_car_01") -> void:
	vehicle_id = id_value.left(48)
	spawn_transform = global_transform
	target_transform = global_transform
	_build_car(color)
	add_to_group("driveable_vehicle")
	var net = get_node_or_null("/root/NetworkManager")
	if net != null:
		net.register_vehicle(vehicle_id, global_position)
		if not net.vehicle_seat_changed.is_connected(_on_vehicle_seat_changed):
			net.vehicle_seat_changed.connect(_on_vehicle_seat_changed)
		if not net.vehicle_state_received.is_connected(_on_vehicle_state_received):
			net.vehicle_state_received.connect(_on_vehicle_state_received)

func _build_car(color: Color) -> void:
	body_material = _mat(color, 0.35, 0.72)
	_box(Vector3(1.78,0.42,3.55),Vector3(0,0.63,0),body_material)
	_box(Vector3(1.60,0.56,1.72),Vector3(0,1.04,-0.20),body_material)
	_box(Vector3(1.36,0.42,0.80),Vector3(0,1.22,-0.55),_glass())
	_box(Vector3(1.38,0.32,0.58),Vector3(0,1.17,0.60),_glass())
	# visible driver/passenger seat silhouettes
	for x in [-0.42,0.42]:
		_box(Vector3(0.52,0.18,0.58),Vector3(x,0.72,0.10),_mat(Color("26282c"),0.92,0.02))
		_box(Vector3(0.52,0.58,0.14),Vector3(x,1.02,0.36),_mat(Color("26282c"),0.92,0.02))
	driver_occupant_visual = _occupant_marker(-0.42,Color("263653"))
	passenger_occupant_visual = _occupant_marker(0.42,Color("7a5266"))
	for x in [-0.91,0.91]:
		for z in [-1.18,1.18]:
			var wheel = _wheel(Vector3(x,0.40,z))
			wheel_nodes.append(wheel)
	for x in [-0.58,0.58]:
		_sphere(Vector3(x,0.72,-1.79),Vector3(0.18,0.12,0.06),_emissive(Color("fff0ce"),2.2))
		_sphere(Vector3(x,0.72,1.79),Vector3(0.17,0.11,0.06),_emissive(Color("df352f"),1.8))
	var collider = CollisionShape3D.new()
	var shape = BoxShape3D.new()
	shape.size = Vector3(1.85,1.28,3.55)
	collider.shape = shape
	collider.position = Vector3(0,0.64,0)
	add_child(collider)

func get_interaction_label() -> String:
	var net = get_node_or_null("/root/NetworkManager")
	if net == null or not net.is_online():
		return "Araçtan in" if driver != null else "ARABA • Sür"
	var local_id = net.get_local_peer_id()
	if local_id == driver_peer_id or local_id == passenger_peer_id:
		return "ARABA • İn"
	if driver_peer_id == 0:
		return "ARABA • Sürücü koltuğu"
	if passenger_peer_id == 0:
		return "ARABA • Yolcu koltuğu"
	return "ARABA • Dolu"

func interact(player: Node) -> void:
	var net = get_node_or_null("/root/NetworkManager")
	if net != null and net.is_online():
		var local_id = net.get_local_peer_id()
		if local_id == driver_peer_id or local_id == passenger_peer_id:
			net.request_vehicle_leave(vehicle_id)
		elif driver_peer_id == 0:
			net.request_vehicle_seat(vehicle_id,"driver")
		elif passenger_peer_id == 0:
			net.request_vehicle_seat(vehicle_id,"passenger")
		elif player != null and player.has_method("show_status"):
			player.show_status("Araç dolu • 2/2",2.0)
		return
	if driver == null:
		if player != null and player.has_method("enter_vehicle"):
			driver = player
			player.enter_vehicle(self,"driver")
	else:
		exit_vehicle(driver)

func exit_vehicle(player: Node) -> void:
	var net = get_node_or_null("/root/NetworkManager")
	if net != null and net.is_online():
		net.request_vehicle_leave(vehicle_id)
		return
	if driver == null or player != driver:
		return
	var side = global_transform.basis.x.normalized()
	var exit_pos = global_position + side * 1.55 + Vector3.UP * 0.05
	driver = null
	if player.has_method("exit_vehicle"):
		player.exit_vehicle(exit_pos, rotation.y)

func _physics_process(delta: float) -> void:
	var net = get_node_or_null("/root/NetworkManager")
	if net != null and net.is_online():
		_physics_networked(delta,net)
		return
	_physics_offline(delta)

func _physics_offline(delta: float) -> void:
	if driver == null:
		_simulate(Vector2.ZERO,delta)
	else:
		if not is_instance_valid(driver):
			driver = null
			return
		var input = driver.get_drive_input() if driver.has_method("get_drive_input") else Vector2.ZERO
		_simulate(input,delta)
		if driver.has_method("update_vehicle_anchor"):
			driver.update_vehicle_anchor(global_transform,current_speed)
	_spin_wheels(delta)

func _physics_networked(delta: float, net: Node) -> void:
	var local_id = net.get_local_peer_id()
	if net.multiplayer.is_server():
		var input = Vector2.ZERO
		if driver_peer_id != 0:
			if driver_peer_id == local_id:
				var local_player = get_tree().get_first_node_in_group("player")
				if local_player != null and local_player.has_method("get_drive_input"):
					input = local_player.get_drive_input()
			else:
				input = net.get_vehicle_input(driver_peer_id)
		_simulate(input,delta)
		network_accum += delta
		if network_accum >= 0.065:
			network_accum = 0.0
			net.publish_vehicle_state(vehicle_id,global_transform,current_speed)
	else:
		if local_id == driver_peer_id:
			input_accum += delta
			if input_accum >= 0.045:
				input_accum = 0.0
				var p = get_tree().get_first_node_in_group("player")
				if p != null and p.has_method("get_drive_input"):
					net.submit_vehicle_input(vehicle_id,p.get_drive_input())
		if has_network_target:
			global_transform = global_transform.interpolate_with(target_transform,min(1.0,delta*10.0))
			current_speed = lerpf(current_speed,get_meta("target_speed",current_speed),min(1.0,delta*8.0))
	_update_local_occupant_anchor(net)
	_spin_wheels(delta)

func _simulate(input: Vector2, delta: float) -> void:
	var throttle = -input.y
	var steer = input.x
	if throttle > 0.05:
		current_speed = move_toward(current_speed,max_speed,acceleration*delta)
	elif throttle < -0.05:
		if current_speed > 0.8:
			current_speed = move_toward(current_speed,0.0,brake_force*delta)
		else:
			current_speed = move_toward(current_speed,-reverse_speed,acceleration*0.65*delta)
	else:
		current_speed = move_toward(current_speed,0.0,drag*delta)
	var steer_strength = clamp(abs(current_speed)/4.0,0.15,1.0)
	if abs(current_speed) > 0.15:
		rotation.y -= steer*steer_rate*steer_strength*delta*sign(current_speed)
	velocity = -global_transform.basis.z*current_speed
	velocity.y = -2.0 if not is_on_floor() else 0.0
	move_and_slide()
	global_position.y = max(global_position.y,0.02)

func _on_vehicle_seat_changed(id_value: String, driver_id: int, passenger_id: int) -> void:
	if id_value != vehicle_id:
		return
	driver_peer_id = driver_id
	passenger_peer_id = passenger_id
	if driver_occupant_visual != null:
		driver_occupant_visual.visible = driver_peer_id != 0
	if passenger_occupant_visual != null:
		passenger_occupant_visual.visible = passenger_peer_id != 0
	var net = get_node_or_null("/root/NetworkManager")
	if net == null:
		return
	var local_id = net.get_local_peer_id()
	var player = get_tree().get_first_node_in_group("player")
	if player == null:
		return
	if local_id == driver_peer_id:
		player.enter_vehicle(self,"driver")
	elif local_id == passenger_peer_id:
		player.enter_vehicle(self,"passenger")
	elif player.driving_vehicle == self:
		var side = global_transform.basis.x.normalized()
		player.exit_vehicle(global_position+side*1.55+Vector3.UP*0.05,rotation.y)

func _on_vehicle_state_received(id_value: String, value: Transform3D, speed: float, driver_id: int, passenger_id: int) -> void:
	if id_value != vehicle_id:
		return
	target_transform = value
	has_network_target = true
	set_meta("target_speed",speed)
	driver_peer_id = driver_id
	passenger_peer_id = passenger_id
	if driver_occupant_visual != null:
		driver_occupant_visual.visible = driver_peer_id != 0
	if passenger_occupant_visual != null:
		passenger_occupant_visual.visible = passenger_peer_id != 0

func _update_local_occupant_anchor(net: Node) -> void:
	var local_id = net.get_local_peer_id()
	if local_id != driver_peer_id and local_id != passenger_peer_id:
		return
	var player = get_tree().get_first_node_in_group("player")
	if player != null and player.has_method("update_vehicle_anchor"):
		player.update_vehicle_anchor(global_transform,current_speed)

func _spin_wheels(delta: float) -> void:
	for wheel in wheel_nodes:
		if is_instance_valid(wheel):
			wheel.rotate_x(current_speed*delta*1.8)

func reset_vehicle() -> void:
	global_transform = spawn_transform
	target_transform = spawn_transform
	current_speed = 0.0
	velocity = Vector3.ZERO

func _occupant_marker(x: float, shirt: Color) -> Node3D:
	var root = Node3D.new()
	root.position = Vector3(x,0.0,0.02)
	add_child(root)
	var torso = MeshInstance3D.new()
	var torso_mesh = CapsuleMesh.new()
	torso_mesh.radius = 0.20
	torso_mesh.height = 0.58
	torso.mesh = torso_mesh
	torso.position = Vector3(0,0.98,0)
	torso.material_override = _mat(shirt,0.90,0.0)
	root.add_child(torso)
	var head = MeshInstance3D.new()
	var head_mesh = SphereMesh.new()
	head_mesh.radius = 0.19
	head_mesh.height = 0.38
	head.mesh = head_mesh
	head.position = Vector3(0,1.40,-0.02)
	head.material_override = _mat(Color("d3a17f"),0.86,0.0)
	root.add_child(head)
	root.visible = false
	return root

func _box(size: Vector3,pos: Vector3,material: Material) -> MeshInstance3D:
	var node=MeshInstance3D.new(); var mesh=BoxMesh.new(); mesh.size=size; node.mesh=mesh; node.position=pos; node.material_override=material; add_child(node); return node
func _wheel(pos: Vector3) -> Node3D:
	var root=Node3D.new(); root.position=pos; add_child(root); var wheel=MeshInstance3D.new(); var mesh=CylinderMesh.new(); mesh.top_radius=0.31; mesh.bottom_radius=0.31; mesh.height=0.18; mesh.radial_segments=18; wheel.mesh=mesh; wheel.rotation_degrees.z=90.0; wheel.material_override=_mat(Color("17191b"),0.92,0.0); root.add_child(wheel); return root
func _sphere(pos: Vector3,scale_value: Vector3,material: Material) -> void:
	var node=MeshInstance3D.new(); var mesh=SphereMesh.new(); mesh.radius=0.5; mesh.height=1.0; node.mesh=mesh; node.position=pos; node.scale=scale_value*2.0; node.material_override=material; add_child(node)
func _mat(color: Color,roughness: float,metallic: float) -> StandardMaterial3D:
	var mat=StandardMaterial3D.new(); mat.albedo_color=color; mat.roughness=roughness; mat.metallic=metallic; return mat
func _glass() -> StandardMaterial3D:
	var mat=_mat(Color(0.20,0.31,0.38,0.72),0.10,0.20); mat.transparency=BaseMaterial3D.TRANSPARENCY_ALPHA; mat.cull_mode=BaseMaterial3D.CULL_DISABLED; return mat
func _emissive(color: Color,energy: float) -> StandardMaterial3D:
	var mat=_mat(color,0.30,0.05); mat.emission_enabled=true; mat.emission=color; mat.emission_energy_multiplier=energy; return mat
