extends Node

const PublicTransportVehicle = preload("res://scripts/city/public_transport_vehicle.gd")
const ProfessionalCitizen = preload("res://scripts/city/professional_citizen.gd")
const CareerTerminal = preload("res://scripts/economy/career_terminal.gd")
const HairSalonStation = preload("res://scripts/character/hair_salon_station.gd")
const PairActivity = preload("res://scripts/together/pair_activity.gd")
const EventGuest = preload("res://scripts/city/event_guest.gd")
const DynamicCityDirector = preload("res://scripts/social/dynamic_city_director.gd")
const ActivityStation = preload("res://scripts/city/activity_station.gd")

var root: Node3D

func setup(world: Node3D) -> void:
	root = Node3D.new(); root.name = "DynamicCity18"; world.add_child(root)
	_build_city_center()
	_build_workplaces()
	_build_career_terminals()
	_build_public_transport()
	_spawn_professionals()
	_build_home_party()
	_build_pair_activities()
	var director = Node.new(); director.name = "DynamicCityDirector"; director.set_script(DynamicCityDirector); world.add_child(director); director.setup()

func _build_city_center() -> void:
	_box(Vector3(78,0.12,66), Vector3(169,0.02,102), Color("777a78"), true)
	_box(Vector3(12,0.08,66), Vector3(169,0.09,102), Color("30353a"), true)
	_box(Vector3(78,0.08,10), Vector3(169,0.10,102), Color("30353a"), true)
	# Main plaza uses stone bands rather than one empty slab.
	for x in range(143,197,4):
		_box(Vector3(2.8,0.035,18), Vector3(float(x),0.13,126), Color("a7a39a") if x % 8 == 0 else Color("929087"), false)
	for p in [Vector3(147,0,123),Vector3(158,0,129),Vector3(181,0,123),Vector3(192,0,129)]: _tree(p)
	for p in [Vector3(153,0,126),Vector3(187,0,126)]: _bench(p)
	var sign = Label3D.new(); sign.text = "CUMA CITY CENTER • 1.8"; sign.position = Vector3(169,4.4,134); sign.font_size = 38; sign.outline_size = 8; root.add_child(sign)

func _build_workplaces() -> void:
	_open_building("CUMA OFFICE", Vector3(148,0,87), Color("657381"), "office")
	_open_building("CREATIVE LAB", Vector3(166,0,87), Color("796b83"), "creative")
	_open_building("CUMA FIT PLUS", Vector3(184,0,87), Color("657867"), "fitness")
	_open_building("STUDIO HAIR PLUS", Vector3(148,0,113), Color("896f72"), "salon")
	_open_building("CITY SERVICES", Vector3(166,0,113), Color("786f62"), "service")
	_open_building("CO-WORK", Vector3(184,0,113), Color("697b84"), "office")

func _open_building(title: String, c: Vector3, accent: Color, kind: String) -> void:
	# Open south front: characters visibly enter instead of walking through a solid facade.
	_box(Vector3(14,0.12,12), c + Vector3(0,0.06,0), Color("b6a88e"), true)
	_box(Vector3(14,4.2,0.18), c + Vector3(0,2.1,5.9), Color("d7d5cf"), true)
	_box(Vector3(0.18,4.2,12), c + Vector3(-6.9,2.1,0), Color("d7d5cf"), true)
	_box(Vector3(0.18,4.2,12), c + Vector3(6.9,2.1,0), Color("d7d5cf"), true)
	# Front columns leave a real entrance opening.
	_box(Vector3(4.6,4.2,0.18), c + Vector3(-4.65,2.1,-5.9), accent, true)
	_box(Vector3(4.6,4.2,0.18), c + Vector3(4.65,2.1,-5.9), accent, true)
	_glass(c + Vector3(-4.6,2.15,-6.01), Vector3(3.8,2.65,0.05))
	_glass(c + Vector3(4.6,2.15,-6.01), Vector3(3.8,2.65,0.05))
	var sign = Label3D.new(); sign.text = title; sign.position = c + Vector3(0,3.55,-6.08); sign.font_size = 26; sign.outline_size = 6; root.add_child(sign)
	match kind:
		"office":
			for x in [-4.2,0.0,4.2]: _desk(c + Vector3(x,0,-0.2))
		"creative":
			for x in [-4.0,0.0,4.0]: _desk(c + Vector3(x,0,-0.6))
			for x in [-3.0,3.0]: _easel(c + Vector3(x,0,2.5))
		"fitness":
			for x in [-4.0, 0.0, 4.0]:
				_gym_station(c + Vector3(x, 0, 0.5))
				_activity_station(c + Vector3(x, 0.9, -0.6), "Antrenman yap")
		"salon":
			for x in [-3.7,0.0,3.7]: _salon_chair(c + Vector3(x,0,0.5))
		"service":
			_box(Vector3(9.5,0.95,0.65), c + Vector3(0,0.48,1.9), Color("7b674f"), false)
			for x in [-3.5,0.0,3.5]: _desk(c + Vector3(x,0,-1.2))

func _build_career_terminals() -> void:
	_career("OfficeCareer", Vector3(148,0.9,83.0), "office", "Ofis vardiyası", 90, 38, 1.5)
	_career("CreativeCareer", Vector3(166,0.9,83.0), "creative", "Yaratıcı stüdyo vardiyası", 82, 44, 1.5)
	_career("FitnessCareer", Vector3(184,0.9,83.0), "fitness", "Fitness koçluğu vardiyası", 86, 42, 1.25)
	_career("ServiceCareer", Vector3(166,0.9,109.0), "service", "Şehir hizmetleri vardiyası", 78, 34, 1.25)
	var salon = StaticBody3D.new(); salon.name = "HairStyle18"; salon.position = Vector3(148,0.9,109.0); salon.set_script(HairSalonStation); root.add_child(salon); _collision(salon,Vector3(1.0,1.5,0.8))
	var label = Label3D.new(); label.text = "SAÇ STİLİ"; label.position = Vector3(0,1.15,0); label.font_size = 22; label.outline_size = 5; label.billboard = BaseMaterial3D.BILLBOARD_ENABLED; salon.add_child(label)

func _build_public_transport() -> void:
	var bus_route: Array[Vector3] = [Vector3(0,0.08,22),Vector3(15,0.08,38),Vector3(38,0.08,70),Vector3(76,0.08,120),Vector3(116,0.08,72),Vector3(142,0.08,72),Vector3(169,0.08,72),Vector3(198,0.08,78),Vector3(198,0.08,126),Vector3(169,0.08,136),Vector3(116,0.08,124),Vector3(76,0.08,120),Vector3(38,0.08,70),Vector3(15,0.08,38)]
	var bus = StaticBody3D.new(); bus.name = "CityBus18"; bus.set_script(PublicTransportVehicle); root.add_child(bus); bus.setup("city_bus_18","ŞEHİR OTOBÜSÜ",bus_route,7.2,Color("486b82"))
	var taxi_route: Array[Vector3] = [Vector3(116,0.08,102),Vector3(142,0.08,102),Vector3(169,0.08,102),Vector3(198,0.08,102),Vector3(198,0.08,126),Vector3(169,0.08,136),Vector3(142,0.08,102)]
	var taxi = StaticBody3D.new(); taxi.name = "CityTaxi18"; taxi.set_script(PublicTransportVehicle); root.add_child(taxi); taxi.setup("city_taxi_18","TAKSİ",taxi_route,9.0,Color("d4b649"))
	for item in [[Vector3(15,0,38),"EV"],[Vector3(76,0,120),"KOMŞULUK"],[Vector3(116,0,72),"TOPLUM"],[Vector3(169,0,72),"MERKEZ"]]: _bus_stop(item[0],item[1])

func _spawn_professionals() -> void:
	var roles = ["office","creative","fitness","service","office","creative","fitness","service"]
	var colors = [Color("596b7b"),Color("7b607b"),Color("5c765f"),Color("806d58"),Color("66748c"),Color("8a6b68"),Color("536f62"),Color("776c87")]
	for i in range(8):
		var role: String = roles[i]
		var home = Vector3(142.0 + float(i%4)*5.0,0.05,142.0+float(i/4)*3.0)
		var center_x = 148.0 if role == "office" and i < 4 else 166.0 if role in ["creative","service"] else 184.0
		var center_z = 87.0 if role != "service" else 113.0
		var work: Array[Vector3] = [Vector3(home.x,0.05,134),Vector3(169,0.05,128),Vector3(center_x,0.05,80.5 if center_z < 100 else 106.5),Vector3(center_x,0.05,center_z-2.0),Vector3(center_x+float((i%3)-1)*2.8,0.05,center_z)]
		var leisure: Array[Vector3] = [Vector3(169,0.05,128),Vector3(160+float(i%4)*6.0,0.05,126)]
		var npc = Node3D.new(); npc.name = "Professional_%02d"%i; npc.set_script(ProfessionalCitizen); root.add_child(npc); npc.setup(home,work,leisure,role,colors[i],float(i)*0.12)

func _build_home_party() -> void:
	var c = Vector3(158,0,150)
	_box(Vector3(16,0.12,10),c+Vector3(0,0.06,0),Color("b48b68"),true)
	_box(Vector3(16,3.4,0.16),c+Vector3(0,1.7,4.9),Color("dbd6ce"),true)
	_box(Vector3(0.16,3.4,10),c+Vector3(-7.9,1.7,0),Color("dbd6ce"),true)
	_box(Vector3(0.16,3.4,10),c+Vector3(7.9,1.7,0),Color("dbd6ce"),true)
	_round_sofa(c+Vector3(-3.8,0,2.5),Color("6e6575")); _round_sofa(c+Vector3(3.8,0,2.5),Color("68746a"))
	_box(Vector3(3.0,0.12,1.2),c+Vector3(0,0.72,1.6),Color("795c43"),false)
	var sign = Label3D.new(); sign.text = "KOMŞU EV BULUŞMASI"; sign.position = c+Vector3(0,2.8,-4.8); sign.font_size=24; sign.outline_size=6; root.add_child(sign)
	var party_points: Array[Vector3] = [c+Vector3(-4,0.05,0),c+Vector3(-1.5,0.05,1.8),c+Vector3(1.5,0.05,1.8),c+Vector3(4,0.05,0),c+Vector3(0,0.05,-1.8)]
	var colors = [Color("7c5e70"),Color("577184"),Color("687557"),Color("80634f"),Color("6c6384"),Color("8a6d68")]
	for i in range(6):
		var guest = Node3D.new(); guest.name="PartyGuest_%02d"%i; guest.set_script(EventGuest); root.add_child(guest)
		var rotated = party_points.duplicate()
		if i % 2 == 1:
			var tail = rotated.pop_back()
			rotated.push_front(tail)
		guest.setup(rotated, colors[i])

func _build_pair_activities() -> void:
	_pair("duo_career_day","Birlikte şehirde çalışma günü",Vector3(157,0.9,80),28,0.75)
	_pair("duo_bus_ride_18","Birlikte şehir otobüsüne binin",Vector3(169,0.9,72),22,0.45)
	_pair("duo_gym_plus","Birlikte spor salonunda antrenman",Vector3(184,0.9,90),26,0.65)
	_pair("duo_hair_day_18","Birlikte yeni stil seçin",Vector3(148,0.9,116),20,0.40)
	_pair("duo_house_party_18","Komşu ev buluşmasına birlikte katılın",Vector3(158,0.9,146),32,0.90)
	_pair("duo_city_center_18","Şehir merkezinde birlikte vakit geçirin",Vector3(169,0.9,126),24,0.60)

func _activity_station(pos: Vector3, title: String) -> void:
	var body = StaticBody3D.new()
	body.name = "ActivityStation"
	body.position = pos
	body.set_script(ActivityStation)
	root.add_child(body)
	_collision(body, Vector3(0.9, 1.3, 0.8))
	body.setup(title, "exercise", 4.0, 30)

func _career(name_value:String,pos:Vector3,id:String,title:String,pay:int,xp:int,hours:float)->void:
	var body=StaticBody3D.new(); body.name=name_value; body.position=pos; body.set_script(CareerTerminal); root.add_child(body); _collision(body,Vector3(1.1,1.5,0.8)); body.setup(id,title,pay,xp,hours)
	var label=Label3D.new(); label.text=title; label.position=Vector3(0,1.15,0); label.font_size=20; label.outline_size=5; label.billboard=BaseMaterial3D.BILLBOARD_ENABLED; body.add_child(label)

func _pair(id:String,title:String,pos:Vector3,points:int,hours:float)->void:
	var body=StaticBody3D.new(); body.name="DynamicDuo_"+id; body.position=pos; body.set_script(PairActivity); root.add_child(body); _collision(body,Vector3(1.2,1.5,1.2)); body.setup(id,title,points,hours)

func _bus_stop(pos:Vector3,title:String)->void:
	var pole=MeshInstance3D.new(); var cm=CylinderMesh.new(); cm.top_radius=.04; cm.bottom_radius=.05; cm.height=2.2; cm.radial_segments=10; pole.mesh=cm; pole.position=pos+Vector3(0,1.1,0); var mat=StandardMaterial3D.new(); mat.albedo_color=Color("303840"); pole.material_override=mat; root.add_child(pole)
	var l=Label3D.new(); l.text="DURAK • "+title; l.position=pos+Vector3(0,2.2,0); l.font_size=18; l.outline_size=5; l.billboard=BaseMaterial3D.BILLBOARD_ENABLED; root.add_child(l)

func _desk(c:Vector3)->void:
	_box(Vector3(2.4,0.12,0.9),c+Vector3(0,0.78,0),Color("795e48"),false); _box(Vector3(0.7,0.48,0.05),c+Vector3(0,1.15,-0.3),Color("20262b"),false)
func _easel(c:Vector3)->void:
	_box(Vector3(0.08,1.8,0.08),c+Vector3(-.4,.9,0),Color("795a3f"),false); _box(Vector3(.08,1.8,.08),c+Vector3(.4,.9,0),Color("795a3f"),false); _box(Vector3(1.0,.8,.06),c+Vector3(0,1.15,-.08),Color("d7c8a8"),false)
func _gym_station(c:Vector3)->void:
	_box(Vector3(1.8,.12,.55),c+Vector3(0,.45,0),Color("383e44"),false); _cylinder(c+Vector3(-.72,.95,0),.12,1.1,Color("43484e")); _cylinder(c+Vector3(.72,.95,0),.12,1.1,Color("43484e"))
func _salon_chair(c:Vector3)->void:
	var seat=MeshInstance3D.new(); var sm=SphereMesh.new(); sm.radius=.48; sm.height=.5; seat.mesh=sm; seat.scale=Vector3(1.0,.55,1.0); seat.position=c+Vector3(0,.52,0); var mat=StandardMaterial3D.new(); mat.albedo_color=Color("554b50"); mat.roughness=.82; seat.material_override=mat; root.add_child(seat); _box(Vector3(1.1,1.4,.05),c+Vector3(0,1.3,1.1),Color("bfc2c3"),false)
func _round_sofa(c:Vector3,color:Color)->void:
	var mi=MeshInstance3D.new(); var sm=SphereMesh.new(); sm.radius=.5; sm.height=1.0; mi.mesh=sm; mi.scale=Vector3(2.6,.55,1.0); mi.position=c+Vector3(0,.45,0); var mat=StandardMaterial3D.new(); mat.albedo_color=color; mat.roughness=.94; mi.material_override=mat; root.add_child(mi)
func _tree(pos:Vector3)->void:
	_cylinder(pos+Vector3(0,1.2,0),.16,2.4,Color("654a36")); var crown=MeshInstance3D.new(); var sm=SphereMesh.new(); sm.radius=1.0; sm.height=1.7; crown.mesh=sm; crown.position=pos+Vector3(0,2.8,0); crown.scale=Vector3(1,.82,1); var mat=StandardMaterial3D.new(); mat.albedo_color=Color("4e704f"); mat.roughness=.98; crown.material_override=mat; root.add_child(crown)
func _bench(pos:Vector3)->void:
	_box(Vector3(2.0,.13,.62),pos+Vector3(0,.52,0),Color("765a43"),false); _box(Vector3(2.0,.72,.12),pos+Vector3(0,.88,.30),Color("765a43"),false)
func _cylinder(pos:Vector3,r:float,h:float,color:Color)->void:
	var mi=MeshInstance3D.new(); var cm=CylinderMesh.new(); cm.top_radius=r; cm.bottom_radius=r*1.04; cm.height=h; cm.radial_segments=16; mi.mesh=cm; mi.position=pos; var mat=StandardMaterial3D.new(); mat.albedo_color=color; mat.roughness=.9; mi.material_override=mat; root.add_child(mi)
func _glass(pos:Vector3,size:Vector3)->void:
	var mi=MeshInstance3D.new(); var mesh=BoxMesh.new(); mesh.size=size; mi.mesh=mesh; mi.position=pos; var mat=StandardMaterial3D.new(); mat.albedo_color=Color(0.32,0.50,0.61,0.35); mat.transparency=BaseMaterial3D.TRANSPARENCY_ALPHA; mat.roughness=.12; mi.material_override=mat; root.add_child(mi)
func _box(size: Vector3, pos: Vector3, color: Color, collision: bool) -> void:
	var parent: Node3D = root
	if collision:
		var body = StaticBody3D.new()
		body.position = pos
		root.add_child(body)
		parent = body
		_collision(body, size)
	var mi = MeshInstance3D.new()
	var mesh = BoxMesh.new()
	mesh.size = size
	mi.mesh = mesh
	if not collision:
		mi.position = pos
	var mat = StandardMaterial3D.new()
	mat.albedo_color = color
	mat.roughness = 0.88
	mi.material_override = mat
	parent.add_child(mi)

func _collision(parent: Node3D, size: Vector3) -> void:
	var shape = CollisionShape3D.new()
	var box = BoxShape3D.new()
	box.size = size
	shape.shape = box
	parent.add_child(shape)
