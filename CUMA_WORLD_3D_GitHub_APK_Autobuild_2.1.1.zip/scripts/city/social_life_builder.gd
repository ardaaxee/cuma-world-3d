extends Node

const RelationshipCitizen = preload("res://scripts/social/relationship_citizen.gd")
const SocialWorldDirector = preload("res://scripts/social/social_world_director.gd")
const PairActivity = preload("res://scripts/together/pair_activity.gd")

var root: Node3D

func setup(world: Node3D) -> void:
	root = Node3D.new()
	root.name = "SocialLife12"
	world.add_child(root)
	_build_community_block()
	_spawn_neighbors()
	_seed_social_graph()
	_build_pair_activities()
	var director = Node.new()
	director.name = "SocialWorldDirector"
	director.set_script(SocialWorldDirector)
	world.add_child(director)
	director.setup()

func _build_community_block() -> void:
	# Human-scale shared neighborhood connected to the 1.1 residential plaza.
	_box(Vector3(34, 0.10, 22), Vector3(76, 0.02, 130), Color("918e84"), true)
	_box(Vector3(28, 0.08, 5.4), Vector3(73, 0.08, 116), Color("34383b"), true)
	for x in range(62, 87, 4):
		_box(Vector3(1.8, 0.025, 0.10), Vector3(float(x), 0.13, 116), Color("ded8c2"), false)
	_build_corner_cafe(Vector3(67, 0, 124))
	_build_community_lounge(Vector3(84, 0, 124))
	_build_garden(Vector3(76, 0, 138))
	for p in [Vector3(62,0,132),Vector3(68,0,134),Vector3(84,0,134),Vector3(90,0,132)]:
		_tree(p)
	for p in [Vector3(71,0,130),Vector3(80,0,130),Vector3(76,0,136)]:
		_bench(p)
	var sign = Label3D.new()
	sign.text = "CUMA MAHALLESİ • KOMŞULUK ALANI"
	sign.position = Vector3(76, 2.1, 119.0)
	sign.font_size = 30
	sign.outline_size = 7
	root.add_child(sign)

func _build_corner_cafe(c: Vector3) -> void:
	_box(Vector3(11, 4.4, 7), c + Vector3(0, 2.2, 0), Color("b49a80"), true)
	_box(Vector3(8.5, 0.12, 2.8), c + Vector3(0, 0.12, 5.1), Color("795f48"), false)
	for x in [-3.2, 0.0, 3.2]:
		var glass = MeshInstance3D.new(); var bm = BoxMesh.new(); bm.size=Vector3(2.4,2.0,0.08); glass.mesh=bm; glass.position=c+Vector3(x,1.7,-3.53)
		var gm=StandardMaterial3D.new(); gm.albedo_color=Color(0.55,0.72,0.79,0.33); gm.transparency=BaseMaterial3D.TRANSPARENCY_ALPHA; gm.roughness=0.14; glass.material_override=gm; root.add_child(glass)
	for off in [Vector3(-2.5,0,5.2),Vector3(0,0,5.2),Vector3(2.5,0,5.2)]:
		_round_table(c+off)
	var label = Label3D.new(); label.text="KOMŞU KAFE"; label.position=c+Vector3(0,3.1,-3.62); label.font_size=30; label.outline_size=6; root.add_child(label)

func _build_community_lounge(c: Vector3) -> void:
	_box(Vector3(11, 4.0, 7), c + Vector3(0, 2.0, 0), Color("a4aaa3"), true)
	var label = Label3D.new(); label.text="TOPLULUK EVİ"; label.position=c+Vector3(0,2.8,-3.62); label.font_size=28; label.outline_size=6; root.add_child(label)
	for off in [Vector3(-2.8,0,5),Vector3(0,0,5),Vector3(2.8,0,5)]:
		_bench(c+off)

func _build_garden(c: Vector3) -> void:
	_box(Vector3(22,0.08,8),c+Vector3(0,0.04,0),Color("6f8067"),true)
	for x in [-8.0,-4.0,0.0,4.0,8.0]:
		var planter = MeshInstance3D.new(); var cm=CylinderMesh.new(); cm.top_radius=.7; cm.bottom_radius=.78; cm.height=.52; cm.radial_segments=20; planter.mesh=cm; planter.position=c+Vector3(x,.26,0)
		var m=StandardMaterial3D.new(); m.albedo_color=Color("76604d"); m.roughness=.95; planter.material_override=m; root.add_child(planter)
		for off in [Vector3(-.22,.60,0),Vector3(.18,.66,.12),Vector3(0,.74,-.16)]: _leaf(c+Vector3(x,0,0)+off)
	var l=Label3D.new(); l.text="KOMŞULUK BAHÇESİ"; l.position=c+Vector3(0,1.7,3.4); l.font_size=25; l.outline_size=6; root.add_child(l)

func _spawn_neighbors() -> void:
	var shared_plaza = [Vector3(60,0.05,130),Vector3(68,0.05,130),Vector3(76,0.05,130),Vector3(84,0.05,130),Vector3(90,0.05,130)]
	var cafe_route = [Vector3(62,0.05,130),Vector3(64,0.05,129),Vector3(67,0.05,129)]
	var lounge_route = [Vector3(90,0.05,130),Vector3(87,0.05,129),Vector3(84,0.05,129)]
	var garden_route = [Vector3(70,0.05,134),Vector3(74,0.05,138),Vector3(80,0.05,138),Vector3(84,0.05,134)]
	var profiles = [
		{"id":"ece","name":"Ece","bio":"Yan blokta yaşayan yaratıcı bir komşu. Fotoğraf ve sakin kahve molalarını seviyor.","personality":"yaratıcı ve sıcak","favorite_activity":"fotoğraf yürüyüşü","favorite_gift":"photo_album","romance_available":true,"work_label":"Tasarım işleriyle uğraşıyor","leisure_label":"Kafede fotoğraflarını düzenliyor","work_start":10.0,"work_end":17.0,"top":Color("8a5a68"),"hair":Color("35251f"),"home_route":[Vector3(58,0.05,121)],"work_route":lounge_route,"leisure_route":cafe_route},
		{"id":"deniz","name":"Deniz","bio":"Mahallenin enerjik sakinlerinden. Spor, park ve uzun yürüyüşleri seviyor.","personality":"enerjik ve açık sözlü","favorite_activity":"park yürüyüşü","favorite_gift":"sparkling_drink","romance_available":true,"work_label":"Spor stüdyosunda çalışıyor","leisure_label":"Bahçede dinleniyor","work_start":9.0,"work_end":16.0,"top":Color("4c7180"),"hair":Color("211c19"),"home_route":[Vector3(54,0.05,121)],"work_route":garden_route,"leisure_route":shared_plaza},
		{"id":"selin","name":"Selin","bio":"Sessiz ama dikkatli bir komşu. Kitapları ve uzun sohbetleri seviyor.","personality":"sakin ve düşünceli","favorite_activity":"kitap-kahve molası","favorite_gift":"novel","romance_available":false,"work_label":"Topluluk evinde kitapları düzenliyor","leisure_label":"Kafede kitap okuyor","work_start":11.0,"work_end":18.0,"top":Color("596c55"),"hair":Color("422d24"),"home_route":[Vector3(48,0.05,121)],"work_route":lounge_route,"leisure_route":cafe_route},
		{"id":"mert","name":"Mert","bio":"Kafede çalışan sosyal bir mahalle sakini. İnsanlarla tanışmayı ve oyun gecelerini seviyor.","personality":"sosyal ve esprili","favorite_activity":"kafe buluşması","favorite_gift":"dessert_box","romance_available":true,"work_label":"Komşu Kafe'de çalışıyor","leisure_label":"Meydanda arkadaşlarıyla","work_start":8.0,"work_end":16.0,"top":Color("756149"),"hair":Color("251c18"),"home_route":[Vector3(44,0.05,121)],"work_route":cafe_route,"leisure_route":shared_plaza},
		{"id":"ipek","name":"İpek","bio":"Stil ve tasarımla ilgilenen neşeli bir komşu. Yeni yerler keşfetmeyi seviyor.","personality":"neşeli ve meraklı","favorite_activity":"şehir keşfi","favorite_gift":"photo_album","romance_available":true,"work_label":"Topluluk atölyesinde tasarım yapıyor","leisure_label":"Meydanda geziniyor","work_start":10.0,"work_end":17.0,"top":Color("7d5b82"),"hair":Color("2d211c"),"home_route":[Vector3(34,0.05,121)],"work_route":lounge_route,"leisure_route":shared_plaza},
		{"id":"kerem","name":"Kerem","bio":"Teknoloji ve oyunlarla ilgilenen komşu. Kalabalık yerine küçük arkadaş gruplarını seviyor.","personality":"rahat ve esprili","favorite_activity":"oyun gecesi","favorite_gift":"sparkling_drink","romance_available":true,"work_label":"Teknik işlerle uğraşıyor","leisure_label":"Topluluk evinde oyun oynuyor","work_start":9.0,"work_end":17.0,"top":Color("4e5978"),"hair":Color("17191c"),"home_route":[Vector3(30,0.05,121)],"work_route":lounge_route,"leisure_route":lounge_route},
		{"id":"elif","name":"Elif","bio":"Mahallede sık sık fotoğraf çeken sakin biri. Bahçe ve gün batımı saatlerini seviyor.","personality":"gözlemci ve nazik","favorite_activity":"bahçede fotoğraf çekmek","favorite_gift":"photo_album","romance_available":true,"work_label":"Fotoğraf işleriyle ilgileniyor","leisure_label":"Bahçede fotoğraf çekiyor","work_start":10.0,"work_end":16.0,"top":Color("78605b"),"hair":Color("32211c"),"home_route":[Vector3(24,0.05,121)],"work_route":garden_route,"leisure_route":garden_route},
		{"id":"baran","name":"Baran","bio":"Yemek yapmayı seven, mahalle etkinliklerine yardım eden biri. Akşamları kafede takılıyor.","personality":"yardımsever ve sakin","favorite_activity":"birlikte yemek hazırlamak","favorite_gift":"dessert_box","romance_available":true,"work_label":"Mutfak hazırlığı yapıyor","leisure_label":"Kafede arkadaşlarıyla","work_start":8.0,"work_end":15.0,"top":Color("59675e"),"hair":Color("241e1a"),"home_route":[Vector3(20,0.05,121)],"work_route":cafe_route,"leisure_route":garden_route}
	]
	for i in range(profiles.size()):
		var data: Dictionary = profiles[i]
		data["phase"] = float(i) * 0.39
		data["speed"] = 1.02 + float(i % 4) * 0.06
		data["skin"] = [Color("d1a07d"),Color("b98262"),Color("dfb08b"),Color("c99472")][i % 4]
		data["pants"] = [Color("30343b"),Color("28333a"),Color("3c3535"),Color("2f3831")][i % 4]
		data["height_scale"] = 0.96 + float(i % 5) * 0.02
		var npc = Node3D.new()
		npc.name = "Neighbor_" + str(data["id"])
		npc.set_script(RelationshipCitizen)
		root.add_child(npc)
		npc.setup(data)

func _seed_social_graph() -> void:
	var gs = get_node_or_null("/root/GameState")
	if gs == null:
		return
	gs.register_npc_bond("ece", "selin", 58.0, false)
	gs.register_npc_bond("mert", "kerem", 38.0, false)
	gs.register_npc_bond("ipek", "deniz", 70.0, true)
	gs.register_npc_bond("elif", "baran", 92.0, true)
	gs.register_npc_bond("ece", "ipek", 28.0, false)
	gs.register_npc_bond("deniz", "mert", 24.0, false)
	if not bool(gs.story_flags.get("social_life_intro_12", false)):
		gs.story_flags["social_life_intro_12"] = true
		gs.add_social_feed("Mahallede yeni komşularla tanışabilirsin; herkesin kendi rutini ve kişiliği var.")
		gs.add_social_feed("Elif ile Baran mahallede sevgili olarak yaşıyor; diğer ilişkiler zamanla değişebilir.")

func _build_pair_activities() -> void:
	_pair("neighbor_picnic", "Komşularla birlikte piknik yapın", Vector3(76,0.9,138), 26, 0.75)
	_pair("community_game_night", "Topluluk evinde oyun gecesine katılın", Vector3(84,0.9,129), 24, 0.75)
	_pair("double_coffee", "Komşu kafede birlikte kahve molası", Vector3(67,0.9,129), 20, 0.5)
	_pair("garden_evening", "Komşuluk bahçesinde akşam geçirin", Vector3(80,0.9,138), 22, 0.75)
	_pair("meet_neighbors", "Birlikte yeni komşularla tanışın", Vector3(72,0.9,130), 28, 0.75)
	_pair("block_party", "Mahalle buluşmasına birlikte katılın", Vector3(88,0.9,130), 32, 1.0)

func _pair(id:String,title:String,pos:Vector3,points:int,hours:float)->void:
	var body=StaticBody3D.new(); body.name="SocialDuo_"+id; body.position=pos; body.set_script(PairActivity); root.add_child(body)
	var c=CollisionShape3D.new(); var s=BoxShape3D.new(); s.size=Vector3(1.3,1.5,1.3); c.shape=s; body.add_child(c); body.setup(id,title,points,hours)

func _round_table(pos: Vector3) -> void:
	var top=MeshInstance3D.new(); var cm=CylinderMesh.new(); cm.top_radius=.72; cm.bottom_radius=.72; cm.height=.10; cm.radial_segments=24; top.mesh=cm; top.position=pos+Vector3(0,.72,0); var m=StandardMaterial3D.new(); m.albedo_color=Color("6e503c"); m.roughness=.84; top.material_override=m; root.add_child(top)
	var leg=MeshInstance3D.new(); var lm=CylinderMesh.new(); lm.top_radius=.08; lm.bottom_radius=.11; lm.height=.68; lm.radial_segments=16; leg.mesh=lm; leg.position=pos+Vector3(0,.36,0); leg.material_override=m; root.add_child(leg)

func _bench(pos:Vector3)->void:
	_box(Vector3(2.0,.14,.55),pos+Vector3(0,.5,0),Color("77573f"),false)
	_box(Vector3(2.0,.65,.12),pos+Vector3(0,.85,.28),Color("77573f"),false)

func _tree(pos:Vector3)->void:
	var trunk=MeshInstance3D.new(); var cm=CylinderMesh.new(); cm.top_radius=.14; cm.bottom_radius=.18; cm.height=2.5; trunk.mesh=cm; trunk.position=pos+Vector3(0,1.25,0); var tm=StandardMaterial3D.new(); tm.albedo_color=Color("654936"); tm.roughness=.96; trunk.material_override=tm; root.add_child(trunk)
	for off in [Vector3(0,2.8,0),Vector3(-.55,2.55,.1),Vector3(.55,2.5,-.1)]: _leaf(pos+off)

func _leaf(pos:Vector3)->void:
	var n=MeshInstance3D.new(); var sm=SphereMesh.new(); sm.radius=.55; sm.height=1.1; n.mesh=sm; n.position=pos; n.scale=Vector3(1.2,.9,1.2); var m=StandardMaterial3D.new(); m.albedo_color=Color("4a6a4c"); m.roughness=.99; n.material_override=m; root.add_child(n)

func _box(size:Vector3,pos:Vector3,color:Color,collision:bool)->void:
	var parent:Node3D
	if collision:
		var b=StaticBody3D.new(); b.position=pos; root.add_child(b); parent=b
		var c=CollisionShape3D.new(); var s=BoxShape3D.new(); s.size=size; c.shape=s; b.add_child(c)
	else:
		parent=root
	var mi=MeshInstance3D.new(); var mesh=BoxMesh.new(); mesh.size=size; mi.mesh=mesh
	if not collision: mi.position=pos
	var mat=StandardMaterial3D.new(); mat.albedo_color=color; mat.roughness=.88; mi.material_override=mat; parent.add_child(mi)
