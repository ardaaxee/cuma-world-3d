extends Node

var player: AudioStreamPlayer

func _ready() -> void:
	player = AudioStreamPlayer.new()
	player.name = "CityAmbiencePlayer"
	player.volume_db = -28.0
	if ResourceLoader.exists("res://assets/audio/city_ambience.wav"):
		player.stream = load("res://assets/audio/city_ambience.wav")
	add_child(player)
	if player.stream != null:
		player.finished.connect(_restart)
		player.play()

func _restart() -> void:
	if player != null and player.stream != null:
		player.play()
