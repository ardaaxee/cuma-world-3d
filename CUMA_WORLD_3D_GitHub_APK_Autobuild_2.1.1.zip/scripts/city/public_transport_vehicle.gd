extends AnimatableBody3D

# Dynamic City 1.8: host-authoritative moving public transport using the existing
# validated vehicle replication channel. Passengers never control its motion.
var vehicle_id = "city_bus"
var display_name = "ŞEHİR OTOBÜSÜ"
var route: Array[Vector3] = []
var route_index = 0
var cruise_speed = 7.0
var wait_left = 0.0
var local_occupant: Node = null
var driver_peer_id = 0
var passenger_peer_id = 0
var target_transform = Transform3D.IDENTITY
var has_network_target = false
var network_accum = 0.0
var wheel_nodes: Array[Node3D] = []

func setup(id_value: String, title: String, points: Array[Vector3], speed_value: float, body_color: Color) -> void:
	vehicle_id = id_value.strip_edges().left(48)
	display_name = title.left(40)
	route = points.duplicate()
	cruise_speed = clamp(speed_value, 2.0, 14.0)
	if route.size() < 2:
		return
	global_position = route[0]
	target_transform = global_transform
	_build_vehicle(body_color)
	var net = get_node_or_null("/root/NetworkManager")
	if net != null:
		net.register_vehicle(vehicle_id, global_position)
		net.vehicle_seat_changed.connect(_on_vehicle_seat_changed)
		net.vehicle_state_received.connect(_on_vehicle_state_received)

func _build_vehicle(color: Color) -> void:
	var collider = CollisionShape3D.new()
	var shape = BoxShape3D.new()
	shape.size = Vector3(2.1, 1.9, 4.8)
	collider.shape = shape
	collider.position = Vector3(0, 1.0, 0)
	add_child(collider)
	_box(Vector3(2.05, 1.45, 4.6), Vector3(0, 1.08, 0), color)
	_box(Vector3(1.95, 0.48, 3.8), Vector3(0, 1.82, -0.08), color.lightened(0.06))
	# Large glass band avoids a blocky silhouette.
	for z in [-1.35, -0.45, 0.45, 1.35]:
		_glass(Vector3(-1.03, 1.62, z), Vector3(0.035, 0.55, 0.72))
		_glass(Vector3(1.03, 1.62, z), Vector3(0.035, 0.55, 0.72))
	_glass(Vector3(0, 1.62, -2.31), Vector3(1.55, 0.58, 0.035))
	for x in [-0.88, 0.88]:
		for z in [-1.45, 1.45]:
			wheel_nodes.append(_wheel(Vector3(x, 0.38, z)))
	var label = Label3D.new()
	label.text = display_name
	label.position = Vector3(0, 2.38, 0)
	label.font_size = 22
	label.outline_size = 5
	label.billboard = BaseMaterial3D.BILLBOARD_ENABLED
	add_child(label)

func get_interaction_label() -> String:
	var net = get_node_or_null("/root/NetworkManager")
	if net != null and net.is_online():
		var local_id = net.get_local_peer_id()
		if local_id == driver_peer_id or local_id == passenger_peer_id:
			return "%s • İn" % display_name
		if driver_peer_id == 0 or passenger_peer_id == 0:
			return "%s • Bin" % display_name
		return "%s • Dolu" % display_name
	return "%s • %s" % [display_name, "İn" if local_occupant != null else "Bin"]

func interact(player: Node) -> void:
	var net = get_node_or_null("/root/NetworkManager")
	if net != null and net.is_online():
		var local_id = net.get_local_peer_id()
		if local_id == driver_peer_id or local_id == passenger_peer_id:
			net.request_vehicle_leave(vehicle_id)
		elif driver_peer_id == 0:
			net.request_vehicle_seat(vehicle_id, "driver")
		elif passenger_peer_id == 0:
			net.request_vehicle_seat(vehicle_id, "passenger")
		elif player != null and player.has_method("show_status"):
			player.show_status("Toplu taşıma dolu • 2/2", 2.0)
		return
	if local_occupant == null and player != null and player.has_method("enter_vehicle"):
		local_occupant = player
		player.enter_vehicle(self, "transit_left")
	elif local_occupant == player:
		exit_vehicle(player)

func exit_vehicle(player: Node) -> void:
	var net = get_node_or_null("/root/NetworkManager")
	if net != null and net.is_online():
		net.request_vehicle_leave(vehicle_id)
		return
	if local_occupant != player:
		return
	local_occupant = null
	if player != null and player.has_method("exit_vehicle"):
		player.exit_vehicle(global_position + global_transform.basis.x * 1.65 + Vector3.UP * 0.05, rotation.y)

func _process(delta: float) -> void:
	if route.size() < 2:
		return
	var net = get_node_or_null("/root/NetworkManager")
	if net != null and net.is_online():
		if net.multiplayer.is_server():
			_simulate_route(delta)
			network_accum += delta
			if network_accum >= 0.08:
				network_accum = 0.0
				net.publish_vehicle_state(vehicle_id, global_transform, cruise_speed if wait_left <= 0.0 else 0.0)
		elif has_network_target:
			global_transform = global_transform.interpolate_with(target_transform, min(1.0, delta * 8.0))
		_update_local_passenger(net)
	else:
		_simulate_route(delta)
		if local_occupant != null and is_instance_valid(local_occupant) and local_occupant.has_method("update_vehicle_anchor"):
			local_occupant.update_vehicle_anchor(global_transform, cruise_speed)
	_spin_wheels(delta)

func _simulate_route(delta: float) -> void:
	if wait_left > 0.0:
		wait_left -= delta
		return
	var target = route[route_index]
	var flat = target - global_position
	flat.y = 0.0
	if flat.length() < 0.55:
		route_index = (route_index + 1) % route.size()
		wait_left = 1.8
		return
	var dir = flat.normalized()
	global_position += dir * cruise_speed * delta
	rotation.y = lerp_angle(rotation.y, atan2(-dir.x, -dir.z), min(1.0, delta * 4.5))

func _on_vehicle_seat_changed(id_value: String, driver_id: int, passenger_id: int) -> void:
	if id_value != vehicle_id:
		return
	driver_peer_id = driver_id
	passenger_peer_id = passenger_id
	var net = get_node_or_null("/root/NetworkManager")
	var player = get_tree().get_first_node_in_group("player")
	if net == null or player == null:
		return
	var local_id = net.get_local_peer_id()
	if local_id == driver_peer_id:
		player.enter_vehicle(self, "transit_left")
	elif local_id == passenger_peer_id:
		player.enter_vehicle(self, "transit_right")
	elif player.driving_vehicle == self:
		player.exit_vehicle(global_position + global_transform.basis.x * 1.65 + Vector3.UP * 0.05, rotation.y)

func _on_vehicle_state_received(id_value: String, value: Transform3D, _speed: float, driver_id: int, passenger_id: int) -> void:
	if id_value != vehicle_id:
		return
	target_transform = value
	has_network_target = true
	driver_peer_id = driver_id
	passenger_peer_id = passenger_id

func _update_local_passenger(net: Node) -> void:
	var local_id = net.get_local_peer_id()
	if local_id != driver_peer_id and local_id != passenger_peer_id:
		return
	var player = get_tree().get_first_node_in_group("player")
	if player != null and player.has_method("update_vehicle_anchor"):
		player.update_vehicle_anchor(global_transform, cruise_speed)

func set_simulation_enabled(enabled: bool) -> void:
	visible = enabled
	set_process(enabled)

func _box(size: Vector3, pos: Vector3, color: Color) -> void:
	var mi = MeshInstance3D.new(); var mesh = BoxMesh.new(); mesh.size = size; mi.mesh = mesh; mi.position = pos
	var mat = StandardMaterial3D.new(); mat.albedo_color = color; mat.roughness = 0.72; mi.material_override = mat; add_child(mi)

func _glass(pos: Vector3, size: Vector3) -> void:
	var mi = MeshInstance3D.new(); var mesh = BoxMesh.new(); mesh.size = size; mi.mesh = mesh; mi.position = pos
	var mat = StandardMaterial3D.new(); mat.albedo_color = Color(0.14,0.24,0.31,0.64); mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA; mat.roughness = 0.16; mi.material_override = mat; add_child(mi)

func _wheel(pos: Vector3) -> Node3D:
	var pivot = Node3D.new(); pivot.position = pos; add_child(pivot)
	var mi = MeshInstance3D.new(); var mesh = CylinderMesh.new(); mesh.top_radius = 0.34; mesh.bottom_radius = 0.34; mesh.height = 0.20; mesh.radial_segments = 16; mi.mesh = mesh; mi.rotation_degrees.z = 90
	var mat = StandardMaterial3D.new(); mat.albedo_color = Color("15171a"); mat.roughness = 0.94; mi.material_override = mat; pivot.add_child(mi)
	return pivot

func _spin_wheels(delta: float) -> void:
	if wait_left > 0.0:
		return
	for wheel in wheel_nodes:
		if is_instance_valid(wheel): wheel.rotate_x(cruise_speed * delta * 1.6)
