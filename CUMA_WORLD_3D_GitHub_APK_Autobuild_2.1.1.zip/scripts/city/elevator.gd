extends AnimatableBody3D

var low_y = 0.12
var high_y = 8.7
var moving = false
var target_high = false
var persistent_id = "residence_elevator"

func setup(id: String = "residence_elevator") -> void:
	persistent_id = id.left(64)
	sync_to_physics = true
	var mesh_node = MeshInstance3D.new()
	var mesh = BoxMesh.new()
	mesh.size = Vector3(2.15,0.16,2.15)
	mesh_node.mesh = mesh
	var mat = StandardMaterial3D.new()
	mat.albedo_color = Color("686d70")
	mat.metallic = 0.65
	mat.roughness = 0.32
	mesh_node.material_override = mat
	add_child(mesh_node)
	var collider = CollisionShape3D.new()
	var shape = BoxShape3D.new()
	shape.size = Vector3(2.15,0.16,2.15)
	collider.shape = shape
	add_child(collider)
	var net = get_node_or_null("/root/NetworkManager")
	if net != null:
		if net.has_method("register_world_interactable"):
			net.register_world_interactable(persistent_id,global_position,["toggle"])
		if net.world_action_received.is_connected(_on_world_action) == false:
			net.world_action_received.connect(_on_world_action)

func get_interaction_label() -> String:
	if moving:
		return "ASANSÖR • Hareket ediyor"
	return "ASANSÖR • Çatıya çık" if not target_high else "ASANSÖR • Lobiye in"

func interact(player: Node) -> void:
	if moving:
		return
	var net = get_node_or_null("/root/NetworkManager")
	if net != null and net.has_method("request_world_action"):
		net.request_world_action(persistent_id,"toggle")
	else:
		_toggle_motion()
	if player != null and player.has_method("show_status"):
		player.show_status("Asansör çağrıldı",1.8)

func _on_world_action(id: String, action: String) -> void:
	if id == persistent_id and action == "toggle":
		_toggle_motion()

func _toggle_motion() -> void:
	if moving:
		return
	moving = true
	target_high = not target_high
	var target = high_y if target_high else low_y
	var tween = create_tween()
	tween.set_trans(Tween.TRANS_SINE)
	tween.set_ease(Tween.EASE_IN_OUT)
	tween.tween_property(self,"position:y",target,3.2)
	await tween.finished
	moving = false
