extends Node3D

const ProceduralHumanoid = preload("res://scripts/character/procedural_humanoid.gd")

var rig: Node3D
var route: Array[Vector3] = []
var route_index = 0
var speed = 1.15
var pause_left = 0.0
var social_left = 0.0
var buddy: Node3D
var phase = 0.0

func setup(points: Array[Vector3], color: Color, offset: float = 0.0) -> void:
	route = points.duplicate()
	phase = offset
	if route.is_empty():
		return
	global_position = route[0]
	rig = Node3D.new()
	rig.set_script(ProceduralHumanoid)
	add_child(rig)
	rig.setup({"skin":Color("c99a79"),"top":color,"pants":Color("303640"),"hair":Color("211c1a"),"shoes":Color("15171a"),"height_scale":randf_range(0.94,1.05),"shoulder_scale":randf_range(0.92,1.04)})
	add_to_group("social_citizen")
	add_to_group("quality_crowd")

func _process(delta: float) -> void:
	if route.is_empty() or rig == null:
		return
	if pause_left > 0.0:
		pause_left -= delta
		_update_rig(delta, 0.0)
		if buddy != null and is_instance_valid(buddy):
			var flat = buddy.global_position - global_position; flat.y = 0.0
			if flat.length() > 0.15:
				rotation.y = lerp_angle(rotation.y, atan2(-flat.x,-flat.z), min(1.0,delta*3.0))
		return
	var target = route[route_index]
	var flat = target - global_position; flat.y = 0.0
	if flat.length() < 0.48:
		route_index = (route_index + 1) % route.size()
		pause_left = randf_range(0.8, 3.8)
		if randf() < 0.28:
			_try_social_pause()
		_update_rig(delta, 0.0)
		return
	var dir = flat.normalized()
	global_position += dir * speed * delta
	rotation.y = lerp_angle(rotation.y, atan2(-dir.x,-dir.z), min(1.0,delta*4.5))
	_update_rig(delta, speed)

func _try_social_pause() -> void:
	var nearest: Node3D
	var best = 4.0
	for node in get_tree().get_nodes_in_group("social_citizen"):
		if node == self or not (node is Node3D):
			continue
		var d = global_position.distance_to(node.global_position)
		if d < best:
			best = d
			nearest = node
	buddy = nearest
	if buddy != null:
		pause_left = randf_range(2.0, 5.5)
		if rig.has_method("play_emote") and randf() < 0.55:
			rig.play_emote("wave")

func _update_rig(delta: float, move_speed: float) -> void:
	if rig.has_method("update_pose"):
		rig.update_pose(delta,move_speed,false,0.0,true,false,0.0)

func set_simulation_enabled(enabled: bool) -> void:
	visible = enabled
	set_process(enabled)
