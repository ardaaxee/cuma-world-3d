extends Node

const PhysicalNavigationWorld = preload("res://scripts/navigation/physical_navigation_world.gd")
const SmartSpot = preload("res://scripts/navigation/smart_spot.gd")
const LocalNPCDoor = preload("res://scripts/navigation/local_npc_door.gd")

var world: Node3D
var root: Node3D

func setup(world_root: Node3D) -> void:
	world = world_root
	root = Node3D.new()
	root.name = "PhysicalAI14"
	world.add_child(root)
	var nav = Node3D.new()
	nav.set_script(PhysicalNavigationWorld)
	root.add_child(nav)
	nav.setup()
	_build_smart_spots()
	_build_local_doors()

func _spot(id_value: String, kind: String, pos: Vector3, face: Vector3 = Vector3.FORWARD) -> void:
	var node = Node3D.new()
	node.name = "Spot_" + id_value
	node.set_script(SmartSpot)
	root.add_child(node)
	node.setup(id_value, kind, pos, face)

func _build_smart_spots() -> void:
	# Fresh Market: browse -> checkout sequence.
	for i in range(5):
		_spot("market_shelf_%02d" % i, "market_shelf", Vector3(12.0 + float(i % 2) * 3.0, 0.05, 36.0 + float(i) * 1.15), Vector3(1,0,0))
	_spot("market_checkout_a", "checkout", Vector3(13.0,0.05,34.6), Vector3(0,0,-1))
	_spot("market_checkout_b", "checkout", Vector3(14.2,0.05,34.6), Vector3(0,0,-1))
	# Cafes/restaurants: actual sit targets.
	for i in range(4):
		_spot("cafe_seat_%02d" % i, "cafe_seat", Vector3(-18.0 + float(i % 3) * 2.4,0.05,36.7 + float(i / 3) * 1.4), Vector3(0,0,1))
	for i in range(6):
		_spot("restaurant_seat_%02d" % i, "restaurant_seat", Vector3(27.5 + float(i % 3) * 3.5,0.05,45.3 + float(i / 3) * 3.8), Vector3(0,0,1))
	# Neighborhood social seating.
	for i in range(6):
		_spot("neighbor_social_%02d" % i, "social_seat", Vector3(64.0 + float(i % 3) * 3.0,0.05,129.0 + float(i / 3) * 4.5), Vector3(0,0,-1))
	for i in range(4):
		_spot("garden_bench_%02d" % i, "park_seat", Vector3(72.0 + float(i) * 3.0,0.05,136.0), Vector3(0,0,1))
	# Home/entry anchors let residents visibly enter and leave their block.
	for i in range(8):
		_spot("home_entry_%02d" % i, "home_entry", Vector3(20.0 + float(i) * 5.4,0.05,121.0), Vector3(0,0,1))

func _build_local_doors() -> void:
	# These doors belong only to local NPC scenery. They never touch shared multiplayer world state.
	_door("NeighborCafeDoor", Vector3(67.0,1.1,120.45), Color("75533c"))
	_door("CommunityDoor", Vector3(84.0,1.1,120.45), Color("646a63"))
	_door("MarketNPCDoor", Vector3(15.0,1.1,33.05), Color("5e775f"))
	_door("CityCafeNPCDoor", Vector3(-15.0,1.1,33.05), Color("7b5f49"))
	_door("RestaurantNPCDoor", Vector3(31.0,1.1,40.75), Color("8b493d"))
	for i in range(8):
		_door("NeighborHomeDoor_%02d" % i, Vector3(20.0 + float(i) * 5.4, 1.1, 120.55), Color("6e5948"))

func _door(label: String, pos: Vector3, color: Color) -> void:
	var door = Node3D.new()
	door.name = label
	door.position = pos
	door.set_script(LocalNPCDoor)
	root.add_child(door)
	door.setup(Vector3(1.15,2.2,0.10), color)
