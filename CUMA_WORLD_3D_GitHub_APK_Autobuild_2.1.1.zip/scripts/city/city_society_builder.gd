extends Node

const ScheduledCitizen=preload("res://scripts/city/scheduled_citizen.gd")
const SocietyTerminal=preload("res://scripts/city/society_terminal.gd")
const PairActivity=preload("res://scripts/together/pair_activity.gd")
const SocietyDirector=preload("res://scripts/social/city_society_director.gd")

var root:Node3D

func setup(world:Node3D)->void:
	root=Node3D.new(); root.name="CitySociety17"; world.add_child(root)
	_build_district(); _build_services(); _spawn_adult_citizens(); _build_pair_activities()
	var d=Node.new(); d.name="CitySocietyDirector"; d.set_script(SocietyDirector); world.add_child(d); d.setup()

func _build_district()->void:
	# East society boulevard, separated from existing blocks.
	_box(Vector3(52,0.10,36),Vector3(116,0.02,92),Color("8d8b83"),true)
	_box(Vector3(8,0.08,44),Vector3(116,0.08,92),Color("34383c"),true)
	_build_front("CUMA FIT",Vector3(99,0,82),Color("6b7671"))
	_build_front("STUDIO HAIR",Vector3(99,0,94),Color("8b746f"))
	_build_front("ECZANE",Vector3(99,0,106),Color("71877a"))
	_build_front("ATÖLYE 17",Vector3(133,0,82),Color("7b7188"))
	_build_front("CITY HUB",Vector3(133,0,94),Color("6e7986"))
	_build_front("TAXI",Vector3(133,0,106),Color("7c755e"))
	for z in [74.0,84.0,94.0,104.0,114.0]:
		_tree(Vector3(108,0,z)); _tree(Vector3(124,0,z))
	for z in [78.0,98.0,112.0]:
		_bench(Vector3(110,0,z)); _bench(Vector3(122,0,z))
	var l=Label3D.new(); l.text="CUMA CITY • TOPLUM BULVARI"; l.position=Vector3(116,3.0,72); l.font_size=34; l.outline_size=7; root.add_child(l)

func _build_front(label_text:String,c:Vector3,color:Color)->void:
	_box(Vector3(13,4.6,9),c+Vector3(0,2.3,0),color,true)
	for x in [-3.8,0.0,3.8]: _glass(c+Vector3(x,1.65,-4.55),Vector3(2.8,2.1,0.08))
	var l=Label3D.new(); l.text=label_text; l.position=c+Vector3(0,3.4,-4.62); l.font_size=29; l.outline_size=6; root.add_child(l)

func _build_services()->void:
	_terminal("Gym",Vector3(99,0.9,78),"gym","Spor salonunda antrenman",30,1.0,"fitness_pass")
	_terminal("Hair",Vector3(99,0.9,90),"hair","Kuaför/berber randevusu",45,0.75,"fresh_hair")
	_terminal("Pharmacy",Vector3(99,0.9,102),"pharmacy","Eczaneden günlük bakım paketi",20,0.25,"care_pack")
	_terminal("Workshop",Vector3(133,0.9,78),"workshop","Yetişkin atölyesine katıl",25,1.25,"workshop_note")
	_terminal("Taxi",Vector3(133,0.9,102),"taxi","Taksiyle eve dön",35,0.15,"",Vector3(0,0.2,4),true)
	_terminal("BusHome",Vector3(113,0.9,72),"bus_home","Otobüs • Ev",8,0.20,"",Vector3(0,0.2,6),true)
	_terminal("BusSocial",Vector3(119,0.9,72),"bus_social","Otobüs • Komşuluk",8,0.20,"",Vector3(76,0.2,130),true)

func _spawn_adult_citizens()->void:
	var colors=[Color("5e7183"),Color("7b6559"),Color("65765c"),Color("786182"),Color("746f55"),Color("536f72"),Color("805f68"),Color("5d6280"),Color("6f7654"),Color("806b56")]
	for i in range(10):
		var npc=Node3D.new(); npc.name="SocietyCitizen_%02d"%i; npc.set_script(ScheduledCitizen); root.add_child(npc)
		var lane=-1.0 if i%2==0 else 1.0
		var home=Vector3(88.0+float(i%5)*3.0,0.05,118.0+lane*2.0)
		var work=Vector3(99.0 if i%3<2 else 133.0,0.05,77.0+float(i%3)*12.0)
		var leisure=Vector3(112.0+float(i%4)*3.0,0.05,88.0+float(i%3)*8.0)
		npc.setup(home,work,leisure,colors[i%colors.size()],float(i)*0.23,116.0)
		npc.add_to_group("society_crowd")

func _build_pair_activities()->void:
	_pair("duo_gym","Birlikte spor yapın",Vector3(99,0.9,84),22,0.75)
	_pair("duo_style","Birlikte yeni saç/stil seçin",Vector3(99,0.9,96),20,0.5)
	_pair("duo_workshop","Birlikte atölyeye katılın",Vector3(133,0.9,84),26,1.0)
	_pair("duo_city_bus","Birlikte otobüsle şehir turu",Vector3(116,0.9,73),18,0.5)
	_pair("duo_weekend_market","Hafta sonu açık hava pazarını gezin",Vector3(116,0.9,108),24,0.75)
	_pair("duo_city_event","Haftalık şehir etkinliğine katılın",Vector3(116,0.9,94),30,1.0)
	_pair("duo_home_gathering","Komşu ev buluşmasına birlikte katılın",Vector3(84,0.9,129),28,1.0)

func _terminal(name_value:String,pos:Vector3,id:String,title:String,cost:int,hours:float,item:String,target:Vector3=Vector3.ZERO,teleport:bool=false)->void:
	var b=StaticBody3D.new(); b.name=name_value; b.position=pos; b.set_script(SocietyTerminal); root.add_child(b)
	_collision(b,Vector3(1.0,1.4,0.7)); b.setup(id,title,cost,hours,item,target,teleport)
	var l=Label3D.new(); l.text=title; l.position=Vector3(0,1.1,0); l.font_size=21; l.outline_size=5; l.billboard=BaseMaterial3D.BILLBOARD_ENABLED; b.add_child(l)

func _pair(id:String,title:String,pos:Vector3,points:int,hours:float)->void:
	var b=StaticBody3D.new(); b.name="SocietyDuo_"+id; b.position=pos; b.set_script(PairActivity); root.add_child(b); _collision(b,Vector3(1.2,1.4,1.2)); b.setup(id,title,points,hours)

func _box(size:Vector3,pos:Vector3,color:Color,collision:bool)->void:
	var parent:Node3D=root
	if collision:
		var b=StaticBody3D.new(); b.position=pos; root.add_child(b); parent=b; _collision(b,size)
	var mi=MeshInstance3D.new(); var mesh=BoxMesh.new(); mesh.size=size; mi.mesh=mesh
	if not collision:
		mi.position=pos
	var mat=StandardMaterial3D.new(); mat.albedo_color=color; mat.roughness=.88; mi.material_override=mat; parent.add_child(mi)

func _glass(pos:Vector3,size:Vector3)->void:
	var mi=MeshInstance3D.new(); var m=BoxMesh.new(); m.size=size; mi.mesh=m; mi.position=pos
	var mat=StandardMaterial3D.new(); mat.albedo_color=Color(0.55,0.72,0.8,0.32); mat.transparency=BaseMaterial3D.TRANSPARENCY_ALPHA; mat.roughness=.12; mi.material_override=mat; root.add_child(mi)

func _tree(pos:Vector3)->void:
	var t=MeshInstance3D.new(); var cm=CylinderMesh.new(); cm.top_radius=.13; cm.bottom_radius=.18; cm.height=2.4; t.mesh=cm; t.position=pos+Vector3(0,1.2,0); var tm=StandardMaterial3D.new(); tm.albedo_color=Color("644a38"); t.material_override=tm; root.add_child(t)
	var crown=MeshInstance3D.new(); var sm=SphereMesh.new(); sm.radius=1.0; sm.height=1.8; crown.mesh=sm; crown.position=pos+Vector3(0,2.8,0); crown.scale=Vector3(1.0,.8,1.0); var gm=StandardMaterial3D.new(); gm.albedo_color=Color("4b694d"); gm.roughness=.98; crown.material_override=gm; root.add_child(crown)

func _bench(pos:Vector3)->void:
	_box(Vector3(1.8,.14,.55),pos+Vector3(0,.5,0),Color("795a42"),false); _box(Vector3(1.8,.6,.12),pos+Vector3(0,.82,.28),Color("795a42"),false)

func _collision(parent:Node3D,size:Vector3)->void:
	var c=CollisionShape3D.new(); var s=BoxShape3D.new(); s.size=size; c.shape=s; parent.add_child(c)
