extends Node

const StealableItem = preload("res://scripts/crime/stealable_item.gd")
const CyberTerminal = preload("res://scripts/crime/cyber_terminal.gd")
const PoliceDesk = preload("res://scripts/crime/police_desk.gd")
const SecurityCamera = preload("res://scripts/crime/security_camera.gd")
const LawOfficer = preload("res://scripts/crime/law_officer.gd")
const LawDirector = preload("res://scripts/crime/law_director.gd")
const PatrolVehicle = preload("res://scripts/crime/patrol_vehicle.gd")
const PairActivity = preload("res://scripts/together/pair_activity.gd")

var root: Node3D

func setup(target: Node3D) -> void:
	root = target
	_build_justice_district()
	_build_police_presence()
	_build_cyber_gameplay()
	_build_theft_gameplay()
	_build_pair_activities()

func _build_justice_district() -> void:
	_road(Vector3(-38, -0.09, 62), Vector3(48, 0.10, 7.0))
	_sidewalk(Vector3(-38, 0.0, 56.7), Vector3(48, 0.12, 2.6))
	_sidewalk(Vector3(-38, 0.0, 67.3), Vector3(48, 0.12, 2.6))
	_build_civic_building("CUMA POLICE", Vector3(-49,0,51), Vector3(13,7.5,11), Color("596874"))
	_build_civic_building("FIB • FEDERAL INVESTIGATION BUREAU", Vector3(-31,0,51), Vector3(15,8.5,11), Color("4c5058"))
	_build_civic_building("CITY COURT", Vector3(-12,0,51), Vector3(13,8.0,11), Color("857867"))
	_build_civic_building("CUMA CYBER LAB", Vector3(-49,0,74), Vector3(13,6.5,10), Color("334d52"))
	_build_civic_building("CUMA BANK", Vector3(-30,0,74), Vector3(15,7.0,10), Color("6a6150"))
	_build_civic_building("ELECTRONICS", Vector3(-12,0,74), Vector3(13,6.5,10), Color("545a63"))

	var desk = StaticBody3D.new()
	desk.name = "PoliceFrontDesk"
	desk.position = Vector3(-49, 0.85, 54.2)
	desk.set_script(PoliceDesk)
	root.add_child(desk)
	_child_box(desk, Vector3(3.4, 1.0, 0.75), Vector3.ZERO, Color("39434a"))
	desk.setup()

	for p in [Vector3(-36,3.5,69),Vector3(-24,3.5,69),Vector3(-17,3.4,69),Vector3(-6,3.4,69),Vector3(-43,3.6,58)]:
		var cam = Node3D.new()
		cam.position = p
		cam.set_script(SecurityCamera)
		root.add_child(cam)
		cam.setup(11.0)

func _build_police_presence() -> void:
	var director = Node.new()
	director.name = "LawDirector19"
	director.set_script(LawDirector)
	root.add_child(director)
	director.setup()

	_officer("Aylin", false, [Vector3(-51,0.05,58),Vector3(-42,0.05,58),Vector3(-42,0.05,66),Vector3(-51,0.05,66)])
	_officer("Emre", false, [Vector3(-20,0.05,58),Vector3(-8,0.05,58),Vector3(-8,0.05,66),Vector3(-20,0.05,66)])
	_officer("Agent Mira", true, [Vector3(-34,0.05,54),Vector3(-27,0.05,54),Vector3(-27,0.05,66),Vector3(-34,0.05,66)])
	_officer("Agent Can", true, [Vector3(-35,0.05,69),Vector3(-24,0.05,69),Vector3(-24,0.05,80),Vector3(-35,0.05,80)])

	var patrol = AnimatableBody3D.new()
	patrol.name = "PolicePatrolCar"
	patrol.add_to_group("quality_traffic")
	patrol.set_script(PatrolVehicle)
	root.add_child(patrol)
	patrol.setup([Vector3(-58,0.05,62),Vector3(-5,0.05,62),Vector3(-5,0.05,35),Vector3(-58,0.05,35)])

func _build_cyber_gameplay() -> void:
	_cyber("HomeCyberComputer", Vector3(-10.0,1.05,1.7), "home_cyber_sim", "CUMA PC • CYBER ARENA", 2, "training")
	_cyber("CyberTrainingTerminal", Vector3(-49,1.0,76.0), "training_grid", "CYBER LAB TRAINING", 3, "training")
	_cyber("FederalCaseTerminal", Vector3(-31,1.0,54.2), "case_lab", "FIB CASE LAB", 4, "case_lab")
	# Purely fictional node puzzle; no real networking commands or exploitation mechanics.
	_cyber("ShadowGridTerminal", Vector3(-6.5,1.0,80.0), "shadow_grid", "SHADOW GRID • KURGU AĞ", 5, "shadow_grid")

func _build_theft_gameplay() -> void:
	_stealable("ElectronicsDisplayA", Vector3(-14.5,0.75,76.0), "display_headphones", "Kulaklık vitrini", 160, 0.34)
	_stealable("ElectronicsDisplayB", Vector3(-10.5,0.75,76.0), "display_camera", "Kamera vitrini", 320, 0.46)
	_stealable("BankLobbyCollectible", Vector3(-30.0,0.75,76.0), "commemorative_token", "Hatıra madalyonu", 90, 0.55)
	_stealable("AlleyParcel", Vector3(-4.0,0.55,83.0), "unattended_parcel", "Sahipsiz paket", 75, 0.22)

func _build_pair_activities() -> void:
	_pair("cyber_duo_training", "Birlikte dijital güvenlik bulmacası", Vector3(-46.0,0.9,76.0), 24, 0.5)
	_pair("detective_case_board", "Birlikte dedektif vaka panosu", Vector3(-30.0,0.9,55.0), 26, 0.75)
	_pair("city_safety_patrol", "Birlikte şehir güvenlik turu", Vector3(-48.0,0.9,58.0), 22, 0.75)
	_pair("court_visit", "Birlikte adliye turu", Vector3(-12.0,0.9,55.0), 16, 0.5)

func _officer(name_value: String, federal: bool, points: Array[Vector3]) -> void:
	var npc = CharacterBody3D.new()
	npc.name = ("Federal_" if federal else "Police_") + name_value.replace(" ","_")
	npc.set_script(LawOfficer)
	root.add_child(npc)
	npc.setup(name_value, federal, points)

func _cyber(node_name: String, pos: Vector3, id_value: String, title: String, difficulty: int, mode: String) -> void:
	var body = StaticBody3D.new()
	body.name = node_name
	body.position = pos
	body.set_script(CyberTerminal)
	root.add_child(body)
	body.setup(id_value, title, difficulty, mode)

func _stealable(node_name: String, pos: Vector3, id_value: String, title: String, value: int, risk: float) -> void:
	var body = StaticBody3D.new()
	body.name = node_name
	body.position = pos
	body.set_script(StealableItem)
	root.add_child(body)
	body.setup(id_value, title, value, risk)

func _pair(id_value: String, title: String, pos: Vector3, points: int, hours: float) -> void:
	var body = StaticBody3D.new()
	body.name = "CrimeJusticeDuo_" + id_value
	body.position = pos
	body.set_script(PairActivity)
	root.add_child(body)
	_collision(body, Vector3(1.2,1.4,1.2))
	body.setup(id_value, title, points, hours)

func _build_civic_building(title: String, pos: Vector3, size: Vector3, color: Color) -> void:
	_visual_box(Vector3(size.x, 0.28, size.z), pos + Vector3(0,0.14,0), Color("747573"), true)
	_visual_box(Vector3(0.35, size.y, size.z), pos + Vector3(-size.x/2.0,size.y/2.0,0), color, true)
	_visual_box(Vector3(0.35, size.y, size.z), pos + Vector3(size.x/2.0,size.y/2.0,0), color, true)
	var door_width = 2.2
	var door_height = 2.55
	var side_width = (size.x - door_width) * 0.5
	# Both street-facing sides have a real doorway so the civic buildings are actually enterable.
	for z_sign in [-1.0, 1.0]:
		var z = z_sign * size.z * 0.5
		_visual_box(Vector3(side_width, size.y, 0.35), pos + Vector3(-(door_width + side_width)*0.5,size.y*0.5,z), color, true)
		_visual_box(Vector3(side_width, size.y, 0.35), pos + Vector3((door_width + side_width)*0.5,size.y*0.5,z), color, true)
		var header_height = max(0.4, size.y - door_height)
		_visual_box(Vector3(door_width, header_height, 0.35), pos + Vector3(0,door_height + header_height*0.5,z), color, true)
		var label = Label3D.new()
		label.text = title
		label.position = pos + Vector3(0,size.y-0.8,z + z_sign*0.35)
		label.rotation_degrees.y = 180.0 if z_sign > 0.0 else 0.0
		label.font_size = 26
		label.outline_size = 6
		root.add_child(label)
	# Side windows provide depth without sealing the doorways.
	for x in [-0.32,0.32]:
		for z_sign in [-1.0,1.0]:
			var glass = MeshInstance3D.new()
			var gmesh = BoxMesh.new()
			gmesh.size = Vector3(size.x*0.24, size.y*0.34, 0.05)
			glass.mesh = gmesh
			glass.position = pos + Vector3(size.x*x, size.y*0.58, z_sign*(size.z/2.0+0.19))
			var gm = StandardMaterial3D.new()
			gm.albedo_color = Color(0.18,0.31,0.40,0.50)
			gm.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
			gm.roughness = 0.16
			glass.material_override = gm
			root.add_child(glass)

func _road(pos: Vector3, size: Vector3) -> void:
	_visual_box(size, pos, Color("292d31"), false)

func _sidewalk(pos: Vector3, size: Vector3) -> void:
	_visual_box(size, pos, Color("858785"), true)

func _visual_box(size: Vector3, pos: Vector3, color: Color, collision: bool) -> void:
	if collision:
		var body = StaticBody3D.new()
		body.position = pos
		root.add_child(body)
		_collision(body, size)
		var mi = MeshInstance3D.new()
		var mesh = BoxMesh.new()
		mesh.size = size
		mi.mesh = mesh
		var mat = StandardMaterial3D.new()
		mat.albedo_color = color
		mat.roughness = 0.88
		mi.material_override = mat
		body.add_child(mi)
		return
	var mi = MeshInstance3D.new()
	var mesh = BoxMesh.new()
	mesh.size = size
	mi.mesh = mesh
	mi.position = pos
	var mat = StandardMaterial3D.new()
	mat.albedo_color = color
	mat.roughness = 0.88
	mi.material_override = mat
	root.add_child(mi)

func _child_box(parent: Node3D, size: Vector3, pos: Vector3, color: Color) -> void:
	var mi = MeshInstance3D.new()
	var mesh = BoxMesh.new()
	mesh.size = size
	mi.mesh = mesh
	mi.position = pos
	var mat = StandardMaterial3D.new()
	mat.albedo_color = color
	mat.roughness = 0.82
	mi.material_override = mat
	parent.add_child(mi)

func _collision(parent: Node3D, size: Vector3) -> void:
	var c = CollisionShape3D.new()
	var shape = BoxShape3D.new()
	shape.size = size
	c.shape = shape
	parent.add_child(c)
