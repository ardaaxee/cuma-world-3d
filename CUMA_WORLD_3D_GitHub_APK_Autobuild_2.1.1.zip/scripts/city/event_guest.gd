extends Node3D

const ProceduralHumanoid = preload("res://scripts/character/procedural_humanoid.gd")
var rig: Node3D
var points: Array[Vector3] = []
var target_index = 0
var speed = 0.72
var pause_left = 0.0

func setup(route_points: Array[Vector3], color: Color) -> void:
	points = route_points.duplicate()
	if not points.is_empty(): global_position = points[0]
	rig = Node3D.new(); rig.set_script(ProceduralHumanoid); add_child(rig)
	rig.setup({"skin":Color("c99875"),"top":color,"pants":Color("303640"),"hair":Color("241e1b"),"shoes":Color("17191d")})
	add_to_group("dynamic_party_guest")
	visible = false
	set_process(false)

func set_party_active(active: bool) -> void:
	visible = active
	set_process(active)
	if active and rig != null and randf() < 0.45: rig.play_emote("wave")

func _process(delta: float) -> void:
	if rig == null or points.size() < 2: return
	if pause_left > 0.0:
		pause_left -= delta
		rig.update_pose(delta,0.0,false,0.0,true,false,0.0)
		if pause_left <= 0.0 and randf() < 0.22: rig.play_emote("cheer")
		return
	var target = points[target_index]
	var flat = target - global_position; flat.y = 0.0
	if flat.length() < 0.28:
		target_index = (target_index + 1) % points.size()
		pause_left = randf_range(2.0,5.5)
		return
	var dir = flat.normalized(); global_position += dir * speed * delta
	rotation.y = lerp_angle(rotation.y, atan2(-dir.x,-dir.z), min(1.0,delta*5.0))
	rig.update_pose(delta,speed,false,0.0,true,false,0.0)
