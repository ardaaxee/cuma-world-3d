extends Node

const PairActivity = preload("res://scripts/together/pair_activity.gd")
const MarketTerminal = preload("res://scripts/market_terminal.gd")
const CinemaTerminal = preload("res://scripts/cinema_terminal.gd")
const CitizenRoutine = preload("res://scripts/city/citizen_routine.gd")
const TrafficSignal = preload("res://scripts/city/traffic_signal.gd")
const DriveableCar = preload("res://scripts/city/driveable_car.gd")
const Elevator = preload("res://scripts/city/elevator.gd")
const CityAmbience = preload("res://scripts/city/city_ambience.gd")

var world: Node3D
var root: Node3D
var concrete_tex: Texture2D
var asphalt_tex: Texture2D
var stone_tex: Texture2D
var walnut_tex: Texture2D
var fabric_tex: Texture2D

func setup(world_root: Node3D) -> void:
	world = world_root
	root = Node3D.new()
	root.name = "LivingCity08"
	world.add_child(root)
	_load_textures()
	_build_city_floor()
	_build_streets()
	_build_city_blocks()
	_build_market()
	_build_cafe()
	_build_cinema()
	_build_arcade()
	_build_apartment_and_elevator()
	_build_city_park()
	_build_street_furniture()
	_build_traffic_signals()
	_build_driveable_car()
	_build_citizens()
	_build_city_activities()
	var ambience = Node.new()
	ambience.name = "CityAmbience"
	ambience.set_script(CityAmbience)
	root.add_child(ambience)

func _load_textures() -> void:
	concrete_tex = load("res://assets/materials/concrete.png")
	asphalt_tex = load("res://assets/materials/asphalt.png")
	stone_tex = load("res://assets/materials/stone.png")
	walnut_tex = load("res://assets/materials/walnut.png")
	fabric_tex = load("res://assets/materials/fabric.png")

func _build_city_floor() -> void:
	_static_box("CityGround",Vector3(76,0.24,66),Vector3(0,-0.18,49),_mat(Color("707a67"),0.98))
	# City plaza in front of businesses.
	_static_box("CityPlaza",Vector3(70,0.08,10),Vector3(0,-0.02,31),_mat(Color("a6a39d"),0.92,0.0,concrete_tex))

func _build_streets() -> void:
	_static_box("NorthAvenue",Vector3(76,0.10,8.8),Vector3(0,-0.05,25.0),_mat(Color("363a3d"),0.97,0.0,asphalt_tex))
	_static_box("CentralStreet",Vector3(9.0,0.10,52.0),Vector3(0,-0.04,51.0),_mat(Color("383c3f"),0.97,0.0,asphalt_tex))
	# sidewalks
	_static_box("WalkNorth",Vector3(76,0.12,3.0),Vector3(0,0.0,30.0),_mat(Color("a5a39e"),0.94,0.0,concrete_tex))
	_static_box("WalkWest",Vector3(3.0,0.12,51.0),Vector3(-6.0,0.0,51.0),_mat(Color("a5a39e"),0.94,0.0,concrete_tex))
	_static_box("WalkEast",Vector3(3.0,0.12,51.0),Vector3(6.0,0.0,51.0),_mat(Color("a5a39e"),0.94,0.0,concrete_tex))
	# road markings
	var mark = _mat(Color("e8e0b6"),0.78)
	for x in range(-34,35,6):
		_panel(Vector3(2.8,0.015,0.12),Vector3(float(x),0.025,25.0),Vector3.ZERO,mark)
	for z in range(34,75,6):
		_panel(Vector3(0.12,0.015,2.8),Vector3(0,0.025,float(z)),Vector3.ZERO,mark)
	for i in range(6):
		_panel(Vector3(0.65,0.018,3.2),Vector3(-2.0+float(i)*0.8,0.03,28.0),Vector3.ZERO,_mat(Color("e7e7e2"),0.90))

func _build_city_blocks() -> void:
	# Mixed-use blocks close the horizon and give the expanded district a real street wall.
	_build_apartment_block(Vector3(-18.0,0,65.0),Vector3(14.0,11.0,12.0),Color("b9b2a7"),5)
	_build_apartment_block(Vector3(33.0,0,65.0),Vector3(12.0,9.0,13.0),Color("a6aaa7"),4)
	_build_apartment_block(Vector3(-33.0,0,66.0),Vector3(11.0,8.0,12.0),Color("c1b4a2"),4)
	_build_apartment_block(Vector3(20.0,0,80.0),Vector3(16.0,12.0,9.0),Color("999f9f"),6)

func _build_apartment_block(center: Vector3, size: Vector3, color: Color, floors: int) -> void:
	_static_box("CityBlock",size,center+Vector3(0,size.y*0.5,0),_mat(color,0.90))
	var glass = _mat(Color(0.22,0.31,0.36,0.72),0.12,0.18)
	glass.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	var lit = _emissive(Color("e7be82"),1.2)
	for floor_index in range(floors):
		var y = 1.35 + float(floor_index)*1.65
		for col in range(5):
			var x = center.x-size.x*0.36+float(col)*(size.x*0.18)
			_panel(Vector3(0.82,0.92,0.06),Vector3(x,y,center.z-size.z*0.5-0.035),Vector3.ZERO,glass)
			if (floor_index+col)%3 == 0:
				var glow = _panel(Vector3(0.70,0.80,0.035),Vector3(x,y,center.z-size.z*0.5-0.075),Vector3.ZERO,lit)
				glow.visible = false
				glow.add_to_group("building_window_light")
	# balcony bands add depth instead of flat boxes.
	for floor_index in range(1,max(1,floors-1)):
		var y = 1.15 + float(floor_index)*1.65
		_panel(Vector3(size.x*0.72,0.08,0.62),Vector3(center.x,y,center.z-size.z*0.5-0.33),Vector3.ZERO,_mat(Color("656a6b"),0.46,0.62))

func _build_market() -> void:
	var center = Vector3(15.0,0.0,38.0)
	_build_open_shop("FreshMarket",center,Vector3(12.0,3.6,10.0),Color("d8d4c7"),Color("4e785d"),"FRESH MARKET")
	# refrigerated shelves and produce islands
	for z in [36.2,39.0,41.2]:
		_shelf(Vector3(18.6,0.0,z),3.0,Color("d7d9da"))
	for x in [12.0,15.2]:
		var table = _static_box("MarketIsland",Vector3(2.4,0.72,1.25),Vector3(x,0.36,38.8),_mat(Color("7a5a40"),0.78,0.0,walnut_tex))
		for ix in range(4):
			for iz in range(2):
				_sphere(Vector3(x-0.72+ix*0.48,0.88,38.55+iz*0.50),Vector3(0.12,0.10,0.12),_mat(Color("b84c39") if (ix+iz)%2==0 else Color("d8b548"),0.84))
	# checkout counters
	_static_box("MarketCheckout",Vector3(3.5,0.95,0.72),Vector3(13.0,0.48,33.7),_mat(Color("5f665e"),0.70))
	var terminal = StaticBody3D.new()
	terminal.name = "CityMarketTerminal"
	terminal.position = Vector3(13.0,1.15,33.15)
	terminal.set_script(MarketTerminal)
	root.add_child(terminal)
	_collision_box(terminal,Vector3(1.3,1.6,0.35))

func _build_cafe() -> void:
	var center = Vector3(-15.0,0.0,38.0)
	_build_open_shop("CornerCafe",center,Vector3(12.0,3.5,10.0),Color("cbb99d"),Color("7b5f49"),"CORNER CAFE")
	_static_box("CafeBar",Vector3(5.6,1.05,0.85),Vector3(-16.0,0.53,41.4),_mat(Color("6b4d38"),0.74,0.0,walnut_tex))
	for x in [-18.0,-15.6,-13.2]:
		_table_set(Vector3(x,0.0,36.8))
	# coffee machine silhouette
	_static_box("CoffeeMachine",Vector3(0.75,0.62,0.46),Vector3(-17.3,1.36,41.2),_mat(Color("343638"),0.30,0.70))
	for x in [-17.52,-17.08]:
		_cylinder(Vector3(x,1.10,40.98),0.055,0.28,_mat(Color("c1c5c5"),0.28,0.82))

func _build_cinema() -> void:
	var center = Vector3(-29.0,0.0,47.0)
	_build_open_shop("CityCinema",center,Vector3(14.0,5.5,16.0),Color("3a363e"),Color("8c4050"),"CUMA CINEMA")
	# lobby counter and poster frames
	_static_box("CinemaCounter",Vector3(5.0,1.0,0.85),Vector3(-29.0,0.50,40.2),_mat(Color("6b3945"),0.60))
	for x in [-33.5,-31.4,-26.6,-24.5]:
		_panel(Vector3(1.35,2.0,0.08),Vector3(x,1.55,39.1),Vector3.ZERO,_emissive(Color("715167"),0.85))
	# theater floor + rows of actual seats
	for row in range(5):
		var z = 46.0 + float(row)*1.65
		for col in range(6):
			_seat(Vector3(-33.0+float(col)*1.55,0.0,z),Color("713c4a"))
	# screen
	_panel(Vector3(9.2,3.8,0.10),Vector3(-29.0,2.65,54.15),Vector3.ZERO,_mat(Color("e3e1db"),0.38))
	var cinema_terminal = StaticBody3D.new()
	cinema_terminal.name = "CityCinemaTerminal"
	cinema_terminal.position = Vector3(-29.0,1.1,40.0)
	cinema_terminal.set_script(CinemaTerminal)
	root.add_child(cinema_terminal)
	_collision_box(cinema_terminal,Vector3(1.25,1.6,0.35))

func _build_arcade() -> void:
	var center = Vector3(29.0,0.0,47.0)
	_build_open_shop("NeonArcade",center,Vector3(14.0,4.2,16.0),Color("393548"),Color("75558f"),"NEON ARCADE")
	for row in range(3):
		for col in range(3):
			var p = Vector3(25.2+float(col)*3.0,0.0,43.6+float(row)*3.2)
			_arcade_machine(p,Color("5d4e8b") if (row+col)%2==0 else Color("3d7480"))
	_panel(Vector3(7.0,0.14,4.0),Vector3(29.0,0.04,53.0),Vector3.ZERO,_mat(Color("4f405f"),0.82))

func _build_apartment_and_elevator() -> void:
	# A real lobby and rooftop destination make the elevator useful instead of decorative.
	var center = Vector3(0.0,0.0,60.0)
	_static_box("ApartmentLobbyFloor",Vector3(13.0,0.16,13.0),Vector3(0,0.02,60),_mat(Color("a79f93"),0.86,0.0,stone_tex))
	_static_box("ApartmentBack",Vector3(13.0,8.5,0.28),Vector3(0,4.25,66.4),_mat(Color("d2cec5"),0.88))
	_static_box("ApartmentLeft",Vector3(0.28,8.5,13.0),Vector3(-6.4,4.25,60),_mat(Color("d2cec5"),0.88))
	_static_box("ApartmentRight",Vector3(0.28,8.5,13.0),Vector3(6.4,4.25,60),_mat(Color("d2cec5"),0.88))
	# front columns leave lobby open
	_static_box("ApartmentFrontL",Vector3(4.4,8.5,0.28),Vector3(-4.3,4.25,53.6),_mat(Color("d2cec5"),0.88))
	_static_box("ApartmentFrontR",Vector3(4.4,8.5,0.28),Vector3(4.3,4.25,53.6),_mat(Color("d2cec5"),0.88))
	_sign(Vector3(0,3.2,53.42),"CUMA RESIDENCE",Color("e7d6ae"))
	# mailboxes
	for row in range(3):
		for col in range(4):
			_panel(Vector3(0.58,0.42,0.10),Vector3(-5.95,1.0+row*0.50,57.8+col*0.72),Vector3(0,deg_to_rad(90),0),_mat(Color("6f7477"),0.36,0.76))
	# elevator shaft visual frame and moving platform
	_static_box("ElevatorShaftBack",Vector3(2.8,8.5,0.16),Vector3(0,4.25,63.3),_mat(Color("5b6063"),0.34,0.72))
	for x in [-1.45,1.45]:
		_static_box("ElevatorRail",Vector3(0.10,8.5,2.8),Vector3(x,4.25,62.0),_mat(Color("555a5d"),0.30,0.80))
	var elevator = AnimatableBody3D.new()
	elevator.name = "ResidenceElevator"
	elevator.position = Vector3(0,0.12,61.7)
	elevator.set_script(Elevator)
	root.add_child(elevator)
	elevator.setup()
	# rooftop terrace
	# Four roof slabs leave a real 2.8m elevator opening around z=61.7.
	var roof_mat = _mat(Color("77746e"),0.94,0.0,concrete_tex)
	_static_box("ResidenceRoofLeft",Vector3(5.1,0.20,13.0),Vector3(-3.95,8.62,60),roof_mat)
	_static_box("ResidenceRoofRight",Vector3(5.1,0.20,13.0),Vector3(3.95,8.62,60),roof_mat)
	_static_box("ResidenceRoofFront",Vector3(2.8,0.20,6.2),Vector3(0,8.62,57.0),roof_mat)
	_static_box("ResidenceRoofBack",Vector3(2.8,0.20,3.4),Vector3(0,8.62,64.3),roof_mat)
	for x in [-5.9,5.9]:
		_static_box("RoofRailX",Vector3(0.08,1.05,12.0),Vector3(x,9.16,60),_mat(Color("383b3e"),0.30,0.75))
	for z in [54.1,65.9]:
		_static_box("RoofRailZ",Vector3(12.0,1.05,0.08),Vector3(0,9.16,z),_mat(Color("383b3e"),0.30,0.75))
	for p in [Vector3(-4,8.7,57),Vector3(4,8.7,63)]:
		_planter(p)

func _build_city_park() -> void:
	_static_box("CityPark",Vector3(20.0,0.12,19.0),Vector3(19.0,0.0,64.0),_mat(Color("54734e"),0.99))
	for z in [58.0,64.0,70.0]:
		_panel(Vector3(15.0,0.025,1.15),Vector3(19.0,0.07,z),Vector3.ZERO,_mat(Color("b4aa93"),0.96,0.0,stone_tex))
	for p in [Vector3(13,0,57),Vector3(24,0,57),Vector3(12,0,67),Vector3(26,0,69),Vector3(20,0,72)]:
		_tree(p)
	for p in [Vector3(15,0,61),Vector3(23,0,66),Vector3(18,0,69)]:
		_bench(p)
	# small fountain
	_cylinder(Vector3(19,0.32,64),2.0,0.42,_mat(Color("8c8f8b"),0.86,0.0,stone_tex))
	_cylinder(Vector3(19,0.55,64),1.65,0.12,_water())
	_cylinder(Vector3(19,0.98,64),0.18,0.92,_mat(Color("8b8e8b"),0.82,0.0,stone_tex))

func _build_street_furniture() -> void:
	for x in range(-32,33,8):
		_street_lamp(Vector3(float(x),0,29.2))
	for z in range(35,73,8):
		_street_lamp(Vector3(-6.8,0,float(z)))
		_street_lamp(Vector3(6.8,0,float(z)))
	for p in [Vector3(-8,0,31),Vector3(8,0,31),Vector3(-4.7,0,43),Vector3(4.7,0,43)]:
		_bollard(p)

func _build_traffic_signals() -> void:
	var data = [
		[Vector3(-5.2,0,29.0),0.0,0.0],
		[Vector3(5.2,0,21.0),180.0,9.0],
		[Vector3(-5.2,0,21.0),90.0,9.0],
		[Vector3(5.2,0,29.0),-90.0,0.0]
	]
	for item in data:
		var traffic_light = Node3D.new()
		traffic_light.position = item[0]
		traffic_light.rotation_degrees.y = item[1]
		traffic_light.set_script(TrafficSignal)
		root.add_child(traffic_light)
		traffic_light.setup(item[2])

func _build_driveable_car() -> void:
	var car = CharacterBody3D.new()
	car.name = "PlayerCityCar"
	car.position = Vector3(9.0,0.02,25.0)
	car.rotation_degrees.y = -90.0
	car.set_script(DriveableCar)
	root.add_child(car)
	car.setup(Color("395f7a"))

func _build_citizens() -> void:
	var routes: Array = [
		[Vector3(-12,0.05,30.8),Vector3(-18,0.05,34),Vector3(-15,0.05,39),Vector3(-8,0.05,31)],
		[Vector3(11,0.05,30.8),Vector3(16,0.05,34),Vector3(17,0.05,41),Vector3(8,0.05,31)],
		[Vector3(-5,0.05,38),Vector3(-5,0.05,55),Vector3(-5,0.05,69),Vector3(-5,0.05,48)],
		[Vector3(5,0.05,35),Vector3(5,0.05,58),Vector3(10,0.05,62),Vector3(5,0.05,45)],
		[Vector3(11,0.05,58),Vector3(25,0.05,58),Vector3(26,0.05,70),Vector3(14,0.05,70)],
		[Vector3(-24,0.05,31),Vector3(-30,0.05,40),Vector3(-25,0.05,53),Vector3(-18,0.05,31)],
		[Vector3(24,0.05,31),Vector3(30,0.05,40),Vector3(27,0.05,52),Vector3(18,0.05,31)],
		[Vector3(-3,0.05,54),Vector3(3,0.05,54),Vector3(5,0.05,65),Vector3(-5,0.05,65)],
		[Vector3(13,0.05,61),Vector3(19,0.05,57),Vector3(25,0.05,64),Vector3(19,0.05,70)],
		[Vector3(-19,0.05,35),Vector3(-12,0.05,35),Vector3(-12,0.05,41),Vector3(-19,0.05,41)],
		[Vector3(12,0.05,35),Vector3(19,0.05,35),Vector3(19,0.05,41),Vector3(12,0.05,41)],
		[Vector3(-31,0.05,43),Vector3(-26,0.05,43),Vector3(-26,0.05,51),Vector3(-32,0.05,51)]
	]
	var colors = [Color("546c84"),Color("855d63"),Color("5c765d"),Color("725987"),Color("9a7550"),Color("446d76")]
	for i in range(routes.size()):
		var citizen = Node3D.new()
		citizen.name = "CityCitizen_%02d" % i
		citizen.set_script(CitizenRoutine)
		citizen.add_to_group("quality_crowd")
		root.add_child(citizen)
		var route: Array[Vector3] = []
		for p in routes[i]:
			route.append(p)
		citizen.setup(route,colors[i % colors.size()],float(i)+0.73)

func _build_city_activities() -> void:
	_pair_activity("cafe_date","Kafede birlikte otur",Vector3(-15.5,0.9,36.8),18,0.75)
	_pair_activity("cinema_premium","Sinema salonunda film izle",Vector3(-29.0,0.9,47.8),26,2.0)
	_pair_activity("arcade_tournament","Arcade turnuvası",Vector3(29.0,0.9,48.0),22,1.0)
	_pair_activity("park_fountain","Parkta çeşme başında mola",Vector3(19.0,0.85,62.0),16,0.5)
	_pair_activity("rooftop_view","Çatıdan şehir manzarası",Vector3(0.0,9.25,58.0),24,0.75)
	_pair_activity("city_shopping","Şehirde birlikte alışveriş",Vector3(15.0,0.9,37.5),18,0.75)
	_pair_activity("evening_walk","Akşam şehir yürüyüşü",Vector3(4.5,0.8,57.0),20,1.0)

func _build_open_shop(node_name: String, center: Vector3, size: Vector3, wall_color: Color, accent: Color, title: String) -> void:
	var wall = _mat(wall_color,0.88)
	_static_box(node_name+"Floor",Vector3(size.x,0.14,size.z),center+Vector3(0,0.02,0),_mat(Color("8c8379"),0.90,0.0,stone_tex))
	_static_box(node_name+"Back",Vector3(size.x,size.y,0.22),center+Vector3(0,size.y*0.5,size.z*0.5),wall)
	_static_box(node_name+"Left",Vector3(0.22,size.y,size.z),center+Vector3(-size.x*0.5,size.y*0.5,0),wall)
	_static_box(node_name+"Right",Vector3(0.22,size.y,size.z),center+Vector3(size.x*0.5,size.y*0.5,0),wall)
	_static_box(node_name+"Roof",Vector3(size.x,0.18,size.z),center+Vector3(0,size.y,0),wall)
	# front columns + header leave a walkable opening
	_static_box(node_name+"FrontL",Vector3(1.15,size.y,0.20),center+Vector3(-size.x*0.5+0.58,size.y*0.5,-size.z*0.5),wall)
	_static_box(node_name+"FrontR",Vector3(1.15,size.y,0.20),center+Vector3(size.x*0.5-0.58,size.y*0.5,-size.z*0.5),wall)
	_panel(Vector3(size.x-2.3,0.50,0.18),center+Vector3(0,size.y-0.38,-size.z*0.5-0.02),Vector3.ZERO,_emissive(accent,1.4))
	_sign(center+Vector3(0,size.y-0.38,-size.z*0.5-0.14),title,Color("f2ede1"))

func _shelf(pos: Vector3, width: float, color: Color) -> void:
	var mat = _mat(color,0.58,0.25)
	for y in [0.30,0.85,1.40,1.95]:
		_panel(Vector3(width,0.08,0.48),Vector3(pos.x,y,pos.z),Vector3.ZERO,mat)
	for x in [pos.x-width*0.5,pos.x+width*0.5]:
		_panel(Vector3(0.06,2.0,0.48),Vector3(x,1.0,pos.z),Vector3.ZERO,mat)

func _table_set(pos: Vector3) -> void:
	_cylinder(pos+Vector3(0,0.72,0),0.62,0.09,_mat(Color("79563e"),0.76,0.0,walnut_tex))
	_cylinder(pos+Vector3(0,0.35,0),0.045,0.68,_mat(Color("383b3e"),0.32,0.70))
	for a in [0.0,PI]:
		_seat(pos+Vector3(cos(a)*1.05,0,sin(a)*1.05),Color("6c625c"))

func _seat(pos: Vector3, color: Color) -> void:
	var mat = _mat(color,0.97,0.0,fabric_tex)
	_cylinder(pos+Vector3(0,0.46,0),0.34,0.16,mat)
	_panel(Vector3(0.72,0.68,0.15),pos+Vector3(0,0.86,0.31),Vector3.ZERO,mat)
	for x in [-0.24,0.24]:
		for z in [-0.18,0.18]:
			_cylinder(pos+Vector3(x,0.22,z),0.025,0.44,_mat(Color("2e3032"),0.38,0.65))

func _arcade_machine(pos: Vector3, color: Color) -> void:
	_static_box("ArcadeCabinet",Vector3(1.25,1.75,0.85),pos+Vector3(0,0.88,0),_mat(color,0.52,0.2))
	_panel(Vector3(0.88,0.65,0.06),pos+Vector3(0,1.30,-0.46),Vector3.ZERO,_emissive(color.lightened(0.28),1.4))
	_panel(Vector3(0.82,0.10,0.42),pos+Vector3(0,0.88,-0.57),Vector3(deg_to_rad(-12),0,0),_mat(Color("24262a"),0.34,0.55))
	_sphere(pos+Vector3(-0.22,0.98,-0.64),Vector3(0.06,0.06,0.06),_emissive(Color("d63d55"),1.8))

func _tree(pos: Vector3) -> void:
	_cylinder(pos+Vector3(0,1.15,0),0.18,2.30,_mat(Color("674b35"),0.96))
	for off in [Vector3(0,2.5,0),Vector3(-0.55,2.2,0.15),Vector3(0.48,2.25,-0.15)]:
		_sphere(pos+off,Vector3(0.82,0.62,0.82),_mat(Color("49694a"),0.99))

func _bench(pos: Vector3) -> void:
	var wood = _mat(Color("76543b"),0.82,0.0,walnut_tex)
	_panel(Vector3(2.1,0.12,0.48),pos+Vector3(0,0.52,0),Vector3.ZERO,wood)
	_panel(Vector3(2.1,0.70,0.10),pos+Vector3(0,0.92,0.34),Vector3.ZERO,wood)
	for x in [-0.78,0.78]:
		_cylinder(pos+Vector3(x,0.26,0),0.035,0.52,_mat(Color("303336"),0.32,0.70))

func _street_lamp(pos: Vector3) -> void:
	var metal = _mat(Color("34373a"),0.30,0.78)
	_cylinder(pos+Vector3(0,1.65,0),0.045,3.30,metal)
	_sphere(pos+Vector3(0,3.25,0),Vector3(0.18,0.14,0.18),_emissive(Color("ffd8a2"),2.1))
	var light = OmniLight3D.new()
	light.position = pos+Vector3(0,3.05,0)
	light.light_color = Color("ffd2a0")
	light.light_energy = 0.75
	light.omni_range = 5.5
	light.shadow_enabled = false
	light.add_to_group("quality_extra_light")
	light.add_to_group("street_night_light")
	root.add_child(light)

func _bollard(pos: Vector3) -> void:
	_cylinder(pos+Vector3(0,0.40,0),0.085,0.80,_mat(Color("4b4f51"),0.34,0.72))

func _planter(pos: Vector3) -> void:
	_static_box("RoofPlanter",Vector3(1.2,0.52,0.65),pos+Vector3(0,0.26,0),_mat(Color("715748"),0.90))
	for x in [-0.35,0,0.35]:
		_cylinder(pos+Vector3(x,0.78,0),0.05,0.72,_mat(Color("4d714f"),0.98),Vector3(0,0,float(x)*28.0))

func _pair_activity(id: String, title: String, pos: Vector3, points: int, hours: float) -> void:
	var body = StaticBody3D.new()
	body.name = "CityDuo_"+id
	body.position = pos
	body.set_script(PairActivity)
	root.add_child(body)
	_collision_box(body,Vector3(1.35,1.55,1.35))
	body.setup(id,title,points,hours)

func _sign(pos: Vector3, text: String, color: Color) -> void:
	var label = Label3D.new()
	label.text = text
	label.position = pos
	label.font_size = 34
	label.outline_size = 7
	label.modulate = color
	label.billboard = BaseMaterial3D.BILLBOARD_DISABLED
	root.add_child(label)

func _static_box(node_name: String, size: Vector3, pos: Vector3, material: Material) -> StaticBody3D:
	var body = StaticBody3D.new()
	body.name = node_name
	body.position = pos
	root.add_child(body)
	var mesh_node = MeshInstance3D.new()
	var mesh = BoxMesh.new()
	mesh.size = size
	mesh_node.mesh = mesh
	mesh_node.material_override = material
	body.add_child(mesh_node)
	_collision_box(body,size)
	return body

func _collision_box(parent: Node3D, size: Vector3) -> void:
	var collision = CollisionShape3D.new()
	var shape = BoxShape3D.new()
	shape.size = size
	collision.shape = shape
	parent.add_child(collision)

func _panel(size: Vector3, pos: Vector3, rot: Vector3, material: Material) -> MeshInstance3D:
	var node = MeshInstance3D.new()
	var mesh = BoxMesh.new()
	mesh.size = size
	node.mesh = mesh
	node.position = pos
	node.rotation = rot
	node.material_override = material
	root.add_child(node)
	return node

func _cylinder(pos: Vector3, radius: float, height: float, material: Material, rot_deg: Vector3 = Vector3.ZERO) -> MeshInstance3D:
	var node = MeshInstance3D.new()
	var mesh = CylinderMesh.new()
	mesh.top_radius = radius
	mesh.bottom_radius = radius
	mesh.height = height
	mesh.radial_segments = 18
	node.mesh = mesh
	node.position = pos
	node.rotation_degrees = rot_deg
	node.material_override = material
	root.add_child(node)
	return node

func _sphere(pos: Vector3, scale_value: Vector3, material: Material) -> MeshInstance3D:
	var node = MeshInstance3D.new()
	var mesh = SphereMesh.new()
	mesh.radius = 0.5
	mesh.height = 1.0
	node.mesh = mesh
	node.position = pos
	node.scale = scale_value*2.0
	node.material_override = material
	root.add_child(node)
	return node

func _mat(color: Color, roughness: float = 0.82, metallic: float = 0.0, texture: Texture2D = null) -> StandardMaterial3D:
	var mat = StandardMaterial3D.new()
	mat.albedo_color = color
	mat.roughness = roughness
	mat.metallic = metallic
	if texture != null:
		mat.albedo_texture = texture
	return mat

func _emissive(color: Color, energy: float) -> StandardMaterial3D:
	var mat = _mat(color,0.38,0.05)
	mat.emission_enabled = true
	mat.emission = color
	mat.emission_energy_multiplier = energy
	return mat

func _water() -> StandardMaterial3D:
	var mat = _mat(Color(0.31,0.58,0.70,0.72),0.08,0.12)
	mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	mat.cull_mode = BaseMaterial3D.CULL_DISABLED
	return mat
