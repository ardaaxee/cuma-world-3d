extends StaticBody3D

var title = "Antrenman"
var pose = "exercise"
var duration = 4.0
var stamina_restore = 0

func setup(display_title: String, pose_name: String = "exercise", seconds: float = 4.0, restore_amount: int = 0) -> void:
	title = display_title.left(64)
	pose = pose_name.left(24)
	duration = clamp(seconds, 1.0, 12.0)
	stamina_restore = clamp(restore_amount, 0, 100)

func get_interaction_label() -> String:
	return title

func interact(player: Node) -> void:
	if player == null or not player.has_method("begin_pose_activity"):
		return
	player.begin_pose_activity(title, pose, duration)
	if stamina_restore > 0 and player.has_method("restore_stamina"):
		player.restore_stamina()
