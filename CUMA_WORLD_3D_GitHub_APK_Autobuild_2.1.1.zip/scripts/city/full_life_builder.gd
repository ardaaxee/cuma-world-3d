extends Node

const ShopTerminal = preload("res://scripts/economy/shop_terminal.gd")
const WorkShift = preload("res://scripts/economy/work_shift.gd")
const CustomizationStation = preload("res://scripts/character/customization_station.gd")
const PairActivity = preload("res://scripts/together/pair_activity.gd")

var root: Node3D

func setup(target: Node3D) -> void:
	root = target
	_build_retail_gameplay()
	_build_work_gameplay()
	_build_customization_corner()
	_build_story_lounge()
	_build_new_pair_activities()
	_build_city_detail_pass()

func _build_retail_gameplay() -> void:
	# Existing 0.9 locations receive real purchasable products instead of decorative-only shelves.
	_shop("MarketDrink", Vector3(12.0, 0.85, 38.8), "sparkling_drink", "Soğuk içecek", 18, 1, "item")
	_shop("MarketBreakfast", Vector3(15.2, 0.85, 38.8), "breakfast_box", "Kahvaltılık paket", 42, 1, "item")
	_shop("MarketDessert", Vector3(18.6, 0.85, 39.0), "dessert_box", "Tatlı kutusu", 55, 1, "item")
	_shop("BookNovel", Vector3(36.0, 0.9, 66.0), "novel", "Roman", 65, 1, "item")
	_shop("BookAlbum", Vector3(42.0, 0.9, 66.0), "photo_album", "Anı albümü", 95, 1, "item")
	_shop("OutfitRose", Vector3(44.0, 0.9, 47.0), "rose", "Rose kıyafet", 180, 1, "outfit")
	_shop("OutfitOcean", Vector3(46.0, 0.9, 47.0), "ocean", "Ocean kıyafet", 210, 1, "outfit")
	_shop("OutfitOlive", Vector3(48.0, 0.9, 47.0), "olive", "Olive kıyafet", 195, 1, "outfit")
	_shop("OutfitMono", Vector3(50.0, 0.9, 47.0), "mono", "Mono kıyafet", 240, 1, "outfit")

func _build_work_gameplay() -> void:
	_shift("CafeShift", Vector3(-16.0, 0.95, 41.0), "cafe_shift", "Kafede kısa vardiya", 95, 1.0)
	_shift("RestaurantShift", Vector3(31.0, 0.95, 50.8), "restaurant_shift", "Restoran hazırlığı", 125, 1.25)
	_shift("BookShift", Vector3(39.0, 0.95, 70.2), "book_shift", "Kitap raflarını düzenle", 85, 0.75)
	_shift("ArcadeShift", Vector3(29.0, 0.95, 50.8), "arcade_shift", "Arcade bakım vardiyası", 90, 0.75)

func _build_customization_corner() -> void:
	var station = StaticBody3D.new()
	station.name = "CharacterStudioMirror"
	station.position = Vector3(47.0, 1.05, 50.5)
	station.set_script(CustomizationStation)
	root.add_child(station)
	_visual_panel(station, Vector3(1.55, 2.05, 0.08), Color("b9c3c8"), 0.10, 0.82)
	_collision(station, Vector3(1.8, 2.2, 0.35))
	var label = Label3D.new()
	label.text = "STYLE MIRROR"
	label.position = Vector3(0, 1.25, 0)
	label.font_size = 25
	label.outline_size = 5
	station.add_child(label)

func _build_story_lounge() -> void:
	# A comfortable progress corner in the residence lobby rather than another floating marker.
	var c = Vector3(11.0, 0.0, 47.0)
	_cylinder(c + Vector3(0, 0.46, 0), 0.62, 0.12, Color("765b46"))
	for off in [Vector3(-1.05,0.48,0), Vector3(1.05,0.48,0)]:
		_visual_box(Vector3(0.72,0.18,0.70), c + off, Color("5d6269"), 0.92)
	var board = Label3D.new()
	board.name = "StoryProgressBoard"
	board.text = "CUMA WORLD • HİKÂYE"
	board.position = c + Vector3(0, 1.55, 0.45)
	board.font_size = 34
	board.outline_size = 7
	root.add_child(board)

func _build_new_pair_activities() -> void:
	_pair("first_big_shop", "Birlikte haftalık alışveriş", Vector3(15.0,0.9,38.0), 18, 0.5)
	_pair("style_session", "Birlikte stil seçin", Vector3(47.0,0.9,49.5), 18, 0.5)
	_pair("book_album", "Anı albümünü birlikte hazırlayın", Vector3(42.0,0.9,65.0), 24, 0.75)
	_pair("restaurant_team", "Birlikte restoran masası hazırlayın", Vector3(31.0,0.9,49.4), 20, 0.75)
	_pair("night_drive", "Gece şehir turuna çıkın", Vector3(22.0,0.9,32.0), 28, 0.75)
	_pair("morning_rooftop", "Çatıda sabahı karşılayın", Vector3(8.0,8.2,47.0), 26, 0.75)
	_pair("city_photo_walk", "Şehir fotoğraf yürüyüşü", Vector3(46.0,0.9,82.0), 24, 0.75)
	_pair("home_plan", "Birlikte gelecek planı yapın", Vector3(11.0,0.9,47.0), 30, 1.0)

func _build_city_detail_pass() -> void:
	# Human-scale details make the district read as lived-in without adding expensive physics.
	for x in range(24, 55, 5):
		_street_bin(Vector3(float(x), 0.0, 38.5))
	for p in [Vector3(26,0,42),Vector3(35,0,42),Vector3(44,0,42),Vector3(53,0,42),Vector3(27,0,77),Vector3(49,0,77)]:
		_bike_rack(p)
	for p in [Vector3(25,0,55),Vector3(36,0,56),Vector3(50,0,55),Vector3(30,0,74),Vector3(48,0,74)]:
		_planter(p)

func _shop(name_value: String, pos: Vector3, id: String, title: String, cost: int, count: int, kind: String) -> void:
	var body = StaticBody3D.new()
	body.name = name_value
	body.position = pos
	body.set_script(ShopTerminal)
	root.add_child(body)
	_visual_panel(body, Vector3(0.62, 0.95, 0.18), Color("56616b"), 0.58, 0.05)
	_collision(body, Vector3(0.8, 1.2, 0.5))
	body.setup(id, title, cost, count, kind)

func _shift(name_value: String, pos: Vector3, id: String, title: String, pay: int, hours: float) -> void:
	var body = StaticBody3D.new()
	body.name = name_value
	body.position = pos
	body.set_script(WorkShift)
	root.add_child(body)
	_visual_panel(body, Vector3(0.70, 1.05, 0.18), Color("4d6257"), 0.70, 0.02)
	_collision(body, Vector3(0.9, 1.3, 0.45))
	body.setup(id, title, pay, hours)

func _pair(id: String, title: String, pos: Vector3, points: int, hours: float) -> void:
	var body = StaticBody3D.new()
	body.name = "FullLifeDuo_" + id
	body.position = pos
	body.set_script(PairActivity)
	root.add_child(body)
	_collision(body, Vector3(1.25,1.45,1.25))
	body.setup(id,title,points,hours)

func _street_bin(pos: Vector3) -> void:
	_cylinder(pos+Vector3(0,0.42,0),0.22,0.78,Color("42484a"))
	_cylinder(pos+Vector3(0,0.84,0),0.24,0.08,Color("303538"))

func _bike_rack(pos: Vector3) -> void:
	for i in range(3):
		var x = float(i-1)*0.52
		_cylinder(pos+Vector3(x,0.36,0),0.025,0.72,Color("666c70"),Vector3(0,0,90))

func _planter(pos: Vector3) -> void:
	_cylinder(pos+Vector3(0,0.32,0),0.42,0.58,Color("77634f"))
	for off in [Vector3(-0.18,0.80,0),Vector3(0.17,0.86,0.06),Vector3(0.02,0.98,-0.12)]:
		_sphere(pos+off,Vector3(0.30,0.34,0.30),Color("49684e"))

func _visual_panel(parent: Node3D, size: Vector3, color: Color, rough: float, metallic: float) -> void:
	var mesh_i = MeshInstance3D.new()
	var mesh = BoxMesh.new(); mesh.size = size
	mesh_i.mesh = mesh
	var mat = StandardMaterial3D.new(); mat.albedo_color=color; mat.roughness=rough; mat.metallic=metallic
	mesh_i.material_override = mat
	parent.add_child(mesh_i)

func _visual_box(size: Vector3, pos: Vector3, color: Color, rough: float) -> void:
	var mesh_i = MeshInstance3D.new(); var mesh = BoxMesh.new(); mesh.size=size; mesh_i.mesh=mesh; mesh_i.position=pos
	var mat=StandardMaterial3D.new(); mat.albedo_color=color; mat.roughness=rough; mesh_i.material_override=mat; root.add_child(mesh_i)

func _cylinder(pos: Vector3, radius: float, height: float, color: Color, rot: Vector3=Vector3.ZERO) -> void:
	var n=MeshInstance3D.new(); var mesh=CylinderMesh.new(); mesh.top_radius=radius; mesh.bottom_radius=radius; mesh.height=height; mesh.radial_segments=16
	n.mesh=mesh; n.position=pos; n.rotation_degrees=rot; var mat=StandardMaterial3D.new(); mat.albedo_color=color; mat.roughness=0.82; n.material_override=mat; root.add_child(n)

func _sphere(pos: Vector3, scale_value: Vector3, color: Color) -> void:
	var n=MeshInstance3D.new(); var mesh=SphereMesh.new(); mesh.radius=0.5; mesh.height=1.0; n.mesh=mesh; n.position=pos; n.scale=scale_value*2.0
	var mat=StandardMaterial3D.new(); mat.albedo_color=color; mat.roughness=0.96; n.material_override=mat; root.add_child(n)

func _collision(parent: Node3D, size: Vector3) -> void:
	var c=CollisionShape3D.new(); var shape=BoxShape3D.new(); shape.size=size; c.shape=shape; parent.add_child(c)
