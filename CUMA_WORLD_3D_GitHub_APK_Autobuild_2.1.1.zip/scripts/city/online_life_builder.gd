extends Node

const PairActivity = preload("res://scripts/together/pair_activity.gd")
const ScheduledCitizen = preload("res://scripts/city/scheduled_citizen.gd")
var world: Node3D
var root: Node3D

func setup(world_root: Node3D) -> void:
	world = world_root
	root = Node3D.new()
	root.name = "OnlineLife09"
	world.add_child(root)
	_build_extension_ground()
	_build_restaurant()
	_build_clothing_store()
	_build_bookshop()
	_build_riverside_walk()
	_build_scheduled_citizens()
	_build_activities()

func _build_extension_ground() -> void:
	_static_box("EastDistrictGround",Vector3(44,0.16,42),Vector3(37,-0.09,63),_mat(Color("777c6e"),0.98))
	_static_box("EastDistrictRoad",Vector3(9,0.10,42),Vector3(17,-0.02,63),_mat(Color("35393c"),0.98))
	_static_box("EastWalk",Vector3(3,0.12,42),Vector3(22.5,0.02,63),_mat(Color("aaa7a1"),0.92))
	for z in range(44,84,6):
		_box_mesh(Vector3(0.11,0.02,2.8),Vector3(17,0.04,float(z)),_mat(Color("e8e3c8"),0.76))

func _build_restaurant() -> void:
	var c = Vector3(31,0,47)
	_open_building("Restaurant",c,Vector3(14,4.0,12),Color("c6b49f"),Color("8b493d"),"CUMA KITCHEN")
	# warm wood floor strip and dining sets
	_static_box("RestaurantFloorWarm",Vector3(13.3,0.05,11.3),c+Vector3(0,0.08,0),_mat(Color("8d694d"),0.82))
	for x in [-3.5,0.0,3.5]:
		for z in [-1.8,2.0]:
			_table_set(c+Vector3(x,0,z))
	# kitchen pass, cookline and pendant lights
	_static_box("RestaurantPass",Vector3(9.0,1.05,0.65),c+Vector3(0,0.52,4.2),_mat(Color("473d37"),0.54))
	for x in [-3.2,-1.1,1.1,3.2]:
		_cylinder(c+Vector3(x,2.72,0.0),0.17,0.22,_emissive(Color("ffd5a1"),2.0))
		_cylinder(c+Vector3(x,3.15,0.0),0.025,0.70,_mat(Color("383b3e"),0.28,0.8))

func _build_clothing_store() -> void:
	var c = Vector3(47,0,47)
	_open_building("Clothing",c,Vector3(13,4.2,12),Color("d5d1cc"),Color("6a5f82"),"STUDIO WEAR")
	# racks with hanging silhouettes, fitting area and full mirror
	for x in [-3.2,0,3.2]:
		_cylinder(c+Vector3(x,1.35,0.6),0.035,2.7,_mat(Color("404347"),0.28,0.80),Vector3(0,0,90))
		for i in range(5):
			var col = [Color("435b78"),Color("9a6b61"),Color("5f7355"),Color("b79c76"),Color("343945")][i]
			_box_mesh(Vector3(0.46,0.78,0.10),c+Vector3(x-0.95+i*0.48,1.12,0.6),_mat(col,0.92))
	_box_mesh(Vector3(2.2,2.4,0.06),c+Vector3(4.4,1.35,4.5),_mirror())
	_static_box("FittingPartition",Vector3(3.0,2.6,0.12),c+Vector3(-4.7,1.3,3.3),_mat(Color("6b6470"),0.98))

func _build_bookshop() -> void:
	var c = Vector3(39,0,66)
	_open_building("BookCafe",c,Vector3(18,4.2,12),Color("bfb5a6"),Color("4e6c67"),"BOOK & COFFEE")
	for x in [-6.0,-2.0,2.0,6.0]:
		_static_box("BookShelf",Vector3(2.6,2.5,0.48),c+Vector3(x,1.25,4.6),_mat(Color("70523b"),0.80))
		for row in range(4):
			for col in range(5):
				_box_mesh(Vector3(0.28,0.36,0.16),c+Vector3(x-0.78+col*0.38,0.46+row*0.48,4.30),_mat(Color.from_hsv(fmod(float(row*5+col)*0.09,1.0),0.30,0.66),0.82))
	for x in [-4.0,0.0,4.0]:
		_table_set(c+Vector3(x,0,-1.2))

func _build_riverside_walk() -> void:
	# stylized canal edge gives the expanded district a destination and richer skyline.
	_static_box("Promenade",Vector3(44,0.14,7),Vector3(37,0.0,83),_mat(Color("9c9990"),0.92))
	_static_box("Canal",Vector3(44,0.06,11),Vector3(37,-0.10,92),_water())
	for x in range(25,57,5):
		_bench(Vector3(float(x),0.0,81.2))
		_tree(Vector3(float(x)+1.8,0.0,84.5))

func _build_scheduled_citizens() -> void:
	var sets = [
		[Vector3(27,0.05,73),Vector3(31,0.05,47),Vector3(38,0.05,82),Color("5c728e"),0.0],
		[Vector3(50,0.05,72),Vector3(47,0.05,47),Vector3(42,0.05,82),Color("8d636d"),0.4],
		[Vector3(31,0.05,72),Vector3(39,0.05,66),Vector3(32,0.05,82),Color("5f7c68"),0.9],
		[Vector3(53,0.05,69),Vector3(31,0.05,47),Vector3(48,0.05,82),Color("8e7656"),1.2],
		[Vector3(28,0.05,59),Vector3(47,0.05,47),Vector3(36,0.05,82),Color("6d5f88"),1.7],
		[Vector3(52,0.05,59),Vector3(39,0.05,66),Vector3(53,0.05,82),Color("4f737b"),2.1]
	]
	for i in range(sets.size()):
		var d = sets[i]
		var npc = Node3D.new()
		npc.name = "ScheduledCitizen_%02d" % i
		npc.set_script(ScheduledCitizen)
		root.add_child(npc)
		npc.setup(d[0],d[1],d[2],d[3],d[4])

func _build_activities() -> void:
	_pair("restaurant_dinner","Restoranda birlikte akşam yemeği",Vector3(31,0.9,47),24,1.25)
	_pair("coffee_and_book","Kitap-kahve molası",Vector3(39,0.9,65),18,0.75)
	_pair("outfit_day","Birlikte kıyafet seç",Vector3(47,0.9,47),18,0.6)
	_pair("promenade_walk","Su kenarında birlikte yürü",Vector3(37,0.9,82),22,1.0)
	_pair("rain_walk","Yağmurda şehir yürüyüşü",Vector3(29,0.9,82),26,0.75)
	_pair("city_breakfast","Şehirde kahvaltı yap",Vector3(34,0.9,48.5),20,0.8)
	_pair("book_pick","Birbirinize kitap seçin",Vector3(43,0.9,67),16,0.5)

func _open_building(prefix: String, c: Vector3, size: Vector3, wall_color: Color, accent: Color, title: String) -> void:
	var wall = _mat(wall_color,0.88)
	_static_box(prefix+"Floor",Vector3(size.x,0.14,size.z),c+Vector3(0,0.02,0),_mat(Color("8f877d"),0.88))
	_static_box(prefix+"Back",Vector3(size.x,size.y,0.22),c+Vector3(0,size.y*0.5,size.z*0.5),wall)
	_static_box(prefix+"Left",Vector3(0.22,size.y,size.z),c+Vector3(-size.x*0.5,size.y*0.5,0),wall)
	_static_box(prefix+"Right",Vector3(0.22,size.y,size.z),c+Vector3(size.x*0.5,size.y*0.5,0),wall)
	_static_box(prefix+"Roof",Vector3(size.x,0.18,size.z),c+Vector3(0,size.y,0),wall)
	_static_box(prefix+"FrontL",Vector3(1.0,size.y,0.20),c+Vector3(-size.x*0.5+0.5,size.y*0.5,-size.z*0.5),wall)
	_static_box(prefix+"FrontR",Vector3(1.0,size.y,0.20),c+Vector3(size.x*0.5-0.5,size.y*0.5,-size.z*0.5),wall)
	_box_mesh(Vector3(size.x-2.0,0.48,0.16),c+Vector3(0,size.y-0.38,-size.z*0.5-0.02),_emissive(accent,1.5))
	var label = Label3D.new(); label.text=title; label.position=c+Vector3(0,size.y-0.38,-size.z*0.5-0.14); label.font_size=34; label.outline_size=7; label.modulate=Color("f4eee4"); root.add_child(label)

func _table_set(pos: Vector3) -> void:
	_cylinder(pos+Vector3(0,0.72,0),0.65,0.10,_mat(Color("76543d"),0.78))
	_cylinder(pos+Vector3(0,0.35,0),0.045,0.68,_mat(Color("34373a"),0.32,0.75))
	for dx in [-1.0,1.0]:
		_static_box("Chair",Vector3(0.62,0.12,0.58),pos+Vector3(dx,0.48,0),_mat(Color("6d655f"),0.96))
		_static_box("ChairBack",Vector3(0.62,0.66,0.10),pos+Vector3(dx,0.82,0.24),_mat(Color("6d655f"),0.96))

func _bench(pos: Vector3) -> void:
	_static_box("BenchSeat",Vector3(2.0,0.12,0.5),pos+Vector3(0,0.5,0),_mat(Color("75543e"),0.84))
	_static_box("BenchBack",Vector3(2.0,0.65,0.1),pos+Vector3(0,0.88,0.28),_mat(Color("75543e"),0.84))

func _tree(pos: Vector3) -> void:
	_cylinder(pos+Vector3(0,1.2,0),0.16,2.4,_mat(Color("654936"),0.96))
	for o in [Vector3(0,2.6,0),Vector3(-0.55,2.35,0.10),Vector3(0.50,2.30,-0.12)]:
		_sphere(pos+o,Vector3(0.82,0.62,0.82),_mat(Color("4a6a4c"),0.99))

func _pair(id: String, title: String, pos: Vector3, points: int, hours: float) -> void:
	var body = StaticBody3D.new(); body.name="LifeDuo_"+id; body.position=pos; body.set_script(PairActivity); root.add_child(body); _collision_box(body,Vector3(1.35,1.55,1.35)); body.setup(id,title,points,hours)

func _static_box(name_value: String, size: Vector3, pos: Vector3, material: Material) -> StaticBody3D:
	var b=StaticBody3D.new(); b.name=name_value; b.position=pos; root.add_child(b); var m=MeshInstance3D.new(); var mesh=BoxMesh.new(); mesh.size=size; m.mesh=mesh; m.material_override=material; b.add_child(m); _collision_box(b,size); return b
func _box_mesh(size: Vector3,pos: Vector3,material: Material) -> MeshInstance3D:
	var n=MeshInstance3D.new(); var mesh=BoxMesh.new(); mesh.size=size; n.mesh=mesh; n.position=pos; n.material_override=material; root.add_child(n); return n
func _cylinder(pos: Vector3,radius: float,height: float,material: Material,rot: Vector3=Vector3.ZERO) -> MeshInstance3D:
	var n=MeshInstance3D.new(); var mesh=CylinderMesh.new(); mesh.top_radius=radius; mesh.bottom_radius=radius; mesh.height=height; mesh.radial_segments=18; n.mesh=mesh; n.position=pos; n.rotation_degrees=rot; n.material_override=material; root.add_child(n); return n
func _sphere(pos: Vector3,scale_value: Vector3,material: Material) -> MeshInstance3D:
	var n=MeshInstance3D.new(); var mesh=SphereMesh.new(); mesh.radius=0.5; mesh.height=1.0; n.mesh=mesh; n.position=pos; n.scale=scale_value*2.0; n.material_override=material; root.add_child(n); return n
func _collision_box(parent: Node3D,size: Vector3) -> void:
	var c=CollisionShape3D.new(); var s=BoxShape3D.new(); s.size=size; c.shape=s; parent.add_child(c)
func _mat(color: Color,rough: float=0.85,metal: float=0.0) -> StandardMaterial3D:
	var m=StandardMaterial3D.new(); m.albedo_color=color; m.roughness=rough; m.metallic=metal; return m
func _emissive(color: Color,energy: float) -> StandardMaterial3D:
	var m=_mat(color,0.35,0.05); m.emission_enabled=true; m.emission=color; m.emission_energy_multiplier=energy; return m
func _mirror() -> StandardMaterial3D:
	return _mat(Color("b8c3c9"),0.04,0.88)
func _water() -> StandardMaterial3D:
	var m=_mat(Color(0.18,0.43,0.54,0.72),0.08,0.16); m.transparency=BaseMaterial3D.TRANSPARENCY_ALPHA; return m
