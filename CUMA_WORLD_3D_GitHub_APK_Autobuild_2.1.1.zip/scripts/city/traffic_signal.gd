extends Node3D

@export var phase_offset = 0.0
var cycle_seconds = 18.0
var red_light: MeshInstance3D
var amber_light: MeshInstance3D
var green_light: MeshInstance3D
var state = "green"

func setup(offset: float = 0.0) -> void:
	phase_offset = offset
	add_to_group("traffic_signal")
	_build_signal()

func _process(_delta: float) -> void:
	var t = fmod(Time.get_ticks_msec() / 1000.0 + phase_offset, cycle_seconds)
	var next_state = "green"
	if t >= 9.0 and t < 11.0:
		next_state = "amber"
	elif t >= 11.0:
		next_state = "red"
	if next_state != state:
		state = next_state
		_refresh()

func is_red() -> bool:
	return state == "red"

func _build_signal() -> void:
	_box(Vector3(0.12,2.7,0.12),Vector3(0,1.35,0),_mat(Color("343638"),0.38,0.7))
	_box(Vector3(0.48,1.10,0.36),Vector3(0,2.45,0),_mat(Color("202225"),0.42,0.55))
	red_light = _lamp(Vector3(0,2.78,-0.20),Color("d73932"))
	amber_light = _lamp(Vector3(0,2.45,-0.20),Color("dfa637"))
	green_light = _lamp(Vector3(0,2.12,-0.20),Color("39b96c"))
	_refresh()

func _refresh() -> void:
	_set_lamp(red_light,state == "red",Color("d73932"))
	_set_lamp(amber_light,state == "amber",Color("dfa637"))
	_set_lamp(green_light,state == "green",Color("39b96c"))

func _set_lamp(node: MeshInstance3D, enabled: bool, color: Color) -> void:
	if node == null:
		return
	var mat = _mat(color if enabled else color.darkened(0.72),0.34,0.05)
	if enabled:
		mat.emission_enabled = true
		mat.emission = color
		mat.emission_energy_multiplier = 2.8
	node.material_override = mat

func _lamp(pos: Vector3, color: Color) -> MeshInstance3D:
	var node = MeshInstance3D.new()
	var mesh = SphereMesh.new()
	mesh.radius = 0.12
	mesh.height = 0.24
	node.mesh = mesh
	node.position = pos
	node.material_override = _mat(color,0.34,0.05)
	add_child(node)
	return node

func _box(size: Vector3, pos: Vector3, material: Material) -> void:
	var node = MeshInstance3D.new()
	var mesh = BoxMesh.new()
	mesh.size = size
	node.mesh = mesh
	node.position = pos
	node.material_override = material
	add_child(node)

func _mat(color: Color, roughness: float, metallic: float) -> StandardMaterial3D:
	var mat = StandardMaterial3D.new()
	mat.albedo_color = color
	mat.roughness = roughness
	mat.metallic = metallic
	return mat
