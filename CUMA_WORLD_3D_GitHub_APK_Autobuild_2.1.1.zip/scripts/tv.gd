extends StaticBody3D

var screen: MeshInstance3D
var is_on = false
var persistent_id = "tv"

func setup(size: Vector3) -> void:
	persistent_id = name
	add_to_group("persistent_world")
	var body_mesh = MeshInstance3D.new()
	var body = BoxMesh.new()
	body.size = size
	body_mesh.mesh = body
	var body_material = StandardMaterial3D.new()
	body_material.albedo_color = Color("0d0f13")
	body_material.roughness = 0.28
	body_mesh.material_override = body_material
	add_child(body_mesh)
	var collision = CollisionShape3D.new()
	var shape = BoxShape3D.new()
	shape.size = size
	collision.shape = shape
	add_child(collision)
	screen = MeshInstance3D.new()
	var panel = BoxMesh.new()
	panel.size = Vector3(size.x * 0.92, size.y * 0.86, 0.02)
	screen.mesh = panel
	screen.position.z = size.z * 0.5 + 0.012
	add_child(screen)
	_update_screen()
	_register_network()

func _register_network() -> void:
	var net = get_node_or_null("/root/NetworkManager")
	if net == null:
		return
	net.register_world_interactable(persistent_id, global_position, ["toggle"])
	if not net.world_action_received.is_connected(_on_world_action_received):
		net.world_action_received.connect(_on_world_action_received)

func get_interaction_label() -> String:
	return "TV'yi kapat" if is_on else "TV'yi aç"

func interact(actor: Node) -> void:
	var net = get_node_or_null("/root/NetworkManager")
	if net != null:
		net.request_world_action(persistent_id, "toggle")
	else:
		set_power(not is_on)
	if actor != null and actor.has_method("show_status"):
		actor.show_status("TV isteği gönderildi")

func _on_world_action_received(id: String, action: String) -> void:
	if id == persistent_id and action == "toggle":
		set_power(not is_on)

func set_power(value: bool) -> void:
	is_on = value
	_update_screen()

func _update_screen() -> void:
	if screen == null:
		return
	var material = StandardMaterial3D.new()
	material.roughness = 0.18
	if is_on:
		material.albedo_color = Color("244d77")
		material.emission_enabled = true
		material.emission = Color("357fc3")
		material.emission_energy_multiplier = 1.8
	else:
		material.albedo_color = Color("07090c")
	screen.material_override = material

func get_persistent_id() -> String:
	return persistent_id

func get_persistent_state() -> Dictionary:
	return {"on": is_on}

func apply_persistent_state(state: Variant) -> void:
	if state is Dictionary:
		set_power(bool(state.get("on", false)))
