extends StaticBody3D

var persistent_id = "bed"

func setup(id: String) -> void:
	persistent_id = id

func get_interaction_label() -> String:
	return "Uyu (8 saat)"

func interact(player: Node) -> void:
	var net = get_node_or_null("/root/NetworkManager")
	if net != null and net.is_online():
		if player != null and player.has_method("show_status"):
			player.show_status("Online oturumda zaman ortak etkinliklerle ilerler", 2.8)
		return
	var gs = get_node_or_null("/root/GameState")
	if gs != null:
		gs.advance_time(8.0)
	if player.has_method("restore_stamina"):
		player.restore_stamina()
	if player.has_method("show_status"):
		player.show_status("Dinlendin • saat ileri alındı", 2.5)
