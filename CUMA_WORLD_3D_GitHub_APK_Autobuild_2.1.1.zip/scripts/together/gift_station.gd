extends StaticBody3D

func get_interaction_label() -> String:
	return "Küçük sürpriz kutusu hazırla (35 TL)"

func interact(player: Node) -> void:
	var gs = get_node_or_null("/root/GameState")
	if gs == null:
		return
	if gs.spend_money(35):
		gs.add_item("surprise_box", 1)
		gs.add_memory("Sürpriz kutusu hazırlandı")
		if player != null and player.has_method("show_status"):
			player.show_status("Sürpriz kutusu envantere eklendi")
	else:
		if player != null and player.has_method("show_status"):
			player.show_status("35 TL gerekiyor")
