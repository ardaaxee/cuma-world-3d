extends StaticBody3D

func get_interaction_label() -> String:
	return "Ortak plan panosuna bak"

func interact(player: Node) -> void:
	var gs = get_node_or_null("/root/GameState")
	if gs == null:
		return
	var memory = "Henüz ortak anı yok"
	if gs.duo_memories.size() > 0:
		memory = str(gs.duo_memories[0])
	if player != null and player.has_method("show_status"):
		player.show_status("%s • %d puan • %s" % [gs.get_duo_rank(), gs.duo_points, memory], 4.0)
