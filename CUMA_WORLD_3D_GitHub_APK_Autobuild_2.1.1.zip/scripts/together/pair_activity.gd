extends StaticBody3D

var activity_id = ""
var title = "Birlikte etkinlik"
var points = 10
var time_cost = 0.25

func setup(id: String, display_title: String, reward_points: int = 10, hours: float = 0.25) -> void:
	activity_id = id
	title = display_title
	points = reward_points
	time_cost = hours
	# Production mode: interaction markers stay invisible. The real-world prop/location is the visual cue.
	for child in get_children():
		if child is GeometryInstance3D or child is Label3D:
			child.visible = false
	var net = get_node_or_null("/root/NetworkManager")
	if net != null and net.has_method("register_pair_activity"):
		net.register_pair_activity(activity_id, global_position, title, points, time_cost)

func get_interaction_label() -> String:
	return "BİRLİKTE • " + title

func interact(player: Node) -> void:
	var net = get_node_or_null("/root/NetworkManager")
	if net == null or not net.has_method("request_pair_activity"):
		return
	if not net.is_online():
		if player != null and player.has_method("show_status"):
			player.show_status("Bu etkinlik için TOGETHER menüsünden HOST/JOIN yapın", 3.0)
		return
	if net.get_peer_count() < 2:
		if player != null and player.has_method("show_status"):
			player.show_status("Partnerin bağlanması bekleniyor", 2.4)
		return
	net.request_pair_activity(activity_id)
	if player != null and player.has_method("show_status"):
		player.show_status("Hazırsın • partnerin de USE yapsın", 2.6)
