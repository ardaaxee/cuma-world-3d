extends MeshInstance3D

var palette = [Color("6f5666"), Color("385c66"), Color("6b5b3f"), Color("4e5c43")]

func _ready() -> void:
	add_to_group("decor_accent")
	var gs = get_node_or_null("/root/GameState")
	if gs != null:
		apply_decor_preset(int(gs.decor_preset))
		if not gs.state_changed.is_connected(_on_state_changed):
			gs.state_changed.connect(_on_state_changed)

func _on_state_changed() -> void:
	var gs = get_node_or_null("/root/GameState")
	if gs != null:
		apply_decor_preset(int(gs.decor_preset))

func apply_decor_preset(index: int) -> void:
	var mat = StandardMaterial3D.new()
	mat.albedo_color = palette[index % palette.size()]
	mat.roughness = 0.72
	material_override = mat
