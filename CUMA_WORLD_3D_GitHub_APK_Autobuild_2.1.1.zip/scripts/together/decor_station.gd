extends StaticBody3D

const PERSISTENT_ID := "shared_decor"

func _ready() -> void:
	var net = get_node_or_null("/root/NetworkManager")
	if net != null:
		net.register_world_interactable(PERSISTENT_ID, global_position, ["next"])
		if not net.world_action_received.is_connected(_on_world_action_received):
			net.world_action_received.connect(_on_world_action_received)

func get_interaction_label() -> String:
	return "Ortak dekor temasını değiştir"

func interact(player: Node) -> void:
	var net = get_node_or_null("/root/NetworkManager")
	if net != null:
		net.request_world_action(PERSISTENT_ID, "next")
	else:
		_apply_next()
	if player != null and player.has_method("show_status"):
		player.show_status("Dekor değişikliği gönderildi")

func _on_world_action_received(id: String, action: String) -> void:
	if id == PERSISTENT_ID and action == "next":
		_apply_next()

func _apply_next() -> void:
	var gs = get_node_or_null("/root/GameState")
	if gs == null:
		return
	var preset = gs.cycle_decor_preset()
	for node in get_tree().get_nodes_in_group("decor_accent"):
		if node.has_method("apply_decor_preset"):
			node.apply_decor_preset(preset)
