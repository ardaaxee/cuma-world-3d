extends Node3D

const ProceduralHumanoidScript = preload("res://scripts/character/procedural_humanoid.gd")
const ImportedCharacterBridge = preload("res://scripts/imported_character_bridge.gd")

var peer_id = 0
var target_transform = Transform3D.IDENTITY
var has_target = false
var rig
var imported_bridge
var last_position = Vector3.ZERO
var speed = 0.0

func setup(id: int, display_name: String = "Partner") -> void:
	peer_id = id
	name = "RemotePlayer_%d" % id
	_build_visual(display_name)
	last_position = global_position

func _process(delta: float) -> void:
	if has_target:
		global_transform = global_transform.interpolate_with(target_transform, min(1.0, delta * 11.0))
		speed = last_position.distance_to(global_position) / max(delta, 0.001)
		last_position = global_position
	if rig != null and rig.has_method("update_pose"):
		rig.update_pose(delta, speed, speed > 5.3, 0.0, true, false, 0.0)
	if imported_bridge != null and imported_bridge.has_method("update_state"):
		imported_bridge.update_state(speed, speed > 5.3, true, 0.0, false)

func set_network_transform(value: Transform3D) -> void:
	target_transform = value
	if not has_target:
		global_transform = value
		has_target = true
		last_position = global_position

func play_emote(emote: String) -> void:
	if rig != null and rig.has_method("play_emote"):
		rig.play_emote(emote)
	if imported_bridge != null and imported_bridge.has_method("play_emote"):
		imported_bridge.play_emote(emote)

func _build_visual(display_name: String) -> void:
	if FileAccess.file_exists("res://assets/characters/partner.glb"):
		var resource = load("res://assets/characters/partner.glb")
		if resource is PackedScene:
			var imported = resource.instantiate()
			imported.name = "ImportedPartnerGLB"
			add_child(imported)
			imported_bridge = Node.new()
			imported_bridge.set_script(ImportedCharacterBridge)
			add_child(imported_bridge)
			imported_bridge.setup(imported)
			if imported_bridge.available:
				_add_name_label(display_name)
				return
			imported.queue_free()
			imported_bridge.queue_free()
			imported_bridge = null

	rig = Node3D.new()
	rig.name = "PartnerOrganicRig"
	rig.set_script(ProceduralHumanoidScript)
	add_child(rig)
	rig.setup({
		"skin": Color("d7aa88"),
		"top": Color("6b4961"),
		"pants": Color("302a38"),
		"hair": Color("2c2020"),
		"shoes": Color("121316"),
		"height_scale": 0.97,
		"shoulder_scale": 0.94,
		"label": display_name
	})

func _add_name_label(display_name: String) -> void:
	var label = Label3D.new()
	label.text = display_name.left(24)
	label.position = Vector3(0.0, 2.65, 0.0)
	label.font_size = 28
	label.outline_size = 7
	label.billboard = BaseMaterial3D.BILLBOARD_ENABLED
	add_child(label)
