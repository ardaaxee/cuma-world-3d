extends StaticBody3D

var item_id = "item"
var display_name = "Eşya"
var taken = false
var persistent_id = "pickup"

func setup(id: String, label: String, pid: String) -> void:
	item_id = id
	display_name = label
	persistent_id = pid
	add_to_group("persistent_world")

func get_interaction_label() -> String:
	return "" if taken else display_name + " al"

func interact(player: Node) -> void:
	if taken:
		return
	taken = true
	visible = false
	var shape = get_node_or_null("CollisionShape3D")
	if shape != null:
		shape.disabled = true
	var gs = get_node_or_null("/root/GameState")
	if gs != null:
		gs.add_item(item_id, 1)
	if player.has_method("show_status"):
		player.show_status(display_name + " envantere eklendi")

func get_persistent_id() -> String:
	return persistent_id

func get_persistent_state() -> Dictionary:
	return {"taken": taken}

func apply_persistent_state(state: Variant) -> void:
	if state is Dictionary:
		taken = bool(state.get("taken", false))
		visible = not taken
		var shape = get_node_or_null("CollisionShape3D")
		if shape != null:
			shape.disabled = taken
