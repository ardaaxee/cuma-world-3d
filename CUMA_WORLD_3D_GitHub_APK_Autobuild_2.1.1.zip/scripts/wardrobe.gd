extends StaticBody3D

func get_interaction_label() -> String:
	return "Kıyafeti değiştir"

func interact(player: Node) -> void:
	if player.has_method("cycle_outfit"):
		player.cycle_outfit()
