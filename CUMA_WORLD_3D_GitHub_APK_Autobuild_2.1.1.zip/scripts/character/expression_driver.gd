extends Node

# Lightweight face/attention layer used by procedural and imported characters.
# It deliberately avoids camera-facing billboard expressions; the head reacts to world context.
var mood = "neutral"
var mood_until = 0
var attention_target: Node3D
var look_weight = 0.0
var smile_weight = 0.0
var surprise_weight = 0.0

func set_mood(value: String, duration_ms: int = 1800) -> void:
	var clean = value.to_lower()
	if clean not in ["neutral", "happy", "excited", "curious"]:
		return
	mood = clean
	mood_until = Time.get_ticks_msec() + clamp(duration_ms, 200, 6000)

func set_attention_target(value: Node3D) -> void:
	attention_target = value

func update_expression(delta: float) -> Dictionary:
	if Time.get_ticks_msec() > mood_until:
		mood = "neutral"
	var target_smile = 0.0
	var target_surprise = 0.0
	match mood:
		"happy": target_smile = 0.75
		"excited":
			target_smile = 0.85
			target_surprise = 0.22
		"curious": target_surprise = 0.15
	smile_weight = lerp(smile_weight, target_smile, min(1.0, delta * 5.0))
	surprise_weight = lerp(surprise_weight, target_surprise, min(1.0, delta * 5.0))
	look_weight = lerp(look_weight, 1.0 if is_instance_valid(attention_target) else 0.0, min(1.0, delta * 4.0))
	return {"smile": smile_weight, "surprise": surprise_weight, "look_weight": look_weight}
