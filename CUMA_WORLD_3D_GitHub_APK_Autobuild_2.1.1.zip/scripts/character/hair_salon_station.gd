extends StaticBody3D

var price = 30

func get_interaction_label() -> String:
	return "SAÇ STİLİ DEĞİŞTİR • ₺%d" % price

func interact(player: Node) -> void:
	var gs = get_node_or_null("/root/GameState")
	if gs == null:
		return
	if not gs.spend_money(price):
		if player != null and player.has_method("show_status"): player.show_status("Yeterli paran yok", 2.0)
		return
	if gs.has_method("cycle_hair_style"):
		gs.cycle_hair_style()
	if player != null and player.has_method("apply_saved_customization"):
		player.apply_saved_customization()
	if gs.has_method("add_daily_life_event"):
		gs.add_daily_life_event("style", "Yeni saç stili: %s" % gs.get_hair_style_name())
	if player != null and player.has_method("show_status"):
		player.show_status("Yeni saç stili • %s" % gs.get_hair_style_name(), 2.2)
