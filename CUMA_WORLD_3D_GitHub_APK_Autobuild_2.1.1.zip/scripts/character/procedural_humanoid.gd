extends Node3D
class_name ProceduralHumanoid

var profile: Dictionary = {}
var time_alive = 0.0
var gait_phase = 0.0
var blink_clock = 0.0
var next_blink = 2.8
var blink_amount = 0.0
var emote_name = ""
var emote_until = 0

var body_root: Node3D
var pelvis: Node3D
var spine: Node3D
var chest: Node3D
var neck: Node3D
var head: Node3D
var left_shoulder: Node3D
var right_shoulder: Node3D
var left_elbow: Node3D
var right_elbow: Node3D
var left_hip: Node3D
var right_hip: Node3D
var left_knee: Node3D
var right_knee: Node3D
var left_foot: Node3D
var right_foot: Node3D
var eye_l: MeshInstance3D
var eye_r: MeshInstance3D
var mouth: MeshInstance3D
var brow_l: MeshInstance3D
var brow_r: MeshInstance3D
var mood = "neutral"
var mood_until = 0
var smile_weight = 0.0
var chest_mesh: MeshInstance3D
var shirt_meshes: Array[MeshInstance3D] = []
var activity_pose = ""

func setup(character_profile: Dictionary = {}) -> void:
	profile = {
		"skin": Color("d3a17f"),
		"top": Color("263653"),
		"pants": Color("20293a"),
		"hair": Color("171819"),
		"shoes": Color("101216"),
		"height_scale": 1.0,
		"shoulder_scale": 1.0,
		"label": ""
	}
	for key in character_profile.keys():
		profile[key] = character_profile[key]
	_build_rig()

func _build_rig() -> void:
	body_root = Node3D.new()
	body_root.name = "OrganicCharacterRig"
	body_root.scale = Vector3.ONE * float(profile.get("height_scale", 1.0))
	add_child(body_root)

	pelvis = _pivot(body_root, "Pelvis", Vector3(0.0, 0.91, 0.0))
	spine = _pivot(pelvis, "Spine", Vector3(0.0, 0.28, 0.0))
	chest = _pivot(spine, "Chest", Vector3(0.0, 0.30, 0.0))
	neck = _pivot(chest, "Neck", Vector3(0.0, 0.37, 0.0))
	head = _pivot(neck, "Head", Vector3(0.0, 0.18, 0.0))

	var skin: Color = profile["skin"]
	var top: Color = profile["top"]
	var pants: Color = profile["pants"]
	var hair: Color = profile["hair"]
	var shoes: Color = profile["shoes"]
	var shoulder_scale = float(profile.get("shoulder_scale", 1.0))

	_sphere(pelvis, "PelvisForm", Vector3.ZERO, Vector3(0.235, 0.18, 0.19), pants, 0.90)
	_sphere(spine, "Waist", Vector3(0.0, 0.04, 0.0), Vector3(0.235, 0.27, 0.18), top.darkened(0.08), 0.92)
	chest_mesh = _sphere(chest, "ChestForm", Vector3(0.0, 0.05, 0.0), Vector3(0.285 * shoulder_scale, 0.30, 0.19), top, 0.90)
	shirt_meshes.append(chest_mesh)
	shirt_meshes.append(_sphere(chest, "UpperChest", Vector3(0.0, 0.19, 0.0), Vector3(0.28 * shoulder_scale, 0.16, 0.185), top.lightened(0.025), 0.90))
	_capsule(neck, "NeckMesh", Vector3(0.0, -0.01, 0.0), 0.082, 0.18, skin, 0.91)
	_sphere(head, "HeadMesh", Vector3(0.0, 0.055, 0.0), Vector3(0.175, 0.225, 0.17), skin, 0.91)
	_sphere(head, "Jaw", Vector3(0.0, -0.045, -0.020), Vector3(0.155, 0.13, 0.155), skin.darkened(0.015), 0.91)

	# Layered hair reads as a hairstyle rather than a helmet from gameplay distance.
	_sphere(head, "HairCrown", Vector3(0.0, 0.225, 0.018), Vector3(0.185, 0.095, 0.175), hair, 0.96)
	_sphere(head, "HairBack", Vector3(0.0, 0.13, 0.145), Vector3(0.18, 0.13, 0.075), hair.darkened(0.03), 0.96)
	for x in [-0.13, -0.065, 0.0, 0.065, 0.13]:
		_sphere(head, "HairStrand", Vector3(x, 0.198 + abs(x) * 0.10, -0.148), Vector3(0.040, 0.075, 0.034), hair, 0.96)

	eye_l = _sphere(head, "EyeL", Vector3(-0.067, 0.080, -0.188), Vector3(0.016, 0.020, 0.009), Color("211f1e"), 0.55)
	eye_r = _sphere(head, "EyeR", Vector3(0.067, 0.080, -0.188), Vector3(0.016, 0.020, 0.009), Color("211f1e"), 0.55)
	_sphere(head, "Nose", Vector3(0.0, 0.032, -0.203), Vector3(0.020, 0.034, 0.020), skin.darkened(0.035), 0.90)
	mouth = _capsule(head, "Mouth", Vector3(0.0, -0.050, -0.197), 0.008, 0.052, Color("7f4e4d"), 0.92, Vector3(0.0, 0.0, 90.0), Vector3(1.0, 1.0, 0.30))
	brow_l = _capsule(head, "BrowL", Vector3(-0.086, 0.160, -0.242), 0.009, 0.075, hair.darkened(0.08), 0.96, Vector3(0.0, 0.0, 90.0), Vector3(1.0,1.0,0.42))
	brow_r = _capsule(head, "BrowR", Vector3(0.086, 0.160, -0.242), 0.009, 0.075, hair.darkened(0.08), 0.96, Vector3(0.0, 0.0, 90.0), Vector3(1.0,1.0,0.42))

	var shoulder_x = 0.305 * shoulder_scale
	left_shoulder = _pivot(chest, "LeftShoulder", Vector3(-shoulder_x, 0.18, 0.0))
	right_shoulder = _pivot(chest, "RightShoulder", Vector3(shoulder_x, 0.18, 0.0))
	left_elbow = _build_arm(left_shoulder, "Left", top, skin)
	right_elbow = _build_arm(right_shoulder, "Right", top, skin)

	left_hip = _pivot(pelvis, "LeftHip", Vector3(-0.125, -0.10, 0.0))
	right_hip = _pivot(pelvis, "RightHip", Vector3(0.125, -0.10, 0.0))
	left_knee = _build_leg(left_hip, "Left", pants, shoes)
	right_knee = _build_leg(right_hip, "Right", pants, shoes)
	left_foot = left_knee.get_node("Foot") as Node3D
	right_foot = right_knee.get_node("Foot") as Node3D

	var label_text = str(profile.get("label", ""))
	if not label_text.is_empty():
		var label = Label3D.new()
		label.text = label_text.left(24)
		label.position = Vector3(0.0, 2.25, 0.0)
		label.font_size = 28
		label.outline_size = 6
		label.billboard = BaseMaterial3D.BILLBOARD_ENABLED
		add_child(label)

func _build_arm(shoulder: Node3D, side: String, top: Color, skin: Color) -> Node3D:
	_capsule(shoulder, side + "UpperArm", Vector3(0.0, -0.17, 0.0), 0.058, 0.36, top, 0.91)
	var elbow = _pivot(shoulder, side + "Elbow", Vector3(0.0, -0.34, 0.0))
	_capsule(elbow, side + "Forearm", Vector3(0.0, -0.155, 0.0), 0.052, 0.33, skin, 0.91)
	_sphere(elbow, side + "Hand", Vector3(0.0, -0.34, -0.01), Vector3(0.058, 0.086, 0.044), skin, 0.91)
	return elbow

func _build_leg(hip: Node3D, side: String, pants: Color, shoes: Color) -> Node3D:
	_capsule(hip, side + "Thigh", Vector3(0.0, -0.235, 0.0), 0.074, 0.50, pants, 0.94)
	var knee = _pivot(hip, side + "Knee", Vector3(0.0, -0.47, 0.0))
	_capsule(knee, side + "Shin", Vector3(0.0, -0.22, 0.0), 0.062, 0.46, pants.darkened(0.12), 0.94)
	var foot = _pivot(knee, "Foot", Vector3(0.0, -0.45, -0.050))
	_capsule(foot, side + "Shoe", Vector3(0.0, 0.0, -0.075), 0.071, 0.27, shoes, 0.76, Vector3(90.0, 0.0, 0.0), Vector3(1.10, 1.0, 0.88))
	return knee

func update_pose(delta: float, horizontal_speed: float, running: bool, vertical_velocity: float, grounded: bool, sitting: bool, look_pitch: float = 0.0) -> void:
	if body_root == null:
		return
	time_alive += delta
	_update_blink(delta)
	_update_expression(delta)
	var blend = min(1.0, delta * 10.0)
	var moving = horizontal_speed > 0.18 and grounded and not sitting
	var run_blend = clamp((horizontal_speed - 3.2) / 3.8, 0.0, 1.0) if running else 0.0

	# Human idle is never perfectly frozen: breathing + tiny weight shift.
	var breath = sin(time_alive * 1.75) * 0.012
	chest.scale.y = lerp(chest.scale.y, 1.0 + breath, min(1.0, delta * 4.0))
	pelvis.position.x = lerp(pelvis.position.x, sin(time_alive * 0.72) * 0.010 if not moving else 0.0, blend)
	head.rotation.x = lerp_angle(head.rotation.x, clamp(look_pitch * 0.23, -0.16, 0.14), min(1.0, delta * 6.0))

	if sitting:
		_pose_sit(delta)
	elif not grounded:
		_pose_air(delta, vertical_velocity)
	elif moving:
		_pose_locomotion(delta, horizontal_speed, run_blend)
	else:
		_pose_idle(delta)

	_apply_activity_pose(delta, moving, sitting)
	_update_emote(delta)

func _pose_idle(delta: float) -> void:
	var t = min(1.0, delta * 7.0)
	left_shoulder.rotation = left_shoulder.rotation.lerp(Vector3(0.0, 0.0, 0.035), t)
	right_shoulder.rotation = right_shoulder.rotation.lerp(Vector3(0.0, 0.0, -0.035), t)
	left_elbow.rotation.x = lerp_angle(left_elbow.rotation.x, -0.08, t)
	right_elbow.rotation.x = lerp_angle(right_elbow.rotation.x, -0.08, t)
	left_hip.rotation.x = lerp_angle(left_hip.rotation.x, 0.0, t)
	right_hip.rotation.x = lerp_angle(right_hip.rotation.x, 0.0, t)
	left_knee.rotation.x = lerp_angle(left_knee.rotation.x, 0.04, t)
	right_knee.rotation.x = lerp_angle(right_knee.rotation.x, 0.04, t)
	left_foot.rotation.x = lerp_angle(left_foot.rotation.x, 0.0, t)
	right_foot.rotation.x = lerp_angle(right_foot.rotation.x, 0.0, t)
	spine.rotation.y = lerp_angle(spine.rotation.y, sin(time_alive * 0.62) * 0.012, t)
	body_root.position.y = lerp(body_root.position.y, 0.0, t)

func _pose_locomotion(delta: float, speed: float, run_blend: float) -> void:
	var cadence = lerp(7.0, 11.5, run_blend)
	gait_phase += delta * cadence * clamp(speed / 4.4, 0.75, 1.25)
	var s = sin(gait_phase)
	var c = cos(gait_phase)
	var hip_amp = lerp(0.48, 0.78, run_blend)
	var arm_amp = lerp(0.52, 0.92, run_blend)
	var knee_l = max(0.0, -s) * lerp(0.62, 1.02, run_blend)
	var knee_r = max(0.0, s) * lerp(0.62, 1.02, run_blend)
	var t = min(1.0, delta * 14.0)

	left_hip.rotation.x = lerp_angle(left_hip.rotation.x, s * hip_amp, t)
	right_hip.rotation.x = lerp_angle(right_hip.rotation.x, -s * hip_amp, t)
	left_knee.rotation.x = lerp_angle(left_knee.rotation.x, knee_l, t)
	right_knee.rotation.x = lerp_angle(right_knee.rotation.x, knee_r, t)
	left_foot.rotation.x = lerp_angle(left_foot.rotation.x, -s * 0.14 - knee_l * 0.28, t)
	right_foot.rotation.x = lerp_angle(right_foot.rotation.x, s * 0.14 - knee_r * 0.28, t)
	left_shoulder.rotation.x = lerp_angle(left_shoulder.rotation.x, -s * arm_amp, t)
	right_shoulder.rotation.x = lerp_angle(right_shoulder.rotation.x, s * arm_amp, t)
	left_elbow.rotation.x = lerp_angle(left_elbow.rotation.x, -0.16 - max(0.0, s) * 0.28 * run_blend, t)
	right_elbow.rotation.x = lerp_angle(right_elbow.rotation.x, -0.16 - max(0.0, -s) * 0.28 * run_blend, t)
	spine.rotation.y = lerp_angle(spine.rotation.y, -s * lerp(0.07, 0.13, run_blend), t)
	spine.rotation.z = lerp_angle(spine.rotation.z, c * lerp(0.018, 0.032, run_blend), t)
	var bob = abs(sin(gait_phase * 2.0)) * lerp(0.018, 0.045, run_blend)
	body_root.position.y = lerp(body_root.position.y, bob, t)

func _pose_air(delta: float, vertical_velocity: float) -> void:
	var t = min(1.0, delta * 9.0)
	var rising = vertical_velocity > 0.0
	var hip_target = -0.22 if rising else 0.18
	left_hip.rotation.x = lerp_angle(left_hip.rotation.x, hip_target, t)
	right_hip.rotation.x = lerp_angle(right_hip.rotation.x, -hip_target * 0.55, t)
	left_knee.rotation.x = lerp_angle(left_knee.rotation.x, 0.45, t)
	right_knee.rotation.x = lerp_angle(right_knee.rotation.x, 0.36, t)
	left_shoulder.rotation.x = lerp_angle(left_shoulder.rotation.x, -0.22, t)
	right_shoulder.rotation.x = lerp_angle(right_shoulder.rotation.x, -0.22, t)
	left_shoulder.rotation.z = lerp_angle(left_shoulder.rotation.z, 0.20, t)
	right_shoulder.rotation.z = lerp_angle(right_shoulder.rotation.z, -0.20, t)
	body_root.position.y = lerp(body_root.position.y, 0.0, t)

func _pose_sit(delta: float) -> void:
	var t = min(1.0, delta * 9.0)
	left_hip.rotation.x = lerp_angle(left_hip.rotation.x, -1.42, t)
	right_hip.rotation.x = lerp_angle(right_hip.rotation.x, -1.42, t)
	left_knee.rotation.x = lerp_angle(left_knee.rotation.x, 1.48, t)
	right_knee.rotation.x = lerp_angle(right_knee.rotation.x, 1.48, t)
	left_foot.rotation.x = lerp_angle(left_foot.rotation.x, -0.06, t)
	right_foot.rotation.x = lerp_angle(right_foot.rotation.x, -0.06, t)
	left_shoulder.rotation.x = lerp_angle(left_shoulder.rotation.x, -0.12, t)
	right_shoulder.rotation.x = lerp_angle(right_shoulder.rotation.x, -0.12, t)
	left_elbow.rotation.x = lerp_angle(left_elbow.rotation.x, -0.42, t)
	right_elbow.rotation.x = lerp_angle(right_elbow.rotation.x, -0.42, t)
	spine.rotation.x = lerp_angle(spine.rotation.x, 0.06, t)
	body_root.position.y = lerp(body_root.position.y, -0.38, t)

func set_activity_pose(value: String) -> void:
	var clean = value.to_lower()
	activity_pose = clean if clean in ["", "exercise", "work", "eat", "phone"] else ""

func _apply_activity_pose(delta: float, moving: bool, sitting: bool) -> void:
	if moving or sitting or activity_pose.is_empty():
		return
	var t = min(1.0, delta * 10.0)
	match activity_pose:
		"exercise":
			var pump = sin(time_alive * 5.4)
			left_shoulder.rotation.x = lerp_angle(left_shoulder.rotation.x, -0.65 + pump * 0.42, t)
			right_shoulder.rotation.x = lerp_angle(right_shoulder.rotation.x, -0.65 - pump * 0.42, t)
			left_elbow.rotation.x = lerp_angle(left_elbow.rotation.x, -0.85 - pump * 0.35, t)
			right_elbow.rotation.x = lerp_angle(right_elbow.rotation.x, -0.85 + pump * 0.35, t)
			left_knee.rotation.x = lerp_angle(left_knee.rotation.x, 0.16 + abs(pump) * 0.15, t)
			right_knee.rotation.x = lerp_angle(right_knee.rotation.x, 0.16 + abs(pump) * 0.15, t)
		"work":
			left_elbow.rotation.x = lerp_angle(left_elbow.rotation.x, -0.55, t)
			right_elbow.rotation.x = lerp_angle(right_elbow.rotation.x, -0.62, t)
			spine.rotation.x = lerp_angle(spine.rotation.x, 0.05, t)
		"eat":
			right_shoulder.rotation.x = lerp_angle(right_shoulder.rotation.x, -0.65, t)
			right_elbow.rotation.x = lerp_angle(right_elbow.rotation.x, -1.05 + sin(time_alive * 3.2) * 0.12, t)
		"phone":
			right_shoulder.rotation.x = lerp_angle(right_shoulder.rotation.x, -0.78, t)
			right_elbow.rotation.x = lerp_angle(right_elbow.rotation.x, -1.18, t)

func apply_hair_style(style: int) -> void:
	if head == null:
		return
	var clean = clamp(style, 0, 3)
	var crown = head.get_node_or_null("HairCrown")
	var back = head.get_node_or_null("HairBack")
	if crown is Node3D:
		crown.visible = true
	if back is Node3D:
		back.visible = clean in [0, 2, 3]
	var strands = head.find_children("HairStrand*", "MeshInstance3D", true, false)
	for i in range(strands.size()):
		var strand = strands[i] as MeshInstance3D
		if strand == null:
			continue
		match clean:
			1: strand.visible = i in [1, 2, 3]
			2: strand.visible = i % 2 == 0
			3: strand.visible = i in [0, 4]
			_: strand.visible = true

func play_emote(emote: String) -> void:
	if emote not in ["wave", "cheer", "highfive"]:
		return
	emote_name = emote
	emote_until = Time.get_ticks_msec() + 1400
	set_mood("excited" if emote == "cheer" else "happy", 1800)

func set_mood(value: String, duration_ms: int = 1800) -> void:
	var clean = value.to_lower()
	if clean not in ["neutral", "happy", "excited", "curious"]:
		return
	mood = clean
	mood_until = Time.get_ticks_msec() + clamp(duration_ms, 200, 6000)

func _update_expression(delta: float) -> void:
	if Time.get_ticks_msec() > mood_until:
		mood = "neutral"
	var target_smile = 0.0
	if mood == "happy": target_smile = 0.65
	elif mood == "excited": target_smile = 0.90
	elif mood == "curious": target_smile = 0.18
	smile_weight = lerp(smile_weight, target_smile, min(1.0, delta * 5.0))
	if mouth != null:
		mouth.position.y = -0.055 + smile_weight * 0.012
		mouth.scale.x = 1.0 + smile_weight * 0.18
	if brow_l != null:
		brow_l.rotation.z = deg_to_rad(90.0 - smile_weight * 7.0)
	if brow_r != null:
		brow_r.rotation.z = deg_to_rad(90.0 + smile_weight * 7.0)

func _update_emote(delta: float) -> void:
	if Time.get_ticks_msec() >= emote_until:
		emote_name = ""
		left_shoulder.rotation.z = lerp_angle(left_shoulder.rotation.z, 0.035, min(1.0, delta * 9.0))
		right_shoulder.rotation.z = lerp_angle(right_shoulder.rotation.z, -0.035, min(1.0, delta * 9.0))
		return
	match emote_name:
		"wave":
			right_shoulder.rotation.x = lerp_angle(right_shoulder.rotation.x, -1.15, min(1.0, delta * 12.0))
			right_shoulder.rotation.z = lerp_angle(right_shoulder.rotation.z, -1.05, min(1.0, delta * 12.0))
			right_elbow.rotation.x = -0.75 + sin(time_alive * 13.0) * 0.25
		"cheer":
			left_shoulder.rotation.z = lerp_angle(left_shoulder.rotation.z, 2.45, min(1.0, delta * 12.0))
			right_shoulder.rotation.z = lerp_angle(right_shoulder.rotation.z, -2.45, min(1.0, delta * 12.0))
		"highfive":
			right_shoulder.rotation.x = lerp_angle(right_shoulder.rotation.x, -1.65, min(1.0, delta * 12.0))
			right_elbow.rotation.x = lerp_angle(right_elbow.rotation.x, -0.18, min(1.0, delta * 12.0))

func _update_blink(delta: float) -> void:
	blink_clock += delta
	if blink_clock >= next_blink:
		blink_clock = 0.0
		next_blink = randf_range(2.2, 5.2)
		blink_amount = 1.0
	blink_amount = max(0.0, blink_amount - delta * 6.5)
	var closed = sin(blink_amount * PI) if blink_amount > 0.0 else 0.0
	var eye_y = lerp(0.056, 0.006, clamp(closed, 0.0, 1.0))
	if eye_l != null:
		eye_l.scale.y = eye_y
	if eye_r != null:
		eye_r.scale.y = eye_y


func apply_palette(values: Dictionary) -> void:
	if values.has("top"):
		profile["top"] = values["top"]
		for mesh in shirt_meshes:
			if is_instance_valid(mesh):
				mesh.material_override = _material(profile["top"], 0.90)
	if values.has("pants"):
		profile["pants"] = values["pants"]
		for node in body_root.find_children("*Thigh", "MeshInstance3D", true, false) + body_root.find_children("*Shin", "MeshInstance3D", true, false):
			if node is MeshInstance3D:
				node.material_override = _material(profile["pants"], 0.94)
	if values.has("hair"):
		profile["hair"] = values["hair"]
		for node in head.find_children("Hair*", "MeshInstance3D", true, false):
			if node is MeshInstance3D:
				node.material_override = _material(profile["hair"], 0.96)

func cycle_outfit() -> void:
	var palette = [Color("263653"), Color("4a2c3d"), Color("285447"), Color("5a4a2a"), Color("34343a")]
	var current: Color = profile["top"]
	var index = palette.find(current)
	index = (index + 1) % palette.size()
	profile["top"] = palette[index]
	for mesh in shirt_meshes:
		if is_instance_valid(mesh):
			mesh.material_override = _material(palette[index], 0.90)

func _pivot(parent: Node3D, node_name: String, pos: Vector3) -> Node3D:
	var node = Node3D.new()
	node.name = node_name
	node.position = pos
	parent.add_child(node)
	return node

func _sphere(parent: Node3D, node_name: String, pos: Vector3, scale_value: Vector3, color: Color, roughness: float) -> MeshInstance3D:
	var mi = MeshInstance3D.new()
	mi.name = node_name
	var mesh = SphereMesh.new()
	mesh.radius = 0.5
	mesh.height = 1.0
	mesh.radial_segments = 24
	mesh.rings = 12
	mi.mesh = mesh
	mi.position = pos
	mi.scale = scale_value * 2.0
	mi.material_override = _material(color, roughness)
	parent.add_child(mi)
	return mi

func _capsule(parent: Node3D, node_name: String, pos: Vector3, radius: float, height: float, color: Color, roughness: float, rot_deg: Vector3 = Vector3.ZERO, scale_value: Vector3 = Vector3.ONE) -> MeshInstance3D:
	var mi = MeshInstance3D.new()
	mi.name = node_name
	var mesh = CapsuleMesh.new()
	mesh.radius = radius
	mesh.height = max(height, radius * 2.05)
	mesh.radial_segments = 20
	mesh.rings = 8
	mi.mesh = mesh
	mi.position = pos
	mi.rotation_degrees = rot_deg
	mi.scale = scale_value
	mi.material_override = _material(color, roughness)
	parent.add_child(mi)
	return mi

func _material(color: Color, roughness: float) -> StandardMaterial3D:
	var mat = StandardMaterial3D.new()
	mat.albedo_color = color
	mat.roughness = roughness
	return mat
