extends StaticBody3D

func get_interaction_label() -> String:
	return "Karakter görünümünü değiştir"

func interact(player: Node) -> void:
	var gs = get_node_or_null("/root/GameState")
	if gs == null:
		return
	gs.cycle_character_style()
	if player.has_method("apply_saved_customization"):
		player.apply_saved_customization()
	player.show_status("Karakter stili • " + gs.get_character_style_name())
