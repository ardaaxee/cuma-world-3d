extends StaticBody3D

func setup() -> void:
	var base_mesh = MeshInstance3D.new()
	var cylinder = CylinderMesh.new()
	cylinder.top_radius = 0.42
	cylinder.bottom_radius = 0.48
	cylinder.height = 0.14
	base_mesh.mesh = cylinder
	var mat = StandardMaterial3D.new()
	mat.albedo_color = Color("20252d")
	mat.metallic = 0.25
	mat.roughness = 0.42
	base_mesh.material_override = mat
	add_child(base_mesh)
	var collision = CollisionShape3D.new()
	var shape = CylinderShape3D.new()
	shape.radius = 0.48
	shape.height = 0.18
	collision.shape = shape
	add_child(collision)

func get_interaction_label() -> String:
	return "Oyunu kaydet"

func interact(actor: Node) -> void:
	if actor != null and actor.has_method("save_now"):
		actor.save_now()
