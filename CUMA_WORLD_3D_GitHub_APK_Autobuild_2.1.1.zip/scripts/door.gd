extends StaticBody3D

var is_open = false
var busy = false
var closed_angle = 0.0
var open_delta = -92.0
var persistent_id = "door"

func setup(size: Vector3, color: Color, angle: float = -92.0) -> void:
	persistent_id = name
	closed_angle = rotation.y
	open_delta = angle
	add_to_group("persistent_world")
	var mesh_instance = MeshInstance3D.new()
	var mesh = BoxMesh.new()
	mesh.size = size
	mesh_instance.mesh = mesh
	mesh_instance.position.x = size.x * 0.5
	var material = StandardMaterial3D.new()
	material.albedo_color = color
	material.roughness = 0.62
	if ResourceLoader.exists("res://assets/materials/walnut.png"):
		material.albedo_texture = load("res://assets/materials/walnut.png")
	mesh_instance.material_override = material
	add_child(mesh_instance)
	var collision = CollisionShape3D.new()
	var shape = BoxShape3D.new()
	shape.size = size
	collision.shape = shape
	collision.position.x = size.x * 0.5
	add_child(collision)
	# Four recessed panels and a lever handle make the door read as joinery, not a prototype slab.
	var detail_mat = StandardMaterial3D.new()
	detail_mat.albedo_color = color.darkened(0.055)
	detail_mat.roughness = 0.62
	for row in [-0.56, 0.56]:
		for col in [0.28, 0.72]:
			var inset = MeshInstance3D.new()
			var inset_mesh = BoxMesh.new()
			inset_mesh.size = Vector3(size.x * 0.32, 0.72, 0.025)
			inset.mesh = inset_mesh
			inset.position = Vector3(size.x * col, row, -size.z * 0.58)
			inset.material_override = detail_mat
			add_child(inset)
	var hm = StandardMaterial3D.new()
	hm.albedo_color = Color("b9a36b")
	hm.metallic = 0.82
	hm.roughness = 0.24
	var rose = MeshInstance3D.new()
	var rose_mesh = CylinderMesh.new()
	rose_mesh.top_radius = 0.055
	rose_mesh.bottom_radius = 0.055
	rose_mesh.height = 0.025
	rose_mesh.radial_segments = 16
	rose.mesh = rose_mesh
	rose.rotation_degrees.x = 90.0
	rose.position = Vector3(size.x - 0.17, 0.0, -0.09)
	rose.material_override = hm
	add_child(rose)
	var handle = MeshInstance3D.new()
	var handle_mesh = BoxMesh.new()
	handle_mesh.size = Vector3(0.12, 0.028, 0.028)
	handle.mesh = handle_mesh
	handle.position = Vector3(size.x - 0.16, 0.0, -0.13)
	handle.material_override = hm
	add_child(handle)
	_register_network()

func _register_network() -> void:
	var net = get_node_or_null("/root/NetworkManager")
	if net == null:
		return
	net.register_world_interactable(persistent_id, global_position, ["toggle"])
	if not net.world_action_received.is_connected(_on_world_action_received):
		net.world_action_received.connect(_on_world_action_received)

func get_interaction_label() -> String:
	return "Kapıyı kapat" if is_open else "Kapıyı aç"

func interact(_actor: Node) -> void:
	if busy:
		return
	var net = get_node_or_null("/root/NetworkManager")
	if net != null:
		net.request_world_action(persistent_id, "toggle")
	else:
		_set_open(not is_open, true)

func _on_world_action_received(id: String, action: String) -> void:
	if id == persistent_id and action == "toggle" and not busy:
		_set_open(not is_open, true)

func _set_open(value: bool, animate: bool) -> void:
	is_open = value
	var target_y = closed_angle + deg_to_rad(open_delta) if is_open else closed_angle
	if not animate:
		rotation.y = target_y
		return
	busy = true
	var tween = create_tween()
	tween.set_trans(Tween.TRANS_QUAD)
	tween.set_ease(Tween.EASE_IN_OUT)
	tween.tween_property(self, "rotation:y", target_y, 0.38)
	tween.finished.connect(func(): busy = false)

func get_persistent_id() -> String:
	return persistent_id

func get_persistent_state() -> Dictionary:
	return {"open": is_open}

func apply_persistent_state(state: Variant) -> void:
	if state is Dictionary:
		_set_open(bool(state.get("open", false)), false)
