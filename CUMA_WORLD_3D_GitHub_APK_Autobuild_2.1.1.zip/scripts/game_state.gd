extends Node

signal state_changed
signal objective_changed(text: String)
signal quality_changed(profile: String)
signal duo_activity_completed(activity_id: String, title: String, points: int)
signal memory_added(title: String)
signal social_relationship_changed(npc_id: String, stage: String)
signal social_feed_added(text: String)

const SAVE_PATH := "user://cuma_world_save_v19.cfg"
const LEGACY_SAVE_PATHS := ["user://cuma_world_save_v18.cfg", "user://cuma_world_save_v04.cfg", "user://cuma_world_save_v03.cfg"]

var money: int = 250
var inventory: Dictionary = {}
var objective: String = "Evi keşfet ve birlikte yapılacak etkinlikleri bul"
var time_of_day: float = 17.5
var world_day: int = 1
var quality_profile: String = "MEDIUM"
var checkpoint_position = Vector3(0.0, 0.15, 7.1)
var world_states: Dictionary = {}
var weather_mode: String = "CLEAR"

# Full Life 1.0 progression/customization
var story_chapter: int = 0
var story_objective: String = "Birlikte yeni hayatınıza başlayın"
var story_flags: Dictionary = {}
var owned_outfits: Array[String] = ["classic"]
var selected_outfit: String = "classic"
var character_style: int = 0
var hair_style: int = 0

# Dynamic City 1.8 - local career progression.
var current_career: String = "freelance"
var career_level: int = 1
var career_xp: int = 0
var completed_shifts: int = 0
var career_last_shift_day: Dictionary = {}

# Together Update 0.4
var partner_name: String = "Partner"
var duo_points: int = 0
var duo_stats: Dictionary = {}
var duo_memories: Array[String] = []
var shared_goal: String = "Birlikte 3 farklı etkinlik tamamla"
var shared_goal_progress: int = 0
var decor_preset: int = 0
var duo_achievements: Array[String] = []

# Social Life 1.2 - local, player-specific social simulation.
# These values are intentionally not included in the shared multiplayer snapshot:
# each human player owns their own friendships/romance with NPCs.
var social_profiles: Dictionary = {}
var social_relationships: Dictionary = {}
var social_memories: Dictionary = {}
var social_feed: Array[String] = []
var npc_bonds: Dictionary = {}

# NPC Intelligence 1.3 - local calendar/invitations; never shared over multiplayer.
var social_invitations: Array[Dictionary] = []
var neighborhood_events: Array[Dictionary] = []

# Daily Life 1.6 - local life diary. Never part of multiplayer shared snapshot.
var daily_life_events: Array[Dictionary] = []

# Crime & Justice 1.9 - local player law/cyber state.
# Intentionally excluded from shared multiplayer snapshots: each human player owns their own consequences.
var law_heat: int = 0
var outstanding_fine: int = 0
var crime_record: Array[Dictionary] = []
var stolen_goods: Dictionary = {}
var cyber_xp: int = 0
var cyber_level: int = 1
var cyber_cases_completed: Array[String] = []

func _ready() -> void:
	load_game()

func add_money(amount: int) -> void:
	money = max(0, money + amount)
	state_changed.emit()

func spend_money(amount: int) -> bool:
	if amount < 0 or money < amount:
		return false
	money -= amount
	state_changed.emit()
	return true

func add_item(item_id: String, amount: int = 1) -> void:
	if item_id.is_empty() or amount <= 0:
		return
	inventory[item_id] = int(inventory.get(item_id, 0)) + amount
	state_changed.emit()

func remove_item(item_id: String, amount: int = 1) -> bool:
	if amount <= 0 or not has_item(item_id, amount):
		return false
	var left = int(inventory.get(item_id, 0)) - amount
	if left <= 0:
		inventory.erase(item_id)
	else:
		inventory[item_id] = left
	state_changed.emit()
	return true

func has_item(item_id: String, amount: int = 1) -> bool:
	return int(inventory.get(item_id, 0)) >= amount

func set_objective(text: String) -> void:
	objective = text
	objective_changed.emit(text)
	state_changed.emit()

func advance_time(hours: float) -> void:
	var old_day = world_day
	var total = time_of_day + max(0.0, hours)
	if total >= 24.0:
		world_day += int(floor(total / 24.0))
	time_of_day = fposmod(total, 24.0)
	if world_day > old_day:
		for day_value in range(old_day + 1, world_day + 1):
			_social_new_day(day_value)
	state_changed.emit()

func set_quality(profile: String) -> void:
	var normalized = profile.to_upper()
	if normalized not in ["LOW", "MEDIUM", "HIGH"]:
		return
	quality_profile = normalized
	quality_changed.emit(quality_profile)
	state_changed.emit()

func cycle_quality() -> String:
	match quality_profile:
		"LOW": set_quality("MEDIUM")
		"MEDIUM": set_quality("HIGH")
		_: set_quality("LOW")
	return quality_profile

func set_partner_name(value: String) -> void:
	var cleaned = value.strip_edges()
	if cleaned.is_empty():
		cleaned = "Partner"
	partner_name = cleaned.left(24)
	state_changed.emit()

func complete_duo_activity(activity_id: String, title: String, points: int = 10, time_cost: float = 0.25) -> void:
	if activity_id.is_empty():
		return
	var count = int(duo_stats.get(activity_id, 0)) + 1
	duo_stats[activity_id] = count
	duo_points += max(0, points)
	advance_time(max(0.0, time_cost))
	add_memory(title)
	shared_goal_progress = _count_unique_duo_activities()
	_refresh_duo_achievements(activity_id)
	if shared_goal_progress >= 3:
		shared_goal = "Harika takım! Yeni birlikte etkinlikleri keşfet"
	else:
		shared_goal = "Birlikte 3 farklı etkinlik tamamla (%d/3)" % shared_goal_progress
	duo_activity_completed.emit(activity_id, title, points)
	state_changed.emit()

func add_memory(title: String) -> void:
	var cleaned = title.strip_edges()
	if cleaned.is_empty():
		return
	var hour = int(floor(time_of_day))
	var minute = int(floor(fposmod(time_of_day, 1.0) * 60.0))
	var entry = "%02d:%02d • %s" % [hour, minute, cleaned]
	duo_memories.push_front(entry)
	if duo_memories.size() > 30:
		duo_memories.resize(30)
	memory_added.emit(entry)

func _count_unique_duo_activities() -> int:
	var count = 0
	for key in duo_stats.keys():
		if int(duo_stats[key]) > 0:
			count += 1
	return count

func _refresh_duo_achievements(last_activity_id: String) -> void:
	_unlock_achievement("İlk Ortak Anı", _count_unique_duo_activities() >= 1)
	_unlock_achievement("Keşif Ekibi", _count_unique_duo_activities() >= 5)
	_unlock_achievement("Her Yerde Beraber", _count_unique_duo_activities() >= 10)
	_unlock_achievement("100 DUO", duo_points >= 100)
	_unlock_achievement("Film Ekibi", last_activity_id in ["movie_night", "cinema_duo"])
	_unlock_achievement("Mutfak Takımı", last_activity_id == "cook_together")
	_unlock_achievement("Albüm Başladı", last_activity_id == "photo_booth")
	_unlock_achievement("Sürpriz Paylaşıldı", last_activity_id == "gift_exchange")

func _unlock_achievement(title: String, condition: bool) -> void:
	if condition and title not in duo_achievements:
		duo_achievements.append(title)

func get_duo_rank() -> String:
	if duo_points >= 500:
		return "EFSANE İKİLİ"
	if duo_points >= 250:
		return "UYUMLU TAKIM"
	if duo_points >= 100:
		return "İYİ İKİLİ"
	if duo_points >= 40:
		return "BERABER KEŞİF"
	return "YENİ TAKIM"

func cycle_decor_preset() -> int:
	decor_preset = (decor_preset + 1) % 4
	state_changed.emit()
	return decor_preset



func unlock_outfit(outfit_id: String) -> void:
	var clean = outfit_id.strip_edges().left(32)
	if clean.is_empty():
		return
	if clean not in owned_outfits:
		owned_outfits.append(clean)
	state_changed.emit()

func cycle_character_style() -> int:
	character_style = (character_style + 1) % 5
	state_changed.emit()
	return character_style

func get_character_style_name() -> String:
	return ["Doğal", "Gece", "Orman", "Kum", "Şehir"][clamp(character_style, 0, 4)]

func cycle_hair_style() -> int:
	hair_style = (hair_style + 1) % 4
	state_changed.emit()
	return hair_style

func get_hair_style_name() -> String:
	return ["Doğal", "Kısa", "Katlı", "Toplu"][clamp(hair_style, 0, 3)]

func set_career(career_id: String) -> void:
	var clean = career_id.strip_edges().to_lower().left(32)
	if clean not in ["freelance", "office", "creative", "service", "fitness"]:
		return
	current_career = clean
	state_changed.emit()

func add_career_xp(amount: int, money_reward: int = 0) -> void:
	var gain = clamp(amount, 0, 500)
	career_xp = clamp(career_xp + gain, 0, 1000000)
	completed_shifts = clamp(completed_shifts + (1 if gain > 0 else 0), 0, 1000000)
	career_level = clamp(1 + int(career_xp / 120), 1, 20)
	if money_reward > 0:
		add_money(clamp(money_reward, 0, 5000))
	state_changed.emit()

func get_career_summary() -> String:
	var names = {"freelance":"Serbest", "office":"Ofis", "creative":"Yaratıcı", "service":"Hizmet", "fitness":"Fitness"}
	return "%s • Sv.%d • %d XP" % [str(names.get(current_career, "Serbest")), career_level, career_xp]

func can_work_career(career_id: String) -> bool:
	var clean = career_id.strip_edges().to_lower().left(32)
	return int(career_last_shift_day.get(clean, -1)) != world_day

func record_career_shift(career_id: String) -> void:
	var clean = career_id.strip_edges().to_lower().left(32)
	if clean.is_empty():
		return
	career_last_shift_day[clean] = world_day
	state_changed.emit()

func get_character_palette() -> Dictionary:
	var palettes = [
		{"top": Color("263653"), "pants": Color("20293a"), "hair": Color("171819")},
		{"top": Color("30273d"), "pants": Color("161b24"), "hair": Color("201918")},
		{"top": Color("315846"), "pants": Color("27342f"), "hair": Color("33251d")},
		{"top": Color("796249"), "pants": Color("4b443c"), "hair": Color("1c1917")},
		{"top": Color("45536b"), "pants": Color("23252b"), "hair": Color("2d211d")}
	]
	var result: Dictionary = palettes[clamp(character_style, 0, palettes.size()-1)].duplicate()
	match selected_outfit:
		"rose": result["top"] = Color("704254")
		"ocean": result["top"] = Color("315f78")
		"olive": result["top"] = Color("526341")
		"mono": result["top"] = Color("34363a")
	return result

func register_social_profile(npc_id: String, values: Dictionary) -> void:
	var clean = npc_id.strip_edges().left(40)
	if clean.is_empty():
		return
	var profile = values.duplicate(true)
	profile["id"] = clean
	profile["name"] = str(profile.get("name", clean)).left(28)
	profile["personality"] = str(profile.get("personality", "sakin")).left(40)
	profile["favorite_activity"] = str(profile.get("favorite_activity", "sohbet")).left(40)
	profile["favorite_gift"] = str(profile.get("favorite_gift", "sparkling_drink")).left(32)
	profile["romance_available"] = bool(profile.get("romance_available", true))
	profile["work_start"] = clamp(float(profile.get("work_start", 9.0)), 0.0, 24.0)
	profile["work_end"] = clamp(float(profile.get("work_end", 17.0)), 0.0, 24.0)
	social_profiles[clean] = profile
	if not social_relationships.has(clean):
		social_relationships[clean] = {
			"friendship": 0.0,
			"trust": 0.0,
			"affection": 0.0,
			"tension": 0.0,
			"stage": "acquaintance",
			"met": false,
			"last_action": "",
			"last_action_day": 0,
			"daily_actions": 0,
			"last_seen_day": 0
		}
	if not social_memories.has(clean):
		social_memories[clean] = []

func get_social_profile(npc_id: String) -> Dictionary:
	return social_profiles.get(npc_id, {}).duplicate(true)

func get_social_relationship(npc_id: String) -> Dictionary:
	var rel: Dictionary = social_relationships.get(npc_id, {})
	return rel.duplicate(true)

func get_social_stage_label(npc_id: String) -> String:
	var rel: Dictionary = social_relationships.get(npc_id, {})
	if rel.is_empty() or not bool(rel.get("met", false)):
		return "Henüz tanışmadınız"
	match str(rel.get("stage", "acquaintance")):
		"friend": return "Arkadaş"
		"close_friend": return "Yakın arkadaş"
		"dating": return "Buluşuyorsunuz"
		"partner": return "Sevgili"
		_: return "Tanışıyorsunuz"

func get_social_mood_label(npc_id: String) -> String:
	var profile: Dictionary = social_profiles.get(npc_id, {})
	if profile.is_empty():
		return "Sakin"
	var hour = time_of_day
	var work_start = float(profile.get("work_start", 9.0))
	var work_end = float(profile.get("work_end", 17.0))
	if hour < 7.0:
		return "Uykulu"
	if hour >= work_start and hour < work_end:
		return "Meşgul"
	if hour >= 18.0 and hour < 22.0:
		return "Rahat"
	if hour >= 22.0:
		return "Yorgun"
	return "Sakin"

func perform_social_action(npc_id: String, action: String) -> Dictionary:
	if not social_profiles.has(npc_id) or not social_relationships.has(npc_id):
		return {"ok": false, "text": "Bu kişiyle şu an etkileşilemiyor."}
	var allowed = ["greet", "chat", "compliment", "coffee", "walk", "gift", "friend", "date", "relationship", "apologize", "home_visit"]
	if action not in allowed:
		return {"ok": false, "text": "Bilinmeyen sosyal etkileşim."}
	var profile: Dictionary = social_profiles[npc_id]
	var rel: Dictionary = social_relationships[npc_id]
	if int(rel.get("last_action_day", 0)) != world_day:
		rel["daily_actions"] = 0
		rel["last_action"] = ""
		rel["last_action_day"] = world_day
	var daily_actions = int(rel.get("daily_actions", 0))
	if daily_actions >= 7 and action not in ["apologize"]:
		return {"ok": false, "text": "%s bugün biraz kendi alanında kalmak istiyor." % str(profile["name"]), "mood": "neutral"}

	var friendship = float(rel.get("friendship", 0.0))
	var trust = float(rel.get("trust", 0.0))
	var affection = float(rel.get("affection", 0.0))
	var tension = float(rel.get("tension", 0.0))
	var repeated = str(rel.get("last_action", "")) == action and int(rel.get("last_action_day", 0)) == world_day
	var repeat_scale = 0.45 if repeated else 1.0
	var busy = get_social_mood_label(npc_id) == "Meşgul"
	var accepted = true
	var text = ""
	var mood = "happy"
	var time_cost = 0.05
	var df = 0.0
	var dt = 0.0
	var da = 0.0

	match action:
		"greet":
			df = 2.0; dt = 1.0
			text = "%s selamını aldı ve kısa bir sohbet için durdu." % str(profile["name"])
		"chat":
			df = 4.0; dt = 2.5
			text = _social_chat_line(profile)
			time_cost = 0.15
		"compliment":
			df = 1.5; dt = 1.0; da = 3.0
			text = "%s teşekkür etti; sohbet biraz daha sıcaklaştı." % str(profile["name"])
		"coffee":
			if busy:
				accepted = false; mood = "neutral"
				text = "%s şu an işi olduğunu söyledi; daha sonra kahveye açık." % str(profile["name"])
			elif friendship < 10.0:
				accepted = false; mood = "curious"
				text = "%s önce biraz daha tanışmayı tercih ediyor." % str(profile["name"])
			else:
				df = 6.0; dt = 4.0; da = 2.0; time_cost = 0.5
				text = "%s kahve davetini kabul etti." % str(profile["name"])
		"walk":
			if busy:
				accepted = false; mood = "neutral"
				text = "%s şimdi meşgul; yürüyüşü başka zamana bırakıyor." % str(profile["name"])
			elif friendship < 15.0:
				accepted = false; mood = "curious"
				text = "%s önce biraz daha sohbet etmek istiyor." % str(profile["name"])
			else:
				df = 7.0; dt = 4.0; da = 2.5; time_cost = 0.75
				text = "%s birlikte yürüyüş yapmayı kabul etti." % str(profile["name"])
		"home_visit":
			if busy:
				accepted = false; mood = "neutral"
				text = "%s şu an gelemiyor; daha sakin bir zamanda uğrayabilir." % str(profile["name"])
			elif friendship < 34.0 or trust < 22.0:
				accepted = false; mood = "curious"
				text = "%s eve gelmeden önce biraz daha yakın arkadaş olmayı tercih ediyor." % str(profile["name"])
			else:
				df = 4.0; dt = 3.0; da = 1.5; time_cost = 0.15
				text = "%s birazdan evinin kapısına uğrayacağını söyledi." % str(profile["name"])
		"gift":
			var gift_id = _consume_social_gift(str(profile.get("favorite_gift", "")))
			if gift_id.is_empty():
				accepted = false; mood = "curious"
				text = "Envanterinde verebileceğin uygun bir hediye yok."
			else:
				var favorite = gift_id == str(profile.get("favorite_gift", ""))
				df = 5.0 if favorite else 2.5
				dt = 3.0 if favorite else 1.5
				da = 5.0 if favorite else 2.0
				text = "%s hediyeyi %s." % [str(profile["name"]), "çok sevdi" if favorite else "gülümseyerek kabul etti"]
		"friend":
			if friendship >= 34.0 and trust >= 20.0:
				rel["stage"] = "friend"
				df = 4.0; dt = 4.0
				text = "%s arkadaş olmayı içtenlikle kabul etti." % str(profile["name"])
			else:
				accepted = false; mood = "curious"
				text = "%s bunun için birbirinizi biraz daha tanımanız gerektiğini düşünüyor." % str(profile["name"])
		"date":
			if not bool(profile.get("romance_available", true)):
				accepted = false; mood = "neutral"
				text = "%s ilişkiyi arkadaşlık olarak tutmak istiyor." % str(profile["name"])
			elif str(rel.get("stage", "")) not in ["friend", "close_friend"] or friendship < 48.0 or trust < 34.0 or affection < 40.0:
				accepted = false; mood = "curious"
				text = "%s acele etmek istemiyor; önce daha güçlü bir bağ kurmak istiyor." % str(profile["name"])
			else:
				rel["stage"] = "dating"
				da = 6.0; dt = 3.0; time_cost = 0.5
				text = "%s birlikte bir buluşmaya çıkmayı kabul etti." % str(profile["name"])
		"relationship":
			if str(rel.get("stage", "")) == "dating" and friendship >= 70.0 and trust >= 60.0 and affection >= 68.0:
				rel["stage"] = "partner"
				df = 3.0; dt = 5.0; da = 5.0
				text = "%s ilişkinizi sevgililik olarak tanımlamayı kabul etti." % str(profile["name"])
			else:
				accepted = false; mood = "curious"
				text = "%s bu konuda biraz daha zamana ihtiyaç duyuyor." % str(profile["name"])
		"apologize":
			if tension <= 0.5:
				text = "%s aranızda çözülecek önemli bir sorun olmadığını söyledi." % str(profile["name"])
			else:
				rel["tension"] = max(0.0, tension - 12.0)
				dt = 3.0
				text = "%s özrünü kabul etti; ortam yumuşadı." % str(profile["name"])

	if accepted:
		rel["met"] = true
		rel["friendship"] = clamp(friendship + df * repeat_scale, 0.0, 100.0)
		rel["trust"] = clamp(trust + dt * repeat_scale, 0.0, 100.0)
		rel["affection"] = clamp(affection + da * repeat_scale, 0.0, 100.0)
		rel["tension"] = max(0.0, float(rel.get("tension", tension)) - 0.6)
		rel["daily_actions"] = daily_actions + 1
		rel["last_action"] = action
		rel["last_action_day"] = world_day
		rel["last_seen_day"] = world_day
		_auto_social_stage(rel)
		if time_cost > 0.0:
			advance_time(time_cost)
		_add_social_memory(npc_id, text)
	else:
		rel["daily_actions"] = daily_actions + 1
		rel["last_action"] = action
		rel["last_action_day"] = world_day
	social_relationships[npc_id] = rel
	social_relationship_changed.emit(npc_id, str(rel.get("stage", "acquaintance")))
	state_changed.emit()
	return {"ok": accepted, "text": text, "mood": mood, "stage": str(rel.get("stage", "acquaintance"))}

func _social_chat_line(profile: Dictionary) -> String:
	var name = str(profile.get("name", "Komşu"))
	var personality = str(profile.get("personality", "sakin"))
	var activity = str(profile.get("favorite_activity", "şehirde dolaşmak"))
	var lines = [
		"%s gününün nasıl geçtiğini anlattı; %s tarafı sohbetine yansıyor." % [name, personality],
		"%s sohbet sırasında en çok %s sevdiğinden bahsetti." % [name, activity],
		"%s seni dinledi ve kendi gününden küçük bir şey paylaştı." % name
	]
	return str(lines[randi() % lines.size()])

func _consume_social_gift(favorite: String) -> String:
	var candidates = []
	if not favorite.is_empty():
		candidates.append(favorite)
	for item in ["dessert_box", "novel", "photo_album", "sparkling_drink", "breakfast_box"]:
		if item not in candidates:
			candidates.append(item)
	for item in candidates:
		if has_item(item, 1):
			remove_item(item, 1)
			return item
	return ""

func _auto_social_stage(rel: Dictionary) -> void:
	var stage = str(rel.get("stage", "acquaintance"))
	if stage in ["dating", "partner"]:
		return
	var friendship = float(rel.get("friendship", 0.0))
	var trust = float(rel.get("trust", 0.0))
	if friendship >= 64.0 and trust >= 45.0:
		rel["stage"] = "close_friend"
	elif friendship >= 34.0 and trust >= 20.0:
		rel["stage"] = "friend"

func _add_social_memory(npc_id: String, text: String) -> void:
	var entries: Array = social_memories.get(npc_id, [])
	var stamp = "Gün %d • %02d:%02d • %s" % [world_day, int(time_of_day), int(fmod(time_of_day, 1.0) * 60.0), text.left(140)]
	entries.push_front(stamp)
	if entries.size() > 12:
		entries.resize(12)
	social_memories[npc_id] = entries

func add_social_feed(text: String) -> void:
	var clean = text.strip_edges().left(180)
	if clean.is_empty():
		return
	var entry = "Gün %d • %s" % [world_day, clean]
	if social_feed.size() > 0 and str(social_feed[0]) == entry:
		return
	social_feed.push_front(entry)
	if social_feed.size() > 28:
		social_feed.resize(28)
	social_feed_added.emit(entry)
	state_changed.emit()

func _social_new_day(day_value: int) -> void:
	var fresh_invites: Array[Dictionary] = []
	for invite in social_invitations:
		if int(invite.get("day", 0)) >= day_value - 1 and str(invite.get("status", "pending")) == "pending":
			fresh_invites.append(invite)
	social_invitations = fresh_invites.slice(0, 18)
	var fresh_events: Array[Dictionary] = []
	for event in neighborhood_events:
		if int(event.get("day", 0)) >= day_value - 1:
			fresh_events.append(event)
	neighborhood_events = fresh_events.slice(0, 16)
	for npc_id in social_relationships.keys():
		var rel: Dictionary = social_relationships[npc_id]
		rel["daily_actions"] = 0
		rel["tension"] = max(0.0, float(rel.get("tension", 0.0)) - 2.0)
		social_relationships[npc_id] = rel
		if not bool(rel.get("met", false)):
			continue
		var stage = str(rel.get("stage", "acquaintance"))
		var profile: Dictionary = social_profiles.get(npc_id, {})
		if stage in ["friend", "close_friend", "dating", "partner"] and randf() < 0.28:
			var invite = str(profile.get("favorite_activity", "biraz sohbet etmek"))
			add_social_feed("%s bugün %s için müsait olabileceğini söyledi." % [str(profile.get("name", npc_id)), invite])


func queue_social_invitation(npc_id: String, kind: String, day_value: int, hour_value: float) -> void:
	if not social_profiles.has(npc_id):
		return
	var allowed = ["coffee", "walk", "game_night", "park"]
	if kind not in allowed:
		return
	# One pending invitation per NPC avoids notification spam.
	for entry in social_invitations:
		if str(entry.get("npc_id", "")) == npc_id and str(entry.get("status", "pending")) == "pending":
			return
	var invite = {
		"id": "%s_%d_%d" % [npc_id, max(1, day_value), int(hour_value * 100.0)],
		"npc_id": npc_id.left(40),
		"kind": kind,
		"day": max(1, day_value),
		"hour": clamp(hour_value, 0.0, 24.0),
		"status": "pending"
	}
	social_invitations.push_front(invite)
	if social_invitations.size() > 18:
		social_invitations.resize(18)
	var profile: Dictionary = social_profiles.get(npc_id, {})
	add_social_feed("%s seni %s için davet etti." % [str(profile.get("name", npc_id)), _social_invite_label(kind)])

func respond_social_invitation(invitation_id: String, accept: bool) -> Dictionary:
	var clean = invitation_id.left(96)
	for i in range(social_invitations.size()):
		var invite: Dictionary = social_invitations[i]
		if str(invite.get("id", "")) != clean or str(invite.get("status", "")) != "pending":
			continue
		var npc_id = str(invite.get("npc_id", ""))
		invite["status"] = "accepted" if accept else "declined"
		social_invitations[i] = invite
		var profile: Dictionary = social_profiles.get(npc_id, {})
		var name = str(profile.get("name", npc_id))
		if accept:
			var rel: Dictionary = social_relationships.get(npc_id, {})
			rel["friendship"] = clamp(float(rel.get("friendship", 0.0)) + 2.0, 0.0, 100.0)
			rel["trust"] = clamp(float(rel.get("trust", 0.0)) + 1.5, 0.0, 100.0)
			social_relationships[npc_id] = rel
			add_social_feed("%s ile planı kabul ettin: %s." % [name, _social_invite_label(str(invite.get("kind", "coffee")))])
			return {"ok": true, "text": "%s ile plan takvime eklendi." % name}
		add_social_feed("%s ile bu planı başka zamana bıraktın." % name)
		return {"ok": true, "text": "Davet nazikçe reddedildi."}
	return {"ok": false, "text": "Bu davet artık aktif değil."}

func schedule_neighborhood_event(kind: String, attendees: Array[String], day_value: int, hour_value: float) -> void:
	var allowed = ["coffee_circle", "garden_meet", "game_night", "photo_walk", "community_dinner"]
	if kind not in allowed or attendees.size() < 2:
		return
	var clean_attendees: Array[String] = []
	for npc_id in attendees.slice(0, 6):
		var clean = str(npc_id).left(40)
		if social_profiles.has(clean) and clean not in clean_attendees:
			clean_attendees.append(clean)
	if clean_attendees.size() < 2:
		return
	var event = {
		"id": "%s_%d_%d" % [kind, max(1, day_value), int(hour_value * 100.0)],
		"kind": kind, "attendees": clean_attendees, "day": max(1, day_value),
		"hour": clamp(hour_value, 0.0, 24.0), "status": "scheduled"
	}
	neighborhood_events.push_front(event)
	if neighborhood_events.size() > 16:
		neighborhood_events.resize(16)
	var names: Array[String] = []
	for npc_id in clean_attendees:
		names.append(str(social_profiles.get(npc_id, {}).get("name", npc_id)))
	add_social_feed("%s, %s planlıyor." % [", ".join(names), _neighborhood_event_label(kind)])

func get_active_social_invitations() -> Array[Dictionary]:
	var out: Array[Dictionary] = []
	for invite in social_invitations:
		if str(invite.get("status", "")) in ["pending", "accepted"]:
			out.append(invite.duplicate(true))
	return out

func finish_social_invitation(invitation_id: String, status: String) -> void:
	if status not in ["active", "expired", "canceled", "done"]:
		return
	for i in range(social_invitations.size()):
		var invite: Dictionary = social_invitations[i]
		if str(invite.get("id", "")) != invitation_id.left(96):
			continue
		invite["status"] = status
		social_invitations[i] = invite
		var profile: Dictionary = social_profiles.get(str(invite.get("npc_id", "")), {})
		if status == "expired":
			add_social_feed("%s ile planın saati geçti; başka bir gün yeniden planlayabilirsiniz." % str(profile.get("name", "Komşu")))
		elif status == "canceled":
			add_social_feed("%s bugün çok yorulduğu için planı başka güne erteledi." % str(profile.get("name", "Komşu")))
		elif status == "active":
			add_social_feed("%s planladığınız buluşma için yola çıktı." % str(profile.get("name", "Komşu")))
		return

func get_pending_social_invitations() -> Array[Dictionary]:
	var out: Array[Dictionary] = []
	for invite in social_invitations:
		if str(invite.get("status", "")) == "pending":
			out.append(invite.duplicate(true))
	return out

func get_active_neighborhood_events() -> Array[Dictionary]:
	var out: Array[Dictionary] = []
	for event in neighborhood_events:
		if str(event.get("status", "scheduled")) == "scheduled":
			out.append(event.duplicate(true))
	return out

func finish_neighborhood_event(event_id: String) -> void:
	for i in range(neighborhood_events.size()):
		var event: Dictionary = neighborhood_events[i]
		if str(event.get("id", "")) == event_id.left(96):
			event["status"] = "active"
			neighborhood_events[i] = event
			return

func get_social_calendar_summary() -> String:
	var pending = get_pending_social_invitations().size()
	var future_events = 0
	for event in neighborhood_events:
		if int(event.get("day", 0)) >= world_day:
			future_events += 1
	return "%d bekleyen davet • %d mahalle planı" % [pending, future_events]

func _social_invite_label(kind: String) -> String:
	match kind:
		"walk": return "bir yürüyüş"
		"game_night": return "oyun gecesi"
		"park": return "parkta mola"
		_: return "kahve"

func _neighborhood_event_label(kind: String) -> String:
	match kind:
		"garden_meet": return "bahçede buluşmayı"
		"game_night": return "oyun gecesini"
		"photo_walk": return "fotoğraf yürüyüşünü"
		"community_dinner": return "mahalle yemeğini"
		_: return "kahve buluşmasını"


func add_daily_life_event(kind: String, text: String) -> void:
	var clean_kind = kind.strip_edges().left(32)
	var clean_text = text.strip_edges().left(180)
	if clean_text.is_empty():
		return
	var entry = {
		"day": world_day,
		"hour": time_of_day,
		"kind": clean_kind,
		"text": clean_text
	}
	if daily_life_events.size() > 0:
		var first: Dictionary = daily_life_events[0]
		if str(first.get("text", "")) == clean_text and int(first.get("day", 0)) == world_day:
			return
	daily_life_events.push_front(entry)
	if daily_life_events.size() > 32:
		daily_life_events.resize(32)
	state_changed.emit()

func get_daily_life_summary() -> String:
	if daily_life_events.is_empty():
		return "Günlük yaşam akışı sakin"
	var entry: Dictionary = daily_life_events[0]
	return str(entry.get("text", "Mahalle günlük rutininde")).left(110)

func get_weekday_name() -> String:
	var names = ["Pazar", "Pazartesi", "Salı", "Çarşamba", "Perşembe", "Cuma", "Cumartesi"]
	return names[posmod(world_day, 7)]

func register_npc_bond(a: String, b: String, initial_score: float = 0.0, romance_possible: bool = false) -> void:
	var key = _bond_key(a, b)
	if key.is_empty():
		return
	if not npc_bonds.has(key):
		npc_bonds[key] = {"a": a, "b": b, "score": clamp(initial_score, 0.0, 100.0), "stage": _npc_bond_stage(initial_score, romance_possible), "romance": romance_possible}

func advance_npc_bond(a: String, b: String, amount: float) -> void:
	var key = _bond_key(a, b)
	if key.is_empty():
		return
	if not npc_bonds.has(key):
		register_npc_bond(a, b, 0.0, false)
	var bond: Dictionary = npc_bonds[key]
	var old_stage = str(bond.get("stage", "acquaintance"))
	var score = clamp(float(bond.get("score", 0.0)) + max(0.0, amount), 0.0, 100.0)
	bond["score"] = score
	var new_stage = _npc_bond_stage(score, bool(bond.get("romance", false)))
	bond["stage"] = new_stage
	npc_bonds[key] = bond
	if new_stage != old_stage:
		var profile_a: Dictionary = social_profiles.get(a, {})
		var profile_b: Dictionary = social_profiles.get(b, {})
		var a_name = str(profile_a.get("name", a))
		var b_name = str(profile_b.get("name", b))
		match new_stage:
			"friend": add_social_feed("%s ile %s arkadaş oldu." % [a_name, b_name])
			"close_friend": add_social_feed("%s ile %s artık yakın arkadaş." % [a_name, b_name])
			"dating": add_social_feed("%s ile %s birbirlerinden hoşlanmaya başladı ve buluşuyor." % [a_name, b_name])
			"partner": add_social_feed("%s ile %s sevgili oldu." % [a_name, b_name])

func get_npc_bond(a: String, b: String) -> Dictionary:
	return npc_bonds.get(_bond_key(a, b), {}).duplicate(true)

func _bond_key(a: String, b: String) -> String:
	var x = a.strip_edges().left(40)
	var y = b.strip_edges().left(40)
	if x.is_empty() or y.is_empty() or x == y:
		return ""
	return x + "|" + y if x.naturalnocasecmp_to(y) < 0 else y + "|" + x

func _npc_bond_stage(score: float, romance_possible: bool) -> String:
	if romance_possible and score >= 90.0:
		return "partner"
	if romance_possible and score >= 76.0:
		return "dating"
	if score >= 55.0:
		return "close_friend"
	if score >= 25.0:
		return "friend"
	return "acquaintance"

func get_social_summary() -> String:
	var met_count = 0
	var friend_count = 0
	var closest_name = "-"
	var closest_score = -1.0
	for npc_id in social_relationships.keys():
		var rel: Dictionary = social_relationships[npc_id]
		if not bool(rel.get("met", false)):
			continue
		met_count += 1
		if str(rel.get("stage", "")) in ["friend", "close_friend", "dating", "partner"]:
			friend_count += 1
		var score = float(rel.get("friendship", 0.0)) + float(rel.get("trust", 0.0)) * 0.7 + float(rel.get("affection", 0.0)) * 0.5
		if score > closest_score:
			closest_score = score
			var closest_profile: Dictionary = social_profiles.get(npc_id, {})
			closest_name = str(closest_profile.get("name", npc_id))
	return "%d tanışıklık • %d yakın bağ • En yakın: %s" % [met_count, friend_count, closest_name]

func add_stolen_good(item_id: String, title: String, value: int) -> void:
	var clean = item_id.strip_edges().to_lower().left(40)
	if clean.is_empty():
		return
	var entry: Dictionary = stolen_goods.get(clean, {"title": title.left(60), "value": 0, "count": 0})
	entry["title"] = title.left(60)
	entry["value"] = clamp(int(entry.get("value", 0)) + max(0, value), 0, 100000)
	entry["count"] = clamp(int(entry.get("count", 0)) + 1, 1, 99)
	stolen_goods[clean] = entry
	state_changed.emit()

func commit_game_crime(crime_id: String, title: String, severity: int = 1, detected: bool = true, value: int = 0) -> void:
	var clean_id = crime_id.strip_edges().to_lower().left(40)
	if clean_id.is_empty():
		return
	var event = {
		"id": clean_id,
		"title": title.left(80),
		"day": world_day,
		"time": time_of_day,
		"severity": clamp(severity, 1, 3),
		"detected": detected,
		"value": clamp(value, 0, 100000)
	}
	crime_record.push_front(event)
	if crime_record.size() > 40:
		crime_record.resize(40)
	if detected:
		law_heat = clamp(law_heat + clamp(severity, 1, 3), 0, 5)
		outstanding_fine = clamp(outstanding_fine + 35 * severity + int(max(0, value) * 0.15), 0, 100000)
	state_changed.emit()

func reduce_law_heat(amount: int = 1) -> void:
	law_heat = clamp(law_heat - max(0, amount), 0, 5)
	state_changed.emit()

func resolve_arrest() -> Dictionary:
	var seized = 0
	for key in stolen_goods.keys():
		var entry: Variant = stolen_goods[key]
		if entry is Dictionary:
			seized += clamp(int(entry.get("count", 0)), 0, 99)
	stolen_goods.clear()
	var fine = clamp(outstanding_fine + law_heat * 45, 0, 100000)
	var paid = min(money, fine)
	money -= paid
	outstanding_fine = max(0, fine - paid)
	law_heat = 0
	advance_time(2.0)
	state_changed.emit()
	return {"fine": fine, "paid": paid, "seized": seized}

func complete_cyber_puzzle(case_id: String, mode: String, xp_gain: int) -> void:
	var clean = case_id.strip_edges().to_lower().left(40)
	cyber_xp = clamp(cyber_xp + clamp(xp_gain, 0, 250), 0, 100000)
	cyber_level = clamp(1 + int(cyber_xp / 120), 1, 25)
	if not clean.is_empty() and clean not in cyber_cases_completed:
		cyber_cases_completed.append(clean)
		if cyber_cases_completed.size() > 48:
			cyber_cases_completed.resize(48)
	if mode == "case_lab":
		add_money(35)
	elif mode == "shadow_grid":
		add_item("fictional_data_shard", 1)
	state_changed.emit()

func get_law_summary() -> String:
	if law_heat <= 0:
		return "Temiz kayıt • Ceza ₺%d" % outstanding_fine
	var stars = "★".repeat(law_heat) + "☆".repeat(5 - law_heat)
	var unit = "FIB takibi" if law_heat >= 4 else ("Polis takibi" if law_heat >= 2 else "Dikkat")
	return "%s • %s • Ceza ₺%d" % [stars, unit, outstanding_fine]

func get_cyber_summary() -> String:
	return "Cyber Sv.%d • %d XP • %d vaka" % [cyber_level, cyber_xp, cyber_cases_completed.size()]

func get_shared_snapshot() -> Dictionary:
	_capture_world_states()
	return {
		"time_of_day": time_of_day,
		"world_day": world_day,
		"world_states": world_states.duplicate(true),
		"duo_points": duo_points,
		"duo_stats": duo_stats.duplicate(true),
		"duo_memories": duo_memories.duplicate(),
		"shared_goal": shared_goal,
		"shared_goal_progress": shared_goal_progress,
		"decor_preset": decor_preset,
		"duo_achievements": duo_achievements.duplicate(),
		"weather_mode": weather_mode
	}

func apply_shared_snapshot(snapshot: Dictionary) -> void:
	if snapshot.size() > 16:
		return
	time_of_day = clamp(float(snapshot.get("time_of_day", time_of_day)), 0.0, 24.0)
	world_day = clamp(int(snapshot.get("world_day", world_day)), 1, 1000000)
	var incoming_world: Variant = snapshot.get("world_states", {})
	if incoming_world is Dictionary and incoming_world.size() <= 128:
		world_states = incoming_world.duplicate(true)
	duo_points = clamp(int(snapshot.get("duo_points", duo_points)), 0, 1000000)
	var incoming_stats: Variant = snapshot.get("duo_stats", {})
	if incoming_stats is Dictionary and incoming_stats.size() <= 128:
		duo_stats = incoming_stats.duplicate(true)
	var incoming_memories: Variant = snapshot.get("duo_memories", [])
	duo_memories.clear()
	if incoming_memories is Array:
		for entry in incoming_memories.slice(0, 30):
			duo_memories.append(str(entry).left(160))
	shared_goal = str(snapshot.get("shared_goal", shared_goal)).left(160)
	shared_goal_progress = clamp(int(snapshot.get("shared_goal_progress", shared_goal_progress)), 0, 128)
	decor_preset = clamp(int(snapshot.get("decor_preset", decor_preset)), 0, 3)
	var incoming_weather = str(snapshot.get("weather_mode", weather_mode)).to_upper()
	if incoming_weather in ["CLEAR", "CLOUDY", "RAIN"]:
		weather_mode = incoming_weather
	var incoming_achievements: Variant = snapshot.get("duo_achievements", [])
	duo_achievements.clear()
	if incoming_achievements is Array:
		for achievement in incoming_achievements.slice(0, 32):
			duo_achievements.append(str(achievement).left(80))
	call_deferred("_restore_world_states")
	state_changed.emit()

func save_game(player_position: Vector3 = checkpoint_position) -> int:
	checkpoint_position = player_position
	_capture_world_states()
	var cfg = ConfigFile.new()
	cfg.set_value("player", "position", checkpoint_position)
	cfg.set_value("game", "money", money)
	cfg.set_value("game", "inventory", inventory)
	cfg.set_value("game", "objective", objective)
	cfg.set_value("game", "time_of_day", time_of_day)
	cfg.set_value("game", "world_day", world_day)
	cfg.set_value("game", "quality", quality_profile)
	cfg.set_value("world", "states", world_states)
	cfg.set_value("world", "weather_mode", weather_mode)
	cfg.set_value("progress", "story_chapter", story_chapter)
	cfg.set_value("progress", "story_objective", story_objective)
	cfg.set_value("progress", "story_flags", story_flags)
	cfg.set_value("character", "owned_outfits", owned_outfits)
	cfg.set_value("character", "selected_outfit", selected_outfit)
	cfg.set_value("character", "style", character_style)
	cfg.set_value("character", "hair_style", hair_style)
	cfg.set_value("career", "id", current_career)
	cfg.set_value("career", "level", career_level)
	cfg.set_value("career", "xp", career_xp)
	cfg.set_value("career", "completed_shifts", completed_shifts)
	cfg.set_value("career", "last_shift_day", career_last_shift_day)
	cfg.set_value("together", "partner_name", partner_name)
	cfg.set_value("together", "duo_points", duo_points)
	cfg.set_value("together", "duo_stats", duo_stats)
	cfg.set_value("together", "memories", duo_memories)
	cfg.set_value("together", "shared_goal", shared_goal)
	cfg.set_value("together", "shared_goal_progress", shared_goal_progress)
	cfg.set_value("together", "decor_preset", decor_preset)
	cfg.set_value("together", "achievements", duo_achievements)
	cfg.set_value("social", "relationships", social_relationships)
	cfg.set_value("social", "memories", social_memories)
	cfg.set_value("social", "feed", social_feed)
	cfg.set_value("social", "npc_bonds", npc_bonds)
	cfg.set_value("social", "invitations", social_invitations)
	cfg.set_value("social", "neighborhood_events", neighborhood_events)
	cfg.set_value("social", "daily_life_events", daily_life_events)
	cfg.set_value("law", "heat", law_heat)
	cfg.set_value("law", "fine", outstanding_fine)
	cfg.set_value("law", "crime_record", crime_record)
	cfg.set_value("law", "stolen_goods", stolen_goods)
	cfg.set_value("cyber", "xp", cyber_xp)
	cfg.set_value("cyber", "level", cyber_level)
	cfg.set_value("cyber", "cases", cyber_cases_completed)
	return cfg.save(SAVE_PATH)

func load_game() -> int:
	var cfg = ConfigFile.new()
	var paths: Array[String] = [SAVE_PATH]
	for legacy in LEGACY_SAVE_PATHS:
		paths.append(str(legacy))
	var err = ERR_FILE_NOT_FOUND
	for path in paths:
		err = cfg.load(path)
		if err == OK:
			break
	if err != OK:
		return err

	var loaded_position: Variant = cfg.get_value("player", "position", checkpoint_position)
	if loaded_position is Vector3 and _safe_world_position(loaded_position):
		checkpoint_position = loaded_position
	money = clamp(int(cfg.get_value("game", "money", money)), 0, 1000000)
	inventory = _sanitize_inventory(cfg.get_value("game", "inventory", inventory))
	objective = str(cfg.get_value("game", "objective", objective)).strip_edges().left(180)
	time_of_day = clamp(float(cfg.get_value("game", "time_of_day", time_of_day)), 0.0, 23.999)
	world_day = clamp(int(cfg.get_value("game", "world_day", world_day)), 1, 1000000)
	var loaded_quality = str(cfg.get_value("game", "quality", quality_profile)).to_upper()
	quality_profile = loaded_quality if loaded_quality in ["LOW", "MEDIUM", "HIGH"] else "MEDIUM"
	world_states = _sanitize_world_states(cfg.get_value("world", "states", world_states))
	var loaded_weather = str(cfg.get_value("world", "weather_mode", weather_mode)).to_upper()
	if loaded_weather in ["CLEAR", "CLOUDY", "RAIN"]:
		weather_mode = loaded_weather
	story_chapter = clamp(int(cfg.get_value("progress", "story_chapter", story_chapter)), 0, 5)
	story_objective = str(cfg.get_value("progress", "story_objective", story_objective)).left(180)
	var loaded_flags: Variant = cfg.get_value("progress", "story_flags", story_flags)
	if loaded_flags is Dictionary and loaded_flags.size() <= 256:
		story_flags = loaded_flags.duplicate(true)

	var loaded_outfits: Variant = cfg.get_value("character", "owned_outfits", owned_outfits)
	owned_outfits.clear()
	if loaded_outfits is Array:
		for outfit in loaded_outfits.slice(0, 24):
			var clean_outfit = str(outfit).strip_edges().left(32)
			if not clean_outfit.is_empty() and clean_outfit not in owned_outfits:
				owned_outfits.append(clean_outfit)
	if "classic" not in owned_outfits:
		owned_outfits.append("classic")
	selected_outfit = str(cfg.get_value("character", "selected_outfit", selected_outfit)).left(32)
	if selected_outfit not in owned_outfits:
		selected_outfit = "classic"
	character_style = clamp(int(cfg.get_value("character", "style", character_style)), 0, 4)
	hair_style = clamp(int(cfg.get_value("character", "hair_style", hair_style)), 0, 3)
	var loaded_career = str(cfg.get_value("career", "id", current_career)).to_lower().left(32)
	current_career = loaded_career if loaded_career in ["freelance", "office", "creative", "service", "fitness"] else "freelance"
	career_xp = clamp(int(cfg.get_value("career", "xp", career_xp)), 0, 1000000)
	career_level = clamp(int(cfg.get_value("career", "level", 1 + int(career_xp / 120))), 1, 20)
	completed_shifts = clamp(int(cfg.get_value("career", "completed_shifts", completed_shifts)), 0, 1000000)
	var loaded_shift_days: Variant = cfg.get_value("career", "last_shift_day", career_last_shift_day)
	career_last_shift_day.clear()
	if loaded_shift_days is Dictionary:
		for raw_key in loaded_shift_days.keys():
			if career_last_shift_day.size() >= 16:
				break
			var clean_key = str(raw_key).strip_edges().to_lower().left(32)
			if not clean_key.is_empty():
				career_last_shift_day[clean_key] = clamp(int(loaded_shift_days[raw_key]), 0, world_day)

	partner_name = str(cfg.get_value("together", "partner_name", partner_name)).strip_edges().left(24)
	if partner_name.is_empty(): partner_name = "Partner"
	duo_points = clamp(int(cfg.get_value("together", "duo_points", duo_points)), 0, 1000000)
	duo_stats = _sanitize_duo_stats(cfg.get_value("together", "duo_stats", duo_stats))
	var loaded_memories: Variant = cfg.get_value("together", "memories", duo_memories)
	duo_memories.clear()
	if loaded_memories is Array:
		for entry in loaded_memories.slice(0, 30):
			duo_memories.append(str(entry).left(160))
	shared_goal = str(cfg.get_value("together", "shared_goal", shared_goal)).left(160)
	shared_goal_progress = clamp(int(cfg.get_value("together", "shared_goal_progress", shared_goal_progress)), 0, 128)
	decor_preset = clamp(int(cfg.get_value("together", "decor_preset", decor_preset)), 0, 3)
	var loaded_achievements: Variant = cfg.get_value("together", "achievements", duo_achievements)
	duo_achievements.clear()
	if loaded_achievements is Array:
		for achievement in loaded_achievements.slice(0, 32):
			duo_achievements.append(str(achievement).left(80))

	var loaded_relationships: Variant = cfg.get_value("social", "relationships", social_relationships)
	if loaded_relationships is Dictionary and loaded_relationships.size() <= 64:
		social_relationships = loaded_relationships.duplicate(true)
	var loaded_social_memories: Variant = cfg.get_value("social", "memories", social_memories)
	if loaded_social_memories is Dictionary and loaded_social_memories.size() <= 64:
		social_memories = loaded_social_memories.duplicate(true)
	var loaded_feed: Variant = cfg.get_value("social", "feed", social_feed)
	social_feed.clear()
	if loaded_feed is Array:
		for entry in loaded_feed.slice(0, 28):
			social_feed.append(str(entry).left(180))
	var loaded_bonds: Variant = cfg.get_value("social", "npc_bonds", npc_bonds)
	if loaded_bonds is Dictionary and loaded_bonds.size() <= 128:
		npc_bonds = loaded_bonds.duplicate(true)
	var loaded_invitations: Variant = cfg.get_value("social", "invitations", social_invitations)
	social_invitations.clear()
	if loaded_invitations is Array:
		for invite in loaded_invitations.slice(0, 18):
			if invite is Dictionary and invite.size() <= 16:
				social_invitations.append(invite.duplicate(true))
	var loaded_events: Variant = cfg.get_value("social", "neighborhood_events", neighborhood_events)
	neighborhood_events.clear()
	if loaded_events is Array:
		for event in loaded_events.slice(0, 16):
			if event is Dictionary and event.size() <= 16:
				neighborhood_events.append(event.duplicate(true))
	var loaded_daily: Variant = cfg.get_value("social", "daily_life_events", daily_life_events)
	daily_life_events.clear()
	if loaded_daily is Array:
		for event in loaded_daily.slice(0, 32):
			if event is Dictionary and event.size() <= 12:
				daily_life_events.append(event.duplicate(true))
	law_heat = clamp(int(cfg.get_value("law", "heat", law_heat)), 0, 5)
	outstanding_fine = clamp(int(cfg.get_value("law", "fine", outstanding_fine)), 0, 100000)
	crime_record.clear()
	var loaded_crimes: Variant = cfg.get_value("law", "crime_record", [])
	if loaded_crimes is Array:
		for event in loaded_crimes.slice(0, 40):
			if event is Dictionary and event.size() <= 12:
				crime_record.append(event.duplicate(true))
	stolen_goods.clear()
	var loaded_stolen: Variant = cfg.get_value("law", "stolen_goods", {})
	if loaded_stolen is Dictionary:
		for raw_key in loaded_stolen.keys():
			if stolen_goods.size() >= 32:
				break
			var key = str(raw_key).strip_edges().to_lower().left(40)
			var entry: Variant = loaded_stolen[raw_key]
			if not key.is_empty() and entry is Dictionary and entry.size() <= 8:
				stolen_goods[key] = {
					"title": str(entry.get("title", key)).left(60),
					"value": clamp(int(entry.get("value", 0)), 0, 100000),
					"count": clamp(int(entry.get("count", 1)), 1, 99)
				}
	cyber_xp = clamp(int(cfg.get_value("cyber", "xp", cyber_xp)), 0, 100000)
	cyber_level = clamp(int(cfg.get_value("cyber", "level", 1 + int(cyber_xp / 120))), 1, 25)
	cyber_cases_completed.clear()
	var loaded_cases: Variant = cfg.get_value("cyber", "cases", [])
	if loaded_cases is Array:
		for case_id in loaded_cases.slice(0, 48):
			var clean_case = str(case_id).strip_edges().to_lower().left(40)
			if not clean_case.is_empty() and clean_case not in cyber_cases_completed:
				cyber_cases_completed.append(clean_case)
	call_deferred("_restore_world_states")
	state_changed.emit()
	return OK

func _safe_world_position(value: Vector3) -> bool:
	return value.is_finite() and abs(value.x) < 450.0 and value.y > -20.0 and value.y < 80.0 and abs(value.z) < 450.0

func _sanitize_inventory(value: Variant) -> Dictionary:
	var out: Dictionary = {}
	if not (value is Dictionary):
		return out
	for raw_key in value.keys():
		if out.size() >= 128:
			break
		var key = str(raw_key).strip_edges().left(48)
		var amount = clamp(int(value[raw_key]), 0, 999)
		if not key.is_empty() and amount > 0:
			out[key] = amount
	return out

func _sanitize_duo_stats(value: Variant) -> Dictionary:
	var out: Dictionary = {}
	if not (value is Dictionary):
		return out
	for raw_key in value.keys():
		if out.size() >= 128:
			break
		var key = str(raw_key).strip_edges().left(64)
		if not key.is_empty():
			out[key] = clamp(int(value[raw_key]), 0, 10000)
	return out

func _sanitize_world_states(value: Variant) -> Dictionary:
	var out: Dictionary = {}
	if not (value is Dictionary):
		return out
	for raw_key in value.keys():
		if out.size() >= 256:
			break
		var key = str(raw_key).strip_edges().left(64)
		var state: Variant = value[raw_key]
		if key.is_empty():
			continue
		if state is Dictionary and state.size() <= 16:
			out[key] = state.duplicate(true)
		elif state is bool or state is int or state is float or state is String:
			out[key] = state
	return out

func _capture_world_states() -> void:
	world_states.clear()
	if get_tree() == null:
		return
	for node in get_tree().get_nodes_in_group("persistent_world"):
		if node.has_method("get_persistent_id") and node.has_method("get_persistent_state"):
			var pid = str(node.get_persistent_id())
			if not pid.is_empty():
				world_states[pid] = node.get_persistent_state()

func _restore_world_states() -> void:
	if get_tree() == null:
		return
	for node in get_tree().get_nodes_in_group("persistent_world"):
		if node.has_method("get_persistent_id") and node.has_method("apply_persistent_state"):
			var pid = str(node.get_persistent_id())
			if world_states.has(pid):
				node.apply_persistent_state(world_states[pid])
