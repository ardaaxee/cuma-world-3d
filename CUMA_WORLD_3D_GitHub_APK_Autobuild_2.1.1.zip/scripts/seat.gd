extends StaticBody3D

var seat_anchor: Vector3
var seat_yaw = 0.0

func setup(anchor: Vector3, yaw: float = 0.0) -> void:
	seat_anchor = anchor
	seat_yaw = yaw

func get_interaction_label() -> String:
	return "Otur / kalk"

func interact(player: Node) -> void:
	if player.has_method("toggle_sit"):
		player.toggle_sit(seat_anchor, seat_yaw)
