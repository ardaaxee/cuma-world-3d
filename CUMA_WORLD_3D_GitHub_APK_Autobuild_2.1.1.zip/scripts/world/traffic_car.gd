extends Node3D

var start_x = -24.0
var end_x = 24.0
var speed = 5.0
var direction = 1.0

func setup(a: float, b: float, drive_speed: float, initial_direction: float = 1.0) -> void:
	start_x = min(a, b)
	end_x = max(a, b)
	speed = drive_speed
	direction = 1.0 if initial_direction >= 0.0 else -1.0
	rotation.y = -PI * 0.5 if direction > 0.0 else PI * 0.5

func _process(delta: float) -> void:
	var red = _intersection_red()
	var approaching = (direction > 0.0 and position.x > -7.0 and position.x < -1.8) or (direction < 0.0 and position.x < 7.0 and position.x > 1.8)
	if red and approaching:
		return
	position.x += direction * speed * delta
	if position.x > end_x:
		position.x = start_x
	elif position.x < start_x:
		position.x = end_x

func _intersection_red() -> bool:
	# East/west traffic shares the 18-second city signal cycle.
	var t = fmod(Time.get_ticks_msec() / 1000.0, 18.0)
	return t >= 11.0

func set_simulation_enabled(enabled: bool) -> void:
	visible = enabled
	set_process(enabled)
