extends StaticBody3D

var persistent_id = "curtain"
var opened = false
var left_group: Node3D
var right_group: Node3D
var closed_left_x = 0.0
var closed_right_x = 0.0
var open_left_x = 0.0
var open_right_x = 0.0
var busy = false

func setup(id: String, left: Node3D, right: Node3D, closed_left: float, closed_right: float, open_left: float, open_right: float) -> void:
	persistent_id = id
	left_group = left
	right_group = right
	closed_left_x = closed_left
	closed_right_x = closed_right
	open_left_x = open_left
	open_right_x = open_right
	add_to_group("persistent_world")
	var shape = BoxShape3D.new()
	shape.size = Vector3(3.8, 2.4, 0.42)
	var collision = CollisionShape3D.new()
	collision.shape = shape
	add_child(collision)
	_register_network()

func _register_network() -> void:
	var net = get_node_or_null("/root/NetworkManager")
	if net == null:
		return
	net.register_world_interactable(persistent_id, global_position, ["toggle"])
	if not net.world_action_received.is_connected(_on_world_action_received):
		net.world_action_received.connect(_on_world_action_received)

func get_interaction_label() -> String:
	return "Perdeyi kapat" if opened else "Perdeyi aç"

func interact(_actor: Node) -> void:
	if busy:
		return
	var net = get_node_or_null("/root/NetworkManager")
	if net != null:
		net.request_world_action(persistent_id, "toggle")
	else:
		_set_open(not opened, true)

func _on_world_action_received(id: String, action: String) -> void:
	if id == persistent_id and action == "toggle" and not busy:
		_set_open(not opened, true)

func _set_open(value: bool, animate: bool) -> void:
	opened = value
	if left_group == null or right_group == null:
		return
	var lx = open_left_x if opened else closed_left_x
	var rx = open_right_x if opened else closed_right_x
	if not animate:
		left_group.position.x = lx
		right_group.position.x = rx
		return
	busy = true
	var tween = create_tween().set_parallel(true)
	tween.set_trans(Tween.TRANS_CUBIC)
	tween.set_ease(Tween.EASE_IN_OUT)
	tween.tween_property(left_group, "position:x", lx, 0.75)
	tween.tween_property(right_group, "position:x", rx, 0.75)
	tween.finished.connect(func(): busy = false)

func get_persistent_id() -> String:
	return persistent_id

func get_persistent_state() -> Dictionary:
	return {"open": opened}

func apply_persistent_state(state: Variant) -> void:
	if state is Dictionary:
		_set_open(bool(state.get("open", false)), false)
