extends Control

var streaks: Array[Dictionary] = []

func _ready() -> void:
	for i in range(78):
		streaks.append({"x": randf(), "y": randf(), "speed": randf_range(0.38, 0.82), "len": randf_range(12.0, 29.0)})
	set_process(true)

func _process(delta: float) -> void:
	for item in streaks:
		item["y"] = fmod(float(item["y"]) + float(item["speed"]) * delta, 1.08)
	queue_redraw()

func _draw() -> void:
	var s = size
	if s.x <= 0.0 or s.y <= 0.0:
		return
	for item in streaks:
		var p = Vector2(float(item["x"]) * s.x, float(item["y"]) * s.y)
		draw_line(p, p + Vector2(-5.0, float(item["len"])), Color(0.76,0.86,0.94,0.34), 1.2)
