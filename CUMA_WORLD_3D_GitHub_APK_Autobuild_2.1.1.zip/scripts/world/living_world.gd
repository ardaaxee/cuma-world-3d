extends Node

var cloud_speed = 0.35
var breeze_time = 0.0

func _process(delta: float) -> void:
	breeze_time += delta
	var clouds = get_tree().get_nodes_in_group("ambient_cloud")
	for cloud in clouds:
		var cloud_3d = cloud as Node3D
		if cloud_3d == null:
			continue
		cloud_3d.position.x += cloud_speed * delta
		if cloud_3d.position.x > 38.0:
			cloud_3d.position.x = -38.0

	var tree_tops = get_tree().get_nodes_in_group("tree_crown")
	for tree_top in tree_tops:
		var tree_3d = tree_top as Node3D
		if tree_3d == null:
			continue
		tree_3d.rotation.z = sin(breeze_time * 0.7 + tree_3d.global_position.x * 0.17) * 0.018

	var gs = get_node_or_null("/root/GameState")
	if gs == null:
		return
	var night = float(gs.time_of_day) >= 19.0 or float(gs.time_of_day) <= 6.0

	var street_lights = get_tree().get_nodes_in_group("street_night_light")
	for light_node in street_lights:
		var light_3d = light_node as Light3D
		if light_3d != null:
			light_3d.visible = night

	var window_lights = get_tree().get_nodes_in_group("building_window_light")
	for window_node in window_lights:
		var window_mesh = window_node as MeshInstance3D
		if window_mesh != null:
			window_mesh.visible = night
