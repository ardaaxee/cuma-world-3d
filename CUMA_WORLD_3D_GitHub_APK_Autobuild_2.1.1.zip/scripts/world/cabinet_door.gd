extends StaticBody3D

var persistent_id = "cabinet"
var opened = false
var closed_angle = 0.0
var open_delta = 92.0
var busy = false

func setup(id: String, size: Vector3, color: Color, hinge_right: bool = false) -> void:
	persistent_id = id
	closed_angle = rotation.y
	open_delta = -92.0 if hinge_right else 92.0
	add_to_group("persistent_world")
	var panel = MeshInstance3D.new()
	var mesh = BoxMesh.new()
	mesh.size = size
	panel.mesh = mesh
	panel.position.x = (-size.x * 0.5) if hinge_right else (size.x * 0.5)
	var mat = StandardMaterial3D.new()
	mat.albedo_color = color
	mat.roughness = 0.62
	panel.material_override = mat
	add_child(panel)
	# Raised inner panel gives the door furniture-like depth rather than a flat prototype slab.
	var inset = MeshInstance3D.new()
	var inset_mesh = BoxMesh.new()
	inset_mesh.size = Vector3(size.x * 0.70, size.y * 0.72, 0.025)
	inset.mesh = inset_mesh
	inset.position = panel.position + Vector3(0.0, 0.0, -size.z * 0.53)
	var inset_mat = StandardMaterial3D.new()
	inset_mat.albedo_color = color.darkened(0.045)
	inset_mat.roughness = 0.68
	inset.material_override = inset_mat
	add_child(inset)
	var handle = MeshInstance3D.new()
	var handle_mesh = CylinderMesh.new()
	handle_mesh.top_radius = 0.014
	handle_mesh.bottom_radius = 0.014
	handle_mesh.height = 0.18
	handle_mesh.radial_segments = 12
	handle.mesh = handle_mesh
	handle.rotation_degrees.x = 90.0
	handle.position = panel.position + Vector3((-size.x * 0.35) if hinge_right else (size.x * 0.35), 0.0, -size.z * 0.72)
	var hm = StandardMaterial3D.new()
	hm.albedo_color = Color("aeb2b4")
	hm.metallic = 0.82
	hm.roughness = 0.25
	handle.material_override = hm
	add_child(handle)
	var collision = CollisionShape3D.new()
	var shape = BoxShape3D.new()
	shape.size = size
	collision.shape = shape
	collision.position = panel.position
	add_child(collision)
	_register_network()

func _register_network() -> void:
	var net = get_node_or_null("/root/NetworkManager")
	if net == null:
		return
	net.register_world_interactable(persistent_id, global_position, ["toggle"])
	if not net.world_action_received.is_connected(_on_world_action_received):
		net.world_action_received.connect(_on_world_action_received)

func get_interaction_label() -> String:
	return "Dolabı kapat" if opened else "Dolabı aç"

func interact(_actor: Node) -> void:
	if busy:
		return
	var net = get_node_or_null("/root/NetworkManager")
	if net != null:
		net.request_world_action(persistent_id, "toggle")
	else:
		_set_open(not opened, true)

func _on_world_action_received(id: String, action: String) -> void:
	if id == persistent_id and action == "toggle" and not busy:
		_set_open(not opened, true)

func _set_open(value: bool, animate: bool) -> void:
	opened = value
	var target = closed_angle + deg_to_rad(open_delta) if opened else closed_angle
	if not animate:
		rotation.y = target
		return
	busy = true
	var tween = create_tween()
	tween.set_trans(Tween.TRANS_QUAD)
	tween.set_ease(Tween.EASE_IN_OUT)
	tween.tween_property(self, "rotation:y", target, 0.42)
	tween.finished.connect(func(): busy = false)

func get_persistent_id() -> String:
	return persistent_id

func get_persistent_state() -> Dictionary:
	return {"open": opened}

func apply_persistent_state(state: Variant) -> void:
	if state is Dictionary:
		_set_open(bool(state.get("open", false)), false)
