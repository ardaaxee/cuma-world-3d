extends Node

var world: Node3D
var root: Node3D
var oak_tex: Texture2D
var plaster_tex: Texture2D
var linen_tex: Texture2D

func setup(world_root: Node3D) -> void:
	world = world_root
	root = Node3D.new()
	root.name = "VisualRebuild20"
	world.add_child(root)
	oak_tex = load("res://assets/materials/oak_floor.png")
	plaster_tex = load("res://assets/materials/plaster.png")
	linen_tex = load("res://assets/materials/linen.png")
	_build_corridor()
	_build_wall_details()
	_build_ceiling_lights()

func _build_corridor() -> void:
	var runner = _mat(Color("766d64"), 0.96, 0.0, linen_tex)
	_panel(Vector3(1.72, 0.022, 14.8), Vector3(0.0, 0.026, -0.25), runner)
	var trim = _mat(Color("ebe8e1"), 0.90, 0.0, plaster_tex)
	_panel(Vector3(0.055, 0.15, 17.2), Vector3(-1.68, 0.075, 0.0), trim)
	_panel(Vector3(0.055, 0.15, 17.2), Vector3(1.68, 0.075, 0.0), trim)
	# Thin central ceiling reveal instead of large hanging primitives.
	_panel(Vector3(0.055, 0.045, 15.8), Vector3(0.0, 3.105, -0.2), _mat(Color("b6a58d"), 0.48, 0.25))

func _build_wall_details() -> void:
	var frame = _mat(Color("5b4a3d"), 0.72, 0.0, oak_tex)
	var art_a = _mat(Color("73818a"), 0.86)
	var art_b = _mat(Color("9b806c"), 0.86)
	var positions = [
		[-1.675, -7.7, art_a],
		[1.675, -3.8, art_b],
		[-1.675, 2.0, art_b],
		[1.675, 6.0, art_a]
	]
	for item in positions:
		var x = float(item[0])
		var z = float(item[1])
		var art: Material = item[2]
		_panel(Vector3(0.035, 0.82, 0.72), Vector3(x, 1.66, z), frame)
		var inward = 0.020 if x < 0.0 else -0.020
		_panel(Vector3(0.040, 0.68, 0.58), Vector3(x + inward, 1.66, z), art)

func _build_ceiling_lights() -> void:
	for z in [-7.2, -3.3, 0.6, 4.5, 7.6]:
		var fixture = MeshInstance3D.new()
		var mesh = CylinderMesh.new()
		mesh.top_radius = 0.13
		mesh.bottom_radius = 0.13
		mesh.height = 0.035
		mesh.radial_segments = 24
		fixture.mesh = mesh
		fixture.position = Vector3(0.0, 3.08, float(z))
		fixture.material_override = _emissive(Color("ffe2bd"), 1.35)
		root.add_child(fixture)
	# A few low-cost warm pools of light give faces and doors readable contrast.
	for z in [-5.2, 0.6, 6.2]:
		var light = OmniLight3D.new()
		light.position = Vector3(0.0, 2.72, float(z))
		light.light_color = Color("ffd9ad")
		light.light_energy = 0.72
		light.omni_range = 4.3
		light.shadow_enabled = false
		light.add_to_group("quality_extra_light")
		root.add_child(light)

func _panel(size: Vector3, pos: Vector3, material: Material) -> MeshInstance3D:
	var mi = MeshInstance3D.new()
	var mesh = BoxMesh.new()
	mesh.size = size
	mi.mesh = mesh
	mi.position = pos
	mi.material_override = material
	root.add_child(mi)
	return mi

func _mat(color: Color, roughness: float = 0.8, metallic: float = 0.0, texture: Texture2D = null) -> StandardMaterial3D:
	var mat = StandardMaterial3D.new()
	mat.albedo_color = color
	mat.roughness = roughness
	mat.metallic = metallic
	if texture != null:
		mat.albedo_texture = texture
	return mat

func _emissive(color: Color, energy: float) -> StandardMaterial3D:
	var mat = _mat(color, 0.38)
	mat.emission_enabled = true
	mat.emission = color
	mat.emission_energy_multiplier = energy
	return mat
