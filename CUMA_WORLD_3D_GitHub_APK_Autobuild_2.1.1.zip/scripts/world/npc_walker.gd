extends Node3D

const ProceduralHumanoidScript = preload("res://scripts/character/procedural_humanoid.gd")

var path_points: Array[Vector3] = []
var target_index = 0
var walk_speed = 1.25
var rig
var pause_until = 0
var idle_variant = 0

func setup(points: Array[Vector3], outfit_color: Color, skin_color: Color = Color("c99b78")) -> void:
	path_points = points
	walk_speed = randf_range(0.9, 1.55)
	idle_variant = randi_range(0, 2)
	rig = Node3D.new()
	rig.name = "ResidentOrganicRig"
	rig.set_script(ProceduralHumanoidScript)
	add_child(rig)
	rig.setup({
		"skin": skin_color,
		"top": outfit_color,
		"pants": outfit_color.darkened(0.34),
		"hair": Color("282421").lightened(randf_range(0.0, 0.08)),
		"shoes": Color("17181a"),
		"height_scale": randf_range(0.93, 1.04),
		"shoulder_scale": randf_range(0.93, 1.05)
	})
	if not path_points.is_empty():
		global_position = path_points[0]
		target_index = 1 % path_points.size()

func _process(delta: float) -> void:
	if path_points.size() < 2 or rig == null:
		return
	if Time.get_ticks_msec() < pause_until:
		rig.update_pose(delta, 0.0, false, 0.0, true, false, 0.0)
		return
	var target = path_points[target_index]
	var flat = target - global_position
	flat.y = 0.0
	if flat.length() < 0.32:
		target_index = (target_index + 1) % path_points.size()
		# Residents sometimes stop instead of walking endlessly like robots.
		if randf() < 0.42:
			pause_until = Time.get_ticks_msec() + randi_range(900, 3200)
			if idle_variant == 2 and randf() < 0.35:
				rig.play_emote("wave")
		return
	var dir = flat.normalized()
	global_position += dir * walk_speed * delta
	rotation.y = lerp_angle(rotation.y, atan2(-dir.x, -dir.z), min(1.0, delta * 5.5))
	rig.update_pose(delta, walk_speed, false, 0.0, true, false, 0.0)

func set_simulation_enabled(enabled: bool) -> void:
	visible = enabled
	set_process(enabled)
