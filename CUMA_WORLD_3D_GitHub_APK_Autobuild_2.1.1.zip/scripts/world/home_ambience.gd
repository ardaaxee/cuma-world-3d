extends Node

var elapsed = 0.0

func _process(delta: float) -> void:
	elapsed += delta
	# Tiny independent motion prevents a frozen showroom feel without physics cost.
	for node in get_tree().get_nodes_in_group("home_soft_motion"):
		if node is Node3D:
			node.rotation.z = sin(elapsed * 0.55 + float(node.get_instance_id() % 17)) * 0.008
	for node in get_tree().get_nodes_in_group("home_clock_hand"):
		if node is Node3D:
			node.rotation.z = -elapsed * 0.006
