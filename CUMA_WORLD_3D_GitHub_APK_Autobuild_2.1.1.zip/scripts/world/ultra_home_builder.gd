extends Node

const CabinetDoor = preload("res://scripts/world/cabinet_door.gd")
const CurtainController = preload("res://scripts/world/curtain_controller.gd")
const HomeAmbience = preload("res://scripts/world/home_ambience.gd")

var world: Node3D
var root: Node3D
var tile_tex: Texture2D
var walnut_tex: Texture2D
var linen_tex: Texture2D
var marble_tex: Texture2D
var backsplash_tex: Texture2D

func setup(world_root: Node3D) -> void:
	world = world_root
	root = Node3D.new()
	root.name = "UltraHome07"
	world.add_child(root)
	_load_textures()
	_build_entry()
	_build_living_room_layer()
	_build_kitchen_layer()
	_build_bathroom_layer()
	_build_bedroom_layer()
	_build_balcony_layer()
	_build_ceiling_and_lighting()
	_build_curtains()
	_build_micro_details()
	var ambience = Node.new()
	ambience.name = "HomeAmbience07"
	ambience.set_script(HomeAmbience)
	world.add_child(ambience)

func _load_textures() -> void:
	tile_tex = load("res://assets/materials/porcelain_tile.png")
	walnut_tex = load("res://assets/materials/walnut.png")
	linen_tex = load("res://assets/materials/linen.png")
	marble_tex = load("res://assets/materials/marble.png")
	backsplash_tex = load("res://assets/materials/backsplash.png")

func _build_entry() -> void:
	var walnut = _mat(Color("76513a"), 0.68, 0.0, walnut_tex)
	var metal = _mat(Color("3c4043"), 0.32, 0.72)
	# Slim console, wall mirror, catch-all tray and coat rail create a believable arrival zone.
	_panel(root, Vector3(1.45,0.10,0.42), Vector3(0.0,0.82,7.92), Vector3.ZERO, walnut)
	for x in [-0.58,0.58]:
		_cylinder(root,Vector3(x,0.40,7.92),0.025,0.78,metal)
	_panel(root,Vector3(0.55,0.035,0.25),Vector3(0.25,0.91,7.90),Vector3.ZERO,_mat(Color("b6a690"),0.62))
	_mirror(Vector3(0.0,1.75,8.76),Vector2(1.15,1.20),Vector3.ZERO)
	# Coat rack with pegs and soft hanging pieces.
	_panel(root,Vector3(1.75,0.055,0.055),Vector3(1.25,1.60,8.70),Vector3.ZERO,metal)
	for x in [0.68,1.02,1.36,1.70]:
		_cylinder(root,Vector3(x,1.48,8.61),0.018,0.20,metal,Vector3(90,0,0))
	for i in range(3):
		_capsule(root,Vector3(0.86+float(i)*0.40,1.07,8.58),0.15,0.70,_mat(Color.from_hsv(0.58+float(i)*0.07,0.20,0.45),0.96,0.0,linen_tex),Vector3.ZERO,Vector3(0.85,1.0,0.28))
	# Shoe rack with curved shoe silhouettes.
	for y in [0.18,0.42]:
		_panel(root,Vector3(1.35,0.05,0.38),Vector3(-1.05,y,7.92),Vector3.ZERO,walnut)
	for i in range(3):
		_capsule(root,Vector3(-1.42+float(i)*0.38,0.27,7.83),0.07,0.30,_mat(Color("292b2e"),0.84),Vector3(90,0,0),Vector3(1.20,1.0,0.85))

func _build_living_room_layer() -> void:
	var walnut = _mat(Color("694834"),0.70,0.0,walnut_tex)
	var warm = _mat(Color("d9d0c3"),0.98,0.0,linen_tex)
	# Media wall with shelves and vertical slats instead of a single TV block.
	for x in range(9):
		_panel(root,Vector3(0.055,2.05,0.08),Vector3(-9.0+float(x)*0.50,1.25,3.01),Vector3.ZERO,walnut)
	for y in [0.48,1.04,1.58]:
		_panel(root,Vector3(1.25,0.055,0.32),Vector3(-4.90,y,3.08),Vector3.ZERO,walnut)
	for i in range(6):
		var c = Color.from_hsv(0.04+float(i)*0.07,0.30,0.58)
		_panel(root,Vector3(0.07,0.25+float(i%2)*0.08,0.19),Vector3(-5.35+float(i)*0.17,0.68,2.90),Vector3(0,0,deg_to_rad(-4.0+float(i))),_mat(c,0.90))
	# Side table + lamp + soft throw.
	_cylinder(root,Vector3(-9.25,0.53,5.72),0.34,0.07,walnut)
	_cylinder(root,Vector3(-9.25,0.27,5.72),0.028,0.50,_mat(Color("373a3d"),0.32,0.72))
	_lamp(Vector3(-9.25,0.57,5.72),0.75)
	for i in range(5):
		_capsule(root,Vector3(-8.10+float(i)*0.12,1.10,6.00),0.045,0.72,warm,Vector3(0,0,90),Vector3(1.0,1.0,0.42))
	# Large woven rug overlay.
	_panel(root,Vector3(4.75,0.018,3.25),Vector3(-7.0,0.028,4.85),Vector3.ZERO,_mat(Color("a89d90"),0.99,0.0,linen_tex))

func _build_kitchen_layer() -> void:
	var cabinet_color = Color("dedad1")
	var walnut = _mat(Color("71503b"),0.68,0.0,walnut_tex)
	var marble = _mat(Color("c7c8c4"),0.36,0.0,marble_tex)
	var metal = _mat(Color("aeb2b4"),0.24,0.84)
	# Distinct porcelain floor zone and backsplash.
	_panel(root,Vector3(9.6,0.018,5.45),Vector3(6.8,0.024,4.9),Vector3.ZERO,_mat(Color("d5d4ce"),0.78,0.0,tile_tex))
	_panel(root,Vector3(4.75,1.15,0.035),Vector3(8.9,1.62,2.96),Vector3.ZERO,_mat(Color("dad8d0"),0.56,0.0,backsplash_tex))
	# Upper cabinets with real hinged doors.
	for i in range(4):
		var x = 7.45 + float(i)*1.05
		_panel(root,Vector3(0.98,0.92,0.42),Vector3(x,2.02,3.20),Vector3.ZERO,_mat(cabinet_color,0.72))
		_add_cabinet("upper_kitchen_%02d" % i, Vector3(x-0.45,2.02,2.975), Vector3(0.90,0.86,0.055), cabinet_color, false)
	# Lower cabinet doors are individually interactive and persistent/network synced.
	for i in range(5):
		var x = 7.10 + float(i)*0.90
		_add_cabinet("lower_kitchen_%02d" % i, Vector3(x-0.40,0.43,2.975), Vector3(0.80,0.72,0.055), cabinet_color, false)
	# Marble waterfall island sides, pendant lights and practical counter objects.
	_panel(root,Vector3(2.75,0.08,1.15),Vector3(6.3,0.98,4.95),Vector3.ZERO,marble)
	for x in [4.96,7.64]:
		_panel(root,Vector3(0.08,0.92,1.08),Vector3(x,0.50,4.95),Vector3.ZERO,marble)
	for x in [5.75,6.85]:
		_pendant(Vector3(x,2.05,4.95))
	# Cutting board, kettle, fruit bowl, soap and spice jars.
	_panel(root,Vector3(0.65,0.035,0.38),Vector3(8.0,0.955,3.45),Vector3.ZERO,walnut)
	_cylinder(root,Vector3(9.55,1.09,3.45),0.16,0.27,metal)
	_cylinder(root,Vector3(9.55,1.27,3.45),0.05,0.12,_mat(Color("333638"),0.38,0.4))
	_cylinder(root,Vector3(8.95,1.04,3.50),0.07,0.14,_mat(Color("e9e5d9"),0.58))
	for i in range(4):
		_sphere(root,Vector3(6.0+float(i%2)*0.20,1.08,4.80+float(i/2)*0.18),Vector3(0.11,0.10,0.11),_mat(Color.from_hsv(0.02+float(i)*0.10,0.72,0.82),0.82))
	# Fridge seams, handles and toe kick.
	_panel(root,Vector3(0.95,0.035,0.018),Vector3(10.7,1.08,5.085),Vector3.ZERO,_mat(Color("6a6d70"),0.30,0.72))
	_panel(root,Vector3(4.65,0.09,0.08),Vector3(8.9,0.06,3.0),Vector3.ZERO,_mat(Color("393b3d"),0.48,0.45))

func _build_bathroom_layer() -> void:
	var tile = _mat(Color("d6d7d2"),0.70,0.0,tile_tex)
	var marble = _mat(Color("c7c8c4"),0.35,0.0,marble_tex)
	var chrome = _mat(Color("b7bcc0"),0.17,0.92)
	# Proper tiled wet zone.
	_panel(root,Vector3(10.0,0.018,2.65),Vector3(6.8,0.025,7.55),Vector3.ZERO,tile)
	_panel(root,Vector3(4.4,2.35,0.035),Vector3(8.45,1.42,8.80),Vector3.ZERO,tile)
	# Frameless shower screen and rail.
	_panel(root,Vector3(0.035,1.82,1.75),Vector3(7.05,1.05,7.75),Vector3.ZERO,_glass(Color(0.70,0.82,0.86,0.20)))
	_cylinder(root,Vector3(7.05,1.08,6.86),0.018,1.82,chrome)
	# Floating shelf with bottles and folded towels.
	_panel(root,Vector3(1.20,0.055,0.30),Vector3(10.35,1.48,8.58),Vector3.ZERO,marble)
	for i in range(3):
		_cylinder(root,Vector3(10.00+float(i)*0.28,1.65,8.58),0.045+float(i)*0.006,0.25,_mat(Color.from_hsv(0.48+float(i)*0.08,0.18,0.82),0.42))
	for i in range(3):
		_panel(root,Vector3(0.55,0.07,0.30),Vector3(5.25,0.72+float(i)*0.075,8.45),Vector3.ZERO,_mat(Color("ded8cc"),0.98,0.0,linen_tex))
	# Larger polished mirror and vanity lighting.
	_mirror(Vector3(4.30,1.78,7.57),Vector2(1.25,1.05),Vector3.ZERO)
	for x in [3.86,4.74]:
		_sphere(root,Vector3(x,2.38,7.48),Vector3(0.09,0.09,0.09),_emissive(Color("ffe1b4"),2.0))

func _build_bedroom_layer() -> void:
	var wood = _mat(Color("71503b"),0.72,0.0,walnut_tex)
	var linen = _mat(Color("d7d0c5"),0.99,0.0,linen_tex)
	var bedrooms = [Vector3(-7.2,0,-6.35),Vector3(-7.0,0,-0.05),Vector3(7.0,0,-6.15),Vector3(7.2,0,-0.15)]
	for idx in range(bedrooms.size()):
		var p: Vector3 = bedrooms[idx]
		# Two bedside tables with lamps, books and charging-phone shapes.
		for side in [-1.0,1.0]:
			var table_pos = p + Vector3(side*1.95,0.42,1.05)
			_cylinder(root,table_pos,0.31,0.08,wood)
			_cylinder(root,table_pos-Vector3(0,0.21,0),0.025,0.40,_mat(Color("35383a"),0.35,0.7))
			_lamp(table_pos+Vector3(0,0.10,0),0.45)
		# Linen throw across the foot of each bed.
		for i in range(7):
			_capsule(root,p+Vector3(-0.62+float(i)*0.20,0.83,-0.72),0.035,1.55,linen,Vector3(90,0,0),Vector3(1.0,1.0,0.45))
		# Soft headboard wall panel.
		for i in range(5):
			_capsule(root,p+Vector3(-0.80+float(i)*0.40,1.52,1.59),0.14,1.20,_mat(Color("8b796b"),0.98,0.0,linen_tex),Vector3.ZERO,Vector3(1.0,1.0,0.38))
	# Full-length mirror and dressing stool in master room.
	_mirror(Vector3(11.70,1.45,0.35),Vector2(0.82,1.85),Vector3(0,-90,0))
	_cylinder(root,Vector3(9.55,0.48,1.00),0.30,0.12,_mat(Color("77695e"),0.96,0.0,linen_tex))
	for x in [9.35,9.75]:
		_cylinder(root,Vector3(x,0.23,1.0),0.018,0.45,_mat(Color("323537"),0.34,0.70))

func _build_balcony_layer() -> void:
	var deck = _mat(Color("785b43"),0.78,0.0,walnut_tex)
	# Narrow deck boards hide the single-slab prototype floor visually.
	for i in range(20):
		_panel(root,Vector3(0.46,0.026,4.55),Vector3(-10.72+float(i)*0.49,0.025,11.40),Vector3.ZERO,deck)
	# Planter troughs, lanterns and a small outdoor lounge bench.
	for x in [-10.2,-9.1,-3.4,-2.3]:
		_panel(root,Vector3(0.75,0.42,0.42),Vector3(x,0.22,13.12),Vector3.ZERO,_mat(Color("6f5747"),0.90))
		for j in range(3):
			_capsule(root,Vector3(x-0.22+float(j)*0.22,0.72,13.12),0.045,0.52,_mat(Color("52704f"),0.98),Vector3(25.0-float(j)*10.0,0,float(j)*14.0),Vector3(0.8,1.0,0.45))
	_panel(root,Vector3(2.15,0.16,0.72),Vector3(-8.5,0.50,10.05),Vector3.ZERO,_mat(Color("555b60"),0.96,0.0,linen_tex))
	for x in [-9.35,-7.65]:
		_cylinder(root,Vector3(x,0.25,10.05),0.025,0.48,_mat(Color("34383b"),0.34,0.72))
	for p in [Vector3(-10.35,0.42,9.75),Vector3(-2.0,0.42,13.0)]:
		_cylinder(root,p,0.12,0.16,_mat(Color("4a4039"),0.75))
		_sphere(root,p+Vector3(0,0.18,0),Vector3(0.13,0.16,0.13),_emissive(Color("ffd59c"),1.35))

func _build_ceiling_and_lighting() -> void:
	# Ceiling fixtures have visible geometry even when LOW mode disables extra lights.
	for p in [Vector3(-7.0,3.02,5.5),Vector3(0.0,3.02,1.2),Vector3(-7.0,3.02,-5.8),Vector3(7.0,3.02,-5.8)]:
		_cylinder(root,p,0.24,0.07,_mat(Color("e7e2d8"),0.58))
		_sphere(root,p-Vector3(0,0.08,0),Vector3(0.12,0.07,0.12),_emissive(Color("ffe5bf"),1.45))
	# Tiny clock in corridor.
	_cylinder(root,Vector3(1.69,1.80,2.2),0.27,0.035,_mat(Color("ece9e2"),0.56),Vector3(0,0,90))
	var hand = _panel(root,Vector3(0.18,0.018,0.025),Vector3(1.66,1.80,2.2),Vector3(0,deg_to_rad(90),0),_mat(Color("343638"),0.35))
	hand.add_to_group("home_clock_hand")

func _build_curtains() -> void:
	# Main living-room curtain is interactive and synced. Side bedroom curtains are decorative soft folds.
	_make_interactive_curtain("living_curtain",Vector3(-6.0,1.63,8.72),4.0,2.15)
	_make_interactive_curtain("bedroom_left_curtain",Vector3(-7.3,1.63,-8.72),3.85,1.95)
	_make_interactive_curtain("bedroom_right_curtain",Vector3(7.2,1.63,-8.72),3.85,1.95)

func _make_interactive_curtain(id: String, pos: Vector3, width: float, height: float) -> void:
	var body = StaticBody3D.new()
	body.name = id
	body.position = pos
	body.set_script(CurtainController)
	root.add_child(body)
	var left = Node3D.new()
	left.name = "LeftFabric"
	body.add_child(left)
	var right = Node3D.new()
	right.name = "RightFabric"
	body.add_child(right)
	var cloth = _mat(Color("d7d1c7"),0.99,0.0,linen_tex)
	for i in range(7):
		var off = float(i)*0.085
		_capsule(left,Vector3(-width*0.24+off,0,0),0.055,height,cloth,Vector3.ZERO,Vector3(1.0,1.0,0.46))
		_capsule(right,Vector3(width*0.24-off,0,0),0.055,height,cloth,Vector3.ZERO,Vector3(1.0,1.0,0.46))
	left.add_to_group("home_soft_motion")
	right.add_to_group("home_soft_motion")
	body.setup(id,left,right,0.0,0.0,-width*0.23,width*0.23)

func _build_micro_details() -> void:
	# Switches, outlets, plants, baskets, toiletries, remotes and books add scale cues.
	var plate = _mat(Color("e8e5df"),0.56)
	for p in [Vector3(-1.60,1.15,-5.8),Vector3(-1.60,1.15,0.1),Vector3(1.60,1.15,-5.8),Vector3(1.60,1.15,0.1),Vector3(1.60,1.15,5.5)]:
		_panel(root,Vector3(0.09,0.15,0.025),p,Vector3.ZERO,plate)
	for p in [Vector3(-10.8,0.35,-2.7),Vector3(-10.8,0.35,2.6),Vector3(10.8,0.35,-2.7),Vector3(10.8,0.35,2.6)]:
		_panel(root,Vector3(0.13,0.08,0.022),p,Vector3.ZERO,plate)
	# Living-room remote and magazine.
	_panel(root,Vector3(0.07,0.025,0.20),Vector3(-6.72,0.78,4.13),Vector3(0,deg_to_rad(18),0),_mat(Color("2b2e30"),0.42))
	_panel(root,Vector3(0.30,0.022,0.40),Vector3(-7.18,0.79,4.20),Vector3(0,deg_to_rad(-14),0),_mat(Color("a88c74"),0.86))
	# Laundry basket and rolled towels.
	_cylinder(root,Vector3(10.5,0.31,6.65),0.30,0.55,_mat(Color("8c765f"),0.90))
	for i in range(4):
		_capsule(root,Vector3(10.45+float(i%2)*0.14,0.66,6.65+float(i/2)*0.12),0.07,0.32,_mat(Color("d9d5cc"),0.99,0.0,linen_tex),Vector3(90,0,0),Vector3(1.0,1.0,0.75))

func _add_cabinet(id: String, pivot_pos: Vector3, size: Vector3, color: Color, hinge_right: bool) -> void:
	var door = StaticBody3D.new()
	door.name = id
	door.position = pivot_pos
	door.set_script(CabinetDoor)
	root.add_child(door)
	door.setup(id,size,color,hinge_right)

func _lamp(base_pos: Vector3, height: float) -> void:
	var metal = _mat(Color("4a4d50"),0.32,0.72)
	_cylinder(root,base_pos+Vector3(0,height*0.45,0),0.018,height*0.88,metal)
	_cylinder(root,base_pos+Vector3(0,height*0.90,0),0.20,0.24,_mat(Color("d8cbbb"),0.96,0.0,linen_tex),Vector3.ZERO,Vector3(1.0,1.0,0.78))
	_sphere(root,base_pos+Vector3(0,height*0.89,0),Vector3(0.06,0.06,0.06),_emissive(Color("ffe1b0"),1.45))
	var light = OmniLight3D.new()
	light.position = base_pos + Vector3(0,height*0.82,0)
	light.light_color = Color("ffd9aa")
	light.light_energy = 0.42
	light.omni_range = 2.4
	light.shadow_enabled = false
	light.add_to_group("quality_extra_light")
	root.add_child(light)

func _pendant(pos: Vector3) -> void:
	var metal = _mat(Color("34373a"),0.30,0.75)
	_cylinder(root,pos+Vector3(0,0.42,0),0.012,0.84,metal)
	_cylinder(root,pos,0.23,0.28,_mat(Color("4a4d50"),0.38,0.58),Vector3.ZERO,Vector3(1.0,1.0,0.78))
	_sphere(root,pos-Vector3(0,0.10,0),Vector3(0.08,0.08,0.08),_emissive(Color("ffdca7"),1.8))
	var light = OmniLight3D.new()
	light.position = pos - Vector3(0,0.18,0)
	light.light_color = Color("ffd5a0")
	light.light_energy = 0.62
	light.omni_range = 3.2
	light.shadow_enabled = false
	light.add_to_group("quality_extra_light")
	root.add_child(light)

func _mirror(pos: Vector3, size: Vector2, rot_deg: Vector3) -> void:
	var frame = _mat(Color("47494a"),0.28,0.72)
	var mirror = _mat(Color("b8c4c8"),0.06,0.92)
	_panel(root,Vector3(size.x+0.06,size.y+0.06,0.035),pos,Vector3(deg_to_rad(rot_deg.x),deg_to_rad(rot_deg.y),deg_to_rad(rot_deg.z)),frame)
	_panel(root,Vector3(size.x,size.y,0.042),pos+Vector3(0,0,-0.022),Vector3(deg_to_rad(rot_deg.x),deg_to_rad(rot_deg.y),deg_to_rad(rot_deg.z)),mirror)

func _glass(color: Color) -> StandardMaterial3D:
	var mat = _mat(color,0.08,0.08)
	mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	mat.cull_mode = BaseMaterial3D.CULL_DISABLED
	return mat

func _mat(color: Color, roughness: float = 0.8, metallic: float = 0.0, texture: Texture2D = null) -> StandardMaterial3D:
	var mat = StandardMaterial3D.new()
	mat.albedo_color = color
	mat.roughness = roughness
	mat.metallic = metallic
	if texture != null:
		mat.albedo_texture = texture
	return mat

func _emissive(color: Color, energy: float) -> StandardMaterial3D:
	var mat = _mat(color,0.38)
	mat.emission_enabled = true
	mat.emission = color
	mat.emission_energy_multiplier = energy
	return mat

func _panel(parent: Node3D, size: Vector3, pos: Vector3, rot: Vector3, material: Material) -> MeshInstance3D:
	var mi = MeshInstance3D.new()
	var mesh = BoxMesh.new()
	mesh.size = size
	mi.mesh = mesh
	mi.position = pos
	mi.rotation = rot
	mi.material_override = material
	parent.add_child(mi)
	return mi

func _sphere(parent: Node3D, pos: Vector3, scale_value: Vector3, material: Material) -> MeshInstance3D:
	var mi = MeshInstance3D.new()
	var mesh = SphereMesh.new()
	mesh.radius = 0.5
	mesh.height = 1.0
	mi.mesh = mesh
	mi.position = pos
	mi.scale = scale_value * 2.0
	mi.material_override = material
	parent.add_child(mi)
	return mi

func _cylinder(parent: Node3D, pos: Vector3, radius: float, height: float, material: Material, rot_deg: Vector3 = Vector3.ZERO, scale_value: Vector3 = Vector3.ONE) -> MeshInstance3D:
	var mi = MeshInstance3D.new()
	var mesh = CylinderMesh.new()
	mesh.top_radius = radius
	mesh.bottom_radius = radius
	mesh.height = height
	mesh.radial_segments = 18
	mi.mesh = mesh
	mi.position = pos
	mi.rotation_degrees = rot_deg
	mi.scale = scale_value
	mi.material_override = material
	parent.add_child(mi)
	return mi

func _capsule(parent: Node3D, pos: Vector3, radius: float, height: float, material: Material, rot_deg: Vector3 = Vector3.ZERO, scale_value: Vector3 = Vector3.ONE) -> MeshInstance3D:
	var mi = MeshInstance3D.new()
	var mesh = CapsuleMesh.new()
	mesh.radius = radius
	mesh.height = max(height,radius*2.05)
	mesh.radial_segments = 18
	mesh.rings = 6
	mi.mesh = mesh
	mi.position = pos
	mi.rotation_degrees = rot_deg
	mi.scale = scale_value
	mi.material_override = material
	parent.add_child(mi)
	return mi
