extends Node

signal weather_changed(mode: String)

const MODES = ["CLEAR", "CLOUDY", "RAIN"]
var mode = "CLEAR"
var rain_overlay: Control
var weather_label: Label
var lightning_timer = 0.0
var base_sun_energy = 1.25

func setup(_world: Node) -> void:
	add_to_group("weather_manager")
	var gs = get_node_or_null("/root/GameState")
	if gs != null and MODES.has(str(gs.weather_mode).to_upper()):
		mode = str(gs.weather_mode).to_upper()
	var net = get_node_or_null("/root/NetworkManager")
	if net != null and not net.weather_mode_received.is_connected(set_weather):
		net.weather_mode_received.connect(set_weather)
	if gs != null and not gs.state_changed.is_connected(_sync_from_state):
		gs.state_changed.connect(_sync_from_state)
	_build_overlay()
	_apply_weather()

func _process(delta: float) -> void:
	if Input.is_key_pressed(KEY_R) and not get_meta("r_down", false):
		set_meta("r_down", true)
		cycle_weather()
	elif not Input.is_key_pressed(KEY_R):
		set_meta("r_down", false)
	if mode == "RAIN":
		lightning_timer -= delta
		if lightning_timer <= 0.0:
			lightning_timer = randf_range(8.0, 18.0)
			_flash_lightning()

func cycle_weather() -> String:
	var idx = MODES.find(mode)
	var next_mode: String = MODES[(idx + 1) % MODES.size()]
	var net = get_node_or_null("/root/NetworkManager")
	if net != null and net.is_online():
		net.request_weather(next_mode)
	else:
		set_weather(next_mode)
	return next_mode

func set_weather(value: String) -> void:
	var clean = value.to_upper()
	if not MODES.has(clean):
		return
	mode = clean
	var gs = get_node_or_null("/root/GameState")
	if gs != null and gs.weather_mode != mode:
		gs.weather_mode = mode
		gs.state_changed.emit()
	_apply_weather()
	weather_changed.emit(mode)

func get_weather_label() -> String:
	if mode == "RAIN":
		return "YAĞMURLU"
	if mode == "CLOUDY":
		return "BULUTLU"
	return "AÇIK"

func _apply_weather() -> void:
	for node in get_tree().get_nodes_in_group("world_environment"):
		if node is WorldEnvironment and node.environment != null:
			var env = node.environment
			match mode:
				"RAIN":
					env.background_color = Color("536274")
					env.ambient_light_color = Color("9aabba")
					env.ambient_light_energy = 0.48
					env.fog_density = 0.024
				"CLOUDY":
					env.background_color = Color("78889a")
					env.ambient_light_color = Color("bbc4cc")
					env.ambient_light_energy = 0.60
					env.fog_density = 0.014
				_:
					env.background_color = Color("91b3d3")
					env.ambient_light_color = Color("dce9f4")
					env.ambient_light_energy = 0.72
					env.fog_density = 0.008
	for sun in get_tree().get_nodes_in_group("quality_shadow"):
		if sun is DirectionalLight3D:
			sun.light_energy = 0.48 if mode == "RAIN" else (0.82 if mode == "CLOUDY" else base_sun_energy)
	if rain_overlay != null:
		rain_overlay.visible = mode == "RAIN"
	if weather_label != null:
		weather_label.text = "HAVA • " + get_weather_label() + "  (R)"

func _build_overlay() -> void:
	var layer = CanvasLayer.new()
	layer.name = "WeatherHUD"
	layer.layer = 18
	add_child(layer)
	weather_label = Label.new()
	weather_label.position = Vector2(20, 98)
	weather_label.add_theme_font_size_override("font_size", 13)
	weather_label.mouse_filter = Control.MOUSE_FILTER_IGNORE
	layer.add_child(weather_label)
	rain_overlay = Control.new()
	rain_overlay.set_script(preload("res://scripts/world/rain_overlay.gd"))
	rain_overlay.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	rain_overlay.mouse_filter = Control.MOUSE_FILTER_IGNORE
	layer.add_child(rain_overlay)

func _flash_lightning() -> void:
	for node in get_tree().get_nodes_in_group("world_environment"):
		if node is WorldEnvironment and node.environment != null:
			var env = node.environment
			var old = env.ambient_light_energy
			env.ambient_light_energy = min(1.4, old + 0.55)
			await get_tree().create_timer(0.09).timeout
			if mode == "RAIN":
				env.ambient_light_energy = 0.48

func _sync_from_state() -> void:
	var gs = get_node_or_null("/root/GameState")
	if gs != null:
		var desired = str(gs.weather_mode).to_upper()
		if MODES.has(desired) and desired != mode:
			mode = desired
			_apply_weather()
