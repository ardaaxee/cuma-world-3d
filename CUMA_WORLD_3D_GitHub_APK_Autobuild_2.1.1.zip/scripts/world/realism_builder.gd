extends Node

const NPCWalker = preload("res://scripts/world/npc_walker.gd")
const TrafficCar = preload("res://scripts/world/traffic_car.gd")
const LivingWorld = preload("res://scripts/world/living_world.gd")

var world: Node3D
var realism_root: Node3D
var plaster_tex: Texture2D
var oak_tex: Texture2D
var asphalt_tex: Texture2D
var concrete_tex: Texture2D
var fabric_tex: Texture2D
var stone_tex: Texture2D

func setup(world_root: Node3D) -> void:
	world = world_root
	realism_root = Node3D.new()
	realism_root.name = "RealismOverhaul"
	world.add_child(realism_root)
	_load_textures()
	_upgrade_existing_surfaces()
	_hide_placeholder_visuals()
	_build_architecture_details()
	_build_living_room()
	_build_bedrooms()
	_build_kitchen()
	_build_bathroom()
	_build_balcony()
	_build_lived_in_details()
	_build_interaction_details()
	_build_neighborhood()
	_build_park()
	_build_traffic()
	_build_people()
	_build_sky_life()
	var ambient = Node.new()
	ambient.name = "LivingWorldController"
	ambient.set_script(LivingWorld)
	world.add_child(ambient)

func _load_textures() -> void:
	plaster_tex = load("res://assets/materials/plaster.png")
	oak_tex = load("res://assets/materials/oak_floor.png")
	asphalt_tex = load("res://assets/materials/asphalt.png")
	concrete_tex = load("res://assets/materials/concrete.png")
	fabric_tex = load("res://assets/materials/fabric.png")
	stone_tex = load("res://assets/materials/stone.png")

func _upgrade_existing_surfaces() -> void:
	_apply_material_to_named("HouseFloor", _mat(Color("b58b68"), 0.72, 0.0, oak_tex))
	_apply_material_to_named("OutdoorGround", _mat(Color("65745b"), 0.98))
	_apply_material_to_named("Road", _mat(Color("3d4144"), 0.96, 0.0, asphalt_tex))
	_apply_material_to_named("Sidewalk", _mat(Color("a1a09b"), 0.92, 0.0, concrete_tex))
	var plaster_nodes = [
		"BackWall", "LeftWall", "RightWall", "FrontA", "FrontB", "FrontC", "Ceiling",
		"LeftCorridor01", "LeftCorridor02", "LeftCorridor03", "LeftCorridor04",
		"RightCorridor01", "RightCorridor02", "RightCorridor03", "RightCorridor04", "RightCorridor05",
		"LeftSeparatorBack", "LeftSeparatorFront", "RightSeparatorBack", "RightSeparatorFront", "RightBathSeparator"
	]
	for n in plaster_nodes:
		_apply_material_to_named(n, _mat(Color("e3e0d9"), 0.93, 0.0, plaster_tex))

func _apply_material_to_named(node_name: String, material: Material) -> void:
	var node = world.get_node_or_null(node_name)
	if node == null:
		return
	for child in node.get_children():
		if child is MeshInstance3D:
			child.material_override = material

func _hide_placeholder_visuals() -> void:
	var names = [
		"Bed1", "Bed1Headboard", "Bed2", "Bed2Headboard", "Bed3", "Bed3Headboard", "Bed4", "Bed4Headboard",
		"Wardrobe1", "Wardrobe3", "MasterWardrobe", "Desk2", "Desk2Leg",
		"SofaSeat", "SofaBack", "CoffeeTable", "CoffeeTableLeg", "TVUnit",
		"KitchenCounter", "KitchenCounter2", "KitchenIsland", "Fridge",
		"BathTub", "BathroomSink", "BathroomCabinet", "HallBench",
		"BalconyTable", "BalconyTableLeg", "BalconySeatA", "BalconySeatB",
		"MarketShell", "CinemaShell", "ArcadeShell", "PhotoBoothShell", "SnackCafeShell",
		"GiftStation", "DecorStation", "TogetherBoard"
	]
	for n in names:
		var node = world.get_node_or_null(n)
		if node != null:
			_hide_meshes_recursive(node)
	for child in world.get_children():
		if str(child.name).begins_with("Skyline_"):
			_hide_meshes_recursive(child)
		if str(child.name).begins_with("Duo_"):
			_hide_meshes_recursive(child)
			for c in child.get_children():
				if c is Label3D:
					c.visible = false

func _hide_meshes_recursive(node: Node) -> void:
	for child in node.get_children():
		if child is MeshInstance3D:
			child.visible = false
		_hide_meshes_recursive(child)

func _build_architecture_details() -> void:
	var wood = _mat(Color("7c5c43"), 0.72, 0.0, oak_tex)
	var trim = _mat(Color("edeae3"), 0.88, 0.0, plaster_tex)
	# Skirting and ceiling trims create depth instead of flat placeholder walls.
	for z in [-8.86, 8.86]:
		_panel(realism_root, Vector3(23.4, 0.10, 0.07), Vector3(0.0, 0.06, z), Vector3.ZERO, trim)
	for x in [-11.86, 11.86]:
		_panel(realism_root, Vector3(0.07, 0.10, 17.5), Vector3(x, 0.06, 0.0), Vector3.ZERO, trim)
	# Proper rectangular door trim. The old version used horizontal cylinders here,
	# which appeared as long rods sticking out of corridor walls.
	for p in [Vector3(-1.8,1.18,-5.3),Vector3(-1.8,1.18,0.7),Vector3(-1.8,1.18,6.5),Vector3(1.8,1.18,-5.3),Vector3(1.8,1.18,0.7),Vector3(1.8,1.18,5.0),Vector3(1.8,1.18,8.2)]:
		_panel(realism_root, Vector3(0.08, 2.52, 0.08), p + Vector3(0.0, 0.02, 0.74), Vector3.ZERO, wood)
		_panel(realism_root, Vector3(0.08, 2.52, 0.08), p + Vector3(0.0, 0.02, -0.74), Vector3.ZERO, wood)
		_panel(realism_root, Vector3(0.08, 0.08, 1.56), p + Vector3(0.0, 1.25, 0.0), Vector3.ZERO, wood)
	# Rugs soften large empty floor zones.
	_flat_disc(Vector3(-7.0, 0.018, 4.75), 2.1, Color("6e777a"), Vector3(1.35, 1.0, 0.72))
	_flat_disc(Vector3(6.7, 0.018, 4.6), 1.6, Color("b29a7d"), Vector3(1.20, 1.0, 0.70))
	# Window frames and curtains.
	_build_window(Vector3(-6.0, 1.65, 8.90), Vector2(4.1, 2.25), true)
	_build_window(Vector3(-7.3, 1.65, -8.90), Vector2(4.0, 2.0), false)
	_build_window(Vector3(7.2, 1.65, -8.90), Vector2(4.0, 2.0), false)

func _build_window(pos: Vector3, size: Vector2, curtains: bool) -> void:
	var frame = _mat(Color("34383b"), 0.42, 0.12)
	_panel(realism_root, Vector3(size.x, 0.05, 0.07), pos + Vector3(0,size.y*0.5,0), Vector3.ZERO, frame)
	_panel(realism_root, Vector3(size.x, 0.05, 0.07), pos - Vector3(0,size.y*0.5,0), Vector3.ZERO, frame)
	_panel(realism_root, Vector3(0.05, size.y, 0.07), pos + Vector3(size.x*0.5,0,0), Vector3.ZERO, frame)
	_panel(realism_root, Vector3(0.05, size.y, 0.07), pos - Vector3(size.x*0.5,0,0), Vector3.ZERO, frame)
	_cylinder(realism_root, pos + Vector3(0.0, size.y*0.62, -0.08), 0.025, size.x + 0.45, frame, Vector3(0,0,90))
	if curtains:
		var cloth = _mat(Color("d5d0c6"), 0.98)
		for side in [-1.0, 1.0]:
			for i in range(4):
				_capsule(realism_root, pos + Vector3(side*(size.x*0.5+0.17-i*0.07),0,-0.13), 0.055, size.y*0.92, cloth, Vector3.ZERO, Vector3(1.0,1.0,0.55))

func _build_living_room() -> void:
	var fabric = _mat(Color("3d474f"), 0.98, 0.0, fabric_tex)
	var cushion = _mat(Color("8c7462"), 0.98, 0.0, fabric_tex)
	var wood = _mat(Color("79563d"), 0.76, 0.0, oak_tex)
	# Rounded sectional sofa.
	_capsule(realism_root, Vector3(-7.0,0.48,5.85), 0.48, 3.7, fabric, Vector3(0,0,90), Vector3(1.0,1.0,1.25))
	_capsule(realism_root, Vector3(-7.0,0.98,6.38), 0.32, 3.65, fabric, Vector3(0,0,90), Vector3(1.0,1.0,0.7))
	for x in [-8.1,-7.0,-5.9]:
		_sphere(realism_root, Vector3(x,0.92,5.97), Vector3(0.48,0.40,0.18), _mat(Color("465159"),0.98,0.0,fabric_tex))
	_sphere(realism_root, Vector3(-8.25,1.02,5.72), Vector3(0.32,0.32,0.13), cushion)
	var cushion_dark = _mat(Color("8c7462").darkened(0.08), 0.98, 0.0, fabric_tex)
	_sphere(realism_root, Vector3(-5.75,1.02,5.72), Vector3(0.32,0.32,0.13), cushion_dark)
	# Circular coffee table.
	_cylinder(realism_root, Vector3(-7.0,0.57,4.18), 0.86, 0.10, wood)
	for a in [0.0, 2.1, 4.2]:
		_cylinder(realism_root, Vector3(-7.0+cos(a)*0.48,0.30,4.18+sin(a)*0.48), 0.035, 0.55, _mat(Color("2f302f"),0.35,0.65))
	# Low TV console and sound bar details.
	_panel(realism_root, Vector3(3.2,0.38,0.52), Vector3(-7.0,0.22,3.35), Vector3.ZERO, wood)
	_cylinder(realism_root, Vector3(-7.0,0.55,3.07), 0.055, 1.45, _mat(Color("191a1b"),0.40), Vector3(0,0,90))
	# Floor lamp.
	_cylinder(realism_root, Vector3(-9.5,1.02,4.7), 0.035, 1.95, _mat(Color("3a3c3f"),0.35,0.6))
	_sphere(realism_root, Vector3(-9.5,2.0,4.7), Vector3(0.32,0.24,0.32), _mat(Color("f0dec0"),0.95))
	# Plant and wall art.
	_plant(Vector3(-10.0,0.0,6.9), 1.15)
	_wall_art(Vector3(-9.8,1.75,8.72), Vector2(1.4,0.9), Color("8a6d59"))

func _build_bedrooms() -> void:
	_soft_bed(Vector3(-7.2,0.31,-6.35), Color("d8d3ca"), Color("8d7563"))
	_soft_bed(Vector3(-7.0,0.31,-0.05), Color("c8d0d8"), Color("63778a"))
	_soft_bed(Vector3(7.0,0.31,-6.15), Color("d0c9bf"), Color("846d5b"))
	_soft_bed(Vector3(7.2,0.31,-0.15), Color("d8cdd0"), Color("8a6470"))
	# Real desk silhouette: wooden top + tapered cylindrical legs + monitor stand.
	var wood = _mat(Color("76543c"),0.76,0.0,oak_tex)
	_panel(realism_root, Vector3(2.35,0.10,0.78), Vector3(-10.0,0.78,1.62), Vector3.ZERO, wood)
	for x in [-10.95,-9.05]:
		for z in [1.32,1.92]:
			_cylinder(realism_root, Vector3(x,0.39,z),0.035,0.76,_mat(Color("333537"),0.35,0.55))
	_panel(realism_root, Vector3(0.95,0.58,0.045), Vector3(-10.0,1.27,1.41), Vector3.ZERO, _mat(Color("181a1d"),0.32,0.15))
	_cylinder(realism_root,Vector3(-10.0,0.96,1.54),0.035,0.34,_mat(Color("303235"),0.4,0.5))
	# Wardrobes gain framed doors, plinth and metal handles instead of one giant block.
	_wardrobe(Vector3(-10.1,0.0,-7.9), 2.55, Color("795d49"))
	_wardrobe(Vector3(10.0,0.0,-7.8), 2.75, Color("6e5a4b"))
	_wardrobe(Vector3(10.0,0.0,1.65), 3.05, Color("806a59"))
	_plant(Vector3(-10.4,0.0,-4.2),0.9)
	_plant(Vector3(10.4,0.0,-4.1),0.9)

func _soft_bed(pos: Vector3, linen: Color, accent: Color) -> void:
	var frame = _mat(Color("765640"),0.78,0.0,oak_tex)
	var cloth = _mat(linen,0.99,0.0,fabric_tex)
	var accent_mat = _mat(accent,0.98,0.0,fabric_tex)
	_capsule(realism_root,pos+Vector3(0,0.34,0),0.68,3.3,cloth,Vector3(90,0,0),Vector3(1.55,1.0,0.42))
	_capsule(realism_root,pos+Vector3(0,0.53,-0.10),0.60,2.95,accent_mat,Vector3(90,0,0),Vector3(1.48,1.0,0.24))
	for x in [-0.52,0.52]:
		_sphere(realism_root,pos+Vector3(x,0.78,1.18),Vector3(0.48,0.16,0.35),_mat(linen.lightened(0.08),0.99,0.0,fabric_tex))
	for x in [-0.85,0.85]:
		_cylinder(realism_root,pos+Vector3(x,0.18,1.48),0.055,0.36,frame)
		_cylinder(realism_root,pos+Vector3(x,0.88,1.48),0.055,1.05,frame)
	_cylinder(realism_root,pos+Vector3(0,1.20,1.48),0.055,1.75,frame,Vector3(0,0,90))

func _wardrobe(pos: Vector3, width: float, color: Color) -> void:
	var body = _mat(color,0.76,0.0,oak_tex)
	var dark = _mat(Color("2e3032"),0.35,0.55)
	_panel(realism_root,Vector3(width,2.38,0.64),pos+Vector3(0,1.19,0),Vector3.ZERO,body)
	_panel(realism_root,Vector3(width+0.08,0.08,0.72),pos+Vector3(0,2.40,0),Vector3.ZERO,_mat(color.lightened(0.04),0.74,0.0,oak_tex))
	for x in [-width*0.24,width*0.24]:
		_cylinder(realism_root,pos+Vector3(x,1.18,-0.34),0.018,0.22,dark)

func _build_kitchen() -> void:
	var cabinet = _mat(Color("dad6ce"),0.78,0.0,plaster_tex)
	var counter = _mat(Color("a6a29b"),0.48,0.0,stone_tex)
	var metal = _mat(Color("a8adb0"),0.26,0.82)
	# Cabinet run with individual fronts and handles.
	for i in range(5):
		var x = 7.1 + i * 0.9
		_panel(realism_root,Vector3(0.84,0.80,0.70),Vector3(x,0.42,3.36),Vector3.ZERO,cabinet)
		_cylinder(realism_root,Vector3(x,0.52,2.99),0.012,0.24,metal,Vector3(0,0,90))
	_panel(realism_root,Vector3(4.65,0.10,0.82),Vector3(8.9,0.88,3.35),Vector3.ZERO,counter)
	# Sink basin + faucet.
	_cylinder(realism_root,Vector3(8.7,0.95,3.35),0.34,0.06,metal)
	_cylinder(realism_root,Vector3(9.12,1.12,3.55),0.026,0.42,metal)
	_cylinder(realism_root,Vector3(9.12,1.32,3.42),0.026,0.30,metal,Vector3(90,0,0))
	# Hob burners.
	for x in [7.25,7.72]:
		for z in [3.18,3.55]:
			_cylinder(realism_root,Vector3(x,0.95,z),0.16,0.018,_mat(Color("202224"),0.36,0.20))
	# Island and stools.
	_panel(realism_root,Vector3(2.65,0.12,1.08),Vector3(6.3,0.92,4.95),Vector3.ZERO,counter)
	_panel(realism_root,Vector3(2.35,0.78,0.78),Vector3(6.3,0.42,4.95),Vector3.ZERO,_mat(Color("746252"),0.82,0.0,oak_tex))
	for x in [5.55,6.35,7.15]:
		_cylinder(realism_root,Vector3(x,0.52,5.85),0.23,0.08,_mat(Color("403a35"),0.8))
		_cylinder(realism_root,Vector3(x,0.26,5.85),0.025,0.50,metal)
	# Rounded refrigerator front details.
	_panel(realism_root,Vector3(1.02,2.20,0.88),Vector3(10.7,1.12,5.55),Vector3.ZERO,_mat(Color("c7cbcd"),0.28,0.74))
	_cylinder(realism_root,Vector3(10.30,1.28,5.08),0.018,0.58,metal)
	_plant(Vector3(4.45,0.91,3.55),0.55)

func _build_bathroom() -> void:
	var ceramic = _mat(Color("edf0ee"),0.22)
	var chrome = _mat(Color("b8bdc0"),0.18,0.92)
	# Tub made from a rounded outer shell silhouette.
	_capsule(realism_root,Vector3(8.6,0.38,7.70),0.42,1.82,ceramic,Vector3(0,0,90),Vector3(1.0,0.78,1.15))
	_capsule(realism_root,Vector3(8.6,0.52,7.70),0.30,1.55,_mat(Color("b8d1d8"),0.12),Vector3(0,0,90),Vector3(1.0,0.30,1.0))
	# Sink and vanity.
	_panel(realism_root,Vector3(1.16,0.64,0.55),Vector3(4.3,0.36,7.15),Vector3.ZERO,_mat(Color("6d594a"),0.80,0.0,oak_tex))
	_cylinder(realism_root,Vector3(4.3,0.78,7.15),0.38,0.16,ceramic)
	_cylinder(realism_root,Vector3(4.3,1.03,7.38),0.022,0.34,chrome)
	# Mirror with thin metal surround.
	_cylinder(realism_root,Vector3(4.3,1.77,7.58),0.55,0.035,_mat(Color("aeb9bd"),0.08,0.65),Vector3(90,0,0),Vector3(1.0,1.0,1.0))
	# Towels + plant.
	_capsule(realism_root,Vector3(5.15,1.20,8.55),0.08,0.72,_mat(Color("d9d3c8"),0.99,0.0,fabric_tex),Vector3(0,0,90),Vector3(1,1,0.35))
	_plant(Vector3(10.4,0.0,8.2),0.7)

func _build_balcony() -> void:
	var metal = _mat(Color("34393d"),0.34,0.65)
	var wood = _mat(Color("76523b"),0.78,0.0,oak_tex)
	# Replace slab rails with thin metal posts and glass-like spacing.
	var old_rails = ["BalconyFrontRail","BalconyLeftRail","BalconyRightRail"]
	for n in old_rails:
		var node = world.get_node_or_null(n)
		if node != null:
			_hide_meshes_recursive(node)
	for x in range(-11,-1):
		_cylinder(realism_root,Vector3(float(x)+0.5,0.56,13.72),0.018,1.05,metal)
	_cylinder(realism_root,Vector3(-6.0,1.08,13.72),0.035,9.9,metal,Vector3(0,0,90))
	for z in [9.3,10.3,11.3,12.3,13.3]:
		_cylinder(realism_root,Vector3(-11.0,0.56,z),0.018,1.05,metal)
	# Bistro table and chairs.
	_cylinder(realism_root,Vector3(-6.0,0.73,11.8),0.55,0.08,wood)
	_cylinder(realism_root,Vector3(-6.0,0.37,11.8),0.035,0.70,metal)
	for x in [-7.15,-4.85]:
		_cylinder(realism_root,Vector3(x,0.47,11.8),0.28,0.10,_mat(Color("555b60"),0.92,0.0,fabric_tex))
		_cylinder(realism_root,Vector3(x,0.23,11.8),0.025,0.44,metal)
		_capsule(realism_root,Vector3(x,0.83,12.03),0.16,0.58,_mat(Color("555b60"),0.92,0.0,fabric_tex),Vector3.ZERO,Vector3(1,1,0.48))
	for p in [Vector3(-10.2,0,12.7),Vector3(-3.0,0,12.7),Vector3(-8.7,0,10.0)]:
		_plant(p,0.8)

func _build_lived_in_details() -> void:
	# Small objects break the sterile procedural look.
	for p in [Vector3(-6.8,0.72,4.18),Vector3(-7.25,0.73,4.10)]:
		_cylinder(realism_root,p,0.075,0.13,_mat(Color("e8e2d7"),0.55))
	_cylinder(realism_root,Vector3(-6.8,0.86,4.18),0.035,0.08,_mat(Color("51483f"),0.55))
	# Books on bedroom desk.
	for i in range(3):
		_panel(realism_root,Vector3(0.42,0.035,0.22),Vector3(-9.45,0.86+i*0.045,1.65),Vector3(0,deg_to_rad(7.0*i),0),_mat(Color.from_hsv(0.05+0.1*i,0.32,0.58),0.92))
	# Shoes near entrance.
	for x in [-0.28,0.28]:
		_capsule(realism_root,Vector3(x,0.09,7.55),0.09,0.34,_mat(Color("26282b"),0.86),Vector3(90,0,0),Vector3(1.1,1.0,1.0))
	# Framed photos represented as neutral art panels, not external personal images.
	_wall_art(Vector3(-11.72,1.62,4.8),Vector2(0.65,0.90),Color("6e7d85"),Vector3(0,90,0))
	_wall_art(Vector3(11.72,1.62,-1.0),Vector2(0.70,0.70),Color("9a826d"),Vector3(0,-90,0))

func _build_interaction_details() -> void:
	# Interactions stay functional through invisible colliders, but visible geometry now looks like real objects.
	var dark = _mat(Color("1b1e21"),0.28,0.25)
	var metal = _mat(Color("777d80"),0.28,0.75)
	# Study computer at the daily-task collider.
	_panel(realism_root,Vector3(0.82,0.50,0.035),Vector3(-10.0,1.28,1.36),Vector3.ZERO,dark)
	_cylinder(realism_root,Vector3(-10.0,0.98,1.43),0.028,0.32,metal)
	_cylinder(realism_root,Vector3(-10.0,0.82,1.43),0.16,0.025,metal)
	# Small rounded key fob instead of a floating cube marker.
	_capsule(realism_root,Vector3(-6.0,0.88,11.8),0.045,0.20,_emissive(Color("58b7d9"),0.65),Vector3(90,0,0),Vector3(1.35,1.0,1.0))
	# Physical light switch plate.
	_panel(realism_root,Vector3(0.08,0.19,0.035),Vector3(1.55,1.25,6.86),Vector3.ZERO,_mat(Color("e8e5de"),0.58))
	_cylinder(realism_root,Vector3(1.55,1.25,6.835),0.018,0.07,_mat(Color("b9b7b2"),0.42),Vector3(90,0,0))

func _build_neighborhood() -> void:
	var building_colors = [Color("b9b0a5"),Color("9fa9ae"),Color("c4b7a7"),Color("9b928e"),Color("b6b7ad")]
	var positions = [Vector3(-26,0,8),Vector3(26,0,7),Vector3(-28,0,-8),Vector3(28,0,-9),Vector3(-18,0,30),Vector3(18,0,31)]
	for i in range(positions.size()):
		_build_apartment(positions[i],8.0+float(i%3)*1.7,7.5+float(i%2)*1.8,9.0+float(i%3)*2.0,building_colors[i%building_colors.size()])
	# Storefronts over old shells: glass, awnings, doors, signage geometry.
	_build_storefront(Vector3(8.2,0,18.4),6.9,4.3,Color("d4cdbf"),Color("4e8b66"))
	_build_storefront(Vector3(-8.5,0,18.6),8.3,4.7,Color("423b43"),Color("9b5663"))
	_build_storefront(Vector3(14.8,0,18.4),5.9,4.0,Color("49405d"),Color("7a68a0"))
	_build_cafe(Vector3(-15.2,0,13.5))
	# Road markings and pedestrian crossing.
	for x in range(-18,19,4):
		_panel(realism_root,Vector3(1.9,0.018,0.11),Vector3(float(x),0.012,22.5),Vector3.ZERO,_mat(Color("e5dfc7"),0.85))
	for x in range(-3,4):
		_panel(realism_root,Vector3(0.48,0.020,2.9),Vector3(float(x)*0.72,0.014,20.5),Vector3.ZERO,_mat(Color("e8e7df"),0.85))
	# Street trees and lamps.
	for p in [Vector3(-18,0,15),Vector3(-12,0,15),Vector3(-4,0,15),Vector3(4,0,15),Vector3(12,0,15),Vector3(20,0,15),Vector3(-18,0,27),Vector3(-10,0,27),Vector3(0,0,27),Vector3(10,0,27),Vector3(20,0,27)]:
		_tree(p,1.0+randf()*0.25)
	for x in [-20.0,-10.0,0.0,10.0,20.0]:
		_street_lamp(Vector3(x,0,18.0))

func _build_storefront(pos: Vector3, width: float, depth: float, wall_color: Color, accent: Color) -> void:
	var wall = _mat(wall_color,0.85,0.0,plaster_tex)
	_panel(realism_root,Vector3(width,3.4,depth),pos+Vector3(0,1.7,0),Vector3.ZERO,wall)
	var glass = _glass_material(Color(0.35,0.55,0.68,0.48))
	for x in [-width*0.28,width*0.28]:
		_panel(realism_root,Vector3(width*0.38,2.0,0.035),pos+Vector3(x,1.25,-depth*0.505),Vector3.ZERO,glass)
	_panel(realism_root,Vector3(1.1,2.25,0.05),pos+Vector3(0,1.15,-depth*0.515),Vector3.ZERO,_mat(Color("33383b"),0.40,0.45))
	_panel(realism_root,Vector3(width*0.72,0.18,0.75),pos+Vector3(0,2.72,-depth*0.60),Vector3(deg_to_rad(-12),0,0),_mat(accent,0.72,0.0,fabric_tex))
	for x in [-width*0.44,width*0.44]:
		_cylinder(realism_root,pos+Vector3(x,1.75,-depth*0.53),0.025,3.1,_mat(Color("34383b"),0.38,0.5))

func _build_cafe(pos: Vector3) -> void:
	_build_storefront(pos,5.1,3.7,Color("8c7a67"),Color("b4865f"))
	for x in [-1.1,1.1]:
		_cylinder(realism_root,pos+Vector3(x,0.42,-2.8),0.36,0.07,_mat(Color("77553b"),0.8,0.0,oak_tex))
		_cylinder(realism_root,pos+Vector3(x,0.21,-2.8),0.025,0.40,_mat(Color("333538"),0.35,0.6))

func _build_apartment(pos: Vector3, width: float, depth: float, height: float, color: Color) -> void:
	var mat = _mat(color,0.92,0.0,plaster_tex)
	_panel(realism_root,Vector3(width,height,depth),pos+Vector3(0,height*0.5,0),Vector3.ZERO,mat)
	var dark = _mat(Color("273038"),0.36,0.15)
	var lit = _emissive(Color("f5c982"),1.4)
	var floors = int(height/2.6)
	for floor_index in range(floors):
		for column in range(3):
			var x = -width*0.30 + column*width*0.30
			var y = 1.35 + floor_index*2.45
			_panel(realism_root,Vector3(width*0.18,1.0,0.04),pos+Vector3(x,y,-depth*0.505),Vector3.ZERO,dark)
			var glow = _panel(realism_root,Vector3(width*0.15,0.82,0.045),pos+Vector3(x,y,-depth*0.512),Vector3.ZERO,lit)
			glow.add_to_group("building_window_light")
	# Entrance canopy.
	_panel(realism_root,Vector3(1.7,0.10,0.9),pos+Vector3(0,2.25,-depth*0.63),Vector3(deg_to_rad(-5),0,0),_mat(Color("4a4d4e"),0.4,0.45))

func _build_park() -> void:
	# Keep park patch but add organic vegetation, path, benches and a small fountain.
	var patch = world.get_node_or_null("ParkPatch")
	if patch != null:
		_apply_material_to_named("ParkPatch",_mat(Color("5f7c55"),0.98))
	for p in [Vector3(11,0,10),Vector3(15,0,8.5),Vector3(18,0,12.5),Vector3(13,0,14.2),Vector3(18,0,15.0)]:
		_tree(p,0.8)
	# Curving path approximated by overlapping stone discs.
	for i in range(9):
		var t = float(i)/8.0
		var p = Vector3(10.0+t*9.0,0.012,13.8-sin(t*PI)*3.6)
		_flat_disc(p,0.82,Color("b7b0a5"),Vector3(1.25,1,0.72))
	_bench(Vector3(13.2,0,12.8),-20.0)
	_bench(Vector3(17.2,0,13.8),155.0)
	_cylinder(realism_root,Vector3(15.4,0.18,11.2),1.0,0.24,_mat(Color("a9a5a0"),0.70,0.0,stone_tex))
	_cylinder(realism_root,Vector3(15.4,0.30,11.2),0.72,0.10,_mat(Color("7ea7b2"),0.12))
	_cylinder(realism_root,Vector3(15.4,0.65,11.2),0.09,0.72,_mat(Color("b5b2ad"),0.65,0.0,stone_tex))

func _build_traffic() -> void:
	_add_car(Vector3(-14,0.55,23.5),Color("334a68"),true,false)
	_add_car(Vector3(11,0.55,21.7),Color("7c3e38"),true,false)
	_add_car(Vector3(22,0.55,23.5),Color("dad9d4"),true,false)
	_add_car(Vector3(-22,0.55,21.7),Color("44494e"),true,false)
	# Two low-frequency moving cars make the street feel alive.
	_add_car(Vector3(-20,0.55,22.5),Color("506c55"),false,true,4.2,1.0)
	_add_car(Vector3(18,0.55,24.1),Color("7b725f"),false,true,3.5,-1.0)

func _add_car(pos: Vector3, color: Color, parked: bool, moving: bool, speed: float = 0.0, dir: float = 1.0) -> void:
	var car = Node3D.new()
	car.position = pos
	realism_root.add_child(car)
	var paint = _mat(color,0.28,0.62)
	_capsule(car,Vector3(0,0.34,0),0.42,2.6,paint,Vector3(0,0,90),Vector3(1.0,0.55,1.55))
	_sphere(car,Vector3(0,0.72,0),Vector3(0.72,0.34,0.62),_mat(color.lightened(0.08),0.26,0.56))
	var glass = _glass_material(Color(0.22,0.33,0.40,0.70))
	_sphere(car,Vector3(0,0.82,-0.08),Vector3(0.55,0.22,0.48),glass)
	var rubber = _mat(Color("1c1d1e"),0.86)
	for x in [-0.86,0.86]:
		for z in [-0.54,0.54]:
			_cylinder(car,Vector3(x,0.16,z),0.19,0.12,rubber,Vector3(0,0,90))
	if parked:
		car.rotation.y = deg_to_rad(90.0)
	if moving:
		car.add_to_group("quality_traffic")
		car.set_script(TrafficCar)
		car.setup(-24.0,24.0,speed,dir)

func _build_people() -> void:
	var routes: Array = [
		[Vector3(-18,0,16),Vector3(-3,0,16),Vector3(8,0,16),Vector3(18,0,16)],
		[Vector3(18,0,27),Vector3(4,0,27),Vector3(-12,0,27),Vector3(-20,0,27)],
		[Vector3(11,0,9),Vector3(18,0,10),Vector3(17,0,15),Vector3(12,0,14)],
		[Vector3(-16,0,12),Vector3(-10,0,16),Vector3(-2,0,16),Vector3(-9,0,16)],
		[Vector3(5,0,16),Vector3(10,0,16),Vector3(15,0,16),Vector3(9,0,16)],
		[Vector3(-8,0,27),Vector3(0,0,27),Vector3(8,0,27),Vector3(0,0,27)],
		[Vector3(-20,0,18),Vector3(-15,0,14),Vector3(-9,0,16),Vector3(-14,0,19)],
		[Vector3(2,0,13),Vector3(8,0,12),Vector3(14,0,10),Vector3(8,0,14)]
	]
	var colors = [Color("506d83"),Color("7c5b69"),Color("65744f"),Color("795f47"),Color("5f596f"),Color("4b6a64"),Color("6d5660"),Color("536a78")]
	for i in range(routes.size()):
		var npc = Node3D.new()
		npc.name = "Resident_%02d" % i
		npc.add_to_group("quality_crowd")
		npc.set_script(NPCWalker)
		realism_root.add_child(npc)
		var typed_route: Array[Vector3] = []
		for p in routes[i]:
			typed_route.append(p)
		npc.setup(typed_route,colors[i])

func _build_sky_life() -> void:
	# Layered soft clouds; no billboard placeholders.
	for i in range(7):
		var cloud = Node3D.new()
		cloud.name = "Cloud_%02d" % i
		cloud.position = Vector3(-30.0+i*10.0,12.0+float(i%3)*1.2,-12.0+float(i%4)*10.0)
		cloud.add_to_group("ambient_cloud")
		realism_root.add_child(cloud)
		var cloud_mat = _mat(Color(1.0,1.0,1.0,0.78),0.98)
		cloud_mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
		for j in range(4):
			_sphere(cloud,Vector3(float(j)*0.65-0.9,sin(float(j))*0.20,0.0),Vector3(0.85,0.35,0.60),cloud_mat)

func _tree(pos: Vector3, scale_value: float) -> void:
	var trunk_mat = _mat(Color("66513e"),0.96,0.0,oak_tex)
	var leaves = _mat(Color("476747"),0.98)
	_cylinder(realism_root,pos+Vector3(0,1.15*scale_value,0),0.13*scale_value,2.3*scale_value,trunk_mat)
	var crown = Node3D.new()
	crown.position = pos + Vector3(0,2.75*scale_value,0)
	crown.add_to_group("tree_crown")
	realism_root.add_child(crown)
	_sphere(crown,Vector3(0,0,0),Vector3(0.72,0.82,0.70)*scale_value,leaves)
	_sphere(crown,Vector3(0.48,0.05,0.12),Vector3(0.52,0.62,0.50)*scale_value,_mat(Color("557754"),0.98))
	_sphere(crown,Vector3(-0.44,0.0,-0.10),Vector3(0.54,0.65,0.52)*scale_value,_mat(Color("3f6041"),0.98))

func _street_lamp(pos: Vector3) -> void:
	var metal = _mat(Color("33373a"),0.36,0.72)
	_cylinder(realism_root,pos+Vector3(0,1.55,0),0.045,3.1,metal)
	_cylinder(realism_root,pos+Vector3(0.30,3.05,0),0.028,0.62,metal,Vector3(0,0,90))
	_sphere(realism_root,pos+Vector3(0.61,3.03,0),Vector3(0.16,0.12,0.16),_emissive(Color("ffdca2"),2.2))
	var light = OmniLight3D.new()
	light.position = pos + Vector3(0.61,2.9,0)
	light.light_color = Color("ffd7a0")
	light.light_energy = 1.2
	light.omni_range = 6.0
	light.shadow_enabled = false
	light.visible = false
	light.add_to_group("street_night_light")
	realism_root.add_child(light)

func _bench(pos: Vector3, yaw: float) -> void:
	var bench = Node3D.new()
	bench.position = pos
	bench.rotation_degrees.y = yaw
	realism_root.add_child(bench)
	var wood = _mat(Color("76533b"),0.84,0.0,oak_tex)
	var metal = _mat(Color("36393b"),0.42,0.58)
	for z in [-0.18,0.18]:
		_capsule(bench,Vector3(0,0.55,z),0.07,1.65,wood,Vector3(0,0,90),Vector3(1,1,0.65))
		_capsule(bench,Vector3(0,0.92,z+0.18),0.055,1.65,wood,Vector3(0,0,90),Vector3(1,1,0.65))
	for x in [-0.65,0.65]:
		_cylinder(bench,Vector3(x,0.27,0),0.025,0.54,metal)

func _plant(pos: Vector3, scale_value: float) -> void:
	var pot = _mat(Color("8b654c"),0.90)
	_cylinder(realism_root,pos+Vector3(0,0.23*scale_value,0),0.22*scale_value,0.46*scale_value,pot)
	var green = _mat(Color("4f704d"),0.98)
	for i in range(7):
		var a = float(i)/7.0*TAU
		var leaf_pos = pos+Vector3(cos(a)*0.18,0.58+float(i%3)*0.11,sin(a)*0.18)*scale_value
		_capsule(realism_root,leaf_pos,0.07*scale_value,0.58*scale_value,green,Vector3(30.0*cos(a),0,rad_to_deg(-a)),Vector3(0.75,1,0.45))

func _wall_art(pos: Vector3, size: Vector2, color: Color, rot: Vector3 = Vector3.ZERO) -> void:
	var frame = _mat(Color("3e3934"),0.64,0.15)
	var art = _mat(color,0.90)
	_panel(realism_root,Vector3(size.x+0.08,size.y+0.08,0.035),pos,rot,frame)
	_panel(realism_root,Vector3(size.x,size.y,0.042),pos+Vector3(0,0,-0.024),rot,art)

func _flat_disc(pos: Vector3, radius: float, color: Color, scale_value: Vector3 = Vector3.ONE) -> void:
	_cylinder(realism_root,pos,radius,0.025,_mat(color,0.96,0.0,fabric_tex),Vector3.ZERO,scale_value)

func _mat(color: Color, roughness: float = 0.8, metallic: float = 0.0, texture: Texture2D = null) -> StandardMaterial3D:
	var mat = StandardMaterial3D.new()
	mat.albedo_color = color
	mat.roughness = roughness
	mat.metallic = metallic
	if texture != null:
		mat.albedo_texture = texture
	return mat

func _emissive(color: Color, energy: float) -> StandardMaterial3D:
	var mat = _mat(color,0.42)
	mat.emission_enabled = true
	mat.emission = color
	mat.emission_energy_multiplier = energy
	return mat

func _glass_material(color: Color) -> StandardMaterial3D:
	var mat = _mat(color,0.10,0.08)
	mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	mat.cull_mode = BaseMaterial3D.CULL_DISABLED
	return mat

func _panel(parent: Node3D, size: Vector3, pos: Vector3, rot: Vector3, material: Material) -> MeshInstance3D:
	var mi = MeshInstance3D.new()
	var mesh = BoxMesh.new()
	mesh.size = size
	mi.mesh = mesh
	mi.position = pos
	mi.rotation = rot
	mi.material_override = material
	parent.add_child(mi)
	return mi

func _sphere(parent: Node3D, pos: Vector3, scale_value: Vector3, material: Material) -> MeshInstance3D:
	var mi = MeshInstance3D.new()
	var mesh = SphereMesh.new()
	mesh.radius = 0.5
	mesh.height = 1.0
	mi.mesh = mesh
	mi.position = pos
	mi.scale = scale_value * 2.0
	mi.material_override = material
	parent.add_child(mi)
	return mi

func _cylinder(parent: Node3D, pos: Vector3, radius: float, height: float, material: Material, rot_deg: Vector3 = Vector3.ZERO, scale_value: Vector3 = Vector3.ONE) -> MeshInstance3D:
	var mi = MeshInstance3D.new()
	var mesh = CylinderMesh.new()
	mesh.top_radius = radius
	mesh.bottom_radius = radius
	mesh.height = height
	mesh.radial_segments = 18
	mi.mesh = mesh
	mi.position = pos
	mi.rotation_degrees = rot_deg
	mi.scale = scale_value
	mi.material_override = material
	parent.add_child(mi)
	return mi

func _capsule(parent: Node3D, pos: Vector3, radius: float, height: float, material: Material, rot_deg: Vector3 = Vector3.ZERO, scale_value: Vector3 = Vector3.ONE) -> MeshInstance3D:
	var mi = MeshInstance3D.new()
	var mesh = CapsuleMesh.new()
	mesh.radius = radius
	mesh.height = max(height,radius*2.05)
	mesh.radial_segments = 18
	mesh.rings = 6
	mi.mesh = mesh
	mi.position = pos
	mi.rotation_degrees = rot_deg
	mi.scale = scale_value
	mi.material_override = material
	parent.add_child(mi)
	return mi
