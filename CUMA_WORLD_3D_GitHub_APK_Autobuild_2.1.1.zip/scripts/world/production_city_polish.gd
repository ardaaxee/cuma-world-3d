extends Node

var world: Node3D
var root: Node3D
var concrete: StandardMaterial3D
var asphalt: StandardMaterial3D
var oak: StandardMaterial3D
var metal: StandardMaterial3D
var glass: StandardMaterial3D
var plaster: StandardMaterial3D

func setup(world_root: Node3D) -> void:
	world = world_root
	root = Node3D.new()
	root.name = "ProductionCityPolish21"
	world.add_child(root)
	_build_materials()
	_apply_ground_materials()
	_reskin_legacy_shops()
	_build_curbs_and_crossing()
	_build_street_furniture()
	_build_greenery()

func _build_materials() -> void:
	concrete = _pbr("stone", Color("aaa8a2"), 0.90, 0.0, 2.8, 0.32)
	asphalt = _simple(Color("34383b"), 0.96, 0.0)
	oak = _pbr("oak", Color("76543d"), 0.74, 0.0, 2.6, 0.36)
	plaster = _pbr("plaster", Color("d5d0c7"), 0.90, 0.0, 2.4, 0.30)
	metal = _simple(Color("33383c"), 0.28, 0.76)
	glass = _simple(Color(0.54, 0.70, 0.78, 0.20), 0.08, 0.12)
	glass.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA

func _apply_ground_materials() -> void:
	_apply("Sidewalk", concrete)
	_apply("Road", asphalt)
	_apply("ParkPatch", _simple(Color("536f4d"), 0.98, 0.0))

func _reskin_legacy_shops() -> void:
	_shop("MarketShell", Vector3(8.2, 0.0, 18.4), Vector3(7.0, 3.2, 4.5), Color("d9d4c9"), Color("4c755e"), "FRESH MARKET")
	_shop("CinemaShell", Vector3(-8.5, 0.0, 18.6), Vector3(8.5, 4.0, 4.8), Color("39353d"), Color("824454"), "CUMA CINEMA")
	_shop("ArcadeShell", Vector3(14.8, 0.0, 18.4), Vector3(6.0, 3.4, 4.2), Color("40384e"), Color("6c588f"), "NEON ARCADE")
	_shop("SnackCafeShell", Vector3(-15.2, 0.0, 13.5), Vector3(5.2, 3.0, 3.8), Color("b8aa96"), Color("755b47"), "CORNER CAFE")
	_photo_booth()

func _shop(node_name: String, center: Vector3, size: Vector3, base_color: Color, accent: Color, title: String) -> void:
	var legacy = world.get_node_or_null(node_name)
	if legacy != null:
		_hide_meshes(legacy)
	var body_mat = plaster.duplicate()
	body_mat.albedo_color = base_color
	# Side/back skins are inset from the legacy collider so they never change collision.
	_panel(Vector3(size.x, size.y, 0.08), center + Vector3(0.0, size.y * 0.5, size.z * 0.5 + 0.045), body_mat)
	_panel(Vector3(0.08, size.y, size.z), center + Vector3(-size.x * 0.5 - 0.045, size.y * 0.5, 0.0), body_mat)
	_panel(Vector3(0.08, size.y, size.z), center + Vector3(size.x * 0.5 + 0.045, size.y * 0.5, 0.0), body_mat)
	# Front is visually split into storefront glass and solid pilasters instead of one slab.
	var front_z = center.z - size.z * 0.5 - 0.055
	_panel(Vector3(size.x, 0.45, 0.09), Vector3(center.x, size.y - 0.22, front_z), _simple(accent, 0.58, 0.0))
	_panel(Vector3(0.55, size.y - 0.45, 0.09), Vector3(center.x - size.x * 0.5 + 0.28, (size.y - 0.45) * 0.5, front_z), body_mat)
	_panel(Vector3(0.55, size.y - 0.45, 0.09), Vector3(center.x + size.x * 0.5 - 0.28, (size.y - 0.45) * 0.5, front_z), body_mat)
	var glass_width = max(1.0, size.x - 1.28)
	_panel(Vector3(glass_width, size.y - 0.82, 0.055), Vector3(center.x, (size.y - 0.82) * 0.5 + 0.16, front_z - 0.03), glass)
	# Door seam and handles make the glass read as a storefront, even though this older kiosk is exterior-only.
	_panel(Vector3(0.025, size.y - 0.92, 0.065), Vector3(center.x, (size.y - 0.92) * 0.5 + 0.16, front_z - 0.06), metal)
	_cylinder(Vector3(center.x - 0.12, 1.15, front_z - 0.10), 0.012, 0.34, metal)
	_cylinder(Vector3(center.x + 0.12, 1.15, front_z - 0.10), 0.012, 0.34, metal)
	_sign(Vector3(center.x, size.y - 0.20, front_z - 0.10), title, Color("f4eee3"))
	# Small awning/canopy casts useful shadow and breaks the box silhouette.
	_panel(Vector3(size.x * 0.72, 0.08, 0.74), Vector3(center.x, size.y - 0.58, front_z - 0.38), _simple(accent.darkened(0.10), 0.66, 0.0), Vector3(-8.0, 0.0, 0.0))

func _photo_booth() -> void:
	var legacy = world.get_node_or_null("PhotoBoothShell")
	if legacy != null:
		_hide_meshes(legacy)
	var c = Vector3(0.0, 0.0, 18.4)
	_panel(Vector3(3.2, 2.7, 0.08), c + Vector3(0.0, 1.35, 1.34), _simple(Color("675463"), 0.78, 0.0))
	_panel(Vector3(0.08, 2.7, 2.6), c + Vector3(-1.64, 1.35, 0.0), _simple(Color("675463"), 0.78, 0.0))
	_panel(Vector3(0.08, 2.7, 2.6), c + Vector3(1.64, 1.35, 0.0), _simple(Color("675463"), 0.78, 0.0))
	var front_z = c.z - 1.34
	_panel(Vector3(3.2, 0.42, 0.08), Vector3(0.0, 2.49, front_z), _emissive(Color("d9a9be"), 1.05))
	_panel(Vector3(2.60, 1.86, 0.05), Vector3(0.0, 1.20, front_z - 0.03), glass)
	_sign(Vector3(0.0, 2.48, front_z - 0.10), "PHOTO", Color("fff0f6"))

func _build_curbs_and_crossing() -> void:
	# Curbs visually separate sidewalk from asphalt.
	_panel(Vector3(30.0, 0.11, 0.14), Vector3(0.0, 0.045, 19.47), concrete)
	_panel(Vector3(30.0, 0.11, 0.14), Vector3(0.0, 0.045, 24.98), concrete)
	var paint = _simple(Color("e8e5dc"), 0.84, 0.0)
	for i in range(7):
		_panel(Vector3(0.74, 0.018, 3.20), Vector3(-2.55 + float(i) * 0.86, 0.02, 22.5), paint)
	# Lane dashes.
	for x in range(-15, 16, 5):
		_panel(Vector3(2.3, 0.014, 0.10), Vector3(float(x), 0.018, 22.5), _simple(Color("ded49a"), 0.82, 0.0))

func _build_street_furniture() -> void:
	for x in [-12.0, -4.0, 4.0, 12.0]:
		_street_lamp(Vector3(x, 0.0, 19.1))
	_bench(Vector3(-4.8, 0.0, 16.3), 0.0)
	_bench(Vector3(4.8, 0.0, 16.3), 180.0)
	# Bus-style glass shelter for visual depth.
	_panel(Vector3(3.6, 2.35, 0.06), Vector3(10.5, 1.18, 25.65), glass)
	_panel(Vector3(3.9, 0.10, 1.45), Vector3(10.5, 2.42, 25.0), metal)
	_panel(Vector3(2.65, 0.10, 0.52), Vector3(10.5, 0.52, 25.42), oak)

func _build_greenery() -> void:
	for pos in [Vector3(-13.0, 0.0, 16.0), Vector3(-5.8, 0.0, 16.0), Vector3(5.8, 0.0, 16.0), Vector3(13.0, 0.0, 16.0)]:
		_planter_tree(pos)

func _street_lamp(pos: Vector3) -> void:
	_cylinder(pos + Vector3(0.0, 1.65, 0.0), 0.032, 3.20, metal)
	_cylinder(pos + Vector3(0.28, 3.12, 0.0), 0.024, 0.58, metal, Vector3(0.0, 0.0, 90.0))
	var fixture = _sphere(pos + Vector3(0.58, 3.12, 0.0), Vector3(0.12, 0.08, 0.12), _emissive(Color("ffd9a8"), 1.15))
	fixture.add_to_group("street_lamp_fixture")

func _bench(pos: Vector3, rotation_y: float) -> void:
	var holder = Node3D.new()
	holder.position = pos
	holder.rotation_degrees.y = rotation_y
	root.add_child(holder)
	_panel_on(holder, Vector3(1.55, 0.12, 0.48), Vector3(0.0, 0.52, 0.0), oak)
	_panel_on(holder, Vector3(1.55, 0.62, 0.10), Vector3(0.0, 0.88, 0.22), oak)
	for x in [-0.62, 0.62]:
		_cylinder_on(holder, Vector3(x, 0.26, 0.0), 0.018, 0.48, metal)

func _planter_tree(pos: Vector3) -> void:
	_panel(Vector3(0.75, 0.48, 0.75), pos + Vector3(0.0, 0.24, 0.0), _simple(Color("6c5c4e"), 0.88, 0.0))
	_cylinder(pos + Vector3(0.0, 1.05, 0.0), 0.07, 1.45, _simple(Color("5d4937"), 0.94, 0.0))
	for i in range(8):
		var a = float(i) * TAU / 8.0
		_sphere(pos + Vector3(cos(a) * 0.30, 1.85 + float(i % 2) * 0.16, sin(a) * 0.30), Vector3(0.36, 0.30, 0.36), _simple(Color("4c6f4d"), 0.96, 0.0))
	_sphere(pos + Vector3(0.0, 2.15, 0.0), Vector3(0.48, 0.38, 0.48), _simple(Color("557955"), 0.96, 0.0))

func _apply(node_name: String, material: Material) -> void:
	var node = world.get_node_or_null(node_name)
	if node == null:
		return
	for child in node.get_children():
		if child is MeshInstance3D:
			child.material_override = material

func _hide_meshes(node: Node) -> void:
	for child in node.get_children():
		if child is MeshInstance3D:
			child.visible = false
		_hide_meshes(child)

func _sign(pos: Vector3, text_value: String, color: Color) -> void:
	var label = Label3D.new()
	label.text = text_value
	label.position = pos
	label.font_size = 24
	label.outline_size = 5
	label.modulate = color
	root.add_child(label)

func _panel(size: Vector3, pos: Vector3, material: Material, rot_deg: Vector3 = Vector3.ZERO) -> MeshInstance3D:
	return _panel_on(root, size, pos, material, rot_deg)

func _panel_on(parent: Node3D, size: Vector3, pos: Vector3, material: Material, rot_deg: Vector3 = Vector3.ZERO) -> MeshInstance3D:
	var mi = MeshInstance3D.new()
	var mesh = BoxMesh.new()
	mesh.size = size
	mi.mesh = mesh
	mi.position = pos
	mi.rotation_degrees = rot_deg
	mi.material_override = material
	mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_ON
	parent.add_child(mi)
	return mi

func _sphere(pos: Vector3, scale_value: Vector3, material: Material) -> MeshInstance3D:
	var mi = MeshInstance3D.new()
	var mesh = SphereMesh.new()
	mesh.radius = 0.5
	mesh.height = 1.0
	mesh.radial_segments = 18
	mesh.rings = 9
	mi.mesh = mesh
	mi.position = pos
	mi.scale = scale_value * 2.0
	mi.material_override = material
	root.add_child(mi)
	return mi

func _cylinder(pos: Vector3, radius: float, height: float, material: Material, rot_deg: Vector3 = Vector3.ZERO) -> MeshInstance3D:
	return _cylinder_on(root, pos, radius, height, material, rot_deg)

func _cylinder_on(parent: Node3D, pos: Vector3, radius: float, height: float, material: Material, rot_deg: Vector3 = Vector3.ZERO) -> MeshInstance3D:
	var mi = MeshInstance3D.new()
	var mesh = CylinderMesh.new()
	mesh.top_radius = radius
	mesh.bottom_radius = radius
	mesh.height = max(height, 0.01)
	mesh.radial_segments = 18
	mi.mesh = mesh
	mi.position = pos
	mi.rotation_degrees = rot_deg
	mi.material_override = material
	parent.add_child(mi)
	return mi

func _pbr(texture_name: String, color: Color, roughness: float, metallic: float, uv_scale: float, normal_strength: float) -> StandardMaterial3D:
	var mat = StandardMaterial3D.new()
	mat.albedo_color = color
	mat.roughness = roughness
	mat.metallic = metallic
	var base = "res://assets/materials/production/" + texture_name
	var albedo_path = base + "_albedo.png"
	var normal_path = base + "_normal.png"
	if ResourceLoader.exists(albedo_path):
		mat.albedo_texture = load(albedo_path)
	if ResourceLoader.exists(normal_path):
		mat.normal_enabled = true
		mat.normal_texture = load(normal_path)
		mat.normal_scale = normal_strength
	mat.uv1_scale = Vector3(uv_scale, uv_scale, uv_scale)
	return mat

func _simple(color: Color, roughness: float, metallic: float) -> StandardMaterial3D:
	var mat = StandardMaterial3D.new()
	mat.albedo_color = color
	mat.roughness = roughness
	mat.metallic = metallic
	return mat

func _emissive(color: Color, energy: float) -> StandardMaterial3D:
	var mat = _simple(color, 0.36, 0.0)
	mat.emission_enabled = true
	mat.emission = color
	mat.emission_energy_multiplier = energy
	return mat
