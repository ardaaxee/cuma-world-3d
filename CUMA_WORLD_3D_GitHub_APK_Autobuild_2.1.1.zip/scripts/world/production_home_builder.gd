extends Node

var world: Node3D
var root: Node3D
var plaster: StandardMaterial3D
var oak: StandardMaterial3D
var fabric_dark: StandardMaterial3D
var fabric_light: StandardMaterial3D
var stone: StandardMaterial3D
var tile: StandardMaterial3D
var metal_dark: StandardMaterial3D
var glass_mat: StandardMaterial3D
var warm_white: StandardMaterial3D

func setup(world_root: Node3D) -> void:
	world = world_root
	root = Node3D.new()
	root.name = "ProductionHome21"
	world.add_child(root)
	_build_materials()
	_hide_legacy_visuals()
	_apply_architecture_materials()
	_build_corridor_architecture()
	_build_living_room()
	_build_bedrooms()
	_build_kitchen_details()
	_build_bathroom_details()
	_build_entry_details()
	_build_balcony_details()
	_build_soft_lighting()

func _build_materials() -> void:
	plaster = _pbr_material("plaster", Color("ddd9d2"), 0.88, 0.0, 2.4, 0.34)
	oak = _pbr_material("oak", Color("8b684c"), 0.72, 0.0, 3.0, 0.45)
	fabric_dark = _pbr_material("fabric", Color("343a42"), 0.96, 0.0, 2.1, 0.24)
	fabric_light = _pbr_material("fabric", Color("cfc7bd"), 0.98, 0.0, 2.1, 0.20)
	stone = _pbr_material("stone", Color("b7b6b0"), 0.46, 0.0, 2.0, 0.46)
	tile = _pbr_material("tile", Color("d6d4cd"), 0.52, 0.0, 2.5, 0.34)
	metal_dark = _simple_material(Color("2b2f33"), 0.25, 0.78)
	warm_white = _simple_material(Color("f0ece3"), 0.78, 0.0)
	glass_mat = _simple_material(Color(0.62, 0.76, 0.82, 0.18), 0.08, 0.12)
	glass_mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA

func _hide_legacy_visuals() -> void:
	var legacy_names: Array[String] = [
		"SofaSeat", "SofaBack", "CoffeeTable", "CoffeeTableLeg", "TVUnit",
		"Bed1", "Bed1Headboard", "Bed2", "Bed2Headboard", "Bed3", "Bed3Headboard", "Bed4", "Bed4Headboard",
		"Wardrobe1", "Wardrobe3", "MasterWardrobe", "Desk2", "Desk2Leg",
		"KitchenCounter", "KitchenCounter2", "KitchenIsland", "Fridge",
		"BathTub", "BathroomSink", "BathroomCabinet", "HallBench",
		"BalconyTable", "BalconyTableLeg", "BalconySeatA", "BalconySeatB",
		"TogetherBoard", "GiftStation", "DecorStation"
	]
	for node_name in legacy_names:
		var node = world.get_node_or_null(node_name)
		if node != null:
			_hide_mesh_children(node)
	for i in range(9):
		var skyline = world.get_node_or_null("Skyline_%02d" % i)
		if skyline != null:
			_hide_mesh_children(skyline)

func _hide_mesh_children(node: Node) -> void:
	for child in node.get_children():
		if child is MeshInstance3D:
			child.visible = false
		_hide_mesh_children(child)

func _apply_architecture_materials() -> void:
	_apply_body_material("HouseFloor", oak)
	_apply_body_material("Ceiling", warm_white)
	for wall_name in [
		"BackWall", "LeftWall", "RightWall", "FrontA", "FrontB", "FrontC", "BalconyOpeningHeader", "EntranceHeader",
		"LeftCorridor01", "LeftCorridor02", "LeftCorridor03", "LeftCorridor04",
		"RightCorridor01", "RightCorridor02", "RightCorridor03", "RightCorridor04", "RightCorridor05",
		"LeftSeparatorBack", "LeftSeparatorFront", "RightSeparatorBack", "RightSeparatorFront", "RightBathSeparator"
	]:
		_apply_body_material(wall_name, plaster)
	for door_name in ["EntranceDoor", "Bedroom1Door", "Bedroom2Door", "LivingDoor", "Bedroom3Door", "Bedroom4Door", "KitchenDoor", "BathroomDoor"]:
		_apply_body_material(door_name, oak)

func _apply_body_material(node_name: String, material: Material) -> void:
	var node = world.get_node_or_null(node_name)
	if node == null:
		return
	for child in node.get_children():
		if child is MeshInstance3D:
			child.material_override = material

func _build_corridor_architecture() -> void:
	# Continuous baseboards and a shallow ceiling reveal make the corridor read as architecture, not stacked boxes.
	_panel(Vector3(0.045, 0.13, 17.15), Vector3(-1.685, 0.065, 0.0), warm_white)
	_panel(Vector3(0.045, 0.13, 17.15), Vector3(1.685, 0.065, 0.0), warm_white)
	_panel(Vector3(0.055, 0.055, 15.8), Vector3(0.0, 3.11, -0.1), metal_dark)
	# Door trims: two vertical stiles plus one header for every corridor door.
	var left_doors: Array[float] = [-5.3, 0.7, 6.5]
	var right_doors: Array[float] = [-5.3, 0.7, 5.0, 8.2]
	for z in left_doors:
		_door_trim(Vector3(-1.79, 1.18, z), 90.0, 1.4)
	for z in right_doors:
		_door_trim(Vector3(1.79, 1.18, z), 90.0, 1.4)
	_door_trim(Vector3(-1.25, 1.18, 8.99), 0.0, 2.5)
	# Runner with a very thin profile and subtle edge bands.
	_panel(Vector3(1.52, 0.018, 14.7), Vector3(0.0, 0.025, -0.2), fabric_light)
	_panel(Vector3(0.025, 0.022, 14.7), Vector3(-0.74, 0.029, -0.2), metal_dark)
	_panel(Vector3(0.025, 0.022, 14.7), Vector3(0.74, 0.029, -0.2), metal_dark)
	# Framed art sits flush on the walls and uses no collision.
	_wall_art(Vector3(-1.675, 1.60, -7.6), true, Color("7e8a8f"))
	_wall_art(Vector3(1.675, 1.60, -3.7), false, Color("9b806e"))
	_wall_art(Vector3(-1.675, 1.60, 2.0), true, Color("78806d"))

func _door_trim(center: Vector3, rotation_y: float, width: float) -> void:
	var frame_mat = oak
	var frame = Node3D.new()
	frame.position = center
	frame.rotation_degrees.y = rotation_y
	root.add_child(frame)
	_panel_on(frame, Vector3(0.07, 2.48, 0.08), Vector3(-width * 0.5 - 0.035, 0.0, -0.015), frame_mat)
	_panel_on(frame, Vector3(0.07, 2.48, 0.08), Vector3(width * 0.5 + 0.035, 0.0, -0.015), frame_mat)
	_panel_on(frame, Vector3(width + 0.14, 0.07, 0.08), Vector3(0.0, 1.235, -0.015), frame_mat)

func _wall_art(pos: Vector3, left_wall: bool, art_color: Color) -> void:
	var frame = _simple_material(Color("4e4036"), 0.72, 0.0)
	var art = _simple_material(art_color, 0.90, 0.0)
	var sign_value = 1.0 if left_wall else -1.0
	_panel(Vector3(0.032, 0.84, 0.68), pos, frame)
	_panel(Vector3(0.036, 0.69, 0.53), pos + Vector3(sign_value * 0.019, 0.0, 0.0), art)

func _build_living_room() -> void:
	# Soft modular sofa. Capsules and spheres break the primitive-box silhouette.
	var sofa_root = Node3D.new()
	sofa_root.position = Vector3(-7.0, 0.0, 5.78)
	root.add_child(sofa_root)
	_capsule_on(sofa_root, Vector3(-1.30, 0.44, 0.0), 0.26, 1.55, fabric_dark, Vector3(0.0, 0.0, 90.0), Vector3(1.0, 1.0, 1.35))
	_capsule_on(sofa_root, Vector3(0.0, 0.44, 0.0), 0.26, 1.55, fabric_dark, Vector3(0.0, 0.0, 90.0), Vector3(1.0, 1.0, 1.35))
	_capsule_on(sofa_root, Vector3(1.30, 0.44, 0.0), 0.26, 1.55, fabric_dark, Vector3(0.0, 0.0, 90.0), Vector3(1.0, 1.0, 1.35))
	for x in [-1.32, 0.0, 1.32]:
		_capsule_on(sofa_root, Vector3(x, 0.92, 0.42), 0.22, 1.35, fabric_dark, Vector3(0.0, 0.0, 90.0), Vector3(1.0, 1.0, 1.10))
	for x in [-1.0, 0.95]:
		_sphere_on(sofa_root, Vector3(x, 0.94, -0.28), Vector3(0.42, 0.32, 0.16), fabric_light)
	# Coffee table: thin stone top with four recessed metal legs.
	_panel(Vector3(2.05, 0.075, 1.05), Vector3(-7.0, 0.66, 4.10), stone)
	for x in [-0.82, 0.82]:
		for z in [-0.34, 0.34]:
			_cylinder(Vector3(-7.0 + x, 0.34, 4.10 + z), 0.018, 0.60, metal_dark)
	# Rug, media wall and low floating console.
	_panel(Vector3(4.80, 0.016, 3.25), Vector3(-7.0, 0.024, 4.90), fabric_light)
	_panel(Vector3(4.05, 1.90, 0.06), Vector3(-7.0, 1.35, 3.02), _simple_material(Color("55473e"), 0.84, 0.0))
	for x in range(12):
		_panel(Vector3(0.055, 1.86, 0.028), Vector3(-8.8 + float(x) * 0.33, 1.35, 2.98), oak)
	_panel(Vector3(3.75, 0.16, 0.42), Vector3(-7.0, 0.38, 3.16), stone)
	# Side lamp and two plants.
	_floor_lamp(Vector3(-9.35, 0.0, 5.62))
	_plant(Vector3(-4.75, 0.0, 6.65), 1.10)

func _build_bedrooms() -> void:
	var beds: Array[Vector3] = [Vector3(-7.2, 0.0, -6.4), Vector3(-7.0, 0.0, -0.1), Vector3(7.0, 0.0, -6.2), Vector3(7.2, 0.0, -0.2)]
	for idx in range(beds.size()):
		var p: Vector3 = beds[idx]
		_panel(Vector3(3.04, 0.20, 4.02), p + Vector3(0.0, 0.18, 0.0), oak)
		_panel(Vector3(2.88, 0.32, 3.82), p + Vector3(0.0, 0.46, 0.0), fabric_light)
		# Duvet is a rounded scaled capsule, not a slab.
		_capsule(p + Vector3(0.0, 0.72, -0.15), 0.25, 2.55, fabric_light, Vector3(0.0, 0.0, 90.0), Vector3(1.0, 1.0, 6.8))
		_sphere(p + Vector3(-0.67, 0.79, 1.30), Vector3(0.58, 0.18, 0.38), warm_white)
		_sphere(p + Vector3(0.67, 0.79, 1.30), Vector3(0.58, 0.18, 0.38), warm_white)
		# Upholstered headboard with vertical channels.
		for x in range(6):
			_capsule(p + Vector3(-1.0 + float(x) * 0.40, 1.48, 1.78), 0.13, 1.05, fabric_dark, Vector3.ZERO, Vector3(1.0, 1.0, 0.34))
		_bedside_table(p + Vector3(-1.92, 0.0, 1.0), idx)
		_bedside_table(p + Vector3(1.92, 0.0, 1.0), idx + 10)
	# Better wardrobe faces keep the existing collision/interactions.
	_wardrobe_visual(Vector3(-10.1, 0.0, -7.9), 2.6)
	_wardrobe_visual(Vector3(10.0, 0.0, -7.8), 2.8)
	_wardrobe_visual(Vector3(10.0, 0.0, 1.65), 3.1)

func _bedside_table(pos: Vector3, seed_value: int) -> void:
	_panel(Vector3(0.68, 0.08, 0.52), pos + Vector3(0.0, 0.58, 0.0), oak)
	for x in [-0.24, 0.24]:
		for z in [-0.17, 0.17]:
			_cylinder(pos + Vector3(x, 0.29, z), 0.018, 0.54, metal_dark)
	_lamp(pos + Vector3(0.0, 0.66, 0.0), 0.42)
	_panel(Vector3(0.20, 0.018, 0.12), pos + Vector3(0.17 if seed_value % 2 == 0 else -0.17, 0.64, 0.08), metal_dark)

func _wardrobe_visual(pos: Vector3, width: float) -> void:
	_panel(Vector3(width, 2.48, 0.68), pos + Vector3(0.0, 1.24, 0.0), oak)
	var door_width = width * 0.49
	for side in [-1.0, 1.0]:
		_panel(Vector3(door_width, 2.28, 0.035), pos + Vector3(side * width * 0.245, 1.24, -0.36), _simple_material(Color("806048"), 0.74, 0.0))
		_cylinder(pos + Vector3(side * 0.08, 1.24, -0.40), 0.012, 0.34, metal_dark)

func _build_kitchen_details() -> void:
	# Keep interactive Ultra Home cabinets but replace the big prototype counter silhouettes.
	_panel(Vector3(5.35, 0.11, 0.82), Vector3(8.78, 0.98, 3.34), stone)
	_panel(Vector3(0.82, 0.11, 2.12), Vector3(10.96, 0.98, 4.64), stone)
	_panel(Vector3(2.85, 0.11, 1.18), Vector3(6.30, 0.99, 4.95), stone)
	# Fridge with split doors, inset line and handles.
	_panel(Vector3(1.02, 2.24, 0.90), Vector3(10.70, 1.12, 5.55), _simple_material(Color("b8bdc0"), 0.30, 0.72))
	_panel(Vector3(0.92, 0.025, 0.025), Vector3(10.70, 1.22, 5.08), metal_dark)
	_cylinder(Vector3(10.52, 1.35, 5.06), 0.012, 0.54, metal_dark)
	_cylinder(Vector3(10.88, 1.35, 5.06), 0.012, 0.54, metal_dark)
	# Sink basin, faucet and cooktop.
	_panel(Vector3(1.25, 0.03, 0.48), Vector3(8.55, 1.045, 3.31), metal_dark)
	_cylinder(Vector3(8.55, 1.25, 3.13), 0.018, 0.38, metal_dark)
	_cylinder(Vector3(8.55, 1.42, 3.28), 0.018, 0.30, metal_dark, Vector3(90.0, 0.0, 0.0))
	for x in [-0.35, 0.35]:
		for z in [-0.22, 0.22]:
			_cylinder(Vector3(6.30 + x, 1.065, 4.95 + z), 0.12, 0.018, metal_dark)

func _build_bathroom_details() -> void:
	# Floor and wet-wall material.
	_panel(Vector3(9.95, 0.016, 2.60), Vector3(6.85, 0.023, 7.55), tile)
	_panel(Vector3(4.25, 2.25, 0.025), Vector3(8.55, 1.45, 8.86), tile)
	# Freestanding tub silhouette with rounded inner body.
	_capsule(Vector3(8.65, 0.42, 7.78), 0.34, 1.65, warm_white, Vector3(0.0, 0.0, 90.0), Vector3(1.0, 1.0, 2.6))
	# Vanity, floating stone counter, mirror and frameless glass screen.
	_panel(Vector3(1.34, 0.66, 0.54), Vector3(4.30, 0.38, 7.16), oak)
	_panel(Vector3(1.42, 0.08, 0.62), Vector3(4.30, 0.76, 7.16), stone)
	_panel(Vector3(0.028, 1.88, 1.72), Vector3(7.02, 1.08, 7.74), glass_mat)
	_mirror(Vector3(4.30, 1.60, 7.48), Vector2(1.30, 1.12))

func _build_entry_details() -> void:
	# Floating console, padded bench and slim hooks.
	_panel(Vector3(1.42, 0.10, 0.40), Vector3(0.10, 0.82, 7.88), oak)
	_capsule(Vector3(-0.75, 0.38, 6.85), 0.20, 0.95, fabric_dark, Vector3(0.0, 0.0, 90.0), Vector3(1.0, 1.0, 1.30))
	for x in [-1.10, -0.40]:
		_cylinder(Vector3(x, 0.18, 6.85), 0.018, 0.32, metal_dark)
	_mirror(Vector3(1.58, 1.55, 8.75), Vector2(0.72, 1.45))

func _build_balcony_details() -> void:
	# Deck boards and slim vertical railing infill.
	for i in range(20):
		_panel(Vector3(0.46, 0.026, 4.55), Vector3(-10.72 + float(i) * 0.49, 0.025, 11.40), oak)
	for x in range(21):
		_cylinder(Vector3(-10.85 + float(x) * 0.49, 0.63, 13.69), 0.014, 1.02, metal_dark)
	_panel(Vector3(10.0, 0.045, 0.045), Vector3(-6.0, 1.15, 13.69), metal_dark)
	# Outdoor lounge and greenery.
	_capsule(Vector3(-8.45, 0.46, 10.15), 0.24, 1.75, fabric_dark, Vector3(0.0, 0.0, 90.0), Vector3(1.0, 1.0, 1.28))
	_panel(Vector3(1.30, 0.06, 0.72), Vector3(-6.25, 0.63, 11.55), stone)
	for x in [-6.72, -5.78]:
		_cylinder(Vector3(x, 0.32, 11.55), 0.018, 0.58, metal_dark)
	_plant(Vector3(-10.25, 0.0, 12.85), 1.20)
	_plant(Vector3(-2.20, 0.0, 12.85), 1.00)

func _build_soft_lighting() -> void:
	# Visible recessed fixtures plus a few low-cost warm pools. Extra lights obey the existing quality profile.
	for z in [-7.2, -4.0, -0.8, 2.4, 5.6, 7.8]:
		var fixture = MeshInstance3D.new()
		var mesh = CylinderMesh.new()
		mesh.top_radius = 0.10
		mesh.bottom_radius = 0.10
		mesh.height = 0.024
		mesh.radial_segments = 20
		fixture.mesh = mesh
		fixture.position = Vector3(0.0, 3.075, z)
		fixture.material_override = _emissive(Color("ffe2bd"), 1.6)
		root.add_child(fixture)
	for z in [-5.5, 0.0, 5.6]:
		var light = OmniLight3D.new()
		light.position = Vector3(0.0, 2.65, z)
		light.light_color = Color("ffd9ad")
		light.light_energy = 0.62
		light.omni_range = 3.8
		light.shadow_enabled = false
		light.add_to_group("quality_extra_light")
		root.add_child(light)

func _floor_lamp(pos: Vector3) -> void:
	_cylinder(pos + Vector3(0.0, 0.65, 0.0), 0.022, 1.28, metal_dark)
	_cylinder(pos + Vector3(0.0, 1.27, 0.0), 0.22, 0.08, metal_dark)
	_capsule(pos + Vector3(0.0, 1.47, 0.0), 0.16, 0.32, _emissive(Color("ffd6a5"), 1.25), Vector3.ZERO, Vector3(1.0, 1.0, 0.82))

func _lamp(pos: Vector3, height: float) -> void:
	_cylinder(pos + Vector3(0.0, height * 0.36, 0.0), 0.014, height * 0.70, metal_dark)
	_capsule(pos + Vector3(0.0, height * 0.76, 0.0), 0.11, 0.20, _emissive(Color("ffe1b4"), 1.25), Vector3.ZERO, Vector3(1.0, 1.0, 0.86))

func _plant(pos: Vector3, scale_value: float) -> void:
	_cylinder(pos + Vector3(0.0, 0.18 * scale_value, 0.0), 0.22 * scale_value, 0.34 * scale_value, _simple_material(Color("6d5949"), 0.92, 0.0))
	for i in range(7):
		var angle = float(i) * TAU / 7.0
		var offset = Vector3(cos(angle) * 0.18, 0.64 + float(i % 2) * 0.12, sin(angle) * 0.18) * scale_value
		_capsule(pos + offset, 0.055 * scale_value, 0.52 * scale_value, _simple_material(Color("4f6e50"), 0.94, 0.0), Vector3(22.0, rad_to_deg(angle), 0.0), Vector3(0.75, 1.0, 0.34))

func _mirror(pos: Vector3, size: Vector2) -> void:
	var mirror = _simple_material(Color("9fb0b8"), 0.06, 0.62)
	_panel(Vector3(size.x, size.y, 0.025), pos, mirror)
	# Thin dark frame.
	_panel(Vector3(size.x + 0.08, 0.035, 0.04), pos + Vector3(0.0, size.y * 0.5 + 0.02, 0.015), metal_dark)
	_panel(Vector3(size.x + 0.08, 0.035, 0.04), pos - Vector3(0.0, size.y * 0.5 + 0.02, -0.015), metal_dark)
	_panel(Vector3(0.035, size.y, 0.04), pos + Vector3(size.x * 0.5 + 0.02, 0.0, 0.015), metal_dark)
	_panel(Vector3(0.035, size.y, 0.04), pos - Vector3(size.x * 0.5 + 0.02, 0.0, -0.015), metal_dark)

func _panel(size: Vector3, pos: Vector3, material: Material, rot_deg: Vector3 = Vector3.ZERO) -> MeshInstance3D:
	return _panel_on(root, size, pos, material, rot_deg)

func _panel_on(parent: Node3D, size: Vector3, pos: Vector3, material: Material, rot_deg: Vector3 = Vector3.ZERO) -> MeshInstance3D:
	var mi = MeshInstance3D.new()
	var mesh = BoxMesh.new()
	mesh.size = size
	mi.mesh = mesh
	mi.position = pos
	mi.rotation_degrees = rot_deg
	mi.material_override = material
	mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_ON
	parent.add_child(mi)
	return mi

func _sphere(pos: Vector3, scale_value: Vector3, material: Material) -> MeshInstance3D:
	return _sphere_on(root, pos, scale_value, material)

func _sphere_on(parent: Node3D, pos: Vector3, scale_value: Vector3, material: Material) -> MeshInstance3D:
	var mi = MeshInstance3D.new()
	var mesh = SphereMesh.new()
	mesh.radius = 0.5
	mesh.height = 1.0
	mesh.radial_segments = 20
	mesh.rings = 10
	mi.mesh = mesh
	mi.position = pos
	mi.scale = scale_value * 2.0
	mi.material_override = material
	mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_ON
	parent.add_child(mi)
	return mi

func _capsule(pos: Vector3, radius: float, height: float, material: Material, rot_deg: Vector3 = Vector3.ZERO, scale_value: Vector3 = Vector3.ONE) -> MeshInstance3D:
	return _capsule_on(root, pos, radius, height, material, rot_deg, scale_value)

func _capsule_on(parent: Node3D, pos: Vector3, radius: float, height: float, material: Material, rot_deg: Vector3 = Vector3.ZERO, scale_value: Vector3 = Vector3.ONE) -> MeshInstance3D:
	var mi = MeshInstance3D.new()
	var mesh = CapsuleMesh.new()
	mesh.radius = radius
	mesh.height = max(height, radius * 2.05)
	mesh.radial_segments = 20
	mesh.rings = 8
	mi.mesh = mesh
	mi.position = pos
	mi.rotation_degrees = rot_deg
	mi.scale = scale_value
	mi.material_override = material
	mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_ON
	parent.add_child(mi)
	return mi

func _cylinder(pos: Vector3, radius: float, height: float, material: Material, rot_deg: Vector3 = Vector3.ZERO) -> MeshInstance3D:
	var mi = MeshInstance3D.new()
	var mesh = CylinderMesh.new()
	mesh.top_radius = radius
	mesh.bottom_radius = radius
	mesh.height = max(height, 0.01)
	mesh.radial_segments = 20
	mi.mesh = mesh
	mi.position = pos
	mi.rotation_degrees = rot_deg
	mi.material_override = material
	mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_ON
	root.add_child(mi)
	return mi

func _pbr_material(texture_name: String, color: Color, roughness: float, metallic: float, uv_scale: float, normal_strength: float) -> StandardMaterial3D:
	var mat = StandardMaterial3D.new()
	mat.albedo_color = color
	mat.roughness = roughness
	mat.metallic = metallic
	var base = "res://assets/materials/production/" + texture_name
	var albedo_path = base + "_albedo.png"
	var normal_path = base + "_normal.png"
	if ResourceLoader.exists(albedo_path):
		mat.albedo_texture = load(albedo_path)
	if ResourceLoader.exists(normal_path):
		mat.normal_enabled = true
		mat.normal_texture = load(normal_path)
		mat.normal_scale = normal_strength
	mat.uv1_scale = Vector3(uv_scale, uv_scale, uv_scale)
	return mat

func _simple_material(color: Color, roughness: float, metallic: float) -> StandardMaterial3D:
	var mat = StandardMaterial3D.new()
	mat.albedo_color = color
	mat.roughness = roughness
	mat.metallic = metallic
	return mat

func _emissive(color: Color, energy: float) -> StandardMaterial3D:
	var mat = _simple_material(color, 0.38, 0.0)
	mat.emission_enabled = true
	mat.emission = color
	mat.emission_energy_multiplier = energy
	return mat
