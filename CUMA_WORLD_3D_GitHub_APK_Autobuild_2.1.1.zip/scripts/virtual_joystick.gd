extends Control

signal direction_changed(value: Vector2)

var touch_id = -1
var mouse_active = false
var direction = Vector2.ZERO
var radius = 50.0

func _ready() -> void:
	mouse_filter = Control.MOUSE_FILTER_STOP
	queue_redraw()

func _gui_input(event: InputEvent) -> void:
	if event is InputEventScreenTouch:
		if event.pressed and touch_id == -1:
			touch_id = event.index
			_update_direction(event.position)
		elif not event.pressed and event.index == touch_id:
			touch_id = -1
			_set_direction(Vector2.ZERO)
	elif event is InputEventScreenDrag and event.index == touch_id:
		_update_direction(event.position)
	elif event is InputEventMouseButton and event.button_index == MOUSE_BUTTON_LEFT:
		mouse_active = event.pressed
		if mouse_active:
			_update_direction(event.position)
		else:
			_set_direction(Vector2.ZERO)
	elif event is InputEventMouseMotion and mouse_active:
		_update_direction(event.position)

func _update_direction(local_position: Vector2) -> void:
	var center = size * 0.5
	var offset = local_position - center
	_set_direction(offset.limit_length(radius) / radius)

func _set_direction(value: Vector2) -> void:
	direction = value
	direction_changed.emit(direction)
	queue_redraw()

func _draw() -> void:
	var center = size * 0.5
	draw_circle(center, radius + 12.0, Color(0.03, 0.04, 0.055, 0.30))
	draw_circle(center, radius, Color(0.18, 0.22, 0.28, 0.24))
	draw_circle(center + direction * radius, 22.0, Color(0.88, 0.92, 0.98, 0.74))
