extends StaticBody3D

var target_light: Light3D
var persistent_id = "light"
var enabled = true

func setup(id: String, light: Light3D) -> void:
	persistent_id = id
	target_light = light
	add_to_group("persistent_world")
	var net = get_node_or_null("/root/NetworkManager")
	if net != null:
		net.register_world_interactable(persistent_id, global_position, ["toggle"])
		if not net.world_action_received.is_connected(_on_world_action_received):
			net.world_action_received.connect(_on_world_action_received)

func get_interaction_label() -> String:
	return "Işığı kapat" if enabled else "Işığı aç"

func interact(player: Node) -> void:
	var net = get_node_or_null("/root/NetworkManager")
	if net != null:
		net.request_world_action(persistent_id, "toggle")
	else:
		enabled = not enabled
		_apply()
	if player != null and player.has_method("show_status"):
		player.show_status("Işık isteği gönderildi", 1.2)

func _on_world_action_received(id: String, action: String) -> void:
	if id != persistent_id or action != "toggle":
		return
	enabled = not enabled
	_apply()

func _apply() -> void:
	if target_light != null:
		target_light.visible = enabled

func get_persistent_id() -> String:
	return persistent_id

func get_persistent_state() -> Dictionary:
	return {"enabled": enabled}

func apply_persistent_state(state: Variant) -> void:
	if state is Dictionary:
		enabled = bool(state.get("enabled", true))
		_apply()
