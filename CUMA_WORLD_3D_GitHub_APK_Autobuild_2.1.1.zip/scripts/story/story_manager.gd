extends Node

signal story_changed(title: String, objective: String)
signal story_rewarded(amount: int, reason: String)

const CHAPTERS := [
	{"title":"Bölüm 1 • Yeni Ev", "need":2, "duo":0, "reward":120, "objective":"Birlikte 2 farklı ev etkinliği tamamlayın"},
	{"title":"Bölüm 2 • Mahalle Günü", "need":5, "duo":40, "reward":180, "objective":"5 farklı ortak etkinlik ve 40 DUO puanına ulaşın"},
	{"title":"Bölüm 3 • Şehirde Bir Gün", "need":10, "duo":100, "reward":260, "objective":"10 farklı etkinlik keşfedin ve 100 DUO puanına ulaşın"},
	{"title":"Bölüm 4 • Birlikte Yol", "need":18, "duo":250, "reward":400, "objective":"18 farklı etkinlik ve 250 DUO puanına ulaşın"},
	{"title":"Bölüm 5 • CUMA WORLD", "need":28, "duo":500, "reward":650, "objective":"28 farklı ortak etkinliği tamamlayıp EFSANE İKİLİ olun"}
]

var last_text = ""

func _ready() -> void:
	var gs = get_node_or_null("/root/GameState")
	if gs != null:
		gs.state_changed.connect(_refresh)
	call_deferred("_refresh")

func _refresh() -> void:
	var gs = get_node_or_null("/root/GameState")
	if gs == null:
		return
	var idx = clamp(int(gs.story_chapter), 0, CHAPTERS.size())
	if idx >= CHAPTERS.size():
		var done = "Hikâye tamamlandı • Şehri birlikte yaşamaya devam edin"
		if last_text != done:
			last_text = done
			story_changed.emit("CUMA WORLD • TAMAMLANDI", done)
		return
	var chapter: Dictionary = CHAPTERS[idx]
	var unique = _unique_activities(gs.duo_stats)
	var ready = unique >= int(chapter["need"]) and int(gs.duo_points) >= int(chapter["duo"])
	if ready:
		var key = "story_reward_%d" % idx
		if not bool(gs.story_flags.get(key, false)):
			gs.story_flags[key] = true
			gs.add_money(int(chapter["reward"]))
			gs.add_memory("Hikâye tamamlandı • " + str(chapter["title"]))
			story_rewarded.emit(int(chapter["reward"]), str(chapter["title"]))
		gs.story_chapter = idx + 1
		gs.state_changed.emit()
		call_deferred("_refresh")
		return
	var text = "%s • %d/%d etkinlik • DUO %d/%d" % [str(chapter["objective"]), unique, int(chapter["need"]), int(gs.duo_points), int(chapter["duo"])]
	gs.story_objective = text
	if last_text != text:
		last_text = text
		story_changed.emit(str(chapter["title"]), text)

func _unique_activities(stats: Dictionary) -> int:
	var count = 0
	for key in stats.keys():
		if int(stats[key]) > 0:
			count += 1
	return count

func get_story_title() -> String:
	var gs = get_node_or_null("/root/GameState")
	if gs == null:
		return "CUMA WORLD"
	var idx = int(gs.story_chapter)
	return "CUMA WORLD • TAMAMLANDI" if idx >= CHAPTERS.size() else str(CHAPTERS[idx]["title"])

func get_story_objective() -> String:
	var gs = get_node_or_null("/root/GameState")
	return str(gs.story_objective) if gs != null else ""
