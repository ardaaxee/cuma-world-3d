extends Node

func _ready() -> void:
	var gs = get_node_or_null("/root/GameState")
	if gs != null:
		gs.quality_changed.connect(apply_profile)
		call_deferred("apply_profile", gs.quality_profile)

func apply_profile(profile: String) -> void:
	var high = profile == "HIGH"
	var medium_or_high = profile != "LOW"
	for node in get_tree().get_nodes_in_group("quality_shadow"):
		if node is Light3D:
			node.shadow_enabled = medium_or_high
	for node in get_tree().get_nodes_in_group("quality_extra_light"):
		if node is Light3D:
			node.visible = medium_or_high
	for node in get_tree().get_nodes_in_group("quality_crowd"):
		if node.has_method("set_simulation_enabled"):
			node.set_simulation_enabled(medium_or_high)
		elif node is Node3D:
			node.visible = medium_or_high
	for node in get_tree().get_nodes_in_group("quality_traffic"):
		if node.has_method("set_simulation_enabled"):
			node.set_simulation_enabled(medium_or_high)
		elif node is Node3D:
			node.visible = medium_or_high
	var world_env = get_tree().get_first_node_in_group("world_environment")
	if world_env is WorldEnvironment and world_env.environment != null:
		world_env.environment.glow_enabled = high
		world_env.environment.fog_enabled = medium_or_high
