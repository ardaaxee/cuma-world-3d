extends Node3D

const ProceduralHumanoid = preload("res://scripts/character/procedural_humanoid.gd")
const InteractionProxy = preload("res://scripts/social/npc_interaction_proxy.gd")

var npc_id = ""
var display_name = "Komşu"
var profile: Dictionary = {}
var rig: Node3D
var interaction_body: StaticBody3D
var home_route: Array[Vector3] = []
var work_route: Array[Vector3] = []
var leisure_route: Array[Vector3] = []
var active_route: Array[Vector3] = []
var route_index = 0
var speed = 1.15
var pause_left = 0.0
var sit_left = 0.0
var current_phase = "home"
var current_activity = "Evde"
var last_player_wave_ms = 0
var phase_offset = 0.0

# NPC Intelligence 1.3: lightweight needs + temporary plans.
var needs: Dictionary = {"energy": 78.0, "social": 68.0, "hunger": 76.0, "fun": 66.0}
var current_intent = "daily_routine"
var ai_plan_until = -1.0
var ai_target = Vector3.ZERO
var ai_partner_id = ""

# Physical AI 1.4: pathfinding, crowd avoidance and venue actions.
var nav_agent: NavigationAgent3D
var requested_velocity = Vector3.ZERO
var safe_velocity = Vector3.ZERO
var nav_target = Vector3(99999, 0, 99999)
var reserved_spot: Node3D
var smart_stage = ""
var door_check_left = 0.0
var group_leader_id = ""
var group_offset = Vector3.ZERO

# Human Behavior 1.5: visible micro-behaviors and queue/guest state.
var base_speed = 1.15
var crowd_factor = 1.0
var phone_prop: Node3D
var basket_prop: Node3D
var phone_left = 0.0
var pre_phone_activity = ""
var doorbell_announced = false

# Daily Life 1.6: visible carry/meal/call states.
var shopping_bag_prop: Node3D
var meal_prop: Node3D
var call_left = 0.0
var bag_left = 0.0
var meal_left = 0.0
var daily_activity_override = ""

func setup(values: Dictionary) -> void:
	profile = values.duplicate(true)
	npc_id = str(profile.get("id", "neighbor")).left(40)
	display_name = str(profile.get("name", npc_id)).left(28)
	phase_offset = float(profile.get("phase", 0.0))
	needs["energy"] = 62.0 + fmod(abs(float(hash(npc_id))), 29.0)
	needs["social"] = 55.0 + fmod(abs(float(hash(npc_id + "social"))), 36.0)
	needs["hunger"] = 58.0 + fmod(abs(float(hash(npc_id + "food"))), 34.0)
	needs["fun"] = 52.0 + fmod(abs(float(hash(npc_id + "fun"))), 38.0)
	base_speed = clamp(float(profile.get("speed", 1.15)), 0.75, 1.8)
	speed = base_speed
	home_route = _to_vec3_array(profile.get("home_route", []))
	work_route = _to_vec3_array(profile.get("work_route", home_route))
	leisure_route = _to_vec3_array(profile.get("leisure_route", home_route))
	if home_route.is_empty():
		home_route = [global_position]
	global_position = home_route[0]
	_build_visual()
	_build_behavior_props()
	_build_navigation_agent()
	_build_interaction()
	_build_nameplate()
	add_to_group("relationship_npc")
	var gs = get_node_or_null("/root/GameState")
	if gs != null and gs.has_method("register_social_profile"):
		gs.register_social_profile(npc_id, profile)
	_select_schedule(true)

func _to_vec3_array(value: Variant) -> Array[Vector3]:
	var out: Array[Vector3] = []
	if value is Array:
		for entry in value:
			if entry is Vector3:
				out.append(entry)
	return out

func _build_visual() -> void:
	rig = Node3D.new()
	rig.name = "SocialRig"
	rig.set_script(ProceduralHumanoid)
	add_child(rig)
	var skin: Color = profile.get("skin", Color("c99875"))
	var top: Color = profile.get("top", Color("596a7b"))
	var pants: Color = profile.get("pants", Color("303640"))
	var hair: Color = profile.get("hair", Color("211c1a"))
	rig.setup({
		"skin": skin,
		"top": top,
		"pants": pants,
		"hair": hair,
		"shoes": Color("15171a"),
		"height_scale": float(profile.get("height_scale", 1.0)),
		"shoulder_scale": float(profile.get("shoulder_scale", 1.0))
	})

func _build_behavior_props() -> void:
	phone_prop = Node3D.new()
	phone_prop.name = "PhoneProp"
	phone_prop.position = Vector3(0.28, 1.38, -0.20)
	phone_prop.rotation_degrees = Vector3(-18, 0, -10)
	var phone_mesh = MeshInstance3D.new()
	var phone_shape = CapsuleMesh.new()
	phone_shape.radius = 0.07
	phone_shape.height = 0.30
	phone_shape.radial_segments = 12
	phone_mesh.mesh = phone_shape
	phone_mesh.scale = Vector3(0.72, 1.0, 0.16)
	var pm = StandardMaterial3D.new()
	pm.albedo_color = Color("181b20")
	pm.metallic = 0.42
	pm.roughness = 0.24
	phone_mesh.material_override = pm
	phone_prop.add_child(phone_mesh)
	add_child(phone_prop)
	phone_prop.visible = false

	basket_prop = Node3D.new()
	basket_prop.name = "ShoppingBasket"
	basket_prop.position = Vector3(0.40, 0.92, 0.05)
	var tub = MeshInstance3D.new()
	var tub_mesh = CylinderMesh.new()
	tub_mesh.top_radius = 0.24
	tub_mesh.bottom_radius = 0.19
	tub_mesh.height = 0.28
	tub_mesh.radial_segments = 16
	tub.mesh = tub_mesh
	var bm = StandardMaterial3D.new()
	bm.albedo_color = Color("b66b42")
	bm.roughness = 0.82
	tub.material_override = bm
	basket_prop.add_child(tub)
	for hx in [-0.17, 0.17]:
		var side = MeshInstance3D.new()
		var side_mesh = CylinderMesh.new()
		side_mesh.top_radius = 0.018
		side_mesh.bottom_radius = 0.018
		side_mesh.height = 0.26
		side_mesh.radial_segments = 8
		side.mesh = side_mesh
		side.position = Vector3(hx,0.23,0)
		side.material_override = bm
		basket_prop.add_child(side)
	var grip = MeshInstance3D.new()
	var grip_mesh = CylinderMesh.new()
	grip_mesh.top_radius = 0.018
	grip_mesh.bottom_radius = 0.018
	grip_mesh.height = 0.34
	grip_mesh.radial_segments = 8
	grip.mesh = grip_mesh
	grip.position = Vector3(0,0.36,0)
	grip.rotation_degrees = Vector3(0,0,90)
	grip.material_override = bm
	basket_prop.add_child(grip)
	add_child(basket_prop)
	basket_prop.visible = false

	shopping_bag_prop = Node3D.new()
	shopping_bag_prop.name = "ShoppingBag"
	shopping_bag_prop.position = Vector3(-0.34, 0.88, 0.06)
	var bag = MeshInstance3D.new()
	var bag_mesh = BoxMesh.new()
	bag_mesh.size = Vector3(0.34, 0.46, 0.18)
	bag.mesh = bag_mesh
	var bag_mat = StandardMaterial3D.new()
	bag_mat.albedo_color = Color("caa66c")
	bag_mat.roughness = 0.96
	bag.material_override = bag_mat
	shopping_bag_prop.add_child(bag)
	for sx in [-0.10, 0.10]:
		var handle = MeshInstance3D.new()
		var hm = CylinderMesh.new()
		hm.top_radius = 0.012; hm.bottom_radius = 0.012; hm.height = 0.28; hm.radial_segments = 8
		handle.mesh = hm
		handle.position = Vector3(sx,0.30,0)
		handle.rotation_degrees = Vector3(0,0,12 if sx < 0 else -12)
		handle.material_override = bag_mat
		shopping_bag_prop.add_child(handle)
	add_child(shopping_bag_prop)
	shopping_bag_prop.visible = false

	meal_prop = Node3D.new()
	meal_prop.name = "MealTray"
	meal_prop.position = Vector3(0.0, 0.88, -0.40)
	var plate = MeshInstance3D.new()
	var plate_mesh = CylinderMesh.new()
	plate_mesh.top_radius = 0.23; plate_mesh.bottom_radius = 0.24; plate_mesh.height = 0.035; plate_mesh.radial_segments = 22
	plate.mesh = plate_mesh
	var plate_mat = StandardMaterial3D.new(); plate_mat.albedo_color = Color("e7e3d9"); plate_mat.roughness = 0.72
	plate.material_override = plate_mat
	meal_prop.add_child(plate)
	var food = MeshInstance3D.new()
	var food_mesh = SphereMesh.new(); food_mesh.radius = 0.12; food_mesh.height = 0.15
	food.mesh = food_mesh; food.position = Vector3(0,0.07,0)
	var food_mat = StandardMaterial3D.new(); food_mat.albedo_color = Color("ad6a3f"); food_mat.roughness = 0.90
	food.material_override = food_mat
	meal_prop.add_child(food)
	add_child(meal_prop)
	meal_prop.visible = false

func _build_interaction() -> void:
	interaction_body = StaticBody3D.new()
	interaction_body.name = "TalkTo" + display_name.replace(" ", "")
	interaction_body.position = Vector3(0.0, 1.0, 0.0)
	interaction_body.set_script(InteractionProxy)
	add_child(interaction_body)
	var collision = CollisionShape3D.new()
	var shape = CapsuleShape3D.new()
	shape.radius = 0.48
	shape.height = 1.85
	collision.shape = shape
	interaction_body.add_child(collision)
	interaction_body.setup(self)

func _build_nameplate() -> void:
	var label = Label3D.new()
	label.name = "Nameplate"
	label.text = display_name
	label.position = Vector3(0.0, 2.55, 0.0)
	label.font_size = 25
	label.outline_size = 6
	label.billboard = BaseMaterial3D.BILLBOARD_ENABLED
	label.modulate = Color(1, 1, 1, 0.90)
	add_child(label)

func _build_navigation_agent() -> void:
	nav_agent = NavigationAgent3D.new()
	nav_agent.name = "NavigationAgent"
	nav_agent.radius = 0.42
	nav_agent.height = 1.72
	nav_agent.path_desired_distance = 0.34
	nav_agent.target_desired_distance = 0.46
	nav_agent.path_max_distance = 2.5
	nav_agent.max_speed = speed * 1.18
	nav_agent.neighbor_distance = 3.4
	nav_agent.max_neighbors = 8
	nav_agent.time_horizon_agents = 0.85
	nav_agent.time_horizon_obstacles = 0.55
	nav_agent.avoidance_enabled = true
	nav_agent.simplify_path = true
	nav_agent.simplify_epsilon = 0.18
	add_child(nav_agent)
	nav_agent.velocity_computed.connect(_on_safe_velocity)

func _process(delta: float) -> void:
	_select_schedule(false)
	if rig == null:
		return
	if bag_left > 0.0:
		bag_left -= delta
		if shopping_bag_prop != null: shopping_bag_prop.visible = true
	elif shopping_bag_prop != null:
		shopping_bag_prop.visible = false
	if meal_left > 0.0:
		meal_left -= delta
		if meal_prop != null: meal_prop.visible = true
	elif meal_prop != null:
		meal_prop.visible = false
	if call_left > 0.0:
		call_left -= delta
		_update_rig(delta, 0.0, false)
		if phone_prop != null:
			phone_prop.visible = true
			phone_prop.position = Vector3(0.38, 1.63, -0.04)
			phone_prop.rotation_degrees = Vector3(0, 0, -62)
		if call_left <= 0.0:
			if phone_prop != null:
				phone_prop.visible = false
				phone_prop.position = Vector3(0.28, 1.38, -0.20)
				phone_prop.rotation_degrees = Vector3(-18, 0, -10)
			if pre_phone_activity != "": current_activity = pre_phone_activity
		return
	if phone_left > 0.0:
		phone_left -= delta
		_update_rig(delta, 0.0, false)
		if phone_prop != null:
			phone_prop.visible = true
		if phone_left <= 0.0:
			if phone_prop != null: phone_prop.visible = false
			if pre_phone_activity != "": current_activity = pre_phone_activity
		return
	if sit_left > 0.0:
		sit_left -= delta
		_update_rig(delta, 0.0, true)
		_maybe_notice_player()
		if sit_left <= 0.0:
			var finished_intent = current_intent
			_release_reserved_spot()
			if finished_intent in ["cafe_break", "restaurant_meal", "park_break"]:
				current_intent = "daily_routine"
				ai_plan_until = -1.0
				_select_schedule(true)
		return
	if pause_left > 0.0:
		pause_left -= delta
		_update_rig(delta, 0.0, false)
		_maybe_notice_player()
		return

func _physics_process(delta: float) -> void:
	if active_route.is_empty() or rig == null or sit_left > 0.0 or pause_left > 0.0 or phone_left > 0.0 or call_left > 0.0:
		requested_velocity = Vector3.ZERO
		if nav_agent != null:
			nav_agent.velocity = Vector3.ZERO
		return
	var target = active_route[route_index]
	var flat_to_target = target - global_position
	flat_to_target.y = 0.0
	if flat_to_target.length() < 0.48:
		_on_route_point_reached(target)
		return
	var dir = flat_to_target.normalized()
	if nav_agent != null:
		if nav_target.distance_to(target) > 0.08:
			nav_target = target
			nav_agent.target_position = target
		if not nav_agent.is_navigation_finished():
			var next = nav_agent.get_next_path_position()
			var nav_flat = next - global_position
			nav_flat.y = 0.0
			if nav_flat.length() > 0.08:
				dir = nav_flat.normalized()
	requested_velocity = dir * speed
	if nav_agent != null:
		nav_agent.velocity = requested_velocity
	var move_velocity = safe_velocity if safe_velocity.length() > 0.01 else requested_velocity
	move_velocity.y = 0.0
	global_position += move_velocity * delta
	rotation.y = lerp_angle(rotation.y, atan2(-move_velocity.x, -move_velocity.z), min(1.0, delta * 5.0))
	_update_rig(delta, move_velocity.length(), false)
	door_check_left -= delta
	if door_check_left <= 0.0:
		door_check_left = 0.45
		_request_nearby_npc_door()

func _on_safe_velocity(value: Vector3) -> void:
	if not value.is_finite():
		safe_velocity = Vector3.ZERO
		return
	safe_velocity = value.limit_length(speed * 1.18)

func _on_route_point_reached(_target: Vector3) -> void:
	requested_velocity = Vector3.ZERO
	safe_velocity = Vector3.ZERO
	if nav_agent != null:
		nav_agent.velocity = Vector3.ZERO
	# Entrance waypoint: keep walking into the venue instead of treating the entrance as the activity itself.
	if route_index < active_route.size() - 1:
		route_index += 1
		pause_left = 0.08
		return
	if _handle_smart_arrival():
		return
	route_index = (route_index + 1) % active_route.size()
	pause_left = randf_range(0.8, 3.4)
	if current_phase == "leisure" and randf() < 0.32:
		sit_left = randf_range(2.5, 6.0)
	_face_ai_partner_if_near()

func _handle_smart_arrival() -> bool:
	if reserved_spot == null or not is_instance_valid(reserved_spot):
		return false
	if global_position.distance_to(reserved_spot.global_position) > 0.85:
		return false
	var kind = str(reserved_spot.get_spot_kind()) if reserved_spot.has_method("get_spot_kind") else ""
	if kind == "market_shelf" and smart_stage == "browse":
		_face_reserved_spot()
		pause_left = randf_range(2.0, 4.0)
		if basket_prop != null: basket_prop.visible = true
		_release_reserved_spot()
		var queue_spot = _reserve_nearest_spot("checkout_queue", global_position)
		if queue_spot != null:
			reserved_spot = queue_spot
			smart_stage = "queue"
			ai_target = queue_spot.global_position
			active_route = [ai_target]
			route_index = 0
			current_activity = "Sepetiyle kasa sırasına geçiyor"
			return true
	if kind == "checkout_queue" and smart_stage == "queue":
		_face_reserved_spot()
		var checkout = _reserve_nearest_spot("checkout", global_position)
		if checkout == null:
			pause_left = randf_range(0.6, 1.3)
			current_activity = "Kasada sırasını bekliyor"
			return true
		_release_reserved_spot()
		reserved_spot = checkout
		smart_stage = "checkout"
		ai_target = checkout.global_position
		active_route = [ai_target]
		route_index = 0
		current_activity = "Sırası geldi; kasaya ilerliyor"
		return true
	if kind == "checkout":
		_face_reserved_spot()
		pause_left = randf_range(1.6, 3.0)
		needs["hunger"] = clamp(float(needs.get("hunger", 60.0)) + 18.0, 0.0, 100.0)
		if basket_prop != null: basket_prop.visible = false
		bag_left = randf_range(7.0, 13.0)
		if shopping_bag_prop != null: shopping_bag_prop.visible = true
		_release_reserved_spot()
		current_intent = "daily_routine"
		_select_schedule(true)
		return true
	if kind in ["cafe_wait", "restaurant_wait"]:
		var seat_kind = "cafe_seat" if kind == "cafe_wait" else "restaurant_seat"
		var seat = _reserve_nearest_spot(seat_kind, global_position)
		if seat == null:
			pause_left = randf_range(0.8, 1.5)
			current_activity = "Masa boşalmasını bekliyor"
			return true
		_release_reserved_spot()
		reserved_spot = seat
		smart_stage = ""
		ai_target = seat.global_position
		active_route = [ai_target]
		route_index = 0
		current_activity = "Boşalan masaya geçiyor"
		return true
	if kind == "guest_door":
		_face_reserved_spot()
		pause_left = randf_range(7.0, 13.0)
		current_activity = "Kapıda seni bekliyor"
		if not doorbell_announced:
			doorbell_announced = true
			say_custom_line("Kapıdayım, müsaitsen uğradım.")
		return true
	if kind in ["cafe_seat", "restaurant_seat", "social_seat", "park_seat", "group_seat", "home_life", "weekend_meet"]:
		var facing = reserved_spot.get_facing() if reserved_spot.has_method("get_facing") else Vector3.FORWARD
		if facing.length() > 0.1:
			rotation.y = atan2(-facing.x, -facing.z)
		sit_left = randf_range(6.0, 14.0)
		if kind == "restaurant_seat":
			meal_left = sit_left
			current_activity = "Siparişini aldı; yemek yiyor"
		elif kind == "home_life" and daily_activity_override != "":
			current_activity = daily_activity_override
		return true
	return false

func _face_reserved_spot() -> void:
	if reserved_spot == null or not is_instance_valid(reserved_spot):
		return
	var facing = reserved_spot.get_facing() if reserved_spot.has_method("get_facing") else Vector3.FORWARD
	if facing.length() > 0.1:
		rotation.y = atan2(-facing.x, -facing.z)

func _face_ai_partner_if_near() -> void:
	if ai_partner_id == "":
		return
	for node in get_tree().get_nodes_in_group("relationship_npc"):
		if node == self or not node.has_method("get_social_id"):
			continue
		if str(node.get_social_id()) == ai_partner_id and node is Node3D and global_position.distance_to(node.global_position) < 3.2:
			face_social_node(node)
			if node.has_method("face_social_node"):
				node.face_social_node(self)
			return

func _request_nearby_npc_door() -> void:
	for door in get_tree().get_nodes_in_group("npc_local_door"):
		if door is Node3D and global_position.distance_to(door.global_position) < 2.0 and door.has_method("request_npc_pass"):
			door.request_npc_pass(npc_id)
			return

func _reserve_nearest_spot(kind: String, from: Vector3) -> Node3D:
	var best: Node3D
	var best_dist = INF
	for node in get_tree().get_nodes_in_group("npc_spot_" + kind):
		if not (node is Node3D):
			continue
		if node.has_method("is_available") and not bool(node.is_available(npc_id)):
			continue
		var dist = from.distance_squared_to(node.global_position)
		if dist < best_dist and (not node.has_method("try_reserve") or bool(node.try_reserve(npc_id, 28.0))):
			if best != null and best.has_method("release"):
				best.release(npc_id)
			best = node
			best_dist = dist
	return best

func _release_reserved_spot() -> void:
	if reserved_spot != null and is_instance_valid(reserved_spot) and reserved_spot.has_method("release"):
		reserved_spot.release(npc_id)
	reserved_spot = null
	smart_stage = ""

func _select_schedule(force: bool) -> void:
	var gs = get_node_or_null("/root/GameState")
	if gs == null:
		return
	var absolute_hour = float(gs.world_day) * 24.0 + float(gs.time_of_day)
	if ai_plan_until > absolute_hour and current_intent != "daily_routine":
		current_phase = "leisure" if current_intent in ["friend_meetup", "socializing", "park_break"] else current_intent
		current_activity = _intent_label(current_intent)
		if force or active_route.is_empty() or active_route.size() != 1 or active_route[0].distance_to(ai_target) > 0.1:
			active_route = [ai_target]
			route_index = 0
			pause_left = 0.0
		return
	elif current_intent != "daily_routine":
		_release_reserved_spot()
		current_intent = "daily_routine"
		daily_activity_override = ""
		ai_partner_id = ""
		group_leader_id = ""
		group_offset = Vector3.ZERO
	var hour = float(gs.time_of_day)
	var work_start = float(profile.get("work_start", 9.0)) + _daily_schedule_shift(int(gs.world_day))
	var work_end = float(profile.get("work_end", 17.0)) + _daily_schedule_shift(int(gs.world_day)) * 0.35
	var weekend = posmod(int(gs.world_day), 7) in [0, 6]
	var phase = "home"
	var activity = "Evde"
	var route = home_route
	if not weekend and hour >= work_start and hour < work_end:
		phase = "work"
		activity = str(profile.get("work_label", "İşinde"))
		route = work_route
	elif hour >= 17.0 and hour < 22.0:
		phase = "leisure"
		activity = str(profile.get("leisure_label", "Mahallede vakit geçiriyor"))
		route = leisure_route
	elif hour >= 7.0 and hour < work_start:
		phase = "morning"
		activity = "Hafta sonu sabahında evde" if weekend else ("İşe hazırlanıyor" if hour >= work_start - 0.75 else "Sabah rutininde")
		route = home_route
	elif hour >= 22.0 or hour < 7.0:
		activity = "Evinde dinleniyor"
	if force or phase != current_phase:
		current_phase = phase
		current_activity = activity
		active_route = route.duplicate()
		route_index = 0
		pause_left = 0.0
	else:
		current_activity = activity

func _update_rig(delta: float, move_speed: float, sitting: bool) -> void:
	rig.position.y = lerp(rig.position.y, -0.48 if sitting else 0.0, min(1.0, delta * 5.0))
	if rig.has_method("update_pose"):
		rig.update_pose(delta, move_speed, false, 0.0, true, sitting, 0.0)
	var mood = "neutral"
	if current_intent in ["friend_meetup", "socializing", "community_event"]:
		mood = "happy"
	elif current_intent == "resting":
		mood = "neutral"
	elif current_phase == "leisure":
		mood = "happy"
	elif current_phase == "work":
		mood = "curious"
	if rig.has_method("set_mood") and randf() < delta * 0.08:
		rig.set_mood(mood, 2200)

func _maybe_notice_player() -> void:
	var player = get_tree().get_first_node_in_group("player")
	if player == null or not (player is Node3D):
		return
	if global_position.distance_to(player.global_position) > 3.8:
		return
	var gs = get_node_or_null("/root/GameState")
	if gs == null or not gs.has_method("get_social_relationship"):
		return
	var rel: Dictionary = gs.get_social_relationship(npc_id)
	if float(rel.get("friendship", 0.0)) < 24.0:
		return
	var now = Time.get_ticks_msec()
	if now - last_player_wave_ms < 30000:
		return
	last_player_wave_ms = now
	var flat = player.global_position - global_position
	flat.y = 0.0
	if flat.length() > 0.1:
		rotation.y = atan2(-flat.x, -flat.z)
	if rig.has_method("play_emote"):
		rig.play_emote("wave")


func intelligence_tick(gs: Node, hours: float) -> void:
	if gs == null:
		return
	var h = clamp(hours, 0.0, 1.0)
	needs["energy"] = clamp(float(needs.get("energy", 70.0)) - 2.4 * h, 0.0, 100.0)
	needs["hunger"] = clamp(float(needs.get("hunger", 70.0)) - 4.1 * h, 0.0, 100.0)
	needs["social"] = clamp(float(needs.get("social", 70.0)) - 2.1 * h, 0.0, 100.0)
	needs["fun"] = clamp(float(needs.get("fun", 70.0)) - 1.8 * h, 0.0, 100.0)

	match current_intent:
		"resting":
			needs["energy"] = clamp(float(needs["energy"]) + 17.0 * h, 0.0, 100.0)
		"shopping", "cafe_break", "restaurant_meal":
			needs["hunger"] = clamp(float(needs["hunger"]) + (20.0 if current_intent == "restaurant_meal" else 14.0) * h, 0.0, 100.0)
		"friend_meetup", "socializing", "group_table", "home_visit":
			needs["social"] = clamp(float(needs["social"]) + 15.0 * h, 0.0, 100.0)
			needs["fun"] = clamp(float(needs["fun"]) + 9.0 * h, 0.0, 100.0)
		"park_break":
			needs["fun"] = clamp(float(needs["fun"]) + 11.0 * h, 0.0, 100.0)

	var absolute_hour = float(gs.world_day) * 24.0 + float(gs.time_of_day)
	if ai_plan_until > absolute_hour:
		return
	# Work remains a strong commitment. Outside work, needs/personality can override the default route.
	var hour = float(gs.time_of_day)
	var work_start = float(profile.get("work_start", 9.0))
	var work_end = float(profile.get("work_end", 17.0))
	var weekend = posmod(int(gs.world_day), 7) in [0, 6]
	if not weekend and hour >= work_start and hour < work_end and float(needs["energy"]) > 18.0:
		return
	var personality = str(profile.get("personality", "sakin")).to_lower()
	var social_limit = 40.0 if ("sosyal" in personality or "sıcak" in personality) else 33.0
	var fun_limit = 38.0 if ("enerjik" in personality or "meraklı" in personality) else 30.0
	var rest_limit = 34.0 if ("sakin" in personality or "düşünceli" in personality) else 27.0
	if float(needs["energy"]) < rest_limit:
		set_ai_plan("resting", home_route[0], 1.5)
	elif float(needs["hunger"]) < 31.0:
		if hour >= 18.0 and hour < 21.5 and randf() < 0.38:
			set_ai_plan("restaurant_meal", Vector3(31.0, 0.05, 47.0), 1.15)
		else:
			var prefers_cafe = "sosyal" in personality or "esprili" in personality
			var food_target = Vector3(-15.0, 0.05, 38.0) if prefers_cafe or randf() < 0.42 else Vector3(15.0, 0.05, 38.0)
			set_ai_plan("cafe_break" if food_target.x < 0.0 else "shopping", food_target, 0.9)
	elif float(needs["social"]) < social_limit:
		set_ai_plan("socializing", Vector3(67.0, 0.05, 129.0), 1.0)
	elif float(needs["fun"]) < fun_limit:
		set_ai_plan("park_break", Vector3(80.0, 0.05, 138.0), 0.9)

func set_ai_plan(intent: String, target: Vector3, duration_hours: float, partner_id: String = "") -> void:
	var allowed = ["daily_routine", "resting", "shopping", "cafe_break", "restaurant_meal", "socializing", "park_break", "friend_meetup", "community_event", "group_walk", "home_visit", "group_table", "home_chore", "weekend_outing", "celebration"]
	if intent not in allowed:
		return
	var gs = get_node_or_null("/root/GameState")
	if gs == null:
		return
	_release_reserved_spot()
	current_intent = intent
	ai_target = target
	ai_partner_id = partner_id.left(40)
	ai_plan_until = float(gs.world_day) * 24.0 + float(gs.time_of_day) + clamp(duration_hours, 0.15, 3.0)
	# Route intents to physical venue anchors instead of stopping at a generic building coordinate.
	if intent == "shopping":
		reserved_spot = _reserve_nearest_spot("market_shelf", target)
		if reserved_spot != null:
			ai_target = reserved_spot.global_position
			smart_stage = "browse"
	elif intent == "cafe_break":
		reserved_spot = _reserve_nearest_spot("cafe_seat", target)
		if reserved_spot != null:
			ai_target = reserved_spot.global_position
		else:
			reserved_spot = _reserve_nearest_spot("cafe_wait", target)
			if reserved_spot != null:
				ai_target = reserved_spot.global_position
				smart_stage = "cafe_wait"
	elif intent == "restaurant_meal":
		reserved_spot = _reserve_nearest_spot("restaurant_seat", target)
		if reserved_spot != null:
			ai_target = reserved_spot.global_position
		else:
			reserved_spot = _reserve_nearest_spot("restaurant_wait", target)
			if reserved_spot != null:
				ai_target = reserved_spot.global_position
				smart_stage = "restaurant_wait"
	elif intent in ["friend_meetup", "socializing", "community_event"]:
		reserved_spot = _reserve_nearest_spot("social_seat", target)
		if reserved_spot != null: ai_target = reserved_spot.global_position
	elif intent == "park_break":
		reserved_spot = _reserve_nearest_spot("park_seat", target)
		if reserved_spot != null: ai_target = reserved_spot.global_position
	elif intent == "home_visit":
		reserved_spot = _reserve_nearest_spot("guest_door", target)
		if reserved_spot != null:
			ai_target = reserved_spot.global_position
			smart_stage = "doorbell"
		doorbell_announced = false
	elif intent == "group_table":
		reserved_spot = _reserve_nearest_spot("group_seat", target)
		if reserved_spot != null: ai_target = reserved_spot.global_position
	elif intent == "home_chore":
		reserved_spot = _reserve_nearest_spot("home_life", target)
		if reserved_spot != null: ai_target = reserved_spot.global_position
	elif intent == "weekend_outing":
		reserved_spot = _reserve_nearest_spot("weekend_meet", target)
		if reserved_spot != null: ai_target = reserved_spot.global_position
	elif intent == "celebration":
		reserved_spot = _reserve_nearest_spot("group_seat", target)
		if reserved_spot != null: ai_target = reserved_spot.global_position
	var entry = _venue_entry_for_intent(intent, ai_target)
	active_route = [entry, ai_target] if entry != Vector3.ZERO and entry.distance_to(ai_target) > 0.8 else [ai_target]
	route_index = 0
	pause_left = 0.0
	current_activity = _intent_label(current_intent)

func _venue_entry_for_intent(intent: String, target: Vector3) -> Vector3:
	if intent == "shopping":
		return Vector3(15.0, 0.05, 32.8)
	if intent == "cafe_break":
		return Vector3(-15.0, 0.05, 32.8)
	if intent == "restaurant_meal":
		return Vector3(31.0, 0.05, 40.75)
	# Neighborhood cafe/community house entrance lanes.
	if intent in ["friend_meetup", "socializing", "community_event"] and target.z < 128.0 and target.z > 119.0:
		return Vector3(67.0 if target.x < 76.0 else 84.0, 0.05, 120.25)
	return Vector3.ZERO

func _intent_label(intent: String) -> String:
	match intent:
		"resting": return "Evine dönüp dinleniyor"
		"shopping": return "Markete uğruyor"
		"cafe_break": return "Kafede bir şeyler alıp oturuyor"
		"restaurant_meal": return "Restorana gidip yemek yiyor"
		"socializing": return "Arkadaş görmek için mahalleye gidiyor"
		"park_break": return "Bahçede kafa dinliyor"
		"friend_meetup": return "Bir arkadaşıyla buluşmaya gidiyor"
		"community_event": return "Mahalle etkinliğine katılıyor"
		"group_walk": return "Arkadaş grubuyla birlikte yürüyor"
		"home_visit": return "Sana uğramak için evine geliyor"
		"group_table": return "Arkadaşlarıyla aynı masada oturuyor"
		"home_chore": return daily_activity_override if daily_activity_override != "" else "Evde günlük işleriyle ilgileniyor"
		"weekend_outing": return daily_activity_override if daily_activity_override != "" else "Hafta sonu dışarıda"
		"celebration": return "Mahalle kutlamasına katılıyor"
		_: return "Günlük rutininde"

func _daily_schedule_shift(day_value: int) -> float:
	# Deterministic small daily variance: NPCs do not start every day at the exact same minute.
	var seed_value = abs(hash(npc_id + ":" + str(day_value)))
	var centered = float(seed_value % 61) / 60.0 - 0.5
	var shift = centered * 0.7
	if float(needs.get("energy", 70.0)) < 30.0:
		shift += 0.25
	return clamp(shift, -0.35, 0.65)

func set_group_walk(target: Vector3, duration_hours: float, leader_id: String, offset: Vector3) -> void:
	group_leader_id = leader_id.left(40)
	group_offset = Vector3(clamp(offset.x, -2.2, 2.2), 0.0, clamp(offset.z, -2.2, 2.2))
	set_ai_plan("group_walk", target + group_offset, duration_hours, leader_id)

func get_physical_ai_state() -> Dictionary:
	return {
		"intent": current_intent,
		"activity": current_activity,
		"using_navigation": nav_agent != null,
		"reserved_spot": str(reserved_spot.name) if reserved_spot != null and is_instance_valid(reserved_spot) else "",
		"group_leader": group_leader_id
	}

func get_need_summary() -> String:
	return "Enerji %d • Sosyal %d • Açlık %d • Keyif %d" % [int(round(float(needs["energy"]))), int(round(float(needs["social"]))), int(round(float(needs["hunger"]))), int(round(float(needs["fun"])))]

func get_current_intent() -> String:
	return current_intent

func should_cancel_social_plan() -> bool:
	return float(needs.get("energy", 70.0)) < 16.0 or (current_phase == "work" and float(needs.get("energy", 70.0)) < 25.0)

func is_available_for_invite() -> bool:
	return current_intent not in ["resting", "friend_meetup", "community_event", "group_walk", "home_visit", "group_table", "home_chore", "celebration"] and current_phase != "work"


func set_city_crowd_factor(value: float) -> void:
	crowd_factor = clamp(value, 0.25, 1.0)
	speed = base_speed * lerp(0.94, 1.06, crowd_factor)
	if nav_agent != null: nav_agent.max_speed = speed * 1.18

func can_take_micro_break() -> bool:
	return phone_left <= 0.0 and call_left <= 0.0 and sit_left <= 0.0 and pause_left <= 0.0 and current_phase != "work" and current_intent in ["daily_routine", "park_break", "weekend_outing"]

func start_phone_break(seconds: float) -> void:
	if not can_take_micro_break():
		return
	pre_phone_activity = current_activity
	phone_left = clamp(seconds, 1.5, 10.0)
	current_activity = "Telefonuna bakıyor"
	if phone_prop != null: phone_prop.visible = true

func start_phone_call(seconds: float, activity_text: String = "Telefon görüşmesi yapıyor") -> void:
	if not can_take_micro_break():
		return
	pre_phone_activity = current_activity
	call_left = clamp(seconds, 2.0, 12.0)
	current_activity = activity_text.left(56)
	if phone_prop != null: phone_prop.visible = true

func set_home_life_plan(target: Vector3, activity_text: String, duration_hours: float) -> void:
	daily_activity_override = activity_text.left(56)
	set_ai_plan("home_chore", target, duration_hours)

func set_weekend_plan(target: Vector3, activity_text: String, duration_hours: float) -> void:
	daily_activity_override = activity_text.left(56)
	set_ai_plan("weekend_outing", target, duration_hours)

func set_celebration_plan(target: Vector3, duration_hours: float, celebrated_npc_id: String) -> void:
	daily_activity_override = "Doğum günü kutlamasında"
	set_ai_plan("celebration", target, duration_hours, celebrated_npc_id)

func get_daily_life_state() -> Dictionary:
	return {
		"activity": current_activity,
		"phone_call": call_left > 0.0,
		"carrying_bag": bag_left > 0.0,
		"eating": meal_left > 0.0,
		"intent": current_intent
	}

func set_group_table_plan(target: Vector3, duration_hours: float, partner_id: String) -> void:
	set_ai_plan("group_table", target, duration_hours, partner_id)

func say_custom_line(text: String) -> void:
	var bubble = Label3D.new()
	bubble.text = text.left(72)
	bubble.position = Vector3(0, 2.95, 0)
	bubble.font_size = 20
	bubble.outline_size = 5
	bubble.billboard = BaseMaterial3D.BILLBOARD_ENABLED
	bubble.modulate = Color(1,1,1,0.96)
	add_child(bubble)
	var tween = create_tween()
	tween.tween_interval(2.1)
	tween.tween_property(bubble, "modulate:a", 0.0, 0.55)
	tween.finished.connect(bubble.queue_free)

func interact(_player: Node) -> void:
	pause_left = max(pause_left, 4.0)
	var ui_nodes = get_tree().get_nodes_in_group("social_ui")
	if ui_nodes.size() > 0 and ui_nodes[0].has_method("open_for_npc"):
		ui_nodes[0].open_for_npc(npc_id, self)
	if rig != null and rig.has_method("set_mood"):
		rig.set_mood("curious", 2400)

func get_interaction_label() -> String:
	return "Konuş • %s" % display_name

func get_current_activity() -> String:
	return current_activity

func react_to_social_result(result: Dictionary) -> void:
	if rig == null:
		return
	var mood = str(result.get("mood", "happy"))
	if rig.has_method("set_mood"):
		rig.set_mood(mood, 2600)
	if bool(result.get("ok", false)) and rig.has_method("play_emote") and randf() < 0.55:
		rig.play_emote("wave" if mood != "excited" else "cheer")

func say_ambient_line(context: String = "friend") -> void:
	var lines = ["Selam!", "Sonra görüşürüz.", "Bugün mahalle güzel.", "Kahveye geçelim mi?"]
	if context in ["dating", "partner"]:
		lines = ["Biraz yürüyelim mi?", "Bugün birlikte takılalım.", "Akşam meydanda görüşürüz."]
	elif context == "work":
		lines = ["Biraz işim var.", "Molada görüşürüz.", "Sonra uğrarım."]
	var bubble = Label3D.new()
	bubble.text = str(lines[randi() % lines.size()])
	bubble.position = Vector3(0, 2.95, 0)
	bubble.font_size = 20
	bubble.outline_size = 5
	bubble.billboard = BaseMaterial3D.BILLBOARD_ENABLED
	bubble.modulate = Color(1,1,1,0.96)
	add_child(bubble)
	var tween = create_tween()
	tween.tween_interval(1.7)
	tween.tween_property(bubble, "modulate:a", 0.0, 0.55)
	tween.finished.connect(bubble.queue_free)

func get_social_id() -> String:
	return npc_id

func get_social_phase() -> String:
	return current_phase

func set_social_pause(seconds: float) -> void:
	pause_left = max(pause_left, clamp(seconds, 0.0, 8.0))

func face_social_node(other: Node3D) -> void:
	if other == null or not is_instance_valid(other):
		return
	var flat = other.global_position - global_position
	flat.y = 0.0
	if flat.length() > 0.1:
		rotation.y = atan2(-flat.x, -flat.z)

func play_social_reaction(kind: String) -> void:
	if rig == null:
		return
	match kind:
		"friend":
			if rig.has_method("set_mood"): rig.set_mood("happy", 2600)
			if rig.has_method("play_emote") and randf() < 0.55: rig.play_emote("wave")
		"dating", "partner":
			if rig.has_method("set_mood"): rig.set_mood("happy", 3600)
			if rig.has_method("play_emote") and randf() < 0.35: rig.play_emote("cheer")
		_:
			if rig.has_method("set_mood"): rig.set_mood("curious", 2200)

func set_simulation_enabled(enabled: bool) -> void:
	visible = enabled
	set_process(enabled)
	set_physics_process(enabled)
	if nav_agent != null:
		nav_agent.avoidance_enabled = enabled
	if enabled:
		_select_schedule(true)
