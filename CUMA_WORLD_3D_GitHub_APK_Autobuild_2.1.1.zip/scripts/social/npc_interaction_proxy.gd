extends StaticBody3D

var npc_ref: Node

func setup(value: Node) -> void:
	npc_ref = value

func interact(player: Node) -> void:
	if npc_ref != null and is_instance_valid(npc_ref) and npc_ref.has_method("interact"):
		npc_ref.interact(player)

func get_interaction_label() -> String:
	if npc_ref != null and is_instance_valid(npc_ref) and npc_ref.has_method("get_interaction_label"):
		return str(npc_ref.get_interaction_label())
	return "Konuş"
