extends Node

# Human Behavior 1.5
# Local-life director: phone habits, friend visits, crowd rhythm and small human interruptions.
# It intentionally adds no RPC surface and never edits another human player's save.

const THINK_MINUTES := 10
var last_tick = -1
var last_day = -1
var visits_today = 0
var spontaneous_calls_today = 0
var crowd_label = "Sakin"

func setup() -> void:
	add_to_group("human_behavior_director")
	set_process(true)

func _process(_delta: float) -> void:
	var gs = get_node_or_null("/root/GameState")
	if gs == null:
		return
	if last_day != int(gs.world_day):
		last_day = int(gs.world_day)
		visits_today = 0
		spontaneous_calls_today = 0
	var minute = int(floor(float(gs.time_of_day) * 60.0))
	var key = int(gs.world_day) * 1440 + int(floor(float(minute) / float(THINK_MINUTES)))
	if key == last_tick:
		return
	last_tick = key
	_tick_world(gs)

func _tick_world(gs: Node) -> void:
	var npcs = get_tree().get_nodes_in_group("relationship_npc")
	_update_crowd_rhythm(gs, npcs)
	_maybe_phone_break(gs, npcs)
	_maybe_friend_visit(gs, npcs)
	_maybe_spontaneous_message(gs, npcs)
	_maybe_group_table(gs, npcs)

func _update_crowd_rhythm(gs: Node, npcs: Array) -> void:
	var hour = float(gs.time_of_day)
	var factor = 0.65
	crowd_label = "Sakin"
	if (hour >= 7.0 and hour < 9.5) or (hour >= 16.5 and hour < 19.5):
		factor = 1.0
		crowd_label = "Yoğun"
	elif hour >= 11.0 and hour < 15.0:
		factor = 0.82
		crowd_label = "Hareketli"
	elif hour >= 22.5 or hour < 6.5:
		factor = 0.35
		crowd_label = "Gece sakinliği"
	for npc in npcs:
		if npc.has_method("set_city_crowd_factor"):
			npc.set_city_crowd_factor(factor)
	for citizen in get_tree().get_nodes_in_group("ambient_city_citizen"):
		if citizen.has_method("set_crowd_factor"):
			citizen.set_crowd_factor(factor)

func _maybe_phone_break(_gs: Node, npcs: Array) -> void:
	if npcs.is_empty() or randf() > 0.20:
		return
	var candidates: Array = []
	for npc in npcs:
		if npc.has_method("can_take_micro_break") and bool(npc.can_take_micro_break()):
			candidates.append(npc)
	if candidates.is_empty():
		return
	var npc = candidates[randi() % candidates.size()]
	if npc.has_method("start_phone_break"):
		npc.start_phone_break(randf_range(3.0, 8.0))

func _maybe_friend_visit(gs: Node, npcs: Array) -> void:
	if visits_today >= 2 or randf() > 0.055:
		return
	var hour = float(gs.time_of_day)
	if hour < 15.5 or hour > 21.5:
		return
	var candidates: Array = []
	for npc in npcs:
		if not npc.has_method("get_social_id"):
			continue
		var npc_id = str(npc.get_social_id())
		var rel: Dictionary = gs.get_social_relationship(npc_id)
		if str(rel.get("stage", "")) not in ["close_friend", "dating", "partner"]:
			continue
		if npc.has_method("is_available_for_invite") and not bool(npc.is_available_for_invite()):
			continue
		candidates.append(npc)
	if candidates.is_empty():
		return
	var npc = candidates[randi() % candidates.size()]
	if npc.has_method("set_ai_plan"):
		npc.set_ai_plan("home_visit", Vector3(0.0,0.05,10.55), 0.75)
		visits_today += 1
		var profile: Dictionary = gs.get_social_profile(str(npc.get_social_id()))
		gs.add_social_feed("%s uğramak için evinin kapısına doğru geliyor." % str(profile.get("name", "Bir arkadaşın")))

func _maybe_spontaneous_message(gs: Node, npcs: Array) -> void:
	if spontaneous_calls_today >= 3 or randf() > 0.10:
		return
	var friends: Array = []
	for npc in npcs:
		if not npc.has_method("get_social_id"):
			continue
		var rel: Dictionary = gs.get_social_relationship(str(npc.get_social_id()))
		if str(rel.get("stage", "")) in ["friend", "close_friend", "dating", "partner"]:
			friends.append(npc)
	if friends.is_empty():
		return
	var npc = friends[randi() % friends.size()]
	var profile: Dictionary = gs.get_social_profile(str(npc.get_social_id()))
	var messages = ["Bugün nasılsın?", "Akşam mahallede misin?", "Bir ara kahve içelim.", "Parkta denk gelirsek selam ver!"]
	gs.add_social_feed("%s: %s" % [str(profile.get("name", "Arkadaşın")), str(messages[randi() % messages.size()])])
	if npc.has_method("start_phone_break"):
		npc.start_phone_break(randf_range(2.5, 5.5))
	spontaneous_calls_today += 1

func _maybe_group_table(gs: Node, npcs: Array) -> void:
	if npcs.size() < 2 or randf() > 0.06:
		return
	var available: Array = []
	for npc in npcs:
		if npc.has_method("is_available_for_invite") and bool(npc.is_available_for_invite()):
			available.append(npc)
	if available.size() < 2:
		return
	available.shuffle()
	var a = available[0]
	var b = available[1]
	if not a.has_method("get_social_id") or not b.has_method("get_social_id"):
		return
	var bond: Dictionary = gs.get_npc_bond(str(a.get_social_id()), str(b.get_social_id()))
	if float(bond.get("score", 0.0)) < 28.0:
		return
	var center = Vector3(67.0,0.05,129.2) if randf() < 0.62 else Vector3(31.0,0.05,45.3)
	if a.has_method("set_group_table_plan"): a.set_group_table_plan(center, 0.75, str(b.get_social_id()))
	if b.has_method("set_group_table_plan"): b.set_group_table_plan(center, 0.75, str(a.get_social_id()))

func get_crowd_summary() -> String:
	return crowd_label
