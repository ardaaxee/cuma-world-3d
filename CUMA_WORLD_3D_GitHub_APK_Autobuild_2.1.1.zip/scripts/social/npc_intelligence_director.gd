extends Node

# NPC Intelligence 1.3
# Local social simulation only. It never grants multiplayer authority or mutates another human player's relationships.

const THINK_INTERVAL_GAME_MINUTES := 15
const MAX_DAILY_EVENTS := 5

var last_think_key = -1
var daily_event_count = 0
var last_event_day = -1

func setup() -> void:
	set_process(true)

func _process(_delta: float) -> void:
	var gs = get_node_or_null("/root/GameState")
	if gs == null:
		return
	if int(gs.world_day) != last_event_day:
		last_event_day = int(gs.world_day)
		daily_event_count = 0
	var minute = int(floor(float(gs.time_of_day) * 60.0))
	var key = int(gs.world_day) * 1440 + int(floor(float(minute) / float(THINK_INTERVAL_GAME_MINUTES)))
	if key == last_think_key:
		return
	last_think_key = key
	_think(gs)

func _think(gs: Node) -> void:
	var npcs = get_tree().get_nodes_in_group("relationship_npc")
	for npc in npcs:
		if npc.has_method("intelligence_tick"):
			npc.intelligence_tick(gs, float(THINK_INTERVAL_GAME_MINUTES) / 60.0)
	_process_invitation_calendar(gs, npcs)
	_process_neighborhood_calendar(gs, npcs)
	_plan_friend_meetups(gs, npcs)
	_plan_player_invites(gs, npcs)
	_plan_neighborhood_event(gs, npcs)
	_plan_spontaneous_group_walk(gs, npcs)

func _plan_friend_meetups(gs: Node, npcs: Array) -> void:
	if npcs.size() < 2:
		return
	var candidates: Array = []
	for i in range(npcs.size()):
		for j in range(i + 1, npcs.size()):
			var a = npcs[i]
			var b = npcs[j]
			if not a.has_method("get_social_id") or not b.has_method("get_social_id"):
				continue
			var bond: Dictionary = gs.get_npc_bond(str(a.get_social_id()), str(b.get_social_id()))
			var score = float(bond.get("score", 0.0))
			if score < 25.0:
				continue
			var stage = str(bond.get("stage", "acquaintance"))
			var weight = score + (18.0 if stage in ["close_friend", "dating", "partner"] else 0.0) + randf_range(-18.0, 18.0)
			candidates.append({"a": a, "b": b, "weight": weight, "stage": stage})
	if candidates.is_empty():
		return
	candidates.sort_custom(func(x, y): return float(x["weight"]) > float(y["weight"]))
	var chosen: Dictionary = candidates[0]
	if randf() > 0.32:
		return
	var a = chosen["a"]
	var b = chosen["b"]
	var spot = _meeting_spot(str(chosen["stage"]))
	if a.has_method("set_ai_plan"):
		a.set_ai_plan("friend_meetup", spot, 1.1, str(b.get_social_id()))
	if b.has_method("set_ai_plan"):
		b.set_ai_plan("friend_meetup", spot + Vector3(1.15, 0, 0.25), 1.1, str(a.get_social_id()))

func _plan_player_invites(gs: Node, npcs: Array) -> void:
	if not gs.has_method("queue_social_invitation"):
		return
	if randf() > 0.20:
		return
	var available: Array = []
	for npc in npcs:
		if not npc.has_method("get_social_id"):
			continue
		var npc_id = str(npc.get_social_id())
		var rel: Dictionary = gs.get_social_relationship(npc_id)
		if str(rel.get("stage", "")) not in ["friend", "close_friend", "dating", "partner"]:
			continue
		if npc.has_method("is_available_for_invite") and not bool(npc.is_available_for_invite()):
			continue
		available.append(npc)
	if available.is_empty():
		return
	var npc = available[randi() % available.size()]
	var npc_id = str(npc.get_social_id())
	var profile: Dictionary = gs.get_social_profile(npc_id)
	var kinds = ["coffee", "walk", "game_night", "park"]
	var kind = str(kinds[randi() % kinds.size()])
	gs.queue_social_invitation(npc_id, kind, int(gs.world_day), float(gs.time_of_day) + randf_range(0.8, 2.4))

func _plan_neighborhood_event(gs: Node, npcs: Array) -> void:
	if daily_event_count >= MAX_DAILY_EVENTS or randf() > 0.08:
		return
	if not gs.has_method("schedule_neighborhood_event"):
		return
	var types = ["coffee_circle", "garden_meet", "game_night", "photo_walk", "community_dinner"]
	var event_type = str(types[randi() % types.size()])
	var attendees: Array[String] = []
	var shuffled = npcs.duplicate()
	shuffled.shuffle()
	for npc in shuffled.slice(0, min(4, shuffled.size())):
		if npc.has_method("get_social_id"):
			attendees.append(str(npc.get_social_id()))
	if attendees.size() < 2:
		return
	gs.schedule_neighborhood_event(event_type, attendees, int(gs.world_day), float(gs.time_of_day) + randf_range(0.5, 2.0))
	daily_event_count += 1

func _plan_spontaneous_group_walk(gs: Node, npcs: Array) -> void:
	if npcs.size() < 3 or randf() > 0.055:
		return
	var candidates: Array = []
	for npc in npcs:
		if npc.has_method("is_available_for_invite") and bool(npc.is_available_for_invite()):
			candidates.append(npc)
	if candidates.size() < 3:
		return
	candidates.shuffle()
	var count = min(4, candidates.size())
	var target = [Vector3(38,0.05,82), Vector3(76,0.05,138), Vector3(72,0.05,130)][randi() % 3]
	var leader_id = str(candidates[0].get_social_id()) if candidates[0].has_method("get_social_id") else "group"
	var offsets = [Vector3.ZERO, Vector3(-0.85,0,0.75), Vector3(0.85,0,0.75), Vector3(0,0,1.45)]
	for i in range(count):
		var npc = candidates[i]
		if npc.has_method("set_group_walk"):
			npc.set_group_walk(target, 0.85, leader_id, offsets[i])
	if gs.has_method("add_social_feed"):
		gs.add_social_feed("Mahalleden birkaç kişi birlikte yürüyüşe çıktı.")

func _meeting_spot(stage: String) -> Vector3:
	var spots = [
		Vector3(67, 0.05, 129), # neighbor cafe
		Vector3(80, 0.05, 138), # garden
		Vector3(84, 0.05, 129), # community lounge
		Vector3(38, 0.05, 82),  # riverside
		Vector3(-15, 0.05, 38)  # city cafe
	]
	if stage in ["dating", "partner"]:
		spots.append(Vector3(45, 0.05, 83))
	return spots[randi() % spots.size()]


func _process_invitation_calendar(gs: Node, npcs: Array) -> void:
	if not gs.has_method("get_active_social_invitations"):
		return
	var absolute_now = float(gs.world_day) * 24.0 + float(gs.time_of_day)
	for invite in gs.get_active_social_invitations():
		var scheduled = float(int(invite.get("day", gs.world_day))) * 24.0 + float(invite.get("hour", gs.time_of_day))
		var status = str(invite.get("status", "pending"))
		var invite_id = str(invite.get("id", ""))
		if status == "pending" and absolute_now > scheduled + 1.25:
			gs.finish_social_invitation(invite_id, "expired")
			continue
		if status != "accepted" or absolute_now < scheduled or absolute_now > scheduled + 1.1:
			continue
		var npc_id = str(invite.get("npc_id", ""))
		for npc in npcs:
			if not npc.has_method("get_social_id") or str(npc.get_social_id()) != npc_id:
				continue
			if npc.has_method("should_cancel_social_plan") and bool(npc.should_cancel_social_plan()):
				gs.finish_social_invitation(invite_id, "canceled")
				break
			if npc.has_method("set_ai_plan"):
				npc.set_ai_plan(_invite_intent(str(invite.get("kind", "coffee"))), _invite_spot(str(invite.get("kind", "coffee"))), 1.0)
			gs.finish_social_invitation(invite_id, "active")
			break

func _process_neighborhood_calendar(gs: Node, npcs: Array) -> void:
	if not gs.has_method("get_active_neighborhood_events"):
		return
	var absolute_now = float(gs.world_day) * 24.0 + float(gs.time_of_day)
	for event in gs.get_active_neighborhood_events():
		var scheduled = float(int(event.get("day", gs.world_day))) * 24.0 + float(event.get("hour", gs.time_of_day))
		if absolute_now < scheduled or absolute_now > scheduled + 1.0:
			continue
		var attendees: Array = event.get("attendees", [])
		var spot = _event_spot(str(event.get("kind", "coffee_circle")))
		var leader_id = str(attendees[0]) if attendees.size() > 0 else "event"
		var formation_index = 0
		for npc in npcs:
			if not npc.has_method("get_social_id") or str(npc.get_social_id()) not in attendees:
				continue
			if str(event.get("kind", "")) == "photo_walk" and npc.has_method("set_group_walk"):
				var formation = [Vector3.ZERO,Vector3(-0.9,0,0.7),Vector3(0.9,0,0.7),Vector3(0,0,1.5)]
				npc.set_group_walk(spot, 1.1, leader_id, formation[formation_index % formation.size()])
				formation_index += 1
			elif npc.has_method("set_ai_plan"):
				npc.set_ai_plan("community_event", spot + Vector3(randf_range(-1.5, 1.5), 0, randf_range(-1.0, 1.0)), 1.3)
		for i in range(attendees.size()):
			for j in range(i + 1, attendees.size()):
				gs.advance_npc_bond(str(attendees[i]), str(attendees[j]), 1.4)
		gs.finish_neighborhood_event(str(event.get("id", "")))

func _invite_intent(kind: String) -> String:
	return "park_break" if kind in ["walk", "park"] else "socializing"

func _invite_spot(kind: String) -> Vector3:
	match kind:
		"walk": return Vector3(38, 0.05, 82)
		"park": return Vector3(80, 0.05, 138)
		"game_night": return Vector3(84, 0.05, 129)
		_: return Vector3(67, 0.05, 129)

func _event_spot(kind: String) -> Vector3:
	match kind:
		"garden_meet": return Vector3(80, 0.05, 138)
		"game_night": return Vector3(84, 0.05, 129)
		"photo_walk": return Vector3(38, 0.05, 82)
		"community_dinner": return Vector3(67, 0.05, 129)
		_: return Vector3(72, 0.05, 130)
