extends Node

var last_key = -1
var summary = "Şehir merkezi normal akışında"
var party_active = false
var last_party_log_day = -1

func setup() -> void:
	add_to_group("dynamic_city_director")
	set_process(true)

func _process(_delta: float) -> void:
	var gs = get_node_or_null("/root/GameState")
	if gs == null: return
	var key = int(gs.world_day) * 24 + int(floor(float(gs.time_of_day)))
	if key == last_key: return
	last_key = key
	_update_city(gs)

func _update_city(gs: Node) -> void:
	var day = posmod(int(gs.world_day), 7)
	var hour = float(gs.time_of_day)
	party_active = day == 6 and hour >= 20.0 and hour < 23.0
	if party_active:
		summary = "Komşu ev buluşması aktif"
	elif (hour >= 7.0 and hour < 9.5) or (hour >= 16.5 and hour < 19.0):
		summary = "İş giriş-çıkış yoğunluğu"
	elif hour >= 12.0 and hour < 14.0:
		summary = "Öğle molası • merkez hareketli"
	elif hour >= 19.0 and hour < 23.0:
		summary = "Akşam sosyal hayatı"
	else:
		summary = "Şehir merkezi normal akışında"
	for guest in get_tree().get_nodes_in_group("dynamic_party_guest"):
		if guest.has_method("set_party_active"): guest.set_party_active(party_active)
	if party_active and last_party_log_day != int(gs.world_day) and gs.has_method("add_daily_life_event"):
		last_party_log_day = int(gs.world_day)
		gs.add_daily_life_event("home_party", "Komşu ev buluşması başladı")

func get_dynamic_city_summary() -> String:
	return summary
