extends Node

# City Society 1.7: local weekly city calendar + crowd pulse. No RPCs.
var last_key = -1
var weekly_headline = "Şehir haftaya hazırlanıyor"
var event_index = -1
var last_announced_event = ""

const EVENTS := [
	{"day":1,"start":18.0,"end":20.0,"title":"Spor salonu grup antrenmanı"},
	{"day":2,"start":19.0,"end":21.0,"title":"Topluluk atölyesinde yaratıcı akşam"},
	{"day":3,"start":18.5,"end":21.0,"title":"Mahalle kafe buluşması"},
	{"day":4,"start":19.0,"end":21.5,"title":"Arcade turnuvası"},
	{"day":5,"start":19.0,"end":22.0,"title":"Cuma akşamı şehir etkinliği"},
	{"day":6,"start":12.0,"end":16.0,"title":"Hafta sonu açık hava pazarı"},
	{"day":6,"start":20.0,"end":22.5,"title":"Komşu evinde küçük ev buluşması"},
	{"day":0,"start":11.0,"end":15.0,"title":"Pazar brunch ve mahalle yürüyüşü"}
]

func setup() -> void:
	add_to_group("city_society_director")
	set_process(true)

func _process(_delta:float) -> void:
	var gs=get_node_or_null("/root/GameState")
	if gs == null: return
	var key=int(gs.world_day)*24+int(floor(float(gs.time_of_day)))
	if key == last_key: return
	last_key=key
	_update_event(gs)
	_update_crowd(gs)

func _update_event(gs:Node) -> void:
	var day=posmod(int(gs.world_day),7)
	var hour=float(gs.time_of_day)
	event_index=-1
	weekly_headline="Şehir normal akışında"
	for i in range(EVENTS.size()):
		var e:Dictionary=EVENTS[i]
		if int(e.day)==day and hour>=float(e.start) and hour<float(e.end):
			event_index=i; weekly_headline=str(e.title)
			var signature = "%d:%s" % [int(gs.world_day), weekly_headline]
			if signature != last_announced_event:
				last_announced_event = signature
				if gs.has_method("add_daily_life_event"): gs.add_daily_life_event("city_event",weekly_headline)
			break

func _update_crowd(gs:Node) -> void:
	var h=float(gs.time_of_day)
	var factor=0.38
	if (h>=7.0 and h<9.5) or (h>=16.5 and h<19.5): factor=0.92
	elif h>=11.0 and h<16.5: factor=0.70
	elif h>=19.5 and h<23.0: factor=0.62
	elif h>=23.0 or h<6.0: factor=0.18
	if event_index >= 0: factor=min(1.0,factor+0.18)
	for citizen in get_tree().get_nodes_in_group("society_crowd"):
		if citizen.has_method("set_crowd_factor"): citizen.set_crowd_factor(factor)

func get_city_society_summary() -> String:
	return weekly_headline
