extends Node

# Daily Life 1.6
# Local NPC-life simulation layered on top of Social Life/NPC Intelligence.
# No RPCs: birthdays, calls, home routines and weekend plans stay player-local.

const TICK_MINUTES := 15
const MAX_DAILY_CALLS := 3
const MAX_DAILY_HOME_ROUTINES := 5

var last_tick = -1
var last_day = -1
var calls_today = 0
var home_routines_today = 0
var weekend_events_today = 0
var birthday_announced_for = ""
var birthday_party_started_for = ""
var day_label = "Pazartesi"
var daily_headline = "Mahalle güne hazırlanıyor"

const HOME_TARGETS := {
	"ece": Vector3(18.5, 0.05, 144.0),
	"selin": Vector3(22.0, 0.05, 144.0),
	"deniz": Vector3(29.5, 0.05, 144.0),
	"mert": Vector3(33.0, 0.05, 144.0),
	"ipek": Vector3(40.5, 0.05, 144.0),
	"kerem": Vector3(44.0, 0.05, 144.0),
	"elif": Vector3(51.5, 0.05, 144.0),
	"baran": Vector3(55.0, 0.05, 144.0)
}

const BIRTHDAY_DAY := {
	"ece": 3, "deniz": 7, "selin": 11, "mert": 15,
	"ipek": 19, "kerem": 23, "elif": 25, "baran": 27
}

func setup() -> void:
	add_to_group("daily_life_director")
	set_process(true)

func _process(_delta: float) -> void:
	var gs = get_node_or_null("/root/GameState")
	if gs == null:
		return
	if last_day != int(gs.world_day):
		last_day = int(gs.world_day)
		calls_today = 0
		home_routines_today = 0
		weekend_events_today = 0
		birthday_announced_for = ""
		birthday_party_started_for = ""
		day_label = _weekday_name(last_day)
		daily_headline = "%s başladı" % day_label
		if gs.has_method("add_daily_life_event"):
			gs.add_daily_life_event("day_start", "%s • mahalle yeni güne başladı." % day_label)
	var minute = int(floor(float(gs.time_of_day) * 60.0))
	var key = int(gs.world_day) * 1440 + int(floor(float(minute) / float(TICK_MINUTES)))
	if key == last_tick:
		return
	last_tick = key
	_tick(gs)

func _tick(gs: Node) -> void:
	var npcs = get_tree().get_nodes_in_group("relationship_npc")
	if npcs.is_empty():
		return
	_maybe_home_routine(gs, npcs)
	_maybe_phone_call(gs, npcs)
	_maybe_weekend_plan(gs, npcs)
	_maybe_birthday(gs, npcs)
	_update_headline(gs)

func _maybe_home_routine(gs: Node, npcs: Array) -> void:
	if home_routines_today >= MAX_DAILY_HOME_ROUTINES or randf() > 0.16:
		return
	var hour = float(gs.time_of_day)
	if not ((hour >= 6.8 and hour < 8.8) or (hour >= 19.5 and hour < 22.2)):
		return
	var candidates: Array = []
	for npc in npcs:
		if not npc.has_method("get_social_id") or not npc.has_method("is_available_for_invite"):
			continue
		var npc_id = str(npc.get_social_id())
		if not HOME_TARGETS.has(npc_id) or not bool(npc.is_available_for_invite()):
			continue
		candidates.append(npc)
	if candidates.is_empty():
		return
	var npc = candidates[randi() % candidates.size()]
	var id = str(npc.get_social_id())
	var morning = hour < 10.0
	var label = "Kahvaltı hazırlıyor" if morning else ["Evini toparlıyor", "Akşam yemeği hazırlıyor", "Evde dinleniyor"][randi() % 3]
	if npc.has_method("set_home_life_plan"):
		npc.set_home_life_plan(HOME_TARGETS[id], label, 0.65 if morning else 0.9)
		home_routines_today += 1

func _maybe_phone_call(gs: Node, npcs: Array) -> void:
	if calls_today >= MAX_DAILY_CALLS or randf() > 0.08:
		return
	var hour = float(gs.time_of_day)
	if hour < 10.0 or hour > 21.8:
		return
	var candidates: Array = []
	for npc in npcs:
		if not npc.has_method("get_social_id"):
			continue
		var id = str(npc.get_social_id())
		var rel: Dictionary = gs.get_social_relationship(id)
		if str(rel.get("stage", "")) not in ["friend", "close_friend", "dating", "partner"]:
			continue
		if npc.has_method("can_take_micro_break") and bool(npc.can_take_micro_break()):
			candidates.append(npc)
	if candidates.is_empty():
		return
	var npc = candidates[randi() % candidates.size()]
	var profile: Dictionary = gs.get_social_profile(str(npc.get_social_id()))
	var lines = ["Akşam planını konuşuyor", "Bir arkadaşını arıyor", "Kısa bir telefon görüşmesi yapıyor", "Hafta sonu için plan yapıyor"]
	var line = str(lines[randi() % lines.size()])
	if npc.has_method("start_phone_call"):
		npc.start_phone_call(randf_range(4.5, 9.0), line)
		calls_today += 1
		if randf() < 0.30:
			gs.add_social_feed("%s bir arkadaşıyla telefonda plan yapıyor." % str(profile.get("name", "Komşun")))

func _maybe_weekend_plan(gs: Node, npcs: Array) -> void:
	if not _is_weekend(int(gs.world_day)) or weekend_events_today >= 2:
		return
	var hour = float(gs.time_of_day)
	if hour < 10.0 or hour > 19.5 or randf() > 0.08:
		return
	var available: Array = []
	for npc in npcs:
		if npc.has_method("is_available_for_invite") and bool(npc.is_available_for_invite()):
			available.append(npc)
	if available.size() < 2:
		return
	available.shuffle()
	var count = min(4, available.size())
	var brunch = hour < 14.0
	var target = Vector3(67.0,0.05,129.2) if brunch else Vector3(80.0,0.05,138.0)
	var label = "Hafta sonu brunch'ına gidiyor" if brunch else "Hafta sonu arkadaşlarıyla parkta"
	for i in range(count):
		var npc = available[i]
		if npc.has_method("set_weekend_plan"):
			npc.set_weekend_plan(target + Vector3(float(i % 2) * 0.8 - 0.4, 0, float(i / 2) * 0.7), label, 1.25)
	weekend_events_today += 1
	daily_headline = "Hafta sonu • arkadaş grupları dışarıda"
	if gs.has_method("add_daily_life_event"):
		gs.add_daily_life_event("weekend", "%s: mahalleden bir grup %s." % [day_label, "brunch için kafede" if brunch else "parkta buluşuyor"])

func _maybe_birthday(gs: Node, npcs: Array) -> void:
	var cycle_day = ((int(gs.world_day) - 1) % 28) + 1
	var birthday_id = ""
	for id in BIRTHDAY_DAY.keys():
		if int(BIRTHDAY_DAY[id]) == cycle_day:
			birthday_id = str(id)
			break
	if birthday_id == "":
		return
	var profile: Dictionary = gs.get_social_profile(birthday_id)
	if profile.is_empty():
		return
	var name = str(profile.get("name", birthday_id))
	if birthday_announced_for != birthday_id:
		birthday_announced_for = birthday_id
		gs.add_social_feed("Bugün %s'nin doğum günü. Akşam mahallede küçük bir kutlama planlanıyor." % name)
		if gs.has_method("add_daily_life_event"):
			gs.add_daily_life_event("birthday", "%s'nin doğum günü • 19:30 topluluk alanı" % name)
	# After 18:45, route the birthday NPC and a few available friends to the community lounge.
	if float(gs.time_of_day) < 18.75 or birthday_party_started_for == birthday_id:
		return
	birthday_party_started_for = birthday_id
	var guests: Array = []
	for npc in npcs:
		if not npc.has_method("get_social_id"):
			continue
		if str(npc.get_social_id()) == birthday_id:
			guests.push_front(npc)
		elif npc.has_method("is_available_for_invite") and bool(npc.is_available_for_invite()):
			guests.append(npc)
	guests = guests.slice(0, min(5, guests.size()))
	for i in range(guests.size()):
		var npc = guests[i]
		if npc.has_method("set_celebration_plan"):
			npc.set_celebration_plan(Vector3(84.0,0.05,129.0) + Vector3(float(i%3)-1.0,0,float(i/3)*0.8), 1.5, birthday_id)
	daily_headline = "%s'nin doğum günü kutlanıyor" % name

func _update_headline(gs: Node) -> void:
	var hour = float(gs.time_of_day)
	if birthday_party_started_for != "":
		var profile: Dictionary = gs.get_social_profile(birthday_party_started_for)
		daily_headline = "%s'nin doğum günü kutlanıyor" % str(profile.get("name", birthday_party_started_for))
		return
	if _is_weekend(int(gs.world_day)):
		if hour < 10.0: daily_headline = "Hafta sonu sabahı • mahalle yavaş uyanıyor"
		elif hour < 18.0: daily_headline = "Hafta sonu • kafe, park ve ziyaretler hareketli"
		elif "doğum günü" not in daily_headline.to_lower(): daily_headline = "Hafta sonu akşamı • arkadaş grupları dışarıda"
	else:
		if hour < 8.5: daily_headline = "Hafta içi sabahı • işe hazırlanıyorlar"
		elif hour < 17.0: daily_headline = "Hafta içi • iş ve günlük işler sürüyor"
		elif hour < 21.5: daily_headline = "İş çıkışı • market, kafe ve ev dönüşleri"
		else: daily_headline = "Gece • komşular evlerine çekiliyor"

func get_daily_summary() -> String:
	return "%s • %s" % [day_label, daily_headline]

func _weekday_name(day_value: int) -> String:
	var names = ["Pazar", "Pazartesi", "Salı", "Çarşamba", "Perşembe", "Cuma", "Cumartesi"]
	return names[posmod(day_value, 7)]

func _is_weekend(day_value: int) -> bool:
	var index = posmod(day_value, 7)
	return index == 0 or index == 6
