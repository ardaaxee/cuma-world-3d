extends Node

var last_sim_hour = -1
var last_social_scene_ms = 0

func setup() -> void:
	set_process(true)

func _process(_delta: float) -> void:
	var gs = get_node_or_null("/root/GameState")
	if gs == null:
		return
	var hour_key = int(gs.world_day) * 24 + int(floor(float(gs.time_of_day)))
	if hour_key != last_sim_hour:
		last_sim_hour = hour_key
		_simulate_hour()
	_maybe_stage_visible_social_scene()

func _simulate_hour() -> void:
	var gs = get_node_or_null("/root/GameState")
	if gs == null:
		return
	var npcs = get_tree().get_nodes_in_group("relationship_npc")
	for i in range(npcs.size()):
		for j in range(i + 1, npcs.size()):
			var a = npcs[i]
			var b = npcs[j]
			if not (a is Node3D) or not (b is Node3D):
				continue
			if not a.has_method("get_social_id") or not b.has_method("get_social_id"):
				continue
			var distance = a.global_position.distance_to(b.global_position)
			if distance > 7.5:
				continue
			var amount = 1.0
			if distance < 3.5:
				amount = 1.8
			if a.has_method("get_social_phase") and b.has_method("get_social_phase"):
				if str(a.get_social_phase()) == "leisure" and str(b.get_social_phase()) == "leisure":
					amount += 1.2
			gs.advance_npc_bond(str(a.get_social_id()), str(b.get_social_id()), amount)

func _maybe_stage_visible_social_scene() -> void:
	var now = Time.get_ticks_msec()
	if now - last_social_scene_ms < 15000:
		return
	var npcs = get_tree().get_nodes_in_group("relationship_npc")
	var best_a = null
	var best_b = null
	var best = 3.6
	for i in range(npcs.size()):
		for j in range(i + 1, npcs.size()):
			if not (npcs[i] is Node3D) or not (npcs[j] is Node3D):
				continue
			var d = npcs[i].global_position.distance_to(npcs[j].global_position)
			if d < best:
				best = d
				best_a = npcs[i]
				best_b = npcs[j]
	if best_a == null or best_b == null:
		return
	if not best_a.has_method("get_social_id") or not best_b.has_method("get_social_id"):
		return
	last_social_scene_ms = now
	if best_a.has_method("set_social_pause"): best_a.set_social_pause(2.8)
	if best_b.has_method("set_social_pause"): best_b.set_social_pause(2.8)
	if best_a.has_method("face_social_node"): best_a.face_social_node(best_b)
	if best_b.has_method("face_social_node"): best_b.face_social_node(best_a)
	var gs = get_node_or_null("/root/GameState")
	var stage = "acquaintance"
	if gs != null and gs.has_method("get_npc_bond"):
		var bond: Dictionary = gs.get_npc_bond(str(best_a.get_social_id()), str(best_b.get_social_id()))
		stage = str(bond.get("stage", "acquaintance"))
	var reaction = "friend" if stage in ["friend", "close_friend"] else stage
	if best_a.has_method("play_social_reaction"): best_a.play_social_reaction(reaction)
	if best_b.has_method("play_social_reaction"): best_b.play_social_reaction(reaction)
	if best_a.has_method("say_ambient_line") and randf() < 0.72:
		best_a.say_ambient_line(stage)
