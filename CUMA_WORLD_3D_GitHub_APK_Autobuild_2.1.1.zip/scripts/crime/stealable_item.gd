extends StaticBody3D

var item_id = "display_item"
var display_name = "Sergi ürünü"
var value = 40
var risk = 0.35
var taken_day = -1

func setup(id_value: String, title: String, price_value: int, risk_value: float = 0.35) -> void:
	item_id = id_value.strip_edges().to_lower().left(32)
	display_name = title.left(48)
	value = clamp(price_value, 1, 5000)
	risk = clamp(risk_value, 0.05, 0.95)
	add_to_group("crime_target")
	_build_visual()

func _build_visual() -> void:
	var base = MeshInstance3D.new()
	var base_mesh = CylinderMesh.new()
	base_mesh.top_radius = 0.28
	base_mesh.bottom_radius = 0.32
	base_mesh.height = 0.16
	base.mesh = base_mesh
	base.position.y = -0.42
	var base_mat = StandardMaterial3D.new()
	base_mat.albedo_color = Color("31363b")
	base_mat.roughness = 0.72
	base.material_override = base_mat
	add_child(base)
	var item = MeshInstance3D.new()
	var item_mesh = SphereMesh.new()
	item_mesh.radius = 0.24
	item_mesh.height = 0.48
	item.mesh = item_mesh
	item.scale = Vector3(0.75, 1.0, 0.55)
	var mat = StandardMaterial3D.new()
	mat.albedo_color = Color("b6a06a")
	mat.metallic = 0.35
	mat.roughness = 0.28
	item.material_override = mat
	add_child(item)
	var collider = CollisionShape3D.new()
	var shape = BoxShape3D.new()
	shape.size = Vector3(0.8, 1.0, 0.8)
	collider.shape = shape
	add_child(collider)

func get_interaction_label() -> String:
	var gs = get_node_or_null("/root/GameState")
	if gs != null and (taken_day == gs.world_day or gs.stolen_goods.has(item_id)):
		return "%s • Zaten sende" % display_name
	return "RİSKLİ • %s al (oyun içi)" % display_name

func interact(player: Node) -> void:
	var gs = get_node_or_null("/root/GameState")
	if gs == null:
		return
	if taken_day == gs.world_day or gs.stolen_goods.has(item_id):
		if player != null and player.has_method("show_status"):
			player.show_status("Burada bugün başka bir şey yok.", 1.6)
		return
	var camera_bonus = 0.0
	for camera in get_tree().get_nodes_in_group("security_camera"):
		if camera.has_method("can_observe") and camera.can_observe(global_position):
			camera_bonus = max(camera_bonus, 0.24)
	var witness_bonus = 0.0
	for npc in get_tree().get_nodes_in_group("relationship_npc"):
		if npc is Node3D and npc.global_position.distance_to(global_position) < 7.0:
			witness_bonus = 0.18
			break
	var detected = randf() < clamp(risk + camera_bonus + witness_bonus, 0.08, 0.96)
	taken_day = gs.world_day
	gs.add_stolen_good(item_id, display_name, value)
	gs.commit_game_crime("theft", "%s hırsızlığı" % display_name, 1, detected, value)
	if player != null and player.has_method("show_status"):
		if detected:
			player.show_status("%s alındı • Birileri fark etti!" % display_name, 2.4)
		else:
			player.show_status("%s alındı • Şimdilik fark edilmedin" % display_name, 2.2)
