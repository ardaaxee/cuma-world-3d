extends CanvasLayer

var label: Label
var last_text = ""

func setup() -> void:
	layer = 32
	label = Label.new()
	label.anchor_left = 0.5
	label.anchor_right = 0.5
	label.offset_left = -190
	label.offset_right = 190
	label.offset_top = 18
	label.offset_bottom = 52
	label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	label.add_theme_font_size_override("font_size", 20)
	label.visible = false
	add_child(label)
	set_process(true)

func _process(_delta: float) -> void:
	var gs = get_node_or_null("/root/GameState")
	if gs == null or label == null:
		return
	if gs.law_heat <= 0:
		label.visible = false
		return
	var stars = "★".repeat(gs.law_heat) + "☆".repeat(5 - gs.law_heat)
	var unit = "FIB TAKİBİ" if gs.law_heat >= 4 else ("POLİS TAKİBİ" if gs.law_heat >= 2 else "DİKKAT")
	var text = "%s  %s" % [unit, stars]
	if text != last_text:
		last_text = text
		label.text = text
	label.visible = true
