extends StaticBody3D

func setup() -> void:
	var collider = CollisionShape3D.new()
	var shape = BoxShape3D.new()
	shape.size = Vector3(1.6, 1.4, 0.8)
	collider.shape = shape
	add_child(collider)

func get_interaction_label() -> String:
	var gs = get_node_or_null("/root/GameState")
	if gs == null:
		return "POLİS BANKOSU"
	if gs.law_heat > 0:
		return "POLİS BANKOSU • Teslim ol"
	if gs.outstanding_fine > 0:
		return "POLİS BANKOSU • Cezayı öde ₺%d" % gs.outstanding_fine
	return "POLİS BANKOSU • Kayıt bilgisi"

func interact(player: Node) -> void:
	var gs = get_node_or_null("/root/GameState")
	if gs == null:
		return
	if gs.law_heat > 0:
		var director = get_tree().get_first_node_in_group("law_director")
		if director != null and director.has_method("detain_player"):
			director.detain_player(player, "Gönüllü teslim")
		return
	if gs.outstanding_fine > 0:
		var amount = gs.outstanding_fine
		if gs.money >= amount:
			gs.spend_money(amount)
			gs.outstanding_fine = 0
			gs.state_changed.emit()
			if player != null and player.has_method("show_status"):
				player.show_status("Ceza ödendi.", 1.8)
		else:
			if player != null and player.has_method("show_status"):
				player.show_status("Yeterli paran yok.", 1.8)
		return
	if player != null and player.has_method("show_status"):
		player.show_status("Aktif aranma kaydın yok.", 1.8)
