extends CharacterBody3D

const ProceduralHumanoid = preload("res://scripts/character/procedural_humanoid.gd")

var officer_name = "Memur"
var federal = false
var patrol: Array[Vector3] = []
var patrol_index = 0
var speed = 2.6
var visual: Node3D
var label: Label3D
var detain_cooldown = 0.0

func setup(name_value: String, is_federal: bool, points: Array[Vector3]) -> void:
	officer_name = name_value.left(32)
	federal = is_federal
	patrol = points.duplicate()
	if not patrol.is_empty():
		global_position = patrol[0]
	_build_body()
	add_to_group("law_officer")

func _build_body() -> void:
	var collider = CollisionShape3D.new()
	var capsule = CapsuleShape3D.new()
	capsule.radius = 0.38
	capsule.height = 1.78
	collider.shape = capsule
	collider.position.y = 0.89
	add_child(collider)
	visual = Node3D.new()
	visual.set_script(ProceduralHumanoid)
	add_child(visual)
	visual.setup({
		"skin": Color("c99574"),
		"top": Color("202a35") if not federal else Color("2f343b"),
		"pants": Color("151b21"),
		"hair": Color("22201e"),
		"shoes": Color("0c0d0f"),
		"height_scale": 1.0,
		"shoulder_scale": 1.07
	})
	label = Label3D.new()
	label.text = ("FIB • " if federal else "POLİS • ") + officer_name
	label.position = Vector3(0, 2.15, 0)
	label.font_size = 19
	label.outline_size = 5
	label.billboard = BaseMaterial3D.BILLBOARD_ENABLED
	add_child(label)

func _physics_process(delta: float) -> void:
	detain_cooldown = max(0.0, detain_cooldown - delta)
	var gs = get_node_or_null("/root/GameState")
	var player = get_tree().get_first_node_in_group("player")
	var threshold = 4 if federal else 2
	var chasing = gs != null and player != null and gs.law_heat >= threshold
	var target = Vector3.ZERO
	if chasing:
		target = player.global_position
	elif not patrol.is_empty():
		target = patrol[patrol_index]
	else:
		return
	var flat = target - global_position
	flat.y = 0.0
	if flat.length() < (1.45 if chasing else 0.65):
		if chasing and detain_cooldown <= 0.0:
			detain_cooldown = 5.0
			var director = get_tree().get_first_node_in_group("law_director")
			if director != null and director.has_method("detain_player"):
				director.detain_player(player, "Federal takip" if federal else "Polis müdahalesi")
		elif not patrol.is_empty():
			patrol_index = (patrol_index + 1) % patrol.size()
		velocity = Vector3.ZERO
	else:
		var move_speed = 4.1 if chasing else speed
		var dir = flat.normalized()
		velocity = dir * move_speed
		rotation.y = lerp_angle(rotation.y, atan2(-dir.x, -dir.z), min(1.0, delta * 5.0))
		move_and_slide()
	if visual != null and visual.has_method("update_pose"):
		visual.update_pose(delta, Vector2(velocity.x, velocity.z).length(), chasing, velocity.y, is_on_floor(), false, 0.0)
