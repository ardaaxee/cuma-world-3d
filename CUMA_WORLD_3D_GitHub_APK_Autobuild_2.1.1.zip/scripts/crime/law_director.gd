extends Node

var cooldown_clock = 0.0
var station_release = Vector3(-43.0, 0.10, 52.0)

func setup() -> void:
	add_to_group("law_director")

func _process(delta: float) -> void:
	var gs = get_node_or_null("/root/GameState")
	if gs == null or gs.law_heat <= 0:
		return
	cooldown_clock += delta
	if cooldown_clock >= 48.0:
		cooldown_clock = 0.0
		gs.reduce_law_heat(1)

func detain_player(player: Node, reason: String = "Yakalandın") -> void:
	var gs = get_node_or_null("/root/GameState")
	if gs == null or gs.law_heat <= 0:
		return
	var result: Dictionary = gs.resolve_arrest()
	if player != null and player is Node3D:
		player.global_position = station_release
		if player.has_method("show_status"):
			player.show_status("%s • ₺%d ceza • %d eşya el kondu" % [reason, int(result.get("fine", 0)), int(result.get("seized", 0))], 4.0)

func get_dispatch_summary() -> String:
	var gs = get_node_or_null("/root/GameState")
	return gs.get_law_summary() if gs != null and gs.has_method("get_law_summary") else "Yasal durum normal"
