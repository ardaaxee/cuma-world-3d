extends CanvasLayer

var panel: PanelContainer
var title_label: Label
var target_label: Label
var status_label: Label
var sequence: Array[int] = []
var progress = 0
var terminal_id = ""
var mode = "training"
var player_ref: Node = null

const NODE_NAMES := ["A", "B", "C", "D"]

func setup() -> void:
	layer = 58
	add_to_group("cyber_puzzle_ui")
	_build_ui()

func _build_ui() -> void:
	panel = PanelContainer.new()
	panel.anchor_left = 0.5
	panel.anchor_right = 0.5
	panel.anchor_top = 0.5
	panel.anchor_bottom = 0.5
	panel.offset_left = -230
	panel.offset_right = 230
	panel.offset_top = -180
	panel.offset_bottom = 180
	panel.visible = false
	add_child(panel)
	var box = VBoxContainer.new()
	box.add_theme_constant_override("separation", 10)
	panel.add_child(box)
	title_label = Label.new()
	title_label.text = "CUMA CYBER • KURGU SİMÜLASYON"
	title_label.add_theme_font_size_override("font_size", 22)
	box.add_child(title_label)
	var note = Label.new()
	note.text = "Gerçek ağ/komut yok. Ekrandaki NODE sırasını eşleştir."
	note.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	box.add_child(note)
	target_label = Label.new()
	target_label.add_theme_font_size_override("font_size", 28)
	target_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	box.add_child(target_label)
	var row = HBoxContainer.new()
	row.alignment = BoxContainer.ALIGNMENT_CENTER
	box.add_child(row)
	for i in range(4):
		var button = Button.new()
		button.text = "NODE " + NODE_NAMES[i]
		button.custom_minimum_size = Vector2(92, 54)
		button.pressed.connect(_press_node.bind(i))
		row.add_child(button)
	status_label = Label.new()
	status_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	box.add_child(status_label)
	var close = Button.new()
	close.text = "KAPAT"
	close.pressed.connect(close_panel)
	box.add_child(close)

func open_challenge(id_value: String, title: String, difficulty: int, mode_value: String, player: Node) -> void:
	terminal_id = id_value.left(32)
	mode = mode_value
	player_ref = player
	progress = 0
	sequence.clear()
	var length = clamp(difficulty, 2, 5)
	for _i in range(length):
		sequence.append(randi_range(0, 3))
	title_label.text = "%s • KURGU NODE SİMÜLASYONU" % title
	var parts: Array[String] = []
	for value in sequence:
		parts.append("NODE " + NODE_NAMES[int(value)])
	target_label.text = " → ".join(parts)
	status_label.text = "Sırayı baştan sona eşleştir."
	panel.visible = true

func close_panel() -> void:
	panel.visible = false
	player_ref = null

func _press_node(index: int) -> void:
	if not panel.visible or sequence.is_empty():
		return
	if index == int(sequence[progress]):
		progress += 1
		status_label.text = "Doğru • %d/%d" % [progress, sequence.size()]
		if progress >= sequence.size():
			_complete(true)
	else:
		_complete(false)

func _complete(success: bool) -> void:
	var gs = get_node_or_null("/root/GameState")
	if gs == null:
		close_panel()
		return
	if success:
		var xp = 18 + sequence.size() * 7
		gs.complete_cyber_puzzle(terminal_id, mode, xp)
		if mode == "shadow_grid":
			gs.commit_game_crime("cyber_intrusion", "Kurgu Shadow Grid erişimi", 1, randf() < 0.55, 0)
		status_label.text = "BAŞARILI • +%d CYBER XP" % xp
		if player_ref != null and player_ref.has_method("show_status"):
			player_ref.show_status("Kurgu cyber bulmacası tamamlandı.", 2.0)
	else:
		status_label.text = "BAŞARISIZ • Oturum sıfırlandı"
		if mode == "shadow_grid":
			gs.commit_game_crime("cyber_intrusion", "Kurgu Shadow Grid erişimi", 1, true, 0)
		if player_ref != null and player_ref.has_method("show_status"):
			player_ref.show_status("Node sırası bozuldu.", 1.8)
	await get_tree().create_timer(1.0).timeout
	close_panel()
