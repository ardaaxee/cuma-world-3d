extends AnimatableBody3D

var route: Array[Vector3] = []
var route_index = 0
var speed = 6.0
var wait_left = 0.0
var flash = 0.0
var red_light: MeshInstance3D
var blue_light: MeshInstance3D

func setup(points: Array[Vector3]) -> void:
	route = points.duplicate()
	if route.size() < 2:
		return
	global_position = route[0]
	_build_car()
	add_to_group("law_patrol_vehicle")

func _build_car() -> void:
	var collider = CollisionShape3D.new()
	var shape = BoxShape3D.new()
	shape.size = Vector3(1.85, 1.1, 3.8)
	collider.shape = shape
	collider.position = Vector3(0, 0.62, 0)
	add_child(collider)
	_box(Vector3(1.8, 0.75, 3.7), Vector3(0, 0.62, 0), Color("e5e8ea"))
	_box(Vector3(1.56, 0.62, 1.9), Vector3(0, 1.23, -0.1), Color("263543"))
	red_light = _light_box(Vector3(-0.22, 1.62, 0), Color("d7373f"))
	blue_light = _light_box(Vector3(0.22, 1.62, 0), Color("346bd1"))
	for x in [-0.78, 0.78]:
		for z in [-1.22, 1.22]:
			_wheel(Vector3(x, 0.34, z))

func _process(delta: float) -> void:
	if route.size() < 2:
		return
	flash += delta * 7.0
	red_light.visible = sin(flash) > 0.0
	blue_light.visible = not red_light.visible
	if wait_left > 0.0:
		wait_left -= delta
		return
	var target = route[route_index]
	var flat = target - global_position
	flat.y = 0.0
	if flat.length() < 0.6:
		route_index = (route_index + 1) % route.size()
		wait_left = 0.8
		return
	var dir = flat.normalized()
	global_position += dir * speed * delta
	rotation.y = lerp_angle(rotation.y, atan2(-dir.x, -dir.z), min(1.0, delta * 4.5))

func set_simulation_enabled(enabled: bool) -> void:
	visible = enabled
	set_process(enabled)

func _box(size: Vector3, pos: Vector3, color: Color) -> MeshInstance3D:
	var n = MeshInstance3D.new()
	var mesh = BoxMesh.new()
	mesh.size = size
	n.mesh = mesh
	n.position = pos
	var mat = StandardMaterial3D.new()
	mat.albedo_color = color
	mat.roughness = 0.66
	n.material_override = mat
	add_child(n)
	return n

func _light_box(pos: Vector3, color: Color) -> MeshInstance3D:
	var n = _box(Vector3(0.28, 0.12, 0.25), pos, color)
	var mat = StandardMaterial3D.new()
	mat.albedo_color = color
	mat.emission_enabled = true
	mat.emission = color
	mat.emission_energy_multiplier = 2.2
	n.material_override = mat
	return n

func _wheel(pos: Vector3) -> void:
	var n = MeshInstance3D.new()
	var mesh = CylinderMesh.new()
	mesh.top_radius = 0.29
	mesh.bottom_radius = 0.29
	mesh.height = 0.18
	mesh.radial_segments = 14
	n.mesh = mesh
	n.position = pos
	n.rotation_degrees.z = 90
	var mat = StandardMaterial3D.new()
	mat.albedo_color = Color("111316")
	mat.roughness = 0.95
	n.material_override = mat
	add_child(n)
