extends StaticBody3D

var terminal_id = "training_grid"
var display_name = "CYBER LAB"
var difficulty = 3
var mode = "training"

func setup(id_value: String, title: String, difficulty_value: int = 3, mode_value: String = "training") -> void:
	terminal_id = id_value.strip_edges().to_lower().left(32)
	display_name = title.left(48)
	difficulty = clamp(difficulty_value, 2, 5)
	mode = mode_value if mode_value in ["training", "case_lab", "shadow_grid"] else "training"
	_build_visual()

func _build_visual() -> void:
	var screen = MeshInstance3D.new()
	var mesh = BoxMesh.new()
	mesh.size = Vector3(1.25, 0.78, 0.08)
	screen.mesh = mesh
	screen.position = Vector3(0, 0.25, 0)
	var mat = StandardMaterial3D.new()
	mat.albedo_color = Color("17242a")
	mat.emission_enabled = true
	mat.emission = Color("204f58")
	mat.emission_energy_multiplier = 1.3
	mat.roughness = 0.24
	screen.material_override = mat
	add_child(screen)
	var stand = MeshInstance3D.new()
	var stand_mesh = CylinderMesh.new()
	stand_mesh.top_radius = 0.09
	stand_mesh.bottom_radius = 0.13
	stand_mesh.height = 0.65
	stand.mesh = stand_mesh
	stand.position = Vector3(0, -0.43, 0)
	var sm = StandardMaterial3D.new()
	sm.albedo_color = Color("444a4e")
	sm.roughness = 0.58
	stand.material_override = sm
	add_child(stand)
	var collider = CollisionShape3D.new()
	var shape = BoxShape3D.new()
	shape.size = Vector3(1.5, 1.7, 0.7)
	collider.shape = shape
	add_child(collider)

func get_interaction_label() -> String:
	if mode == "shadow_grid":
		return "%s • Kurgu ağ bulmacası (riskli)" % display_name
	return "%s • Node bulmacası" % display_name

func interact(player: Node) -> void:
	var ui_nodes = get_tree().get_nodes_in_group("cyber_puzzle_ui")
	if ui_nodes.is_empty():
		if player != null and player.has_method("show_status"):
			player.show_status("Cyber arayüzü bulunamadı.", 2.0)
		return
	var ui = ui_nodes[0]
	if ui.has_method("open_challenge"):
		ui.open_challenge(terminal_id, display_name, difficulty, mode, player)
