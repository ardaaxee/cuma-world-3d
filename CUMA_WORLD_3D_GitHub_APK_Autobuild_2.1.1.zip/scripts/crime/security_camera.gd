extends Node3D

var sweep = 0.0
var origin_yaw = 0.0
var detection_radius = 10.0

func setup(radius_value: float = 10.0) -> void:
	detection_radius = clamp(radius_value, 4.0, 20.0)
	add_to_group("security_camera")
	origin_yaw = rotation.y
	_build_visual()

func _build_visual() -> void:
	var pole = MeshInstance3D.new()
	var pole_mesh = CylinderMesh.new()
	pole_mesh.top_radius = 0.05
	pole_mesh.bottom_radius = 0.05
	pole_mesh.height = 1.0
	pole.mesh = pole_mesh
	pole.position = Vector3(0, -0.45, 0)
	var metal = StandardMaterial3D.new()
	metal.albedo_color = Color("555c62")
	metal.roughness = 0.45
	pole.material_override = metal
	add_child(pole)
	var housing = MeshInstance3D.new()
	var box = BoxMesh.new()
	box.size = Vector3(0.34, 0.22, 0.48)
	housing.mesh = box
	housing.position = Vector3(0, 0.0, -0.12)
	housing.rotation_degrees.x = -12.0
	var mat = StandardMaterial3D.new()
	mat.albedo_color = Color("d7dde0")
	mat.roughness = 0.38
	housing.material_override = mat
	add_child(housing)
	var lens = MeshInstance3D.new()
	var lens_mesh = CylinderMesh.new()
	lens_mesh.top_radius = 0.08
	lens_mesh.bottom_radius = 0.08
	lens_mesh.height = 0.05
	lens.mesh = lens_mesh
	lens.position = Vector3(0, -0.01, -0.37)
	lens.rotation_degrees.x = 90
	var lens_mat = StandardMaterial3D.new()
	lens_mat.albedo_color = Color("17232d")
	lens_mat.metallic = 0.2
	lens_mat.roughness = 0.1
	lens.material_override = lens_mat
	add_child(lens)

func _process(delta: float) -> void:
	sweep += delta * 0.65
	rotation.y = origin_yaw + sin(sweep) * 0.55

func can_observe(world_position: Vector3) -> bool:
	return global_position.distance_to(world_position) <= detection_radius
