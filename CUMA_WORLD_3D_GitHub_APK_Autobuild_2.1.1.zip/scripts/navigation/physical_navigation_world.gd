extends Node3D

# Physical AI 1.4: lightweight procedural navigation corridors.
# The regions are intentionally simple so Android devices do not need runtime navmesh baking.

var regions: Array[NavigationRegion3D] = []

func setup() -> void:
	name = "PhysicalNavigationWorld14"
	# Overlapping human-scale walkable zones connect the home/city/east district/neighborhood.
	_add_region("HomeToCity", Rect2(-22.0, 6.0, 48.0, 112.0))
	_add_region("Downtown", Rect2(-40.0, 28.0, 102.0, 64.0))
	_add_region("EastDistrict", Rect2(18.0, 38.0, 46.0, 58.0))
	_add_region("NorthConnector", Rect2(14.0, 84.0, 58.0, 48.0))
	_add_region("Neighborhood", Rect2(14.0, 112.0, 84.0, 36.0))
	_add_region("SocietyBoulevard", Rect2(108.0, 68.0, 16.0, 62.0))
	_add_region("SocietyConnector", Rect2(94.0, 112.0, 36.0, 18.0))
	_add_region("DynamicSouthConnector", Rect2(122.0, 68.0, 48.0, 12.0))
	_add_region("DynamicMainAvenue", Rect2(163.0, 68.0, 12.0, 72.0))
	_add_region("DynamicPlaza", Rect2(136.0, 120.0, 68.0, 20.0))
	# Crime & Justice 1.9 western civic district and connector.
	_add_region("JusticeDistrict", Rect2(-64.0, 46.0, 66.0, 42.0))
	_add_region("JusticeConnector", Rect2(-20.0, 34.0, 28.0, 34.0))
	_add_static_avoidance()

func _add_region(label: String, rect: Rect2) -> void:
	var region = NavigationRegion3D.new()
	region.name = "Nav_" + label
	var mesh = NavigationMesh.new()
	mesh.vertices = PackedVector3Array([
		Vector3(rect.position.x, 0.06, rect.position.y),
		Vector3(rect.end.x, 0.06, rect.position.y),
		Vector3(rect.end.x, 0.06, rect.end.y),
		Vector3(rect.position.x, 0.06, rect.end.y)
	])
	mesh.add_polygon(PackedInt32Array([0, 1, 2, 3]))
	region.navigation_mesh = mesh
	add_child(region)
	regions.append(region)

func _add_static_avoidance() -> void:
	# Keep shop entrances open. Avoidance obstacles are used for street furniture and
	# closed scenery while venue navigation is handled with explicit entrance waypoints.
	_add_obstacle("GardenFountain", Vector3(76, 0.05, 136.5), Vector2(2.2, 2.2))
	_add_obstacle("PlazaTreeA", Vector3(62, 0.05, 132), Vector2(1.4, 1.4))
	_add_obstacle("PlazaTreeB", Vector3(90, 0.05, 132), Vector2(1.4, 1.4))
	_add_obstacle("PromenadeTree", Vector3(38.8, 0.05, 84.5), Vector2(1.4, 1.4))

func _add_obstacle(label: String, center: Vector3, size: Vector2) -> void:
	var obstacle = NavigationObstacle3D.new()
	obstacle.name = "Avoid_" + label
	obstacle.position = center
	obstacle.height = 2.2
	var hx = size.x * 0.5
	var hz = size.y * 0.5
	# Counter-clockwise outline pushes agents outward.
	obstacle.vertices = PackedVector3Array([
		Vector3(-hx, 0, -hz),
		Vector3(hx, 0, -hz),
		Vector3(hx, 0, hz),
		Vector3(-hx, 0, hz)
	])
	add_child(obstacle)
