extends Node3D

var panel: MeshInstance3D
var is_open = false
var close_at_ms = 0

func setup(size: Vector3, color: Color) -> void:
	panel = MeshInstance3D.new()
	var mesh = BoxMesh.new()
	mesh.size = size
	panel.mesh = mesh
	panel.position.x = size.x * 0.5
	var mat = StandardMaterial3D.new()
	mat.albedo_color = color
	mat.roughness = 0.55
	panel.material_override = mat
	add_child(panel)
	add_to_group("npc_local_door")

func request_npc_pass(_npc_id: String) -> void:
	close_at_ms = Time.get_ticks_msec() + 2600
	if not is_open:
		is_open = true
		var tween = create_tween()
		tween.set_trans(Tween.TRANS_QUAD).set_ease(Tween.EASE_IN_OUT)
		tween.tween_property(self, "rotation:y", rotation.y - deg_to_rad(88.0), 0.34)

func _process(_delta: float) -> void:
	if is_open and Time.get_ticks_msec() > close_at_ms:
		is_open = false
		var tween = create_tween()
		tween.set_trans(Tween.TRANS_QUAD).set_ease(Tween.EASE_IN_OUT)
		tween.tween_property(self, "rotation:y", rotation.y + deg_to_rad(88.0), 0.34)
