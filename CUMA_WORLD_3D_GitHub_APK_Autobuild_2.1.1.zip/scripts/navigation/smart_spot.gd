extends Node3D

var spot_id = ""
var kind = "stand"
var facing = Vector3.FORWARD
var occupied_by = ""
var reserved_until_ms = 0

func setup(id_value: String, kind_value: String, position_value: Vector3, facing_value: Vector3 = Vector3.FORWARD) -> void:
	spot_id = id_value.left(64)
	kind = kind_value.left(32)
	global_position = position_value
	facing = facing_value.normalized() if facing_value.length() > 0.01 else Vector3.FORWARD
	add_to_group("npc_smart_spot")
	add_to_group("npc_spot_" + kind)

func try_reserve(npc_id: String, hold_seconds: float = 18.0) -> bool:
	var now = Time.get_ticks_msec()
	if occupied_by != "" and occupied_by != npc_id and now < reserved_until_ms:
		return false
	occupied_by = npc_id.left(40)
	reserved_until_ms = now + int(clamp(hold_seconds, 2.0, 60.0) * 1000.0)
	return true

func release(npc_id: String) -> void:
	if occupied_by == npc_id:
		occupied_by = ""
		reserved_until_ms = 0

func is_available(npc_id: String = "") -> bool:
	return occupied_by == "" or occupied_by == npc_id or Time.get_ticks_msec() >= reserved_until_ms

func get_spot_kind() -> String:
	return kind

func get_facing() -> Vector3:
	return facing
