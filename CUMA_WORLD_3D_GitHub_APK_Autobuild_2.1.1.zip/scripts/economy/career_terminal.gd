extends StaticBody3D

var career_id = "office"
var title = "Ofis vardiyası"
var base_pay = 80
var xp_reward = 35
var hours = 1.5

func setup(id_value: String, display_title: String, pay: int, xp: int, time_hours: float) -> void:
	career_id = id_value.strip_edges().to_lower().left(32)
	title = display_title.left(64)
	base_pay = clamp(pay, 0, 1000)
	xp_reward = clamp(xp, 0, 250)
	hours = clamp(time_hours, 0.1, 8.0)

func get_interaction_label() -> String:
	return "%s • +₺%d" % [title, base_pay]

func interact(player: Node) -> void:
	var gs = get_node_or_null("/root/GameState")
	if gs == null:
		return
	if gs.has_method("can_work_career") and not gs.can_work_career(career_id):
		if player != null and player.has_method("show_status"):
			player.show_status("Bu vardiyayı bugün tamamladın", 2.0)
		return
	if gs.has_method("set_career"):
		gs.set_career(career_id)
	var level_bonus = max(0, int(gs.career_level) - 1) * 4
	if gs.has_method("add_career_xp"):
		gs.add_career_xp(xp_reward, base_pay + level_bonus)
	if gs.has_method("record_career_shift"):
		gs.record_career_shift(career_id)
	if gs.has_method("advance_time"):
		gs.advance_time(hours)
	if gs.has_method("add_daily_life_event"):
		gs.add_daily_life_event("career", "%s tamamlandı • +₺%d" % [title, base_pay + level_bonus])
	if player != null and player.has_method("show_status"):
		player.show_status("%s • Kariyer XP +%d" % [title, xp_reward], 2.4)
