extends StaticBody3D

var item_id = "item"
var display_name = "Ürün"
var price = 25
var amount = 1
var category = "item"

func setup(id: String, title: String, cost: int, count: int = 1, kind: String = "item") -> void:
	item_id = id.strip_edges().left(48)
	display_name = title.strip_edges().left(48)
	price = clamp(cost, 0, 10000)
	amount = clamp(count, 1, 20)
	category = kind.strip_edges().left(24)

func get_interaction_label() -> String:
	return "%s satın al • %d TL" % [display_name, price]

func interact(player: Node) -> void:
	var gs = get_node_or_null("/root/GameState")
	if gs == null or item_id.is_empty():
		return
	if category == "outfit" and item_id in gs.owned_outfits:
		gs.selected_outfit = item_id
		if player.has_method("apply_saved_customization"):
			player.apply_saved_customization()
		player.show_status(display_name + " giyildi")
		return
	if not gs.spend_money(price):
		player.show_status("Yeterli paran yok")
		return
	if category == "outfit":
		gs.unlock_outfit(item_id)
		gs.selected_outfit = item_id
		if player.has_method("apply_saved_customization"):
			player.apply_saved_customization()
	else:
		gs.add_item(item_id, amount)
	gs.add_memory("Alışveriş • " + display_name)
	player.show_status("%s alındı • -%d TL" % [display_name, price])
