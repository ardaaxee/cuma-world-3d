extends StaticBody3D

var shift_id = "shift"
var title = "Kısa vardiya"
var reward = 80
var hours = 1.0

func setup(id: String, label: String, pay: int, duration_hours: float) -> void:
	shift_id = id.left(40)
	title = label.left(56)
	reward = clamp(pay, 1, 1000)
	hours = clamp(duration_hours, 0.25, 4.0)

func get_interaction_label() -> String:
	return "%s • +%d TL" % [title, reward]

func interact(player: Node) -> void:
	var gs = get_node_or_null("/root/GameState")
	if gs == null:
		return
	var day_key = "%s_day_%d" % [shift_id, int(gs.world_day)]
	if bool(gs.story_flags.get(day_key, false)):
		player.show_status("Bu vardiyayı bugün tamamladın")
		return
	gs.story_flags[day_key] = true
	gs.add_money(reward)
	gs.advance_time(hours)
	gs.add_memory(title)
	player.show_status("%s tamamlandı • +%d TL" % [title, reward], 2.5)
