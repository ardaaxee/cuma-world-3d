extends CanvasLayer

const JoystickScript = preload("res://scripts/virtual_joystick.gd")
const LookPadScript = preload("res://scripts/look_pad.gd")

var prompt_label: Label
var status_label: Label
var stats_label: Label
var objective_label: Label
var title_label: Label
var together_panel: PanelContainer
var network_label: Label
var memories_label: Label
var partner_input: LineEdit
var address_input: LineEdit
var session_code_input: LineEdit
var relay_url_input: LineEdit
var chat_input: LineEdit
var chat_label: Label
var chat_history: Array[String] = []
var hud_accum = 0.0

func _ready() -> void:
	layer = 20
	_build_ui()
	var net = get_node_or_null("/root/NetworkManager")
	if net != null:
		net.network_status_changed.connect(_on_network_status_changed)
		net.quick_message_received.connect(_on_quick_message_received)
		net.text_message_received.connect(_on_text_message_received)
		net.pair_waiting.connect(_on_pair_waiting)
		net.pair_activity_completed.connect(_on_pair_activity_completed)
		if net.has_signal("session_code_changed"):
			net.session_code_changed.connect(_on_session_code_changed)
		if net.has_signal("session_auth_result"):
			net.session_auth_result.connect(_on_session_auth_result)
		if net.has_signal("upnp_status_changed"):
			net.upnp_status_changed.connect(_on_upnp_status_changed)
		_on_network_status_changed(net.status)

func _process(delta: float) -> void:
	hud_accum += delta
	if hud_accum < 0.08:
		return
	hud_accum = 0.0
	var player = _player()
	var gs = get_node_or_null("/root/GameState")
	var net = get_node_or_null("/root/NetworkManager")
	if player != null:
		if prompt_label != null and player.has_method("get_interaction_text"):
			var interaction_text = str(player.get_interaction_text())
			prompt_label.text = ("KULLAN  •  " + interaction_text) if interaction_text != "" else ""
		if status_label != null and player.has_method("get_status_text"):
			status_label.text = str(player.get_status_text())
	if gs != null:
		var hour = int(floor(gs.time_of_day))
		var minute = int(floor(fposmod(gs.time_of_day, 1.0) * 60.0))
		var stamina = player.get_stamina_percent() if player != null and player.has_method("get_stamina_percent") else 0
		var peers = net.get_peer_count() if net != null else 1
		stats_label.text = "%02d:%02d  •  %d TL  •  %d%%  •  %d/2" % [hour, minute, gs.money, stamina, min(peers, 2)]
		objective_label.text = gs.story_objective.left(72)
		_update_together_text(gs, net)

func _player() -> Node:
	return get_tree().get_first_node_in_group("player")

func _build_ui() -> void:
	var root = Control.new()
	root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	root.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(root)

	var look_pad = Control.new()
	look_pad.set_script(LookPadScript)
	look_pad.anchor_left = 0.42
	look_pad.anchor_top = 0.0
	look_pad.anchor_right = 1.0
	look_pad.anchor_bottom = 1.0
	look_pad.connect("look_dragged", Callable(self, "_on_look"))
	root.add_child(look_pad)

	var joystick = Control.new()
	joystick.set_script(JoystickScript)
	joystick.anchor_left = 0.0
	joystick.anchor_top = 1.0
	joystick.anchor_right = 0.0
	joystick.anchor_bottom = 1.0
	joystick.offset_left = 28.0
	joystick.offset_top = -158.0
	joystick.offset_right = 138.0
	joystick.offset_bottom = -48.0
	joystick.connect("direction_changed", Callable(self, "_on_move"))
	root.add_child(joystick)

	var jump_button = _make_button("ZIPLA", Vector2(-112.0, -138.0), Vector2(-48.0, -74.0))
	jump_button.pressed.connect(_on_jump)
	root.add_child(jump_button)

	var use_button = _make_button("KULLAN", Vector2(-190.0, -104.0), Vector2(-126.0, -40.0))
	use_button.pressed.connect(_on_use)
	root.add_child(use_button)

	var run_button = _make_button("KOŞ", Vector2(-112.0, -212.0), Vector2(-48.0, -148.0))
	run_button.toggle_mode = true
	run_button.toggled.connect(_on_run)
	root.add_child(run_button)

	var save_button = _make_top_button("SAVE", -304.0)
	save_button.pressed.connect(_on_save)
	root.add_child(save_button)

	var quality_button = _make_top_button("FX", -244.0)
	quality_button.pressed.connect(_on_quality)
	root.add_child(quality_button)

	var together_button = _make_top_button("2P", -184.0)
		together_button.pressed.connect(_on_toggle_together)
	root.add_child(together_button)

	var photo_button = _make_top_button("FOTO", -124.0)
	photo_button.pressed.connect(_on_photo)
	root.add_child(photo_button)

	var camera_button = _make_top_button("CAM", -64.0)
	camera_button.pressed.connect(_on_camera_mode)
	root.add_child(camera_button)

	var crosshair = Label.new()
	crosshair.text = "·"
	crosshair.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	crosshair.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	crosshair.anchor_left = 0.5
	crosshair.anchor_top = 0.5
	crosshair.anchor_right = 0.5
	crosshair.anchor_bottom = 0.5
	crosshair.offset_left = -16.0
	crosshair.offset_top = -16.0
	crosshair.offset_right = 16.0
	crosshair.offset_bottom = 16.0
	crosshair.add_theme_font_size_override("font_size", 16)
	crosshair.mouse_filter = Control.MOUSE_FILTER_IGNORE
	root.add_child(crosshair)

	prompt_label = _center_label(28.0, 14)
	root.add_child(prompt_label)
	status_label = _center_label(-235.0, 14)
	status_label.anchor_top = 1.0
	status_label.anchor_bottom = 1.0
	root.add_child(status_label)

	title_label = Label.new()
	title_label.text = "CUMA WORLD"
	title_label.position = Vector2(18.0, 14.0)
	title_label.add_theme_font_size_override("font_size", 11)
	title_label.modulate = Color(1.0, 1.0, 1.0, 0.62)
	title_label.mouse_filter = Control.MOUSE_FILTER_IGNORE
	root.add_child(title_label)

	stats_label = Label.new()
	stats_label.position = Vector2(18.0, 32.0)
	stats_label.add_theme_font_size_override("font_size", 11)
	stats_label.modulate = Color(1.0, 1.0, 1.0, 0.78)
	stats_label.mouse_filter = Control.MOUSE_FILTER_IGNORE
	root.add_child(stats_label)

	objective_label = Label.new()
	objective_label.anchor_left = 0.5
	objective_label.anchor_right = 0.5
	objective_label.offset_left = -320.0
	objective_label.offset_right = 320.0
	objective_label.offset_top = 16.0
	objective_label.offset_bottom = 38.0
	objective_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	objective_label.add_theme_font_size_override("font_size", 11)
	objective_label.modulate = Color(1.0, 1.0, 1.0, 0.68)
	objective_label.mouse_filter = Control.MOUSE_FILTER_IGNORE
	root.add_child(objective_label)

	_build_together_panel(root)

func _build_together_panel(root: Control) -> void:
	together_panel = PanelContainer.new()
	together_panel.anchor_left = 1.0
	together_panel.anchor_right = 1.0
	together_panel.offset_left = -390.0
	together_panel.offset_right = -22.0
	together_panel.offset_top = 122.0
	together_panel.offset_bottom = 700.0
	together_panel.visible = false
	root.add_child(together_panel)

	var box = VBoxContainer.new()
	box.add_theme_constant_override("separation", 8)
	together_panel.add_child(box)

	var heading = Label.new()
	heading.text = "TOGETHER • 2 KİŞİLİK"
	heading.add_theme_font_size_override("font_size", 19)
	box.add_child(heading)

	network_label = Label.new()
	network_label.text = "OFFLINE"
	box.add_child(network_label)

	partner_input = LineEdit.new()
	partner_input.placeholder_text = "Partner adı"
	var gs = get_node_or_null("/root/GameState")
	if gs != null:
		partner_input.text = gs.partner_name
	box.add_child(partner_input)
	var name_button = Button.new()
	name_button.text = "ADI KAYDET"
	name_button.pressed.connect(_on_save_partner_name)
	box.add_child(name_button)

	address_input = LineEdit.new()
	address_input.placeholder_text = "Host IP (örn. 192.168.1.20)"
	address_input.text = "127.0.0.1"
	box.add_child(address_input)

	session_code_input = LineEdit.new()
	session_code_input.placeholder_text = "6 karakter oda kodu"
	session_code_input.max_length = 6
	box.add_child(session_code_input)

	relay_url_input = LineEdit.new()
	relay_url_input.placeholder_text = "Relay URL (wss://sunucu:7008)"
	box.add_child(relay_url_input)

	var network_row = HBoxContainer.new()
	box.add_child(network_row)
	var host_button = Button.new()
	host_button.text = "HOST"
	host_button.pressed.connect(_on_host)
	network_row.add_child(host_button)
	var join_button = Button.new()
	join_button.text = "JOIN"
	join_button.pressed.connect(_on_join)
	network_row.add_child(join_button)
	var stop_button = Button.new()
	stop_button.text = "STOP"
	stop_button.pressed.connect(_on_stop_network)
	network_row.add_child(stop_button)
	var relay_button = Button.new()
	relay_button.text = "RELAY"
	relay_button.pressed.connect(_on_relay_join)
	network_row.add_child(relay_button)
	var internet_button = Button.new()
	internet_button.text = "UPnP"
	internet_button.pressed.connect(_on_upnp)
	network_row.add_child(internet_button)

	var quick_title = Label.new()
	quick_title.text = "HIZLI MESAJ"
	box.add_child(quick_title)
	var msg_grid = GridContainer.new()
	msg_grid.columns = 3
	box.add_child(msg_grid)
	for msg in ["Buraya gel", "Hazırım", "Market?", "Film?", "Fotoğraf?", "Balkona gel"]:
		var b = Button.new()
		b.text = msg
		b.pressed.connect(_on_quick_message.bind(msg))
		msg_grid.add_child(b)

	var chat_title = Label.new()
	chat_title.text = "MESAJ"
	box.add_child(chat_title)
	var chat_row = HBoxContainer.new()
	box.add_child(chat_row)
	chat_input = LineEdit.new()
	chat_input.placeholder_text = "Mesaj yaz (120 karakter)"
	chat_input.max_length = 120
	chat_input.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	chat_input.text_submitted.connect(_on_chat_submit)
	chat_row.add_child(chat_input)
	var send_button = Button.new()
	send_button.text = "GÖNDER"
	send_button.pressed.connect(_on_chat_send)
	chat_row.add_child(send_button)
	chat_label = Label.new()
	chat_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	chat_label.custom_minimum_size = Vector2(340.0, 60.0)
	box.add_child(chat_label)

	var emote_title = Label.new()
	emote_title.text = "EMOTE"
	box.add_child(emote_title)
	var emote_row = HBoxContainer.new()
	box.add_child(emote_row)
	for item in [["EL SALLA", "wave"], ["SEVİN", "cheer"], ["ÇAK", "highfive"]]:
		var eb = Button.new()
		eb.text = item[0]
		eb.pressed.connect(_on_emote.bind(item[1]))
		emote_row.add_child(eb)

	memories_label = Label.new()
	memories_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	memories_label.custom_minimum_size = Vector2(340.0, 110.0)
	box.add_child(memories_label)

func _update_together_text(gs: Node, net: Node) -> void:
	if memories_label == null:
		return
	var recent: Array[String] = []
	for i in range(min(3, gs.duo_memories.size())):
		recent.append(str(gs.duo_memories[i]))
	var memory_text = "Henüz anı yok"
	if not recent.is_empty():
		memory_text = " | ".join(recent)
	var achievement_text = "Yok"
	if gs.duo_achievements.size() > 0:
		achievement_text = str(gs.duo_achievements[-1])
	memories_label.text = "%s • %d DUO\nPartner: %s\nSon anılar: %s\nSon başarı: %s" % [gs.get_duo_rank(), gs.duo_points, gs.partner_name, memory_text, achievement_text]
	if network_label != null and net != null:
		var ip_hint = net.get_lan_address_hint() if net.has_method("get_lan_address_hint") else ""
		var host_hint = (" • IP " + ip_hint) if net.status.begins_with("LAN HOST") and not ip_hint.is_empty() else ""
		network_label.text = "%s • %d/2%s" % [net.status, min(net.get_peer_count(), 2), host_hint]

func _center_label(y: float, font_size: int) -> Label:
	var label = Label.new()
	label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	label.anchor_left = 0.5
	label.anchor_top = 0.5
	label.anchor_right = 0.5
	label.anchor_bottom = 0.5
	label.offset_left = -300.0
	label.offset_top = y
	label.offset_right = 300.0
	label.offset_bottom = y + 34.0
	label.add_theme_font_size_override("font_size", font_size)
	label.mouse_filter = Control.MOUSE_FILTER_IGNORE
	return label

func _make_button(text: String, top_left: Vector2, bottom_right: Vector2) -> Button:
	var button = Button.new()
	button.text = text
	button.anchor_left = 1.0
	button.anchor_top = 1.0
	button.anchor_right = 1.0
	button.anchor_bottom = 1.0
	button.offset_left = top_left.x
	button.offset_top = top_left.y
	button.offset_right = bottom_right.x
	button.offset_bottom = bottom_right.y
	button.add_theme_font_size_override("font_size", 13)
	_apply_action_button_style(button)
	return button

func _make_top_button(text: String, x_from_right: float) -> Button:
	var button = Button.new()
	button.text = text
	button.anchor_left = 1.0
	button.anchor_right = 1.0
	button.offset_left = x_from_right
	button.offset_right = x_from_right + 54.0
	button.offset_top = 14.0
	button.offset_bottom = 42.0
	button.add_theme_font_size_override("font_size", 10)
	_apply_top_button_style(button)
	return button

func _apply_action_button_style(button: Button) -> void:
	var normal = StyleBoxFlat.new()
	normal.bg_color = Color(0.035, 0.042, 0.052, 0.46)
	normal.border_color = Color(0.82, 0.88, 0.94, 0.14)
	normal.set_border_width_all(1)
	normal.set_corner_radius_all(40)
	button.add_theme_stylebox_override("normal", normal)
	var pressed = normal.duplicate()
	pressed.bg_color = Color(0.12, 0.20, 0.28, 0.86)
	button.add_theme_stylebox_override("pressed", pressed)
	button.add_theme_stylebox_override("hover", pressed)
	button.add_theme_color_override("font_color", Color(0.95, 0.97, 1.0, 0.95))

func _apply_top_button_style(button: Button) -> void:
	var normal = StyleBoxFlat.new()
	normal.bg_color = Color(0.025, 0.030, 0.038, 0.42)
	normal.border_color = Color(1.0, 1.0, 1.0, 0.08)
	normal.set_border_width_all(1)
	normal.set_corner_radius_all(9)
	button.add_theme_stylebox_override("normal", normal)
	var active = normal.duplicate()
	active.bg_color = Color(0.10, 0.15, 0.20, 0.82)
	button.add_theme_stylebox_override("pressed", active)
	button.add_theme_stylebox_override("hover", active)

func _on_camera_mode() -> void:
	var player = _player()
	if player != null and player.has_method("toggle_camera_mode"):
		player.toggle_camera_mode()

func _on_move(value: Vector2) -> void:
	var player = _player()
	if player != null:
		player.set_mobile_move(value)

func _on_look(delta: Vector2) -> void:
	if together_panel != null and together_panel.visible:
		return
	var player = _player()
	if player != null:
		player.add_mobile_look(delta)

func _on_jump() -> void:
	var player = _player()
	if player != null:
		player.request_jump()

func _on_use() -> void:
	var player = _player()
	if player != null:
		player.try_interact()

func _on_run(enabled: bool) -> void:
	var player = _player()
	if player != null:
		player.set_sprinting(enabled)

func _on_save() -> void:
	var player = _player()
	if player != null and player.has_method("save_now"):
		player.save_now()

func _on_quality() -> void:
	var gs = get_node_or_null("/root/GameState")
	if gs != null:
		var profile = gs.cycle_quality()
		var player = _player()
		if player != null:
			player.show_status("Grafik: " + profile)

func _on_photo() -> void:
	var player = _player()
	if player != null and player.has_method("take_photo"):
		player.take_photo()

func _on_toggle_together() -> void:
	if together_panel != null:
		together_panel.visible = not together_panel.visible

func _on_save_partner_name() -> void:
	var gs = get_node_or_null("/root/GameState")
	if gs != null and partner_input != null:
		gs.set_partner_name(partner_input.text)

func _on_host() -> void:
	var net = get_node_or_null("/root/NetworkManager")
	if net != null:
		var requested = session_code_input.text if session_code_input != null else ""
		net.host_lan(requested)

func _on_join() -> void:
	var net = get_node_or_null("/root/NetworkManager")
	if net != null and address_input != null and session_code_input != null:
		net.join_lan(address_input.text, session_code_input.text)

func _on_relay_join() -> void:
	var net = get_node_or_null("/root/NetworkManager")
	if net != null and relay_url_input != null and session_code_input != null and net.has_method("join_relay"):
		net.join_relay(relay_url_input.text, session_code_input.text)

func _on_stop_network() -> void:
	var net = get_node_or_null("/root/NetworkManager")
	if net != null:
		net.stop()

func _on_quick_message(message: String) -> void:
	var net = get_node_or_null("/root/NetworkManager")
	if net != null:
		net.send_quick_message(message)

func _on_emote(emote: String) -> void:
	var player = _player()
	if player != null and player.has_method("play_local_emote"):
		player.play_local_emote(emote)
	var net = get_node_or_null("/root/NetworkManager")
	if net != null:
		net.send_emote(emote)

func _on_network_status_changed(text: String) -> void:
	if network_label != null:
		network_label.text = text

func _on_quick_message_received(peer_id: int, message: String) -> void:
	if peer_id == get_node("/root/NetworkManager").get_local_peer_id():
		return
	var player = _player()
	if player != null:
		player.show_status("Partner: " + message, 2.8)

func _on_pair_waiting(_activity_id: String, ready_count: int) -> void:
	var player = _player()
	if player != null:
		player.show_status("Ortak etkinlik • hazır %d/2" % ready_count, 2.0)

func _on_pair_activity_completed(_activity_id: String, title: String) -> void:
	var player = _player()
	if player != null:
		player.show_status("Birlikte tamamlandı • " + title, 3.0)


func _on_chat_send() -> void:
	if chat_input == null:
		return
	_on_chat_submit(chat_input.text)

func _on_chat_submit(text: String) -> void:
	var clean = text.strip_edges()
	if clean.is_empty():
		return
	var net = get_node_or_null("/root/NetworkManager")
	if net != null and net.has_method("send_text_message"):
		net.send_text_message(clean)
	chat_input.clear()

func _on_text_message_received(peer_id: int, message: String) -> void:
	var net = get_node_or_null("/root/NetworkManager")
	if net == null:
		return
	var who = "Sen" if peer_id == net.get_local_peer_id() else "Partner"
	chat_history.append(who + ": " + message)
	if chat_history.size() > 4:
		chat_history.pop_front()
	if chat_label != null:
		var text = ""
		for line in chat_history:
			text += ("\n" if not text.is_empty() else "") + line
		chat_label.text = text

func _on_session_code_changed(code: String) -> void:
	if session_code_input != null:
		session_code_input.text = code

func _on_session_auth_result(ok: bool, message: String) -> void:
	var player = _player()
	if player != null and player.has_method("show_status"):
		player.show_status(("Bağlandı • " if ok else "Bağlantı reddedildi • ") + message, 3.0)

func _on_upnp() -> void:
	var net = get_node_or_null("/root/NetworkManager")
	if net != null and net.has_method("request_upnp_mapping"):
		net.request_upnp_mapping()

func _on_upnp_status_changed(text: String) -> void:
	if network_label != null:
		network_label.text = text
	var player = _player()
	if player != null and player.has_method("show_status"):
		player.show_status(text, 3.0)
