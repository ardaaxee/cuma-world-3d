extends StaticBody3D

var completed = false
var persistent_id = "daily_job_terminal"

func _ready() -> void:
	add_to_group("persistent_world")

func get_interaction_label() -> String:
	return "Görev tamamlandı" if completed else "Günlük işi yap (+100)"

func interact(player: Node) -> void:
	if completed:
		if player.has_method("show_status"):
			player.show_status("Bugünkü görev zaten tamamlandı")
		return
	completed = true
	var gs = get_node_or_null("/root/GameState")
	if gs != null:
		gs.add_money(100)
		gs.set_objective("Balkona çık ve evi keşfet")
	if player.has_method("show_status"):
		player.show_status("Görev tamamlandı • +100", 2.6)

func get_persistent_id() -> String:
	return persistent_id

func get_persistent_state() -> Dictionary:
	return {"completed": completed}

func apply_persistent_state(state: Variant) -> void:
	if state is Dictionary:
		completed = bool(state.get("completed", false))
