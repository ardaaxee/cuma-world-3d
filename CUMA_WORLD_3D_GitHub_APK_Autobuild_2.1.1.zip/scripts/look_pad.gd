extends Control

signal look_dragged(delta: Vector2)

var touch_id = -1
var last_position = Vector2.ZERO
var mouse_active = false

func _ready() -> void:
	mouse_filter = Control.MOUSE_FILTER_STOP

func _gui_input(event: InputEvent) -> void:
	if event is InputEventScreenTouch:
		if event.pressed and touch_id == -1:
			touch_id = event.index
			last_position = event.position
		elif not event.pressed and event.index == touch_id:
			touch_id = -1
	elif event is InputEventScreenDrag and event.index == touch_id:
		look_dragged.emit(event.relative)
		last_position = event.position
	elif event is InputEventMouseButton and event.button_index == MOUSE_BUTTON_LEFT:
		mouse_active = event.pressed
		last_position = event.position
	elif event is InputEventMouseMotion and mouse_active:
		look_dragged.emit(event.relative)
