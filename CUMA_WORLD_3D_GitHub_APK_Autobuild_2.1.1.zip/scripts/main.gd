extends Node3D

const PlayerController = preload("res://scripts/player_controller.gd")
const MobileControls = preload("res://scripts/mobile_controls.gd")
const DoorScript = preload("res://scripts/door.gd")
const SavePointScript = preload("res://scripts/save_point.gd")
const TVScript = preload("res://scripts/tv.gd")
const BedScript = preload("res://scripts/bed.gd")
const SeatScript = preload("res://scripts/seat.gd")
const ShowerScript = preload("res://scripts/shower.gd")
const LightSwitchScript = preload("res://scripts/light_switch.gd")
const WardrobeScript = preload("res://scripts/wardrobe.gd")
const JobTerminalScript = preload("res://scripts/job_terminal.gd")
const PickupScript = preload("res://scripts/pickup.gd")
const DayNightScript = preload("res://scripts/day_night.gd")
const GraphicsManagerScript = preload("res://scripts/graphics_manager.gd")
const MarketTerminalScript = preload("res://scripts/market_terminal.gd")
const CinemaTerminalScript = preload("res://scripts/cinema_terminal.gd")
const PairActivityScript = preload("res://scripts/together/pair_activity.gd")
const RemoteAvatarScript = preload("res://scripts/together/remote_avatar.gd")
const DuoBoardScript = preload("res://scripts/together/duo_board.gd")
const GiftStationScript = preload("res://scripts/together/gift_station.gd")
const DecorStationScript = preload("res://scripts/together/decor_station.gd")
const DecorAccentScript = preload("res://scripts/together/decor_accent.gd")
const RealismBuilderScript = preload("res://scripts/world/realism_builder.gd")
const UltraHomeBuilderScript = preload("res://scripts/world/ultra_home_builder.gd")
const VisualRebuildBuilderScript = preload("res://scripts/world/visual_reboot_builder.gd")
const ProductionHomeBuilderScript = preload("res://scripts/world/production_home_builder.gd")
const ProductionCityPolishScript = preload("res://scripts/world/production_city_polish.gd")
const LivingCityBuilderScript = preload("res://scripts/city/living_city_builder.gd")
const OnlineLifeBuilderScript = preload("res://scripts/city/online_life_builder.gd")
const WeatherManagerScript = preload("res://scripts/world/weather_manager.gd")
const PhoneUIScript = preload("res://scripts/ui/phone_ui.gd")
const FullLifeBuilderScript = preload("res://scripts/city/full_life_builder.gd")
const OnlineRelayBuilderScript = preload("res://scripts/city/online_relay_builder.gd")
const SocialLifeBuilderScript = preload("res://scripts/city/social_life_builder.gd")
const SocialInteractionUIScript = preload("res://scripts/ui/social_interaction_ui.gd")
const NPCIntelligenceDirectorScript = preload("res://scripts/social/npc_intelligence_director.gd")
const PhysicalAIBuilderScript = preload("res://scripts/city/physical_ai_builder.gd")
const HumanBehaviorBuilderScript = preload("res://scripts/city/human_behavior_builder.gd")
const DailyLifeBuilderScript = preload("res://scripts/city/daily_life_builder.gd")
const CitySocietyBuilderScript = preload("res://scripts/city/city_society_builder.gd")
const DynamicCityBuilderScript = preload("res://scripts/city/dynamic_city_builder.gd")
const CrimeJusticeBuilderScript = preload("res://scripts/city/crime_justice_builder.gd")
const CyberPuzzleUIScript = preload("res://scripts/crime/cyber_puzzle_ui.gd")
const LawHUDScript = preload("res://scripts/crime/law_hud.gd")

var remote_avatars: Dictionary = {}

const WALL := Color("ddd9d1")
const INNER_WALL := Color("d2d0ca")
const WOOD := Color("8b6548")
const DARK_WOOD := Color("59402f")
const FLOOR := Color("ad805c")

func _ready() -> void:
	_register_input_actions()
	_build_lighting()
	_build_world_ground()
	_build_house_shell()
	_build_room_layout()
	_build_furniture()
	_build_balcony()
	_build_windows_and_city()
	_build_street_v03()
	_build_interactions_v03()
	_build_together_spaces()
	_build_realism_overhaul()
	_build_ultra_home_07()
	_build_production_home_21()
	_build_living_city_08()
	_build_production_city_polish_21()
	_build_online_life_09()
	_build_full_life_10()
	_build_online_relay_11()
	_build_physical_ai_14()
	_build_human_behavior_15()
	_build_social_life_12()
	_build_npc_intelligence_13()
	_build_daily_life_16()
	_build_city_society_17()
	_build_dynamic_city_18()
	_build_crime_justice_19()
	_build_runtime_systems()
	_build_weather_09()
	var net = get_node_or_null("/root/NetworkManager")
	var dedicated = net != null and net.has_method("is_dedicated_server") and net.is_dedicated_server()
	if dedicated:
		return
	_spawn_player()
	_connect_network()
	_spawn_mobile_controls()
	_build_phone_09()
	_build_social_ui_12()
	_build_cyber_ui_19()
	_build_law_hud_19()

func _register_input_actions() -> void:
	_add_key_action("move_forward", KEY_W)
	_add_key_action("move_back", KEY_S)
	_add_key_action("move_left", KEY_A)
	_add_key_action("move_right", KEY_D)
	_add_key_action("jump", KEY_SPACE)
	_add_key_action("sprint", KEY_SHIFT)
	_add_key_action("interact", KEY_E)

func _add_key_action(action_name: StringName, keycode: Key) -> void:
	if not InputMap.has_action(action_name):
		InputMap.add_action(action_name)
	var event = InputEventKey.new()
	event.physical_keycode = keycode
	if not InputMap.action_has_event(action_name, event):
		InputMap.action_add_event(action_name, event)

func _build_lighting() -> void:
	var world_environment = WorldEnvironment.new()
	var env = Environment.new()
	env.background_mode = Environment.BG_COLOR
	env.background_color = Color("7898b6")
	env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	env.ambient_light_color = Color("c5d1dc")
	env.ambient_light_energy = 0.34
	env.reflected_light_source = Environment.REFLECTION_SOURCE_BG
	env.tonemap_mode = Environment.TONE_MAPPER_FILMIC
	world_environment.environment = env
	world_environment.add_to_group("world_environment")
	env.fog_enabled = true
	env.fog_density = 0.0008
	add_child(world_environment)

	var sun = DirectionalLight3D.new()
	sun.name = "Sun"
	sun.rotation_degrees = Vector3(-48.0, -32.0, 0.0)
	sun.light_color = Color("fff1d3")
	sun.light_energy = 1.08
	sun.shadow_enabled = true
	sun.directional_shadow_max_distance = 55.0
	sun.add_to_group("quality_shadow")
	add_child(sun)

	_add_room_light("HallLight", Vector3(0.0, 2.65, 1.0), 8.0, 1.05)
	_add_room_light("LivingLight", Vector3(-6.1, 2.55, 5.7), 7.5, 1.10)
	_add_room_light("KitchenLight", Vector3(6.2, 2.55, 4.4), 7.0, 1.05)
	_add_room_light("BackRoomsLight", Vector3(0.0, 2.55, -5.8), 9.0, 0.92)

func _add_room_light(light_name: String, position: Vector3, range_value: float, energy: float) -> void:
	var light = OmniLight3D.new()
	light.name = light_name
	light.position = position
	light.omni_range = range_value
	light.light_energy = energy
	light.light_color = Color("ffe8c9")
	light.shadow_enabled = false
	light.add_to_group("quality_extra_light")
	add_child(light)

func _build_world_ground() -> void:
	_add_static_box("OutdoorGround", Vector3(44.0, 0.28, 44.0), Vector3(0.0, -0.34, 0.0), Color("68725f"), 1.0)

func _build_house_shell() -> void:
	# Main 24 x 18 metre footprint.
	_add_static_box("HouseFloor", Vector3(24.0, 0.24, 18.0), Vector3(0.0, -0.12, 0.0), FLOOR, 0.72)
	_add_static_box("Ceiling", Vector3(24.0, 0.16, 18.0), Vector3(0.0, 3.22, 0.0), Color("f1f0eb"), 0.92)

	_add_wall_z("BackWall", -9.0, -12.0, 12.0, WALL)
	_add_wall_x("LeftWall", -12.0, -9.0, 9.0, WALL)
	_add_wall_x("RightWall", 12.0, -9.0, 9.0, WALL)

	# Front has a 4m balcony opening and a 2.5m entrance opening.
	_add_wall_z("FrontA", 9.0, -12.0, -8.0, WALL)
	_add_wall_z("FrontB", 9.0, -4.0, -1.25, WALL)
	_add_wall_z("FrontC", 9.0, 1.25, 12.0, WALL)
	_add_static_box("BalconyOpeningHeader", Vector3(4.0, 0.65, 0.22), Vector3(-6.0, 2.88, 9.0), WALL)
	_add_static_box("EntranceHeader", Vector3(2.5, 0.65, 0.22), Vector3(0.0, 2.88, 9.0), WALL)

	_add_door("EntranceDoor", Vector3(-1.25, 1.18, 9.0), 0.0, 2.5, Color("65452f"), -96.0)

func _build_room_layout() -> void:
	# Corridor boundaries. Gaps become room doors.
	_add_wall_x("LeftCorridor01", -1.8, -9.0, -6.7, INNER_WALL)
	_add_wall_x("LeftCorridor02", -1.8, -5.3, -0.7, INNER_WALL)
	_add_wall_x("LeftCorridor03", -1.8, 0.7, 5.1, INNER_WALL)
	_add_wall_x("LeftCorridor04", -1.8, 6.5, 9.0, INNER_WALL)

	_add_wall_x("RightCorridor01", 1.8, -9.0, -6.7, INNER_WALL)
	_add_wall_x("RightCorridor02", 1.8, -5.3, -0.7, INNER_WALL)
	_add_wall_x("RightCorridor03", 1.8, 0.7, 3.6, INNER_WALL)
	_add_wall_x("RightCorridor04", 1.8, 5.0, 6.8, INNER_WALL)
	_add_wall_x("RightCorridor05", 1.8, 8.2, 9.0, INNER_WALL)

	# Room separators: four bedrooms + living + kitchen + bathroom/utility.
	_add_wall_z("LeftSeparatorBack", -3.0, -12.0, -1.8, INNER_WALL)
	_add_wall_z("LeftSeparatorFront", 2.8, -12.0, -1.8, INNER_WALL)
	_add_wall_z("RightSeparatorBack", -3.0, 1.8, 12.0, INNER_WALL)
	_add_wall_z("RightSeparatorFront", 2.8, 1.8, 12.0, INNER_WALL)
	_add_wall_z("RightBathSeparator", 6.2, 1.8, 12.0, INNER_WALL)

	# Doors hinged at the edge of each 1.4m opening.
	_add_door("Bedroom1Door", Vector3(-1.8, 1.18, -5.3), 90.0, 1.4, Color("7a553a"))
	_add_door("Bedroom2Door", Vector3(-1.8, 1.18, 0.7), 90.0, 1.4, Color("7a553a"))
	_add_door("LivingDoor", Vector3(-1.8, 1.18, 6.5), 90.0, 1.4, Color("7a553a"))
	_add_door("Bedroom3Door", Vector3(1.8, 1.18, -5.3), 90.0, 1.4, Color("7a553a"))
	_add_door("Bedroom4Door", Vector3(1.8, 1.18, 0.7), 90.0, 1.4, Color("7a553a"))
	_add_door("KitchenDoor", Vector3(1.8, 1.18, 5.0), 90.0, 1.4, Color("7a553a"))
	_add_door("BathroomDoor", Vector3(1.8, 1.18, 8.2), 90.0, 1.4, Color("7a553a"))

	# Save checkpoint near the entrance hall.
	var save_point = StaticBody3D.new()
	save_point.name = "HomeSavePoint"
	save_point.position = Vector3(0.0, 0.10, 7.2)
	save_point.set_script(SavePointScript)
	add_child(save_point)
	save_point.setup()

func _build_furniture() -> void:
	# Bedroom 1 - left back.
	_add_bed("Bed1", Vector3(-7.2, 0.28, -6.4), 0.0, Color("d9d1c8"))
	_add_static_box("Wardrobe1", Vector3(2.6, 2.45, 0.72), Vector3(-10.1, 1.23, -7.9), Color("8b674d"))

	# Bedroom 2 - left middle.
	_add_bed("Bed2", Vector3(-7.0, 0.28, -0.1), 0.0, Color("ccd4dc"))
	_add_static_box("Desk2", Vector3(2.4, 0.16, 0.85), Vector3(-10.0, 0.78, 1.65), DARK_WOOD)
	_add_static_box("Desk2Leg", Vector3(0.18, 0.72, 0.18), Vector3(-10.0, 0.38, 1.65), DARK_WOOD)

	# Bedroom 3 - right back.
	_add_bed("Bed3", Vector3(7.0, 0.28, -6.2), 0.0, Color("c9c2b8"))
	_add_static_box("Wardrobe3", Vector3(2.8, 2.45, 0.72), Vector3(10.0, 1.23, -7.8), Color("76604f"))

	# Bedroom 4 - right middle / master.
	_add_bed("Bed4", Vector3(7.2, 0.28, -0.2), 0.0, Color("d7ced1"))
	_add_static_box("MasterWardrobe", Vector3(3.1, 2.5, 0.72), Vector3(10.0, 1.25, 1.65), Color("856b58"))

	# Living room - left front.
	_add_static_box("SofaSeat", Vector3(3.8, 0.50, 1.25), Vector3(-7.0, 0.25, 5.9), Color("2f3841"))
	_add_static_box("SofaBack", Vector3(3.8, 1.25, 0.28), Vector3(-7.0, 0.85, 6.45), Color("2f3841"))
	_add_static_box("CoffeeTable", Vector3(2.1, 0.18, 1.05), Vector3(-7.0, 0.72, 4.1), WOOD)
	_add_static_box("CoffeeTableLeg", Vector3(0.28, 0.62, 0.28), Vector3(-7.0, 0.35, 4.1), DARK_WOOD)
	_add_static_box("TVUnit", Vector3(3.8, 0.50, 0.70), Vector3(-7.0, 0.25, 3.25), Color("42362b"))

	var tv = StaticBody3D.new()
	tv.name = "InteractiveTV"
	tv.position = Vector3(-7.0, 1.55, 3.04)
	tv.rotation_degrees.y = 0.0
	tv.set_script(TVScript)
	add_child(tv)
	tv.setup(Vector3(3.2, 1.65, 0.12))

	# Kitchen - right front middle.
	_add_static_box("KitchenCounter", Vector3(5.4, 0.92, 0.78), Vector3(8.8, 0.46, 3.35), Color("d9d6cf"))
	_add_static_box("KitchenCounter2", Vector3(0.78, 0.92, 2.2), Vector3(11.0, 0.46, 4.65), Color("d9d6cf"))
	_add_static_box("KitchenIsland", Vector3(2.8, 0.92, 1.15), Vector3(6.3, 0.46, 4.95), Color("84705e"))
	_add_static_box("Fridge", Vector3(1.05, 2.25, 0.92), Vector3(10.7, 1.12, 5.55), Color("c4c7ca"), 0.32)

	# Bathroom / utility - right front.
	_add_static_box("BathTub", Vector3(2.3, 0.58, 0.95), Vector3(8.6, 0.29, 7.7), Color("e9ebea"), 0.24)
	_add_static_box("BathroomSink", Vector3(1.2, 0.22, 0.62), Vector3(4.3, 0.86, 7.15), Color("e8e7e2"), 0.25)
	_add_static_box("BathroomCabinet", Vector3(1.25, 0.78, 0.58), Vector3(4.3, 0.39, 7.15), Color("7f6653"))

	# Corridor detail.
	_add_static_box("HallBench", Vector3(1.2, 0.48, 0.52), Vector3(0.0, 0.24, 4.9), Color("67503f"))

func _build_balcony() -> void:
	# Large balcony connected directly to the living room opening.
	_add_static_box("BalconyFloor", Vector3(10.0, 0.22, 4.8), Vector3(-6.0, -0.10, 11.4), Color("8b8c86"), 0.82)
	_add_static_box("BalconyFrontRail", Vector3(10.0, 1.05, 0.12), Vector3(-6.0, 0.62, 13.75), Color("3b4147"), 0.28)
	_add_static_box("BalconyLeftRail", Vector3(0.12, 1.05, 4.8), Vector3(-11.0, 0.62, 11.4), Color("3b4147"), 0.28)
	_add_static_box("BalconyRightRail", Vector3(0.12, 1.05, 4.8), Vector3(-1.0, 0.62, 11.4), Color("3b4147"), 0.28)
	_add_static_box("BalconyTable", Vector3(1.5, 0.12, 0.85), Vector3(-6.0, 0.74, 11.8), Color("5e4a3a"))
	_add_static_box("BalconyTableLeg", Vector3(0.18, 0.70, 0.18), Vector3(-6.0, 0.36, 11.8), Color("4b392d"))
	_add_static_box("BalconySeatA", Vector3(0.65, 0.45, 0.65), Vector3(-7.2, 0.22, 11.8), Color("4d5158"))
	_add_static_box("BalconySeatB", Vector3(0.65, 0.45, 0.65), Vector3(-4.8, 0.22, 11.8), Color("4d5158"))

func _add_bed(node_name: String, position: Vector3, rotation_y: float, sheet_color: Color) -> void:
	var base = _add_static_box(node_name, Vector3(3.0, 0.48, 4.0), position, sheet_color, 0.90)
	base.rotation_degrees.y = rotation_y
	var headboard = _add_static_box(node_name + "Headboard", Vector3(3.0, 1.18, 0.18), position + Vector3(0.0, 0.55, 1.91), Color("856b59"))
	headboard.rotation_degrees.y = rotation_y

func _add_door(node_name: String, position: Vector3, rotation_y: float, width: float, color: Color, open_angle: float = -92.0) -> void:
	var door = StaticBody3D.new()
	door.name = node_name
	door.position = position
	door.rotation_degrees.y = rotation_y
	door.set_script(DoorScript)
	add_child(door)
	door.setup(Vector3(width, 2.36, 0.11), color, open_angle)

func _add_wall_z(node_name: String, z: float, x_from: float, x_to: float, color: Color) -> void:
	var length = abs(x_to - x_from)
	var center = (x_from + x_to) * 0.5
	_add_static_box(node_name, Vector3(length, 3.2, 0.22), Vector3(center, 1.6, z), color)

func _add_wall_x(node_name: String, x: float, z_from: float, z_to: float, color: Color) -> void:
	var length = abs(z_to - z_from)
	var center = (z_from + z_to) * 0.5
	_add_static_box(node_name, Vector3(0.22, 3.2, length), Vector3(x, 1.6, center), color)

func _add_static_box(node_name: String, size: Vector3, position: Vector3, color: Color, roughness: float = 0.78) -> StaticBody3D:
	var body = StaticBody3D.new()
	body.name = node_name
	body.position = position
	body.collision_layer = 1
	body.collision_mask = 1
	add_child(body)

	var mesh_instance = MeshInstance3D.new()
	var mesh = BoxMesh.new()
	mesh.size = size
	mesh_instance.mesh = mesh
	var material = StandardMaterial3D.new()
	material.albedo_color = color
	material.roughness = roughness
	mesh_instance.material_override = material
	body.add_child(mesh_instance)

	var collision = CollisionShape3D.new()
	var shape = BoxShape3D.new()
	shape.size = size
	collision.shape = shape
	body.add_child(collision)
	return body

func _spawn_player() -> void:
	var player = CharacterBody3D.new()
	player.name = "Cuma"
	player.set_script(PlayerController)
	player.position = Vector3(0.0, 0.05, 6.7)
	add_child(player)

func _spawn_mobile_controls() -> void:
	var controls = CanvasLayer.new()
	controls.name = "MobileControls"
	controls.set_script(MobileControls)
	add_child(controls)

func _build_runtime_systems() -> void:
	var env_node = get_tree().get_first_node_in_group("world_environment")
	var sun = get_node_or_null("Sun")
	if env_node is WorldEnvironment and sun is DirectionalLight3D:
		var cycle = Node.new()
		cycle.name = "DayNightCycle"
		cycle.set_script(DayNightScript)
		add_child(cycle)
		cycle.setup(sun, env_node.environment)
	var graphics = Node.new()
	graphics.name = "GraphicsManager"
	graphics.set_script(GraphicsManagerScript)
	add_child(graphics)

func _build_windows_and_city() -> void:
	# Transparent balcony doors/windows and a cheap skyline for depth on mobile.
	_add_glass_panel("LivingGlassA", Vector3(1.8, 2.35, 0.05), Vector3(-7.1, 1.3, 8.92))
	_add_glass_panel("LivingGlassB", Vector3(1.8, 2.35, 0.05), Vector3(-4.9, 1.3, 8.92))
	for i in range(9):
		var x = -20.0 + float(i) * 5.0
		var h = 4.0 + float((i * 7) % 8)
		_add_static_box("Skyline_%02d" % i, Vector3(3.3, h, 3.0), Vector3(x, h * 0.5 - 0.25, -20.0), Color("3e4854"), 0.9)

func _add_glass_panel(node_name: String, size: Vector3, pos: Vector3) -> void:
	var mesh_instance = MeshInstance3D.new()
	mesh_instance.name = node_name
	var mesh = BoxMesh.new()
	mesh.size = size
	mesh_instance.mesh = mesh
	mesh_instance.position = pos
	var material = StandardMaterial3D.new()
	material.albedo_color = Color(0.62, 0.82, 0.95, 0.24)
	material.roughness = 0.08
	material.metallic = 0.15
	material.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	mesh_instance.material_override = material
	add_child(mesh_instance)

func _build_interactions_v03() -> void:
	# Bedroom sleep surfaces.
	_add_bed_interaction("BedSleep1", Vector3(-7.2, 0.56, -6.4), "bed_1")
	_add_bed_interaction("BedSleep2", Vector3(-7.0, 0.56, -0.1), "bed_2")
	_add_bed_interaction("BedSleep3", Vector3(7.0, 0.56, -6.2), "bed_3")
	_add_bed_interaction("BedSleep4", Vector3(7.2, 0.56, -0.2), "bed_4")

	var seat = StaticBody3D.new()
	seat.name = "LivingSeatInteraction"
	seat.position = Vector3(-7.0, 0.55, 5.45)
	seat.set_script(SeatScript)
	add_child(seat)
	_add_collision_box(seat, Vector3(3.4, 1.0, 0.9))
	seat.setup(Vector3(-7.0, 0.05, 5.45), PI)

	var shower = StaticBody3D.new()
	shower.name = "ShowerInteraction"
	shower.position = Vector3(10.2, 1.0, 7.75)
	shower.set_script(ShowerScript)
	add_child(shower)
	_add_collision_box(shower, Vector3(1.3, 2.0, 1.3))

	var wardrobe = StaticBody3D.new()
	wardrobe.name = "WardrobeInteraction"
	wardrobe.position = Vector3(10.0, 1.23, 1.65)
	wardrobe.set_script(WardrobeScript)
	add_child(wardrobe)
	_add_collision_box(wardrobe, Vector3(3.1, 2.5, 0.72))

	var terminal = StaticBody3D.new()
	terminal.name = "DailyJobTerminal"
	terminal.position = Vector3(-10.0, 1.02, 1.35)
	terminal.set_script(JobTerminalScript)
	add_child(terminal)
	_add_collision_box(terminal, Vector3(0.9, 0.6, 0.15))

	var pickup = StaticBody3D.new()
	pickup.name = "BalconyKeycard"
	pickup.position = Vector3(-6.0, 0.92, 11.8)
	pickup.set_script(PickupScript)
	add_child(pickup)
	_add_collision_box(pickup, Vector3(0.38, 0.12, 0.26))
	pickup.setup("home_keycard", "Ev kartı", "balcony_keycard")

	# One switch controls the hall light; more can be added with the same component.
	var hall_light = get_node_or_null("HallLight")
	if hall_light is Light3D:
		var sw = StaticBody3D.new()
		sw.name = "HallLightSwitch"
		sw.position = Vector3(1.55, 1.25, 6.9)
		sw.set_script(LightSwitchScript)
		add_child(sw)
		_add_collision_box(sw, Vector3(0.18, 0.30, 0.16))
		sw.setup("hall_light", hall_light)

func _add_bed_interaction(node_name: String, pos: Vector3, pid: String) -> void:
	var body = StaticBody3D.new()
	body.name = node_name
	body.position = pos
	body.set_script(BedScript)
	add_child(body)
	_add_collision_box(body, Vector3(2.0, 0.45, 3.0))
	body.setup(pid)

func _add_collision_box(parent: Node3D, size: Vector3) -> void:
	var collision = CollisionShape3D.new()
	var shape = BoxShape3D.new()
	shape.size = size
	collision.shape = shape
	parent.add_child(collision)

func _add_visual_box_to(parent: Node3D, size: Vector3, pos: Vector3, color: Color, roughness: float, metallic: float) -> void:
	var mi = MeshInstance3D.new()
	var mesh = BoxMesh.new()
	mesh.size = size
	mi.mesh = mesh
	mi.position = pos
	var material = StandardMaterial3D.new()
	material.albedo_color = color
	material.roughness = roughness
	material.metallic = metallic
	mi.material_override = material
	parent.add_child(mi)


func _build_street_v03() -> void:
	# Small exterior slice: sidewalk, market and cinema shells.
	_add_static_box("Sidewalk", Vector3(30.0, 0.16, 5.0), Vector3(0.0, -0.02, 17.0), Color("777b7d"), 0.95)
	_add_static_box("Road", Vector3(38.0, 0.10, 7.0), Vector3(0.0, -0.05, 22.5), Color("25292d"), 0.92)
	_add_static_box("MarketShell", Vector3(7.0, 3.2, 4.5), Vector3(8.2, 1.6, 18.4), Color("d8d3c5"), 0.88)
	_add_static_box("CinemaShell", Vector3(8.5, 4.0, 4.8), Vector3(-8.5, 2.0, 18.6), Color("343038"), 0.72)

	var market = StaticBody3D.new()
	market.name = "MarketTerminal"
	market.position = Vector3(8.2, 1.05, 15.95)
	market.set_script(MarketTerminalScript)
	add_child(market)
	_add_collision_box(market, Vector3(1.1, 1.7, 0.25))

	var cinema = StaticBody3D.new()
	cinema.name = "CinemaTerminal"
	cinema.position = Vector3(-8.5, 1.05, 16.05)
	cinema.set_script(CinemaTerminalScript)
	add_child(cinema)
	_add_collision_box(cinema, Vector3(1.15, 1.75, 0.25))


func _build_together_spaces() -> void:
	# Home activities. Each shared activity requires both connected players to confirm nearby.
	_add_pair_activity("movie_night", "Birlikte film gecesi", Vector3(-7.0, 0.75, 4.25), 18, 2.0, Color("70445c"))
	_add_pair_activity("console_coop", "Co-op konsol oyunu", Vector3(-5.0, 0.65, 5.75), 16, 1.0, Color("3c5d75"))
	_add_pair_activity("cook_together", "Birlikte yemek hazırla", Vector3(6.3, 0.72, 4.95), 20, 1.0, Color("7a6040"))
	_add_pair_activity("board_game", "Masa oyunu oyna", Vector3(-7.0, 0.85, 4.1), 14, 0.75, Color("446452"))
	_add_pair_activity("study_together", "Birlikte çalışma zamanı", Vector3(-9.9, 0.92, 1.65), 15, 1.0, Color("4a5873"))
	_add_pair_activity("balcony_tea", "Balkonda içecek molası", Vector3(-6.0, 0.86, 11.8), 14, 0.5, Color("7b6548"))
	_add_pair_activity("stargaze", "Balkonda yıldızları izle", Vector3(-8.8, 0.70, 12.7), 22, 1.0, Color("39425f"))
	_add_pair_activity("plant_care", "Balkon bitkileriyle ilgilen", Vector3(-3.0, 0.70, 12.4), 12, 0.4, Color("3f6b49"))
	_add_pair_activity("sunset_watch", "Balkonda gün batımını izle", Vector3(-9.6, 0.70, 10.6), 16, 0.75, Color("7a5a4b"))
	_add_pair_activity("laundry_together", "Çamaşır işini birlikte bitir", Vector3(5.2, 0.75, 7.65), 10, 0.4, Color("557381"))
	_add_pair_activity("tidy_home", "Evi birlikte toparla", Vector3(0.0, 0.72, -1.6), 12, 0.6, Color("62695b"))
	_add_pair_activity("puzzle_together", "Birlikte yapboz çöz", Vector3(7.4, 0.72, -0.8), 16, 0.75, Color("6a526f"))
	_add_pair_activity("dessert_together", "Birlikte tatlı hazırla", Vector3(9.2, 0.72, 4.1), 16, 0.75, Color("806454"))
	_add_pair_activity("gift_exchange", "Sürpriz kutusunu birlikte aç", Vector3(4.6, 0.72, 2.9), 18, 0.25, Color("8a5668"))

	# Shared plan board.
	var board = StaticBody3D.new()
	board.name = "TogetherBoard"
	board.position = Vector3(0.0, 1.35, 4.35)
	board.set_script(DuoBoardScript)
	add_child(board)
	_add_visual_box_to(board, Vector3(1.7, 1.05, 0.12), Vector3.ZERO, Color("26313a"), 0.55, 0.0)
	_add_collision_box(board, Vector3(1.8, 1.15, 0.18))

	# Gift/surprise preparation shelf.
	var gift = StaticBody3D.new()
	gift.name = "GiftStation"
	gift.position = Vector3(4.6, 0.90, 4.05)
	gift.set_script(GiftStationScript)
	add_child(gift)
	_add_visual_box_to(gift, Vector3(0.8, 0.8, 0.8), Vector3.ZERO, Color("8f5b67"), 0.62, 0.0)
	_add_collision_box(gift, Vector3(0.9, 0.9, 0.9))

	# Room theme selector + accent panel.
	var decor = StaticBody3D.new()
	decor.name = "DecorStation"
	decor.position = Vector3(0.0, 1.0, 2.1)
	decor.set_script(DecorStationScript)
	add_child(decor)
	_add_visual_box_to(decor, Vector3(0.7, 1.1, 0.18), Vector3.ZERO, Color("6f5666"), 0.52, 0.0)
	_add_collision_box(decor, Vector3(0.8, 1.2, 0.25))
	_add_decor_accent(Vector3(-11.75, 1.55, 5.6), Vector3(0.08, 2.4, 4.0))
	_add_decor_accent(Vector3(11.75, 1.55, 4.5), Vector3(0.08, 2.2, 3.0))

	# Exterior social/co-op slice.
	_add_static_box("ParkPatch", Vector3(11.0, 0.10, 7.5), Vector3(14.0, -0.04, 11.5), Color("55734d"), 1.0)
	_add_static_box("ArcadeShell", Vector3(6.0, 3.4, 4.2), Vector3(14.8, 1.7, 18.4), Color("3c3550"), 0.72)
	_add_static_box("PhotoBoothShell", Vector3(3.2, 2.7, 2.6), Vector3(0.0, 1.35, 18.4), Color("6b5564"), 0.68)
	_add_static_box("SnackCafeShell", Vector3(5.2, 3.0, 3.8), Vector3(-15.2, 1.5, 13.5), Color("796957"), 0.84)

	_add_pair_activity("walk_together", "Mahalle yürüyüşü", Vector3(12.0, 0.6, 12.0), 14, 0.75, Color("4f7657"))
	_add_pair_activity("picnic", "Parkta piknik", Vector3(16.2, 0.55, 10.5), 18, 1.0, Color("786b45"))
	_add_pair_activity("arcade_duo", "Arcade mini oyunları", Vector3(14.8, 0.95, 16.1), 20, 1.0, Color("57457a"))
	_add_pair_activity("photo_booth", "Birlikte fotoğraf kabini", Vector3(0.0, 0.95, 16.9), 20, 0.25, Color("805c70"))
	_add_pair_activity("snack_break", "Atıştırmalık molası", Vector3(-15.2, 0.85, 11.6), 12, 0.5, Color("826a4c"))
	_add_pair_activity("cinema_duo", "Sinemada birlikte film", Vector3(-8.5, 0.95, 15.5), 24, 2.0, Color("7a3f50"))
	_add_pair_activity("market_challenge", "Birlikte market alışverişi", Vector3(8.2, 0.95, 15.4), 14, 0.5, Color("3f7655"))
	_add_pair_activity("music_corner", "Müzik seçip birlikte dinle", Vector3(-3.2, 0.75, 12.6), 15, 0.75, Color("4d5277"))

func _add_pair_activity(activity_id: String, title: String, pos: Vector3, points: int, hours: float, color: Color) -> void:
	var body = StaticBody3D.new()
	body.name = "Duo_" + activity_id
	body.position = pos
	body.set_script(PairActivityScript)
	add_child(body)
	_add_visual_box_to(body, Vector3(0.62, 0.62, 0.62), Vector3.ZERO, color, 0.48, 0.05)
	_add_collision_box(body, Vector3(0.9, 1.0, 0.9))
	var label = Label3D.new()
	label.text = title
	label.position = Vector3(0.0, 0.85, 0.0)
	label.font_size = 24
	label.outline_size = 6
	label.billboard = BaseMaterial3D.BILLBOARD_ENABLED
	body.add_child(label)
	body.setup(activity_id, title, points, hours)

func _add_decor_accent(pos: Vector3, size: Vector3) -> void:
	var mi = MeshInstance3D.new()
	var mesh = BoxMesh.new()
	mesh.size = size
	mi.mesh = mesh
	mi.position = pos
	mi.set_script(DecorAccentScript)
	add_child(mi)


func _build_realism_overhaul() -> void:
	var realism = Node.new()
	realism.name = "RealismBuilder"
	realism.set_script(RealismBuilderScript)
	add_child(realism)
	realism.setup(self)

func _build_ultra_home_07() -> void:
	var builder = Node.new()
	builder.name = "UltraHomeBuilder"
	builder.set_script(UltraHomeBuilderScript)
	add_child(builder)
	builder.setup(self)


func _build_production_home_21() -> void:
	var builder = Node.new()
	builder.name = "ProductionHomeBuilder21"
	builder.set_script(ProductionHomeBuilderScript)
	add_child(builder)
	builder.setup(self)

func _build_visual_rebuild_20() -> void:
	var builder = Node.new()
	builder.name = "VisualRebuildBuilder20"
	builder.set_script(VisualRebuildBuilderScript)
	add_child(builder)
	builder.setup(self)

func _build_living_city_08() -> void:
	var builder = Node.new()
	builder.name = "LivingCityBuilder"
	builder.set_script(LivingCityBuilderScript)
	add_child(builder)
	builder.setup(self)


func _build_production_city_polish_21() -> void:
	var builder = Node.new()
	builder.name = "ProductionCityPolish21"
	builder.set_script(ProductionCityPolishScript)
	add_child(builder)
	builder.setup(self)

func _build_online_life_09() -> void:
	var builder = Node.new()
	builder.name = "OnlineLifeBuilder"
	builder.set_script(OnlineLifeBuilderScript)
	add_child(builder)
	builder.setup(self)

func _build_full_life_10() -> void:
	var builder = Node.new()
	builder.name = "FullLifeBuilder"
	builder.set_script(FullLifeBuilderScript)
	add_child(builder)
	builder.setup(self)

func _build_online_relay_11() -> void:
	var builder = Node.new()
	builder.name = "OnlineRelayBuilder"
	builder.set_script(OnlineRelayBuilderScript)
	add_child(builder)
	builder.setup(self)

func _build_physical_ai_14() -> void:
	var builder = Node.new()
	builder.name = "PhysicalAIBuilder"
	builder.set_script(PhysicalAIBuilderScript)
	add_child(builder)
	builder.setup(self)

func _build_human_behavior_15() -> void:
	var builder = Node.new()
	builder.name = "HumanBehaviorBuilder15"
	builder.set_script(HumanBehaviorBuilderScript)
	add_child(builder)
	builder.setup(self)

func _build_social_life_12() -> void:
	var builder = Node.new()
	builder.name = "SocialLifeBuilder"
	builder.set_script(SocialLifeBuilderScript)
	add_child(builder)
	builder.setup(self)

func _build_npc_intelligence_13() -> void:
	var director = Node.new()
	director.name = "NPCIntelligenceDirector"
	director.set_script(NPCIntelligenceDirectorScript)
	add_child(director)
	director.setup()

func _build_daily_life_16() -> void:
	var builder = Node.new()
	builder.name = "DailyLifeBuilder16"
	builder.set_script(DailyLifeBuilderScript)
	add_child(builder)
	builder.setup(self)

func _build_city_society_17() -> void:
	var builder = Node.new()
	builder.name = "CitySocietyBuilder17"
	builder.set_script(CitySocietyBuilderScript)
	add_child(builder)
	builder.setup(self)

func _build_dynamic_city_18() -> void:
	var builder = Node.new()
	builder.name = "DynamicCityBuilder18"
	builder.set_script(DynamicCityBuilderScript)
	add_child(builder)
	builder.setup(self)

func _build_crime_justice_19() -> void:
	var builder = Node.new()
	builder.name = "CrimeJusticeBuilder19"
	builder.set_script(CrimeJusticeBuilderScript)
	add_child(builder)
	builder.setup(self)

func _build_cyber_ui_19() -> void:
	var ui = CanvasLayer.new()
	ui.name = "CyberPuzzleUI19"
	ui.set_script(CyberPuzzleUIScript)
	add_child(ui)
	ui.setup()

func _build_law_hud_19() -> void:
	var hud = CanvasLayer.new()
	hud.name = "LawHUD19"
	hud.set_script(LawHUDScript)
	add_child(hud)
	hud.setup()

func _build_weather_09() -> void:
	var manager = Node.new()
	manager.name = "WeatherManager"
	manager.set_script(WeatherManagerScript)
	add_child(manager)
	manager.setup(self)

func _build_phone_09() -> void:
	var phone = CanvasLayer.new()
	phone.name = "CumaPhone"
	phone.set_script(PhoneUIScript)
	add_child(phone)
	phone.setup()

func _build_social_ui_12() -> void:
	var social_ui = CanvasLayer.new()
	social_ui.name = "SocialInteractionUI"
	social_ui.set_script(SocialInteractionUIScript)
	add_child(social_ui)
	social_ui.setup()

func _connect_network() -> void:
	var net = get_node_or_null("/root/NetworkManager")
	if net == null:
		return
	net.peer_joined.connect(_on_network_peer_joined)
	net.peer_left.connect(_on_network_peer_left)
	net.remote_transform_received.connect(_on_remote_transform_received)
	net.emote_received.connect(_on_remote_emote_received)
	net.pair_activity_completed.connect(_on_pair_activity_world_completed)
	for peer_id in net.get_connected_peer_ids():
		_on_network_peer_joined(int(peer_id))

func _on_network_peer_joined(peer_id: int) -> void:
	var net = get_node_or_null("/root/NetworkManager")
	if net == null or peer_id == net.get_local_peer_id() or remote_avatars.has(peer_id):
		return
	var avatar = Node3D.new()
	avatar.set_script(RemoteAvatarScript)
	add_child(avatar)
	var gs = get_node_or_null("/root/GameState")
	var display_name = gs.partner_name if gs != null else "Partner"
	avatar.setup(peer_id, display_name)
	avatar.global_position = Vector3(0.9, 0.05, 6.7)
	remote_avatars[peer_id] = avatar

func _on_network_peer_left(peer_id: int) -> void:
	if not remote_avatars.has(peer_id):
		return
	var avatar: Node = remote_avatars[peer_id]
	remote_avatars.erase(peer_id)
	if is_instance_valid(avatar):
		avatar.queue_free()

func _on_remote_transform_received(peer_id: int, value: Transform3D) -> void:
	if not remote_avatars.has(peer_id):
		_on_network_peer_joined(peer_id)
	if remote_avatars.has(peer_id):
		remote_avatars[peer_id].set_network_transform(value)

func _on_remote_emote_received(peer_id: int, emote: String) -> void:
	var net = get_node_or_null("/root/NetworkManager")
	if net != null and peer_id == net.get_local_peer_id():
		return
	if remote_avatars.has(peer_id):
		remote_avatars[peer_id].play_emote(emote)


func _on_pair_activity_world_completed(activity_id: String, _title: String) -> void:
	var gs = get_node_or_null("/root/GameState")
	var player = get_tree().get_first_node_in_group("player")
	if gs == null:
		return
	match activity_id:
		"cook_together", "dessert_together":
			gs.add_item("shared_meal", 1)
		"market_challenge":
			gs.add_item("duo_snack", 1)
		"gift_exchange":
			if gs.has_item("surprise_box"):
				gs.remove_item("surprise_box", 1)
			gs.add_item("keepsake", 1)
		"arcade_duo":
			gs.add_money(10)
		"movie_night":
			var tv = get_node_or_null("InteractiveTV")
			if tv != null and tv.has_method("set_power"):
				tv.set_power(true)
		"stargaze":
			if gs.time_of_day < 20.5 or gs.time_of_day > 23.5:
				gs.time_of_day = 21.5
				gs.state_changed.emit()
		"sunset_watch":
			gs.time_of_day = 19.0
			gs.state_changed.emit()
		"photo_booth":
			if player != null and player.has_method("take_photo"):
				player.take_photo()
		"restaurant_dinner", "city_breakfast":
			gs.add_item("shared_meal",1)
		"outfit_day":
			if player != null and player.has_method("cycle_outfit"):
				player.cycle_outfit()
		"coffee_and_book", "book_pick":
			gs.add_item("shared_book",1)
		"rain_walk":
			var weather = get_tree().get_first_node_in_group("weather_manager")
			if weather != null and weather.has_method("set_weather"):
				weather.set_weather("RAIN")
