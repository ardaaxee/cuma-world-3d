#!/usr/bin/env python3
from pathlib import Path
import configparser
import sys

root = Path(__file__).resolve().parents[1]
required = [
    root / 'project.godot',
    root / 'export_presets.cfg',
    root / '.github/workflows/android-apk.yml',
    root / 'scenes/main.tscn',
]
missing = [str(p.relative_to(root)) for p in required if not p.exists()]
if missing:
    print('APK PREFLIGHT: FAIL')
    print('Missing:', ', '.join(missing))
    sys.exit(1)

text = (root / 'export_presets.cfg').read_text(encoding='utf-8')
checks = {
    'Android platform': 'platform="Android"' in text,
    'ARM64 enabled': 'architectures/arm64-v8a=true' in text,
    'Internet permission': 'permissions/internet=true' in text,
    'Package ID': 'package/unique_name="com.cumaworld.game"' in text,
}
failed = [name for name, ok in checks.items() if not ok]
if failed:
    print('APK PREFLIGHT: FAIL')
    print('Failed:', ', '.join(failed))
    sys.exit(1)
print('APK PREFLIGHT: PASS')
