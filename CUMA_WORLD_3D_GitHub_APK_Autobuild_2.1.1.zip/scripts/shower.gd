extends StaticBody3D

var busy = false

func get_interaction_label() -> String:
	return "Duş al"

func interact(player: Node) -> void:
	if busy:
		return
	busy = true
	if player.has_method("begin_timed_activity"):
		player.begin_timed_activity("Duş", 2.5)
	await get_tree().create_timer(2.5).timeout
	busy = false
