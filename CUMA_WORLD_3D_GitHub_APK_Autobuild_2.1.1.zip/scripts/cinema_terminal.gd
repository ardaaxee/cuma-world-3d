extends StaticBody3D

func get_interaction_label() -> String:
	return "Film bileti al (50 TL)"

func interact(player: Node) -> void:
	var net = get_node_or_null("/root/NetworkManager")
	if net != null and net.is_online():
		if player != null and player.has_method("show_status"):
			player.show_status("Online: sinema girişindeki BİRLİKTE noktasını kullan", 3.0)
		return
	var gs = get_node_or_null("/root/GameState")
	if gs == null:
		return
	if gs.spend_money(50):
		gs.advance_time(2.0)
		if player.has_method("show_status"):
			player.show_status("Film izlendi • 2 saat geçti", 2.4)
	else:
		if player.has_method("show_status"):
			player.show_status("Bilet için yeterli paran yok")
