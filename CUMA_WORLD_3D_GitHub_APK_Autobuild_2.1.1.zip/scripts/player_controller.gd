extends CharacterBody3D

const WALK_SPEED = 3.9
const RUN_SPEED = 6.4
const JUMP_VELOCITY = 6.4
const MOUSE_SENSITIVITY = 0.0025
const TOUCH_SENSITIVITY = 0.0038
const MAX_STAMINA = 100.0
const ImportedCharacterBridge = preload("res://scripts/imported_character_bridge.gd")
const ProceduralHumanoidScript = preload("res://scripts/character/procedural_humanoid.gd")

var gravity = 18.0
var mobile_move = Vector2.ZERO
var mobile_look = Vector2.ZERO
var jump_requested = false
var sprint_requested = false
var camera_pitch = deg_to_rad(-12.0)
var status_text = ""
var status_until = 0
var stamina = MAX_STAMINA
var activity_locked = false
var sitting = false
var stand_transform: Transform3D
var camera_pivot: Node3D
var camera: Camera3D
var camera_spring: SpringArm3D
var first_person = false
var interaction_ray: RayCast3D
var visual_root: Node3D
var procedural_rig
var imported_bridge
var network_send_accum = 0.0
var previous_grounded = true
var footstep_distance = 0.0
var last_position = Vector3.ZERO
var footstep_a: AudioStreamPlayer3D
var footstep_b: AudioStreamPlayer3D
var use_step_a = true
var driving_vehicle: Node = null
var vehicle_seat = ""

func _ready() -> void:
	add_to_group("player")
	_build_collider()
	_build_visuals()
	_build_camera()
	_build_audio()
	var gs = get_node_or_null("/root/GameState")
	if gs != null:
		global_position = gs.checkpoint_position
	last_position = global_position
	previous_grounded = is_on_floor()
	if not OS.has_feature("mobile"):
		Input.mouse_mode = Input.MOUSE_MODE_CAPTURED

func _build_collider() -> void:
	var collider = CollisionShape3D.new()
	var capsule = CapsuleShape3D.new()
	capsule.radius = 0.34
	capsule.height = 1.78
	collider.shape = capsule
	collider.position.y = 0.89
	add_child(collider)

func _build_visuals() -> void:
	visual_root = Node3D.new()
	visual_root.name = "CharacterVisual"
	add_child(visual_root)

	# Production slot: a rigged GLB can replace the built-in organic fallback without code edits.
	if FileAccess.file_exists("res://assets/characters/cuma.glb"):
		var resource = load("res://assets/characters/cuma.glb")
		if resource is PackedScene:
			var imported = resource.instantiate()
			imported.name = "ImportedCumaGLB"
			visual_root.add_child(imported)
			imported_bridge = Node.new()
			imported_bridge.name = "ImportedCharacterBridge"
			imported_bridge.set_script(ImportedCharacterBridge)
			add_child(imported_bridge)
			imported_bridge.setup(imported)
			if imported_bridge.available:
				return
			# A static/non-animated GLB should not silently downgrade locomotion quality.
			imported.queue_free()
			imported_bridge.queue_free()
			imported_bridge = null

	procedural_rig = Node3D.new()
	procedural_rig.name = "CumaOrganicRig"
	procedural_rig.set_script(ProceduralHumanoidScript)
	visual_root.add_child(procedural_rig)
	var gs = get_node_or_null("/root/GameState")
	var palette = gs.get_character_palette() if gs != null and gs.has_method("get_character_palette") else {"top":Color("263653"),"pants":Color("20293a"),"hair":Color("171819")}
	procedural_rig.setup({
		"skin": Color("d3a17f"),
		"top": palette.get("top", Color("263653")),
		"pants": palette.get("pants", Color("20293a")),
		"hair": palette.get("hair", Color("171819")),
		"shoes": Color("101216"),
		"height_scale": 1.0,
		"shoulder_scale": 1.04
	})
	if gs != null and procedural_rig.has_method("apply_hair_style"):
		procedural_rig.apply_hair_style(int(gs.hair_style))

func _build_camera() -> void:
	camera_pivot = Node3D.new()
	camera_pivot.name = "CameraPivot"
	camera_pivot.position = Vector3(0.0, 1.62, 0.0)
	camera_pivot.rotation.x = camera_pitch
	add_child(camera_pivot)

	camera_spring = SpringArm3D.new()
	camera_spring.name = "CameraSpring"
	camera_spring.spring_length = 4.65
	camera_spring.margin = 0.24
	camera_spring.collision_mask = 1
	camera_pivot.add_child(camera_spring)
	camera_spring.add_excluded_object(get_rid())

	camera = Camera3D.new()
	camera.name = "PlayerCamera"
	camera.current = true
	camera.fov = 70.0
	camera.near = 0.05
	camera_spring.add_child(camera)

	var face_fill = OmniLight3D.new()
	face_fill.name = "CameraFill"
	face_fill.position = Vector3(0.25, 0.10, -0.35)
	face_fill.light_color = Color("ffe4c8")
	face_fill.light_energy = 0.22
	face_fill.omni_range = 3.0
	face_fill.shadow_enabled = false
	camera.add_child(face_fill)

	interaction_ray = RayCast3D.new()
	interaction_ray.name = "InteractionRay"
	interaction_ray.enabled = true
	interaction_ray.target_position = Vector3(0.0, 0.0, -3.4)
	interaction_ray.collide_with_areas = true
	interaction_ray.collision_mask = 1
	interaction_ray.add_exception(self)
	camera.add_child(interaction_ray)

	# Until a real animated GLB is installed, start in first person so the
	# procedural fallback does not dominate the whole screen.
	first_person = true
	_apply_camera_mode()

func toggle_camera_mode() -> void:
	first_person = not first_person
	_apply_camera_mode()

func _apply_camera_mode() -> void:
	if camera_spring == null:
		return
	if first_person:
		camera_spring.spring_length = 0.08
		camera_pivot.position = Vector3(0.0, 1.63, 0.0)
		camera.fov = 72.0
		if visual_root != null:
			visual_root.visible = false
	else:
		camera_spring.spring_length = 4.85
		camera_pivot.position = Vector3(0.0, 1.58, 0.0)
		camera.fov = 63.0
		if visual_root != null:
			visual_root.visible = true

func get_camera_mode_label() -> String:
	return "1P" if first_person else "3P"

func _build_audio() -> void:
	footstep_a = AudioStreamPlayer3D.new()
	footstep_b = AudioStreamPlayer3D.new()
	footstep_a.name = "FootstepA"
	footstep_b.name = "FootstepB"
	footstep_a.volume_db = -13.0
	footstep_b.volume_db = -14.0
	footstep_a.max_distance = 8.0
	footstep_b.max_distance = 8.0
	if ResourceLoader.exists("res://assets/audio/footstep_a.wav"):
		footstep_a.stream = load("res://assets/audio/footstep_a.wav")
	if ResourceLoader.exists("res://assets/audio/footstep_b.wav"):
		footstep_b.stream = load("res://assets/audio/footstep_b.wav")
	add_child(footstep_a)
	add_child(footstep_b)

func _physics_process(delta: float) -> void:
	if driving_vehicle != null:
		if not is_instance_valid(driving_vehicle):
			driving_vehicle = null
			if visual_root != null:
				visual_root.visible = true
		else:
			if Input.is_action_just_pressed("interact"):
				driving_vehicle.exit_vehicle(self)
			if mobile_look != Vector2.ZERO:
				_apply_look(mobile_look, TOUCH_SENSITIVITY)
				mobile_look = Vector2.ZERO
			_sync_network(delta)
			return
	if activity_locked or sitting:
		velocity.x = move_toward(velocity.x, 0.0, 24.0 * delta)
		velocity.z = move_toward(velocity.z, 0.0, 24.0 * delta)
		if not is_on_floor():
			velocity.y -= gravity * delta
		move_and_slide()
		_update_character_visual(delta, false)
		_sync_network(delta)
		return

	if not is_on_floor():
		velocity.y -= gravity * delta

	var keyboard_move = Input.get_vector("move_left", "move_right", "move_forward", "move_back")
	var move_input = mobile_move if mobile_move.length() > 0.04 else keyboard_move
	if move_input.length() > 1.0:
		move_input = move_input.normalized()

	var direction = (transform.basis * Vector3(move_input.x, 0.0, move_input.y)).normalized()
	var wants_run = sprint_requested or Input.is_action_pressed("sprint")
	var running = wants_run and stamina > 2.0 and direction.length() > 0.01
	var speed = RUN_SPEED if running else WALK_SPEED

	if running:
		stamina = max(0.0, stamina - 19.0 * delta)
	else:
		stamina = min(MAX_STAMINA, stamina + 13.0 * delta)

	if direction.length() > 0.01:
		velocity.x = move_toward(velocity.x, direction.x * speed, 24.0 * delta)
		velocity.z = move_toward(velocity.z, direction.z * speed, 24.0 * delta)
	else:
		velocity.x = move_toward(velocity.x, 0.0, 30.0 * delta)
		velocity.z = move_toward(velocity.z, 0.0, 30.0 * delta)

	if (jump_requested or Input.is_action_just_pressed("jump")) and is_on_floor():
		velocity.y = JUMP_VELOCITY
	jump_requested = false

	if Input.is_action_just_pressed("interact"):
		try_interact()

	if mobile_look != Vector2.ZERO:
		_apply_look(mobile_look, TOUCH_SENSITIVITY)
		mobile_look = Vector2.ZERO

	move_and_slide()
	_update_character_visual(delta, running)
	_update_footsteps()
	_sync_network(delta)
	previous_grounded = is_on_floor()

func _update_character_visual(delta: float, running: bool) -> void:
	var horizontal_speed = Vector2(velocity.x, velocity.z).length()
	if procedural_rig != null and procedural_rig.has_method("update_pose"):
		procedural_rig.update_pose(delta, horizontal_speed, running, velocity.y, is_on_floor(), sitting, camera_pitch)
	if imported_bridge != null and imported_bridge.has_method("update_state"):
		imported_bridge.update_state(horizontal_speed, running, is_on_floor(), velocity.y, sitting)

func _update_footsteps() -> void:
	var grounded = is_on_floor()
	var horizontal_speed = Vector2(velocity.x, velocity.z).length()
	if not grounded or horizontal_speed < 0.45:
		last_position = global_position
		return
	var flat_delta = Vector2(global_position.x - last_position.x, global_position.z - last_position.z).length()
	footstep_distance += flat_delta
	last_position = global_position
	var stride = 1.25 if horizontal_speed > 5.3 else 1.55
	if footstep_distance >= stride:
		footstep_distance = 0.0
		var player = footstep_a if use_step_a else footstep_b
		use_step_a = not use_step_a
		if player != null and player.stream != null:
			player.pitch_scale = randf_range(0.96, 1.04)
			player.play()

func _unhandled_input(event: InputEvent) -> void:
	if event is InputEventMouseMotion and Input.mouse_mode == Input.MOUSE_MODE_CAPTURED:
		_apply_look(event.relative, MOUSE_SENSITIVITY)
	elif event is InputEventKey and event.pressed and event.keycode == KEY_ESCAPE:
		Input.mouse_mode = Input.MOUSE_MODE_VISIBLE
	elif event is InputEventMouseButton and event.pressed and event.button_index == MOUSE_BUTTON_LEFT and not OS.has_feature("mobile"):
		Input.mouse_mode = Input.MOUSE_MODE_CAPTURED

func _apply_look(delta: Vector2, sensitivity: float) -> void:
	rotate_y(-delta.x * sensitivity)
	camera_pitch = clamp(camera_pitch - delta.y * sensitivity, deg_to_rad(-55.0), deg_to_rad(48.0))
	camera_pivot.rotation.x = camera_pitch

func set_mobile_move(value: Vector2) -> void:
	mobile_move = value

func add_mobile_look(value: Vector2) -> void:
	mobile_look += value

func request_jump() -> void:
	jump_requested = true

func set_sprinting(value: bool) -> void:
	sprint_requested = value

func try_interact() -> void:
	if driving_vehicle != null:
		driving_vehicle.exit_vehicle(self)
		return
	if sitting:
		toggle_sit(global_position, rotation.y)
		return
	var target = _get_interaction_target()
	if target != null and target.has_method("interact"):
		target.interact(self)

func _get_interaction_target():
	if interaction_ray == null:
		return null
	interaction_ray.force_raycast_update()
	if not interaction_ray.is_colliding():
		return null
	return interaction_ray.get_collider()

func get_interaction_text() -> String:
	if driving_vehicle != null:
		return "Araçtan in"
	if sitting:
		return "Ayağa kalk"
	var target = _get_interaction_target()
	if target != null and target.has_method("get_interaction_label"):
		return str(target.get_interaction_label())
	return ""

func show_status(message: String, seconds: float = 2.2) -> void:
	status_text = message
	status_until = Time.get_ticks_msec() + int(seconds * 1000.0)

func get_status_text() -> String:
	if Time.get_ticks_msec() > status_until:
		return ""
	return status_text

func save_now() -> void:
	var gs = get_node_or_null("/root/GameState")
	if gs == null:
		return
	var err = gs.save_game(global_position)
	show_status("Oyun kaydedildi" if err == OK else "Kayıt başarısız")

func restore_stamina() -> void:
	stamina = MAX_STAMINA

func get_stamina_percent() -> int:
	return int(round((stamina / MAX_STAMINA) * 100.0))

func toggle_sit(anchor: Vector3, yaw: float) -> void:
	if not sitting:
		stand_transform = global_transform
		global_position = anchor
		rotation.y = yaw
		sitting = true
		show_status("Oturuyorsun • USE ile kalk")
	else:
		global_transform = stand_transform
		sitting = false
		show_status("Ayağa kalktın", 1.2)

func begin_timed_activity(label: String, seconds: float) -> void:
	if activity_locked:
		return
	activity_locked = true
	show_status(label + "...", seconds)
	await get_tree().create_timer(seconds).timeout
	activity_locked = false
	show_status(label + " tamamlandı", 1.5)

func begin_pose_activity(label: String, pose: String, seconds: float) -> void:
	if activity_locked or sitting or driving_vehicle != null:
		return
	activity_locked = true
	if procedural_rig != null and procedural_rig.has_method("set_activity_pose"):
		procedural_rig.set_activity_pose(pose)
	show_status(label + "...", seconds)
	await get_tree().create_timer(clamp(seconds, 1.0, 12.0)).timeout
	if procedural_rig != null and procedural_rig.has_method("set_activity_pose"):
		procedural_rig.set_activity_pose("")
	activity_locked = false
	show_status(label + " tamamlandı", 1.5)

func cycle_outfit() -> void:
	var gs = get_node_or_null("/root/GameState")
	if gs != null:
		gs.cycle_character_style()
	apply_saved_customization()
	show_status("Karakter stili değiştirildi")

func apply_saved_customization() -> void:
	var gs = get_node_or_null("/root/GameState")
	if gs == null:
		return
	if procedural_rig != null and procedural_rig.has_method("apply_palette"):
		procedural_rig.apply_palette(gs.get_character_palette())
	if procedural_rig != null and procedural_rig.has_method("apply_hair_style"):
		procedural_rig.apply_hair_style(int(gs.hair_style))

func play_local_emote(emote: String) -> void:
	if procedural_rig != null and procedural_rig.has_method("play_emote"):
		procedural_rig.play_emote(emote)
	if imported_bridge != null and imported_bridge.has_method("play_emote"):
		imported_bridge.play_emote(emote)

func _sync_network(delta: float) -> void:
	network_send_accum += delta
	if network_send_accum < 0.075:
		return
	network_send_accum = 0.0
	var net = get_node_or_null("/root/NetworkManager")
	if net != null and net.has_method("send_local_transform"):
		net.send_local_transform(global_transform)

func take_photo() -> void:
	show_status("Fotoğraf hazırlanıyor...", 1.0)
	await RenderingServer.frame_post_draw
	var image = get_viewport().get_texture().get_image()
	if image == null:
		show_status("Fotoğraf alınamadı")
		return
	var dir_path = ProjectSettings.globalize_path("user://photos")
	DirAccess.make_dir_recursive_absolute(dir_path)
	var filename = "cuma_world_%d.png" % int(Time.get_unix_time_from_system())
	var err = image.save_png("user://photos/" + filename)
	if err == OK:
		var gs = get_node_or_null("/root/GameState")
		if gs != null and gs.has_method("add_memory"):
			gs.add_memory("Fotoğraf çekildi")
		show_status("Fotoğraf kaydedildi • user://photos", 2.5)
	else:
		show_status("Fotoğraf kaydedilemedi")

func get_drive_input() -> Vector2:
	if vehicle_seat != "driver":
		return Vector2.ZERO
	var keyboard_move = Input.get_vector("move_left", "move_right", "move_forward", "move_back")
	var value = mobile_move if mobile_move.length() > 0.04 else keyboard_move
	return value.normalized() if value.length() > 1.0 else value

func enter_vehicle(vehicle: Node, seat: String = "driver") -> void:
	if vehicle == null:
		return
	if driving_vehicle != null and driving_vehicle != vehicle:
		return
	driving_vehicle = vehicle
	vehicle_seat = seat if ["driver", "passenger", "transit_left", "transit_right"].has(seat) else "driver"
	velocity = Vector3.ZERO
	if visual_root != null:
		visual_root.visible = false
	show_status("Araç • %s • USE ile in" % ("sürücü" if vehicle_seat == "driver" else "yolcu"), 3.0)

func update_vehicle_anchor(vehicle_transform: Transform3D, speed: float) -> void:
	if driving_vehicle == null:
		return
	var x_offset = -0.42 if ["driver", "transit_left"].has(vehicle_seat) else 0.42
	global_transform = vehicle_transform.translated_local(Vector3(x_offset,0.48,0.08))
	velocity = -vehicle_transform.basis.z * speed

func exit_vehicle(exit_position: Vector3, yaw: float) -> void:
	driving_vehicle = null
	vehicle_seat = ""
	global_position = exit_position
	rotation.y = yaw
	velocity = Vector3.ZERO
	if visual_root != null:
		visual_root.visible = true
	show_status("Araçtan indin",1.5)
