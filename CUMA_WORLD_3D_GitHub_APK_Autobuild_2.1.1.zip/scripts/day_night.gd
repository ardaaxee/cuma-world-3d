extends Node

var sun: DirectionalLight3D
var environment: Environment
var last_time = -100.0

func setup(sun_node: DirectionalLight3D, env: Environment) -> void:
	sun = sun_node
	environment = env

func _process(_delta: float) -> void:
	if sun == null or environment == null:
		return
	var gs = get_node_or_null("/root/GameState")
	if gs == null:
		return
	var t = float(gs.time_of_day)
	if abs(t - last_time) < 0.01:
		return
	last_time = t
	_update_scene(t, str(gs.weather_mode))

func _update_scene(hour: float, weather_mode: String = "CLEAR") -> void:
	var daylight = clamp(sin(((hour - 6.0) / 12.0) * PI), 0.0, 1.0)
	var dusk = clamp(1.0 - abs(hour - 18.5) / 2.5, 0.0, 1.0)
	var night = 1.0 - daylight

	var sun_rotation = sun.rotation_degrees
	sun_rotation.x = -8.0 - daylight * 62.0
	sun_rotation.y = -145.0 + hour * 8.0
	sun.rotation_degrees = sun_rotation
	sun.light_energy = 0.08 + daylight * 1.45
	sun.light_color = Color("ffd0a0").lerp(Color("fff5df"), daylight)

	var night_bg = Color("08111f")
	var day_bg = Color("8dbce3")
	var sunset_bg = Color("d98267")
	var bg = night_bg.lerp(day_bg, daylight)
	bg = bg.lerp(sunset_bg, dusk * 0.45)
	environment.background_color = bg
	environment.ambient_light_color = Color("30405e").lerp(Color("d9e8f1"), daylight)
	environment.ambient_light_energy = 0.24 + daylight * 0.48 + night * 0.04
	environment.fog_light_color = bg.lerp(Color.WHITE, 0.18)
	match weather_mode.to_upper():
		"RAIN":
			sun.light_energy *= 0.38
			environment.background_color = environment.background_color.lerp(Color("536274"),0.58)
			environment.ambient_light_color = environment.ambient_light_color.lerp(Color("9aabba"),0.58)
			environment.ambient_light_energy *= 0.68
			environment.fog_density = 0.010
		"CLOUDY":
			sun.light_energy *= 0.66
			environment.background_color = environment.background_color.lerp(Color("78889a"),0.38)
			environment.ambient_light_energy *= 0.82
			environment.fog_density = 0.005
		_:
			environment.fog_density = 0.0015
