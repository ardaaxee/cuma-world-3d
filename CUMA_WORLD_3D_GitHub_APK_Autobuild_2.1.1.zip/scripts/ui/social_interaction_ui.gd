extends CanvasLayer

var panel: PanelContainer
var title_label: Label
var info_label: Label
var response_label: Label
var action_box: VBoxContainer
var selected_npc_id = ""
var selected_npc: Node

func setup() -> void:
	layer = 46
	add_to_group("social_ui")
	_build_ui()

func _build_ui() -> void:
	panel = PanelContainer.new()
	panel.anchor_left = 0.5
	panel.anchor_right = 0.5
	panel.anchor_top = 0.5
	panel.anchor_bottom = 0.5
	panel.offset_left = -245
	panel.offset_right = 245
	panel.offset_top = -325
	panel.offset_bottom = 325
	panel.visible = false
	add_child(panel)

	var outer = VBoxContainer.new()
	outer.add_theme_constant_override("separation", 8)
	panel.add_child(outer)
	title_label = Label.new()
	title_label.text = "SOSYAL"
	title_label.add_theme_font_size_override("font_size", 24)
	outer.add_child(title_label)
	info_label = Label.new()
	info_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	info_label.custom_minimum_size = Vector2(440, 115)
	outer.add_child(info_label)
	var scroll = ScrollContainer.new()
	scroll.custom_minimum_size = Vector2(450, 355)
	outer.add_child(scroll)
	action_box = VBoxContainer.new()
	action_box.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	action_box.add_theme_constant_override("separation", 6)
	scroll.add_child(action_box)
	response_label = Label.new()
	response_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	response_label.custom_minimum_size = Vector2(440, 62)
	outer.add_child(response_label)
	var close = Button.new()
	close.text = "KAPAT"
	close.pressed.connect(close_panel)
	outer.add_child(close)

func open_for_npc(npc_id: String, npc_node: Node = null) -> void:
	selected_npc_id = npc_id
	selected_npc = npc_node
	panel.visible = true
	response_label.text = ""
	_refresh_npc()

func open_contacts() -> void:
	selected_npc_id = ""
	selected_npc = null
	panel.visible = true
	response_label.text = "Mahallede tanıştığın kişiler burada görünür."
	_refresh_contacts()

func close_panel() -> void:
	panel.visible = false
	selected_npc_id = ""
	selected_npc = null

func _clear_actions() -> void:
	for child in action_box.get_children():
		child.queue_free()

func _refresh_npc() -> void:
	var gs = get_node_or_null("/root/GameState")
	if gs == null:
		return
	var profile: Dictionary = gs.get_social_profile(selected_npc_id)
	var rel: Dictionary = gs.get_social_relationship(selected_npc_id)
	var name = str(profile.get("name", selected_npc_id))
	title_label.text = name
	var activity = "Mahallede"
	if selected_npc != null and is_instance_valid(selected_npc) and selected_npc.has_method("get_current_activity"):
		activity = str(selected_npc.get_current_activity())
	info_label.text = "%s • %s\n%s\nArkadaşlık %d/100 • Güven %d/100 • Yakınlık %d/100\nRuh hâli: %s • Şu an: %s\nSevdiği şey: %s" % [
		gs.get_social_stage_label(selected_npc_id),
		str(profile.get("personality", "sakin")),
		str(profile.get("bio", "Mahalle sakinlerinden biri.")),
		int(round(float(rel.get("friendship", 0.0)))),
		int(round(float(rel.get("trust", 0.0)))),
		int(round(float(rel.get("affection", 0.0)))),
		gs.get_social_mood_label(selected_npc_id),
		activity,
		str(profile.get("favorite_activity", "sohbet"))
	]
	_clear_actions()
	_add_action("SELAM VER", "greet")
	_add_action("SOHBET ET", "chat")
	_add_action("İLTİFAT ET", "compliment")
	_add_action("KAHVEYE DAVET ET", "coffee")
	_add_action("YÜRÜYÜŞE DAVET ET", "walk")
	_add_action("HEDİYE VER", "gift")
	var stage = str(rel.get("stage", "acquaintance"))
	if stage in ["friend", "close_friend", "dating", "partner"]:
		_add_action("EVE UĞRAMAYA DAVET ET", "home_visit")
	if stage == "acquaintance":
		_add_action("ARKADAŞ OLMAYI SOR", "friend")
	elif stage in ["friend", "close_friend"] and bool(profile.get("romance_available", true)):
		_add_action("BULUŞMAYA DAVET ET", "date")
	elif stage == "dating":
		_add_action("İLİŞKİNİZİ KONUŞ", "relationship")
	if float(rel.get("tension", 0.0)) > 0.5:
		_add_action("ÖZÜR DİLE", "apologize")
	var contacts = Button.new()
	contacts.text = "TÜM KİŞİLER"
	contacts.pressed.connect(open_contacts)
	action_box.add_child(contacts)

func _add_action(label_text: String, action: String) -> void:
	var b = Button.new()
	b.text = label_text
	b.pressed.connect(_perform.bind(action))
	action_box.add_child(b)

func _perform(action: String) -> void:
	if selected_npc_id.is_empty():
		return
	var gs = get_node_or_null("/root/GameState")
	if gs == null or not gs.has_method("perform_social_action"):
		return
	var result: Dictionary = gs.perform_social_action(selected_npc_id, action)
	response_label.text = str(result.get("text", ""))
	if action == "home_visit" and bool(result.get("ok", false)) and selected_npc != null and is_instance_valid(selected_npc) and selected_npc.has_method("set_ai_plan"):
		selected_npc.set_ai_plan("home_visit", Vector3(0.0,0.05,10.55), 0.75)
	if selected_npc != null and is_instance_valid(selected_npc) and selected_npc.has_method("react_to_social_result"):
		selected_npc.react_to_social_result(result)
	_refresh_npc_preserve_response()

func _refresh_npc_preserve_response() -> void:
	var response = response_label.text
	_refresh_npc()
	response_label.text = response

func _refresh_contacts() -> void:
	var gs = get_node_or_null("/root/GameState")
	if gs == null:
		return
	title_label.text = "SOSYAL • KİŞİLER"
	info_label.text = gs.get_social_summary() + "\nİlişkiler zamanla ve karşılıklı etkileşimlerle değişir."
	_clear_actions()
	var entries: Array = []
	for npc_id in gs.social_profiles.keys():
		var rel: Dictionary = gs.get_social_relationship(str(npc_id))
		if not bool(rel.get("met", false)):
			continue
		var score = float(rel.get("friendship", 0.0)) + float(rel.get("trust", 0.0)) * 0.7 + float(rel.get("affection", 0.0)) * 0.5
		entries.append({"id": str(npc_id), "score": score})
	entries.sort_custom(func(a, b): return float(a["score"]) > float(b["score"]))
	if entries.is_empty():
		var empty = Label.new()
		empty.text = "Henüz kimseyle tanışmadın. Mahallede isimli karakterlere yaklaş ve USE kullan."
		empty.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
		action_box.add_child(empty)
	else:
		for entry in entries.slice(0, 12):
			var id = str(entry["id"])
			var profile: Dictionary = gs.get_social_profile(id)
			var b = Button.new()
			b.text = "%s • %s" % [str(profile.get("name", id)), gs.get_social_stage_label(id)]
			b.pressed.connect(_open_contact_by_id.bind(id))
			action_box.add_child(b)
	var pending_invites: Array[Dictionary] = gs.get_pending_social_invitations() if gs.has_method("get_pending_social_invitations") else []
	if not pending_invites.is_empty():
		var invite_title = Label.new()
		invite_title.text = "\nDAVETLER"
		invite_title.add_theme_font_size_override("font_size", 18)
		action_box.add_child(invite_title)
		for invite in pending_invites.slice(0, 4):
			var npc_id = str(invite.get("npc_id", ""))
			var profile: Dictionary = gs.get_social_profile(npc_id)
			var row = HBoxContainer.new()
			var label = Label.new()
			label.text = "%s • %s • %02d:%02d" % [str(profile.get("name", npc_id)), str(invite.get("kind", "plan")), int(float(invite.get("hour", 0.0))), int(fmod(float(invite.get("hour", 0.0)), 1.0) * 60.0)]
			label.size_flags_horizontal = Control.SIZE_EXPAND_FILL
			row.add_child(label)
			var accept = Button.new(); accept.text = "KABUL"; accept.pressed.connect(_respond_invitation.bind(str(invite.get("id", "")), true)); row.add_child(accept)
			var decline = Button.new(); decline.text = "SONRA"; decline.pressed.connect(_respond_invitation.bind(str(invite.get("id", "")), false)); row.add_child(decline)
			action_box.add_child(row)

	var feed_title = Label.new()
	feed_title.text = "\nMAHALLE AKIŞI"
	feed_title.add_theme_font_size_override("font_size", 18)
	action_box.add_child(feed_title)
	if gs.social_feed.is_empty():
		var none = Label.new(); none.text = "Mahalle henüz sakin."; action_box.add_child(none)
	else:
		for item in gs.social_feed.slice(0, 8):
			var l = Label.new()
			l.text = "• " + str(item)
			l.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
			action_box.add_child(l)

func _respond_invitation(invitation_id: String, accept: bool) -> void:
	var gs = get_node_or_null("/root/GameState")
	if gs == null or not gs.has_method("respond_social_invitation"):
		return
	var result: Dictionary = gs.respond_social_invitation(invitation_id, accept)
	response_label.text = str(result.get("text", ""))
	_refresh_contacts_preserve_response()

func _refresh_contacts_preserve_response() -> void:
	var response = response_label.text
	_refresh_contacts()
	response_label.text = response

func _open_contact_by_id(npc_id: String) -> void:
	var node = _find_npc(npc_id)
	open_for_npc(npc_id, node)

func _find_npc(npc_id: String) -> Node:
	for node in get_tree().get_nodes_in_group("relationship_npc"):
		if str(node.get("npc_id")) == npc_id:
			return node
	return null
