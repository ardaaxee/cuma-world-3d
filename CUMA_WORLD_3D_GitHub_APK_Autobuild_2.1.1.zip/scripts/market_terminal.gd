extends StaticBody3D

func get_interaction_label() -> String:
	return "Atıştırmalık al (20 TL)"

func interact(player: Node) -> void:
	var gs = get_node_or_null("/root/GameState")
	if gs == null:
		return
	if gs.spend_money(20):
		gs.add_item("snack", 1)
		if player.has_method("show_status"):
			player.show_status("Atıştırmalık alındı • -20 TL")
	else:
		if player.has_method("show_status"):
			player.show_status("Yeterli paran yok")
