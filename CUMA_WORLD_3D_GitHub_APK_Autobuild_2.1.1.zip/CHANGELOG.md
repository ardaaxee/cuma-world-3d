# Changelog

## 2.1.1 — Runtime Material API Hotfix
- Fixed `realism_builder.gd` living-room crash caused by calling `darkened()` on `StandardMaterial3D`.
- Darkening is now applied to the source `Color`, then a new material is created.
- Added a regression test that rejects `darkened()`/`lightened()` calls on variables created by `_mat(...)`.

## 2.1.0 — Production Rebuild
- Added `production_home_builder.gd`.
- Added `production_city_polish.gd`.
- Added 10 production material textures (5 albedo + 5 normal maps).
- Hid legacy block furniture meshes while preserving collision and interactions.
- Rebuilt corridor presentation with door trims, baseboards, runner, art and recessed lighting.
- Rebuilt visible living room, bedroom, kitchen, bathroom, entry and balcony layers.
- Re-skinned the old market/cinema/arcade/cafe/photo-booth shells.
- Hid pair-activity colored cubes/floating marker labels.
- First-person is now the default local camera mode.
- Retuned third-person camera distance/FOV and interaction range.
- Retuned movement speed, run speed, jump and character collider proportions.
- Slimmed the procedural fallback humanoid proportions.
- Reduced HUD/button size and opacity; moved top utility controls to the right.
- Throttled HUD updates to reduce UI work.
- Fixed redundant `_on_run()` control flow in mobile controls.
- Added `production_rebuild_smoke.py` and `parser_compat_21.py`.
- Kept 68 unique co-op activity IDs and all previous major gameplay systems.
