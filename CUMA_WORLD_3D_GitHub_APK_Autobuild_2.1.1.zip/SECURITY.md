# SECURITY.md — CUMA WORLD 3D

## System and Scope
Godot 4 Android-first life-sim with optional LAN/WebSocket relay multiplayer. Security-relevant code includes
`scripts/network_manager.gd`, shared-world interactables, save loading, and dedicated server code.

## Trust Boundaries
- Remote peers and every value received over multiplayer are attacker-controlled.
- Session-code authentication must complete before gameplay RPCs are honored.
- Dedicated relay owns shared world state by default.
- Local player progression such as money, inventory, social relationships, career, **law heat, crime history,
  stolen goods and cyber progression** must not be accepted from another multiplayer peer.

## Crime & Cyber 1.9
The cyber feature is a fictional A/B/C/D node puzzle only. It must not grow into code that scans real hosts,
steals credentials, bypasses authentication, deploys malware, or executes external attack commands.
The theft mechanic is game-state/risk simulation only and must not model real lock/alarm bypass techniques.

## Security Invariants
- No embedded API keys, private keys, relay secrets or credentials.
- Every gameplay `any_peer` RPC requires an authorized peer.
- Remote transforms and vehicle inputs remain bounded and finite.
- Save content is length/count/range bounded before use.
- Player-specific social/law/cyber state remains outside shared snapshots.
- Crime & Justice 1.9 opens no new RPC surface.

## Known limitations
- Godot native engine/runtime verification is still required on a real Android/device or desktop environment.
- Law NPC simulation is local per player rather than authoritative multiplayer state.
