# Character Asset Slots — 0.6

The game always has an animated organic fallback character, so missing external models never block play.

## Production character slots

- `assets/characters/cuma.glb` — local player
- `assets/characters/partner.glb` — remote/partner player

Use rigged, skinned GLB files you have permission to use. The runtime looks for an `AnimationPlayer` and maps common animation names automatically.

Recognized states/aliases:
- Idle: `idle`, `stand`, `breath`, `rest`
- Walk: `walk`, `walking`, `locomotion`
- Run: `run`, `running`, `sprint`, `jog`
- Jump: `jump`, `jumping`, `takeoff`
- Fall: `fall`, `falling`, `air`
- Sit: `sit`, `sitting`, `seat`
- Optional emotes: `wave`, `cheer`, `highfive`

If a GLB exists but has no usable locomotion animations, the game rejects it at runtime and keeps the built-in articulated fallback rather than showing a frozen character.
