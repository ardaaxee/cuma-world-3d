# CUMA WORLD 3D — Automatic Android APK Build

This repository is prepared to build the Android APK without opening the Godot editor.

## What the workflow does

- Uses Godot 4.7.2 stable.
- Uses OpenJDK 17.
- Installs Android API 35 / Build Tools 35.0.1.
- Installs official Godot export templates.
- Generates a temporary debug keystore inside the GitHub runner.
- Runs every Python regression test under `tests/`.
- Opens the project headlessly so Godot itself can catch parser/import failures.
- Exports an ARM64 debug APK.
- Uploads the APK as a GitHub Actions artifact.

## Build output

`build/CUMA_WORLD_3D-debug-arm64.apk`

The GitHub artifact is named:

`CUMA-WORLD-3D-Android-Debug-ARM64`

## Trigger

A build starts on:

- every push to `main` that changes non-Markdown files;
- pull requests to `main`;
- manual **Run workflow** from the Actions tab.

## Security

No release signing key is stored in the repository. The debug keystore is generated inside the temporary GitHub runner. A Play Store release build should later use GitHub encrypted secrets and a private release keystore.
